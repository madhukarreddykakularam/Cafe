package moduledrivers;

import static cbf.engine.TestResultLogger.*;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.Console;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.python.core.exceptions;

import cbf.engine.TestResult.ResultType;
import cbf.utils.DataRow;
import cbf.utils.SleepUtils;
import cbf.utils.SleepUtils.TimeSlab;
import cbfx.basedrivers.BaseWebModuleDriver;

import org.apache.pdfbox.io.RandomAccessRead;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.PDFTextStripperByArea;

//import sun.net.ftp.impl.FtpClient;


import java.io.File;
import java.io.IOException;

public class FilmtrackDriver extends BaseWebModuleDriver {
	
	ArrayList<String> list_InvoiceNumbers = new ArrayList<>();
	ArrayList<String> list_DocumentNumbers = new ArrayList<>();

	/**
	 * Logs Procedure in Application
	 * 
	 * @param input
	 *            DataRow of input parameters
	 * @param output
	 *            empty DataRow passed to capture any runtime output during
	 *            execution of component
	 */

	/****************************************
	 * Name: report 
	 * Description: report 
	 * Date: 11-July-2018
	 ****************************************/
	public void report(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("report");
	}

	/****************************************
	 * Name: askingPrices
	 * Description: askingPrices
	 * Date: 11-July-2018
	 ****************************************/
	public void askingPrices(DataRow input, DataRow output) {

		uiDriver.click("askingprices");
		// Time taken to load Report page(start time)
		passed("Report Page", "Response time of Report Page",
				"Successfully loded the Report Page");

	}


	/****************************************
	 * Name: EditDefaultAllocationPTV
	 * Description: EditDefaultAllocationPTV
	 * Date: 11-July-2018
	 ****************************************/
	public void EditDefaultAllocationPTV(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.click("Editicon");
		SleepUtils.sleep(5);
		String Name = input.get("Name");
		uiDriver.setValue("Name", Name);
		uiDriver.setValue("Note", input.get("Note"));
		uiDriver.click("InvoiceItemCategory");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("InvoiceItemCategoryInput");
		SleepUtils.sleep(TimeSlab.YIELD);
		Boolean Result = uiDriver.webDr.findElement(By.id("TerritoriesCheckbox")).isSelected();
		if (Result.equals(false)) {
			uiDriver.click("Territories");
		} else {
			// do nothing
		}

		Boolean RightResult = uiDriver.webDr.findElement(By.id("RightsCheckbox")).isSelected();
		if (RightResult.equals(false)) {

			uiDriver.click("Rights");
		} else {
			// do nothing
		}
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		// uiDriver.executeJavaScript("document.getElementsByClassName('k-formatted-value k-input')[0].value=100;");
		Actions action = new Actions(uiDriver.webDr);
		WebElement ele = uiDriver.webDr.findElement(By.xpath("//*[@id='allocationWidget']/div/span/span/input[1]"));
		action.sendKeys("ele", "").build().perform();
		action.sendKeys(ele, "100.00").build().perform();
		// uiDriver.click("IncreaseArrow");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("NameChkBox");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.HIGH);
		// SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("NameChkBox");
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		List<WebElement> lis = uiDriver.webDr.findElements(By.xpath("//input[@value='50.00000000']"));
		for(int k=0;k<lis.size();k++)
		{
			WebElement w = lis.get(k);
			w.clear();
			//w.sendKeys("100.00");
			//action.sendKeys(w,"").build().perform();
			//action.sendKeys(w,"0.00").build().perform();
		}
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("NameChkBoxNext");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Finish");
		SleepUtils.sleep(TimeSlab.HIGH);
		output.put("Name", Name);

	}
	
	/****************************************
	 * Name: EditDefaultAllocationFTVCAN
	 * Description: EditDefaultAllocationFTVCAN
	 * Date: 11-July-2018
	 ****************************************/
	public void EditDefaultAllocationCANADA(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.click("Editicon");
		SleepUtils.sleep(5);
		String Name = input.get("Name");
		uiDriver.setValue("Name", Name);
		uiDriver.setValue("Note", input.get("Note"));

		uiDriver.click("InvoiceItemCategory");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("InvoiceItemCategoryInput");
		SleepUtils.sleep(TimeSlab.YIELD);
		Boolean Result = uiDriver.webDr.findElement(By.id("TerritoriesCheckbox")).isSelected();
		if (Result.equals(false)) {

			uiDriver.click("Territories");
		} else {
			// do nothing
		}

		Boolean RightResult = uiDriver.webDr.findElement(
				By.id("RightsCheckbox")).isSelected();
		if (RightResult.equals(false)) {

			uiDriver.click("Rights");
		} else {
			// do nothing
		}
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		Actions action = new Actions(uiDriver.webDr);
		WebElement ele = uiDriver.webDr.findElement(By.xpath("//*[@id='allocationWidget']/div/span/span/input[1]"));
		action.sendKeys("ele", "").build().perform();
		action.sendKeys(ele, "100.00").build().perform();
		SleepUtils.sleep(TimeSlab.MEDIUM);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("NameChkBox");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		List<WebElement> lis = uiDriver.webDr.findElements(By.xpath("(//input[@value='100.00000000'])[2]"));
		for(int k=0;k<lis.size();k++)
		{
			WebElement w = lis.get(k);
			w.click();
			w.clear();
		}
		String Rights = uiDriver.getDyanmicData("NameChkBoxNext");
		String rights1 = Rights.replace("#",input.get("Rights"));
		uiDriver.click(rights1);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Finish");
		SleepUtils.sleep(TimeSlab.YIELD);
		output.put("Name", Name);

	}

	/****************************************
	 * Name: EditDefaultAllocationFTVCAN
	 * Description: EditDefaultAllocationFTVCAN
	 * Date: 11-July-2018
	 ****************************************/
	public void EditDefault1AllocationCANADA(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.click("Editicon");
		SleepUtils.sleep(5);
		String Name = input.get("Name");
		uiDriver.setValue("Name", Name);
		uiDriver.setValue("Note", input.get("Note"));

		uiDriver.click("InvoiceItemCategory");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("InvoiceItemCategoryInput");
		SleepUtils.sleep(TimeSlab.YIELD);
		Boolean Result = uiDriver.webDr.findElement(By.id("TerritoriesCheckbox")).isSelected();
		if (Result.equals(false)) {

			uiDriver.click("Territories");
		} else {
			// do nothing
		}

		Boolean RightResult = uiDriver.webDr.findElement(By.id("RightsCheckbox")).isSelected();
		if (RightResult.equals(false)) {

			uiDriver.click("Rights");
		} else {
			// do nothing
		}
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		// uiDriver.executeJavaScript("document.getElementsByClassName('k-formatted-value k-input')[0].value=100;");
		Actions action = new Actions(uiDriver.webDr);
		WebElement ele = uiDriver.webDr.findElement(By.xpath("//*[@id='allocationWidget']/div/span/span/input[1]"));
		action.sendKeys("ele", "").build().perform();
		action.sendKeys(ele, "100.00").build().perform();
		SleepUtils.sleep(TimeSlab.MEDIUM);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("NameChkBox");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		// SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("NameChkBox");
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		for(int d=1;d<=3;d++)
		{
		String amount1=uiDriver.getDyanmicData("amount1");
		String amount=amount1.replace("#",Integer.toString(d));
		uiDriver.click_dynamic(amount);
		WebElement w = uiDriver.webDr.findElement(By.xpath(amount));
		w.clear();
		SleepUtils.sleep(TimeSlab.MEDIUM);
	}
		String Rights = uiDriver.getDyanmicData("NameChkBoxNext");
		String rights1 = Rights.replace("#",input.get("Rights"));
		uiDriver.click(rights1);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Finish");
		SleepUtils.sleep(TimeSlab.YIELD);
		output.put("Name", Name);

	}

	

	/****************************************
	 * Name: updateContractName
	 * Description: updateContractName
	 * Date: 11-July-2018
	 ****************************************/
	public void updateContractName(DataRow input, DataRow output)
			throws InterruptedException {

		String originalname = uiDriver.getValue("contractfield");
		String contractidwithoutrevision = (originalname.split("-"))[0];
		String revision = (originalname.split("-"))[1];
		String newname=contractidwithoutrevision+"EE"+input.get("name")+"-"+revision;
		uiDriver.setValue("contractfield", newname);
		String NetSuitename=contractidwithoutrevision+"EE"+input.get("name")+"A";
		String InvoiceName=contractidwithoutrevision+"EE"+input.get("name");
		uiDriver.click("Save");
		output.put("updatedName", newname);
		output.put("SalesOrderNum", NetSuitename);
		output.put("InvoiceName", InvoiceName);
	
}
/****************************************
 * Name: ChangeRoleToAdminUAT
 * Description: Changing the role from administrator 10K to administrator UAT
 * Date: 30-Nov-2017
 ****************************************/
public void ChangeRoleToAdminUAT(DataRow input, DataRow output)
{
	SleepUtils.sleep(10);
	uiDriver.mouseOver("Profile");
	SleepUtils.sleep(5);
	uiDriver.click("AdminUAT");
	SleepUtils.sleep(5);
	if(uiDriver.checkElementPresent("AdminUAT")){
	//uiDriver.click("Manager1");
			passed("Verify Changing the role from administrator 10K to administrator UAT",
			"administrator 10K to administrator UAT Role must be changed Successfully",
			"administrator 10K to administrator UAT Role is changed Successfully");
	SleepUtils.sleep(5);
	}

	}


/****************************************
* Name: Verifytaxcodeforinvoices
* Description: Verifytaxcodeforinvoices
* Date: 30-Nov-2017
****************************************/
public void Verifytaxcodeforinvoices(DataRow input, DataRow output)
{
	uiDriver.click("relatedrecord");
	SleepUtils.sleep(5);
	List<WebElement> invoicerow = uiDriver.webDr.findElements(By.xpath("//td[text()='Invoice']/.."));
	for(int row=1;row<=invoicerow.size();row++)
	{
		uiDriver.click("relatedrecord");
		String invoice=uiDriver.getDyanmicData("invoicelink");
		String invoice1=invoice.replace("#", Integer.toString(row));
		uiDriver.click(invoice1);
		SleepUtils.sleep(5);
		List<WebElement> irow = uiDriver.webDr.findElements(By.xpath("//*[@id='item_splits']/tbody/tr[contains(@class,'uir-machine-row uir-machine-row')]"));
		for(int invrow=1;invrow<=irow.size();invrow++)
		{
			String taxcode=uiDriver.getDyanmicData("taxcode");
			String taxcode1=taxcode.replace("#", Integer.toString(2)); //Hard coded for scenario17
			String taxcodevalue = uiDriver.getValue(taxcode1);
			String exptaxcode=input.get("taxcode");
			if(taxcodevalue.contains(input.get("taxcode")))
			{
				passed("Verify tax code for invoice lines",
						"Tax code should be"+exptaxcode,
						"Tax code is "+taxcodevalue);
			}
			else
			{
				failed("Verify tax code for invoice lines",
						"Tax code should be"+exptaxcode,
						"Tax code is not "+exptaxcode);
			}
		}
		uiDriver.back();
		
	}

	}

	
	/****************************************
	 * Name: assignAllocations
	 * Description: assignAllocations
	 * Date: 11-July-2018
	 ****************************************/
	public void assignAllocations(DataRow input, DataRow output)
			throws InterruptedException {
		uiDriver.click("allocations");
		SleepUtils.sleep(TimeSlab.YIELD);
		String numofbillschedules = input.get("numbill");
		int num = Integer.parseInt(numofbillschedules);
		for (int i = 1; i <= num; i++) {
			uiDriver.click("recalculate");
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("next");
			SleepUtils.sleep(TimeSlab.YIELD);
			SleepUtils.sleep(TimeSlab.HIGH);
		}

	}
	/****************************************
	 * Name: Readpayment Description: Readpayment Date: 06-Dec-2018
	 ****************************************/
	public void Readpayment(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.click("custom");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.executeJavaScript("scroll(0,1000)");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("tapinvoice");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("payment");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String paymentnum=uiDriver.getValue("paymentvalue");
		output.put("paymentvalue",paymentnum);
	}
	
	/****************************************
	 * Name: revRecJournalEntry10K 
	 * Description: revRecJournalEntry
	 * Date:30-Nov-2017
	 ****************************************/
	public void revRecJournalEntry10K(DataRow input, DataRow output)
			throws ParseException {

		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.mouseOver("transactions");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("financial");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("revrecjournal");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("runNow");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("customerdropdownimage");
		uiDriver.handleAlert("", "OK");
		SleepUtils.sleep(5);
		uiDriver.click("customerlist");
		SleepUtils.sleep(5);
		uiDriver.setValue("searchcustomerinput", input.get("revreccustomer"));
		SleepUtils.sleep(5);
		uiDriver.click("searchcustomerbutton");
		SleepUtils.sleep(5);
		uiDriver.click("cussearchresult");
		SleepUtils.sleep(TimeSlab.LOW);
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("postingperiod");
		uiDriver.setValue("postingperiod", input.get("posting"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("postingperiod");
		uiDriver.click("deliveryDate");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("deliveryDate", input.get("delivery"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Subsidiary");
		uiDriver.setValue("Subsidiary", input.get("Subsidiary"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Subsidiary");
		SleepUtils.sleep(TimeSlab.LOW);
		try{
			if(uiDriver.webDr.findElement(By.xpath("//span[@id='includepriorperiods_fs' and @class='checkbox_ck']//input")).isDisplayed()) {			
			} else {
				uiDriver.webDr.findElement(By.xpath("//span[@id='includepriorperiods_fs' and @class='checkbox_ck']//input")).click();
			}
		} catch(Exception e1) {
			try {
				if(uiDriver.webDr.findElement(By.xpath("//span[@id='includepriorperiods_fs' and @class='checkbox_ck']")).isDisplayed()) {			
				} else {
					uiDriver.webDr.findElement(By.xpath("//span[@id='includepriorperiods_fs' and @class='checkbox_ck']")).click();
				}
			} catch(Exception e2) {				
			}
		}
		SleepUtils.sleep(TimeSlab.LOW);
		String revreclist = uiDriver.getDyanmicData("revreclist");
		String revenuenum = input.get("revenuenum");
		String revrecchklist = revreclist.replace("#", revenuenum);

		if (uiDriver.checkElementPresent_dynamic(revrecchklist)) {
			List<WebElement> ele = uiDriver.webDr.findElements(By.xpath(revrecchklist));
			int rowSize = ele.size();
			for (int i = 0; i < rowSize; i++) {

				SleepUtils.sleep(TimeSlab.LOW);

				ele.get(i).click();
			}
		} else {
			uiDriver.click("pagefilterdropdown");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("secondfilter");
			if (uiDriver.checkElementPresent_dynamic(revrecchklist)) {
				List<WebElement> ele = uiDriver.webDr.findElements(By.xpath(revrecchklist));
				int rowSize = ele.size();
				for (int i = 0; i < rowSize; i++) {

					SleepUtils.sleep(TimeSlab.LOW);

					ele.get(i).click();
				}
			} else {
				uiDriver.click("pagefilterdropdown");

				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.click("thirdfilter");
				if (uiDriver.checkElementPresent_dynamic(revrecchklist)) {
					List<WebElement> ele = uiDriver.webDr.findElements(By.xpath(revrecchklist));
					int rowSize = ele.size();
					for (int i = 0; i < rowSize; i++) {

						SleepUtils.sleep(TimeSlab.LOW);

						ele.get(i).click();
					}
				} else {
					uiDriver.click("pagefilterdropdown");

					SleepUtils.sleep(TimeSlab.LOW);
					uiDriver.click("fourthfilter");
					if (uiDriver.checkElementPresent_dynamic(revrecchklist)) {
						List<WebElement> ele = uiDriver.webDr.findElements(By.xpath(revrecchklist));
						int rowSize = ele.size();
						for (int i = 0; i < rowSize; i++) {

							SleepUtils.sleep(TimeSlab.LOW);

							ele.get(i).click();
						}
					}

				}
			}
		}
		uiDriver.executeJavaScript("scroll(0,-1000)");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("createjournalentries");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();

		Date date = new Date();
		DateFormat dateFormat = new SimpleDateFormat("h:mm");
		String strDate = dateFormat.format(date);
		Date d = dateFormat.parse(strDate);
		Calendar cal = Calendar.getInstance();
		cal.setTime(d);
		cal.add(Calendar.MINUTE, -1);
		String newTime = dateFormat.format(cal.getTime());
		String Complete = uiDriver.getDyanmicData("CompleteStatus1");
		String CompleteStaus = Complete.replace("#", newTime);
		cal.add(Calendar.MINUTE, 0);
		String newTime2 = dateFormat.format(cal.getTime());
		String Complete2 = uiDriver.getDyanmicData("CompleteStatus2");
		String CompleteStaus2 = Complete2.replace("#", newTime2);
		cal.add(Calendar.MINUTE, 1);
		String newTime3 = dateFormat.format(cal.getTime());
		String Complete3 = uiDriver.getDyanmicData("CompleteStatus3");
		String CompleteStaus3 = Complete3.replace("#", newTime3);
		if (uiDriver.checkElementPresent_dynamic(CompleteStaus)) {
			uiDriver.click_dynamic(CompleteStaus);
		} else {
			// do nothing
		}

		if (uiDriver.checkElementPresent_dynamic(CompleteStaus2)) {
			uiDriver.click_dynamic(CompleteStaus2);
		} else {
			// do nothing
		}
		if (uiDriver.checkElementPresent_dynamic(CompleteStaus3)) {
			uiDriver.click_dynamic(CompleteStaus3);
		} else {
			// do nothing
		}

		passed("Verify Processed Revenue recognition Journal entries",
				"Processed Revenue recognition Journal entries page should be displayed",
				"Processed Revenue recognition Journal entries page is displayed");

		if (uiDriver.checkElementPresent("completesubmissionstatus")) {
			uiDriver.click("completesubmissionstatus");

		} else {
			// do nothing
		}

		
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Journal");
		uiDriver.executeJavaScript("(scroll(0,500));");
		int invoiceRow = 2;
		int accRows = uiDriver.webDr.findElements(By.xpath("//*[@id='line_splits']/tbody/tr")).size();
		for (i = 0; i < accRows - 1; i++) {
			String creditamount = uiDriver.getValue("creditamount");
			String debitamount = uiDriver.getValue("debitamount");
			if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Deferred Rev - Unpaid"))

			{
				if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[2]").equals("")) {
					failed("Validating Credit Amount",
							"Validating Credit Amount should be successfull",
							"Credit amount is not Deferred Rev - Generic");
				} else {
					passed("Credit is Deferred Rev - Generic " + creditamount
							+ "", "Credit is Deferred Rev - Generic "
							+ creditamount + "",
							"Credit amount is Deferred Rev - Generic "
									+ creditamount + "");
				}
			}
			if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("GAAP contract revenue"))

			{
				if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals("")) {
					failed("Validating Debit Amount",
							"Validating Debit Amount should be successfull",
							"Debit amount is not GAAP contract revenue");
				} else {
					passed("Debit is Deferred Rev - Generic " + debitamount
							+ "", "Debit is Deferred Rev - Generic "
							+ debitamount + "",
							"Debit amount is GAAP contract revenue "
									+ debitamount + "");
				}
			}

			invoiceRow++;
		}
	}

	
	/****************************************
	 * Name: NaviagteToBillingSchedule 
	 * Description: NaviagteToBillingSchedule
	 * Date: 26-March-2019
	 ****************************************/
	public void NavigateToBillingSchedule(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billing");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billingschedules");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		
		if(uiDriver.checkElementPresent("//span[contains(text(),'Billing Schedules')]")) {
			passed("Navigation to Billing Schedule Screen",
					"Billing Schedule Screen Should be displayed",
					"Billing Schedule Screen is displayed");
		} else {
			failed("Display of Billing Schedule Screen",
					"Billing Schedule Screen Should be displayed",
					"Billing Schedule Screen is not displayed");
		}
		
		/*
		int accRows = uiDriver.webDr.findElements(By.xpath("//*[@id='contract-billing-schedules-grid']/div[3]/table/tbody/tr")).size();
		
		if (accRows >= 1) {
			passed("Billing Schedule displayed",
					"B illing Schedule Should be displayed",
					"Billing Schedule is displayed");
		} else {
			failed("Billing Schedule not displayed",
					"Billing Schedule Should be displayed",
					"Billing Schedule is not displayed");
		}
		String actualproject = uiDriver.getValue("project");
		String actualamount = uiDriver.getValue("Amount");
		String actualduedate = uiDriver.getValue("DueDate");
		if (input.get("projects").contains(actualproject)|| actualproject.contains(input.get("projects"))) {
			passed("Validating Project",
					"Project Should be displayed as '"+ input.get("projects") + "' successfully",
					"Project is  displayed as '" + actualproject+ "' successfully");
		} else {
			failed("Validating Project",
					"Project Flag Should be displayed as '"	+ input.get("projects") + "' successfully",
					"Project Flag is  not displayed as '" + actualproject+ "' successfully");
		}

		if (input.get("Amount").contains(actualamount)) {
			passed("Validating Amount", 
					"Amount Should be displayed as '"+ input.get("Amount") + "' successfully",
					"Amount is  displayed as '" + actualamount+ "' successfully");
		} else {
			failed("Validating Amount",
					"Amount Should be displayed as '"+ input.get("Amount") + "' successfully",
					"Amount is  not displayed as '" + actualamount+ "' successfully");
		}
		if (input.get("DueDate").contains(actualduedate)) {
			passed("Validating Due Date", 
					"Due Date Should be displayed as '"	+ input.get("DueDate") + "' successfully",
					"Due Date is  displayed as '" + actualduedate+ "' successfully");
		} else {
			failed("Validating Due Date",
					"Due Date Should be displayed as '"+ input.get("DueDate") + "' successfully",
					"Due Date is  displayed as '" + actualduedate+ "' successfully");
		}
		*/
	}
	
	/****************************************

     * Name: RefireDatetrigger Description: RefireDatetrigger

     * Date: 3-July-2019

     ****************************************/

     public void RefireDatetrigger(DataRow input, DataRow output) {

           uiDriver.click("//div[@id='ft-context-nav']//li/a[contains(text(),'Finance')]");

           SleepUtils.sleep(TimeSlab.LOW);

           uiDriver.click("//a[text()='Billing']");

           SleepUtils.sleep(TimeSlab.LOW);

           uiDriver.click("//a[text()='Billing Schedules']");

           SleepUtils.sleep(TimeSlab.HIGH);

           uiDriver.click("//a[contains(text(),'Re-Fire Date Triggers')]");

           SleepUtils.sleep(TimeSlab.LOW);
           passed("Refire Date trigger",

                   "refire date trigger should be clicked successfully",

                   "refire date trigger successfully clicked");

     }
	
	/****************************************
	 * Name: AddEventtoBillingSchedule 
	 * Description: AddEventtoBillingSchedule
	 * Date: 18-February-2020
	 ****************************************/
	public void AddEventtoBillingSchedule(DataRow input, DataRow output) {
		String installment=input.get("installment");
		uiDriver.click("//*[contains(text(),'"+installment+"')]/../..//a[@class='date-trigger-icon none']");
		SleepUtils.sleep(TimeSlab.LOW);		
		uiDriver.setFrame("//iframe[contains(@src,'DueDate')]");
		SleepUtils.sleep(TimeSlab.LOW);
		while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
			SleepUtils.sleep(TimeSlab.YIELD);
		}
		uiDriver.click("//*[@id='dt-control-wrap']/div[1]/div[2]/span/span");
		SleepUtils.sleep(2);
		uiDriver.click("//li[text()='"+input.get("eventsource")+"']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//*[@id='calculation-params']/div/div[1]/div[2]/div/span[2]/span/input[1]");
		SleepUtils.sleep(TimeSlab.LOW);
        uiDriver.webDr.findElement(By.xpath("//input[@id='requiredByKendo']")).sendKeys(Keys.BACK_SPACE);
		String days=input.get("days");
		uiDriver.setValue("//*[@id='requiredByKendo']", days);
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//*[@id='calculation-params']/div/div[2]/div[2]/span/span");
		SleepUtils.sleep(TimeSlab.LOW);
		String specificday=input.get("specificday");
		uiDriver.click("//li[text()='"+specificday+"']");
		SleepUtils.sleep(TimeSlab.LOW);
        uiDriver.click("//button[text()='Save']");
        SleepUtils.sleep(TimeSlab.HIGH);
        uiDriver.resetFrame();
        SleepUtils.sleep(TimeSlab.HIGH);
        SleepUtils.sleep(TimeSlab.HIGH);
        SleepUtils.sleep(TimeSlab.HIGH);
        passed("Date triggers", "Date should be triggers",
                  "Date is triggered");
  

		
		
	}
	
	
	/****************************************
	 * Name: VerifyBillingSchedule 
	 * Description: VerifyBillingSchedule
	 * Date: 26-March-2019
	 ****************************************/
	public void VerifyBillingSchedule(DataRow input, DataRow output) {
		
		String Display_Schedule = input.get("Schedule");
		int accRows = uiDriver.webDr.findElements(By.xpath("//*[@id='contract-billing-schedules-grid']/div[3]/table/tbody/tr")).size();
		switch(Display_Schedule.toLowerCase()) {
		case "no" :
			if (accRows == 0) {
				passed("Billing Schedule Display",
						"There should be no billing schedule",
						"Billing Schedule is not displayed");
			} else {
				failed("Billing Schedule Display",
						"There should be no billing schedule",
						"Billing Schedule is displayed");
			}
			break;
			
		case "yes" :
			if (accRows >= 1) {
				passed("Billing Schedule displayed",
						"B illing Schedule Should be displayed",
						"Billing Schedule is displayed");
			} else {
				failed("Billing Schedule not displayed",
						"Billing Schedule Should be displayed",
						"Billing Schedule is not displayed");
			}
			String actualproject = uiDriver.getValue("project");
			String actualamount = uiDriver.getValue("Amount");
			String actualduedate = uiDriver.getValue("DueDate");
			if (input.get("projects").contains(actualproject)|| actualproject.contains(input.get("projects"))) {
				passed("Validating Project",
						"Project Should be displayed as '"+ input.get("projects") + "' successfully",
						"Project is  displayed as '" + actualproject+ "' successfully");
			} else {
				failed("Validating Project",
						"Project Flag Should be displayed as '"	+ input.get("projects") + "' successfully",
						"Project Flag is  not displayed as '" + actualproject+ "' successfully");
			}

			if (input.get("Amount").contains(actualamount)) {
				passed("Validating Amount", 
						"Amount Should be displayed as '"+ input.get("Amount") + "' successfully",
						"Amount is  displayed as '" + actualamount+ "' successfully");
			} else {
				failed("Validating Amount",
						"Amount Should be displayed as '"+ input.get("Amount") + "' successfully",
						"Amount is  not displayed as '" + actualamount+ "' successfully");
			}
			if (input.get("DueDate").contains(actualduedate)) {
				passed("Validating Due Date", 
						"Due Date Should be displayed as '"	+ input.get("DueDate") + "' successfully",
						"Due Date is  displayed as '" + actualduedate+ "' successfully");
			} else {
				failed("Validating Due Date",
						"Due Date Should be displayed as '"+ input.get("DueDate") + "' successfully",
						"Due Date is  displayed as '" + actualduedate+ "' successfully");
			}
			break;
			
		default :
			if (accRows == 0) {
				passed("Billing Schedule Display",
						"There should be no billing schedule",
						"Billing Schedule is not displayed");
			} else {
				failed("Billing Schedule Display",
						"There should be no billing schedule",
						"Billing Schedule is displayed");
			}
			break;
		}
		
	}
	
	/****************************************
	 * Name: NavigateToBillingGroups 
	 * Description: NaviagteToBillingSchedule
	 * Date: 26-March-2019
	 ****************************************/
	public void NavigateToBillingGroups(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billing");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("BillingGroups");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		if(uiDriver.checkElementPresent("//span[contains(text(),'Billing Groups')]")) {
			passed("Navigation to Billing Groups Screen",
					"Billing Groups Screen Should be displayed",
					"Billing Groups Screen is displayed");
		} else {
			failed("Display of Billing Groups Screen",
					"Billing Groups Screen Should be displayed",
					"Billing Groups Screen is not displayed");
		}
	}
	
	/****************************************
	 * Name: CreateBillingGroups 
	 * Description: CreateBillingGroups
	 * Date: 26-March-2019
	 ****************************************/
	public void CreateBillingGroups(DataRow input, DataRow output) {
		if(uiDriver.checkElementPresent("//*[text()=' Edit']")) {
			uiDriver.click("//*[text()=' Edit']");
		} else {
			uiDriver.click("button_AddNewRecord");
		}
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.setValue("textfield_Name", input.get("Name"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("dropdown_RevRecMethod");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//li[contains(text(),'"+input.get("RevRecMethod")+"')]");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("textfield_StartDate", input.get("StartDate"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("textfield_EndDate", input.get("EndDate"));
		SleepUtils.sleep(TimeSlab.LOW);
//		uiDriver.setValue("textfield_SequenceNumber", input.get("SequenceNumber"));
//		SleepUtils.sleep(TimeSlab.LOW);
		if(input.get("ApplyCrossCollateralization").trim().toLowerCase().equals("yes")) {			
			uiDriver.click("checkbox_ApplyCrossCollateralization");
			SleepUtils.sleep(TimeSlab.LOW);
		}
		if(input.get("ConsumeUnbilledAdvances").trim().toLowerCase().equals("yes")) {			
			uiDriver.click("checkbox_ConsumeUnbilledAdvances");
			SleepUtils.sleep(TimeSlab.LOW);
		}
		uiDriver.click("button_Save");
//		SleepUtils.sleep(TimeSlab.LOW);
		
		if(uiDriver.checkElementPresent("//*[contains(text(),'Save Successful')]")) {
			passed("Create Billing Groups",
					"Billing Group Creation should be successful",
					"Billing Group Creation is successful");
		} else {
			failed("Create Billing Groups",
					"Billing Group Creation should be successful",
					"Billing Group Creation is not successful");
		}
	}
	
	
	/****************************************
	 * Name: EditBillingGroups 
	 * Description: EditBillingGroups
	 * Date: 22-April-2019
	 ****************************************/
	public void EditBillingGroups(DataRow input, DataRow output) {
		
		SleepUtils.sleep(TimeSlab.LOW);
		String xpath_BillingGroup = "//td[text()='##']//..//td//a[contains(text(),'Edit')]";
		String BillingGroup = input.get("BillingGroup");
		xpath_BillingGroup = xpath_BillingGroup.replace("##", BillingGroup);
		uiDriver.click(xpath_BillingGroup);
		SleepUtils.sleep(TimeSlab.LOW);
		
		uiDriver.setValue("textfield_Name", input.get("Name"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("dropdown_RevRecMethod");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//li[contains(text(),'"+input.get("RevRecMethod")+"')]");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("textfield_StartDate", input.get("StartDate"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("textfield_EndDate", input.get("EndDate"));
		SleepUtils.sleep(TimeSlab.LOW);
//		uiDriver.setValue("textfield_SequenceNumber", input.get("SequenceNumber"));
//		SleepUtils.sleep(TimeSlab.LOW);
		if(input.get("ApplyCrossCollateralization").trim().toLowerCase().equals("yes")) {			
			uiDriver.click("checkbox_ApplyCrossCollateralization");
			SleepUtils.sleep(TimeSlab.LOW);
		}
		if(input.get("ConsumeUnbilledAdvances").trim().toLowerCase().equals("yes")) {			
			uiDriver.click("checkbox_ConsumeUnbilledAdvances");
			SleepUtils.sleep(TimeSlab.LOW);
		}
		uiDriver.click("button_Save");
//		SleepUtils.sleep(TimeSlab.LOW);
		
		if(uiDriver.checkElementPresent("//*[contains(text(),'Save Successful')]")) {
			passed("Edit Billing Groups",
					"Billing Group Editing should be successful",
					"Billing Group Editing is successful");
		} else {
			failed("Edit Billing Groups",
					"Billing Group Editing should be successful",
					"Billing Group Editing is not successful");
		}
	}
	
	/****************************************
	 * Name: DeleteBillingGroups 
	 * Description: DeleteBillingGroups
	 * Date: 22-April-2019
	 ****************************************/
	public void DeleteBillingGroups(DataRow input, DataRow output) {
		
		SleepUtils.sleep(TimeSlab.LOW);
		String xpath_BillingGroup = "//td[text()='##']//..//td//a[contains(text(),'Delete')]";
		String BillingGroup = input.get("BillingGroup");
		xpath_BillingGroup = xpath_BillingGroup.replace("##", BillingGroup);
		uiDriver.click(xpath_BillingGroup);
		SleepUtils.sleep(TimeSlab.LOW);
		
		uiDriver.handleAlert("", "OK");
		if(uiDriver.checkElementPresent("//*[contains(text(),'Delete Successful')]")) {
			passed("Delete Billing Groups",
					"Billing Group Deletion should be successful",
					"Billing Group Deletion is successful");
		} else {
			failed("Delete Billing Groups",
					"Billing Group Deletion should be successful",
					"Billing Group Deletion is not successful");
		}
	}

	/****************************************
	 * Name: Applycash 
	 * Description: Applycash 
	 * Date: 19-July-2018
	 ****************************************/
	

		
		public void Applycash(DataRow input, DataRow output) {

			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.mouseOver("transactions");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.mouseOver("financial");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("makejournalentry");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Subsidiary");
			uiDriver.setValue("Subsidiary", input.get("Subsidiary"));
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("Subsidiary");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("invoicedropdownimage");
			uiDriver.handleAlert("", "OK");
			SleepUtils.sleep(5);
			uiDriver.click("invoicelist");
			SleepUtils.sleep(5);
			String invoice = "Invoice #" + input.get("Invoicenum");
			uiDriver.setValue("searchinvoiceinput", invoice);
			SleepUtils.sleep(5);
			uiDriver.click("searchinvoicebutton");
			SleepUtils.sleep(5);
			uiDriver.click("invsearchresult");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.executeJavaScript("scroll(0,1200)");
			uiDriver.click("accountdebit");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.setValue("editdebitaccount", input.get("debit"));
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("selecteddebit");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("debit");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.setValue("editdebit", input.get("debitamount"));
			SleepUtils.sleep(TimeSlab.LOW);
			WebElement w = uiDriver.webDr.findElement(By.xpath("//*[@id='line_splits']/tbody/tr[2]/td[5]/div"));
			JavascriptExecutor j=(JavascriptExecutor)uiDriver.webDr;
			j.executeScript("arguments[0].click();",w);
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("custdropdownimage");
			uiDriver.handleAlert("", "OK");
			SleepUtils.sleep(5);
			uiDriver.click("custlist");
			SleepUtils.sleep(5);

			uiDriver.setValue("searchcustinput", input.get("custedit"));
			SleepUtils.sleep(5);
			uiDriver.click("searchcustbutton");
			SleepUtils.sleep(5);
			uiDriver.click("custsearchresult");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.executeJavaScript("document.getElementById('line_addedit').click();");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.setValue("editcreditaccount", input.get("credit"));
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("credit");
			uiDriver.click("credit");
			SleepUtils.sleep(TimeSlab.LOW);
			WebElement w1 = uiDriver.webDr.findElement(By.xpath("//*[@id='line_splits']/tbody/tr[3]/td[5]/div"));
			JavascriptExecutor j1=(JavascriptExecutor)uiDriver.webDr;
			j1.executeScript("arguments[0].click();",w1);
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("custdropdownimage");
			uiDriver.handleAlert("", "OK");
			SleepUtils.sleep(5);
			uiDriver.click("custlist");
			SleepUtils.sleep(5);

			uiDriver.setValue("searchcustinput", input.get("custedit"));
			SleepUtils.sleep(5);
			uiDriver.click("searchcustbutton");
			SleepUtils.sleep(5);
			uiDriver.click("custsearchresult");
			uiDriver.setValue("JEtype", "Intercompany AR Clearing");
			uiDriver.click("Save");
			// uiDriver.executeJavaScript("document.getElementById('secondarysubmitter').click();");
			SleepUtils.sleep(TimeSlab.HIGH);
			String journalnum = uiDriver.getValue("JournalNumber");
			passed("Verifying Journal is created",
					"Journal should be  created", "Journal is  created");
		
			output.put("JournalId", journalnum);
		}
			
	
		

	/****************************************
	 * Name: updateRevenueArreangemet
	 * Description:updateRevenueArreangement10K
	 * Date: 30-Nov-2017
	 ****************************************/
	public void updateRevenueArreangement10K(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.LOW);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("transactions");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("financial");
		SleepUtils.sleep(TimeSlab.YIELD);

		uiDriver.click("updateRevenueArrangement");
		SleepUtils.sleep(TimeSlab.YIELD);
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
	    String s = formatter.format(date);
	    System.out.println(s);
	    uiDriver.setValue("sourcedate", s);
		uiDriver.click("updateRevenueArrBtn");
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		 uiDriver.setValue("sourcedate", s);
		uiDriver.click("updateRevenuePlanBtn");
		uiDriver.executeJavaScript("scroll(0,-1000)");
		uiDriver.click("refreshBtn");
		// uiDriver.click("updaterevenuplan");
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		uiDriver.click("refreshBtn");
		// uiDriver.click("updaterevenuplan");
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
	}

	/****************************************
	 * Name: ApproveJournal 
	 * Description:Method to ApproveJournal
	 * Date: 14-Aug-2018
	 ****************************************/
	public void ApproveJournal(DataRow input, DataRow output) {

		String Num = input.get("journ");
		uiDriver.setValue("SearchJournal", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Journal");
		SleepUtils.sleep(TimeSlab.HIGH);
		// uiDriver.click("Approved");
		WebElement w = uiDriver.webDr.findElement(By.xpath("(//input[@value='Approve'])[1]"));
		String id = w.getAttribute("id");
		uiDriver.executeJavaScript("document.getElementById('"+id+"').click();");
		SleepUtils.sleep(TimeSlab.HIGH);
		if (uiDriver.checkElementPresent("Approve")) {
			passed("Verifying Journal is approved",
					"Journal should be  approved",
					"Journal is  approved");
		}
	}
	
	
	/****************************************
	 * Name: Verifyrevisedamount
	 * Description:Method to ApproveJournal
	 * Date: 14-Aug-2018
	 ****************************************/
	public void Verifyrevisedamount(DataRow input, DataRow output) {

		String amount=uiDriver.getValue("amount");
		String expamount=input.get("amount");
		if(amount.equalsIgnoreCase(expamount))
		{
			passed("Verifying amount",
					"Amount should be"+expamount+"", 
					"Amount is"+amount+"");
		}
		else
		{

			failed("Verifying amount",
					"Amount should be"+expamount+"",
					"Amount is not"+expamount+"");
		
		}
		}
	
	/****************************************
	 * Name: confirmallocationBAS
	 * Description:Method to confirm allocations
	 * Date: 18-Nov-2018
	 ****************************************/
	public void confirmallocationBAS(DataRow input, DataRow output) {

		uiDriver.click("editbutton");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("next");
		SleepUtils.sleep(TimeSlab.HIGH);
		String percent=uiDriver.getValue("Territories");
		if(percent.startsWith("100.00"))
		{
			passed("Verifying allocation for territory",
					"territory allocation should be"+percent+"",
					"territory allocation is"+percent+"");
		}
		else
		{
			failed("Verifying allocation for territory",
					"territory allocation should be"+percent+"",
					"territory allocation is not "+percent+"");
		}
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("next");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		String BASallocation=uiDriver.getValue("basiccable");
		if(BASallocation.startsWith("100.00"))
		{
			passed("Verifying allocation for territory",
					"territory allocation should be"+BASallocation+"", 
					"territory allocation is"+BASallocation+"");
		}
		else
		{
			failed("Verifying allocation for territory",
					"territory allocation should be"+BASallocation+"",
					"territory allocation is not "+BASallocation+"");
		}
		
		uiDriver.click("finish");
		SleepUtils.sleep(TimeSlab.HIGH);
		}
	
	
	/****************************************
	 * Name: confirmallocationFTV
	 * Description:Method to confirm allocations
	 * Date: 18-Nov-2018
	 ****************************************/
	public void confirmallocationFTV(DataRow input, DataRow output) {

		uiDriver.click("editbutton");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("next");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.YIELD);
		String percent=uiDriver.getValue("Territories");
		if(percent.startsWith("100.00"))
		{
			passed("Verifying allocation for territory",
					"territory allocation should be"+percent+"",
					"territory allocation is"+percent+"");
		}
		else
		{
			passed("Verifying allocation for territory",
					"territory allocation should be"+percent+"", 
					"territory allocation is not "+percent+"");
		}
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("next");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.YIELD);
		String ftvallocation=uiDriver.getValue("ftv");
		if(ftvallocation.startsWith("100.00"))
		{
			passed("Verifying allocation for territory",
					"territory allocation should be"+ftvallocation+"",
					"territory allocation is"+ftvallocation+"");
		}
		else
		{
			failed("Verifying allocation for territory",
					"territory allocation should be"+ftvallocation+"", 
					"territory allocation is not "+ftvallocation+"");
		}
		
		uiDriver.click("finish");
		SleepUtils.sleep(TimeSlab.HIGH);
		}
	/****************************************
	 * Name: VerifyInvoiceStatus
	 * Description:Method to VerifyInvoiceStatus 
	 * Date: 14-Aug-2018
	 ****************************************/
	public void VerifyInvoiceStatus(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);
		String Status = uiDriver.getValue("Status");
		
		if (Status.equalsIgnoreCase(input.get("Status"))) {

			passed("Verifying the  Invoice Status",
					"Invoice Status should be displayed as '"+ input.get("Status") + "' Successfully",
					"Invoice Status " + Status + " is displayed Successfully");
		} else {
			failed("Verifying the  Invoice Status",
					"Invoice Status should be displayed as '"+ input.get("Status") + "' Successfully",
					"Invoice Status " + Status+ " is not displayed Successfully");
		}
	}
		
	public void verifyinvoicetype(DataRow input, DataRow output) {
		String invoicetype=uiDriver.getValue_Text("//*[@id='custbody_nbcu_inv_type_fs_lbl_uir_label']/following-sibling::*/span");
		if (invoicetype.equalsIgnoreCase(input.get("invoicetype"))) {

			passed("Verifying the  Invoice type",
					"Invoice type should be displayed as '"+ input.get("invoicetype") + "' Successfully",
					"Invoice Status " + invoicetype + " is displayed Successfully");
		} else {
			failed("Verifying the  Invoice Status",
					"Invoice Status should be displayed as '"+ input.get("invoicetype") + "' Successfully",
					"Invoice Status " + invoicetype+ " is not displayed Successfully");
		}

	}
/****************************************
	 * Name: VerifyInvoiceJournalsinUAT
	 * Description:Method to VerifyInvoiceJournals
	 * Date: 29-Jul-2018
	 ****************************************/
	public void VerifyInvoiceJournals_UAT(DataRow input, DataRow output)
			throws InterruptedException {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("reclassJEntry");
		SleepUtils.sleep(TimeSlab.HIGH);
		List<WebElement> ele = uiDriver.webDr.findElements(By.xpath("//*[@id='recmachcustbody_nbcu_related_record__tab']/tbody/tr"));
		int rowSize = ele.size();
		for (int r = 1; r < rowSize; r++) {
			uiDriver.executeJavaScript("document.getElementById('custom25txt').click();");
			//uiDriver.click("reclassJEntry");
			SleepUtils.sleep(2);
			uiDriver.executeJavaScript("scroll(0,1500)");
			String s1 = uiDriver.getDyanmicData("DocNum");
			String s2 = s1.replace("#", Integer.toString(r));
			if (uiDriver.checkElementPresent_dynamic(s2)) {

				SleepUtils.sleep(5);
				uiDriver.click(s2);
				SleepUtils.sleep(5);
				uiDriver.executeJavaScript("scroll(0,800)");
				int invoiceRow = 2;
				int transRows = uiDriver.webDr.findElements(
						By.xpath("//*[@id='line_splits']//tbody/tr")).size();
				for (i = 0; i < transRows - 1; i++) {
					uiDriver.executeJavaScript("scroll(0,100);");
					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Deferred Rev - Generic")) {
						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[2]").equals("")) {

							failed("Validating Debit Amount",
									"Validating Debit Amount should be successfull",
									"Debit amount is not Deferred Rev - Generic");
						} else {

							passed("Debit is Deferred Rev - Generic",
									"Debit is Deferred Rev - Generic",
									"Debit amount is Deferred Rev - Generic");

						}

					}

					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Bad Debt")) {

						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[2]").equals("")) {

							failed("Validating Debit Amount",
									"Validating Debit Amount should be successfull",
									"Debit amount is not Bad Debt");

						} else {
							passed("Debit is Deferred Rev - Generic",
									"Debit is Bad Debt",
									"Debit amount is Bad Debt");
						}
					}
					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Internal Dom")) {

						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[2]").equals("")) {

							failed("Validating Debit Amount",
									"Validating Debit Amount should be successfull",
									"Debit amount is not Bad Debt");

						} else {
							passed("Debit is Internal Dom",
									"Debit is Bad Debt",
									"Debit amount is Bad Debt");
						}
					}

					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Generic Billed")) {
						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals("")) {
							failed("Validating Credit Amount",
									"Validating Credit Amount should be successfull",
									"Credit amount is not Generic Billed");

						}

						else {
							passed("Debit is Generic Billed",
									"Credit is Generic Billed",
									"Credit amount is Generic Billed");

						}

					}

					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Contract revenue")) {
						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[2]").equals("")) {		
							failed("Validating Debit Amount",
									"Validating Credit Amount should be successfull",
									"Credit amount is not Contract revenue");
						}

						else {
							passed("Debit is Contract revenue",
									"Credit is Contract revenue",
									"Credit amount is Contract revenue");

						}
					}

					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Bad Debt Revenue")) {
						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals("")) {

							failed("Validating Credit Amount",
									"Validating Credit Amount should be successfull",
									"Credit amount is not Bad Debt Revenue");
						}

						else

						{
							passed("Credit is Generic Billed",
									"Credit is Bad Debt Revenue",
									"Credit amount is Bad Debt Revenue");

						}
					}

					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Billed Intl")) {
						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals("")) {

							failed("Validating Credit Amount",
									"Validating Credit Amount should be successfull",
									"Credit amount is not Billed Intl");

						}

						else {
							passed("Debit is Billed Intl",
									"Credit is Billed Intl",
									"Credit amount is Billed Intl");

						}

					}

					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Deferred Rev - Unpaid")) {
						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals("")) {

							failed("Validating CREDIT Amount",
									"Validating CREDIT Amount should be successfull",
									"CREDIT amount is not Deferred Rev - Unpaid");

						}

						else {

							passed("CREDIT is Deferred Rev - Unpaid",
									"CREDIT is Deferred Rev - Unpaid",
									"CREDIT amount is Deferred Rev - Unpaid");

						}
					}
					
					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("HST ON")) {
						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals("")) {

							failed("Validating CREDIT Amount",
									"Validating CREDIT Amount should be successfull",
									"CREDIT amount is not HST ON");

						}

						else {

							passed("CREDIT is HST ON",
									"CREDIT is HST ON",
									"CREDIT amount is HST ON");

						}
					}

					invoiceRow++;
				}

				uiDriver.executeJavaScript("scroll(0,800)");
				SleepUtils.sleep(5);
				uiDriver.click("Back1");
				SleepUtils.sleep(5);
				uiDriver.executeJavaScript("scroll(0,-500)");
				SleepUtils.sleep(5);
			}

			else {
				// do nothindf
			}

		}

	}
	
	
	/****************************************
	 * Name: VerifyInvoiceJournals 
	 * Description:Method to VerifyInvoiceJournals
	 * Date: 29-Jul-2018
	 ****************************************/
	public void VerifyInvoiceJournals(DataRow input, DataRow output)
			throws InterruptedException {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("//*[text()='lated Transactions']");
		SleepUtils.sleep(TimeSlab.HIGH);
		List<WebElement> ele = uiDriver.webDr.findElements(By.xpath("//*[text()='Transaction']/following::table//td[text()='Journal' or text()='Invoice' or text()='Credit Memo']"));
		int rowSize = ele.size();
		for (int r = 1; r < rowSize; r++) {
			WebElement w = uiDriver.webDr.findElement(By.xpath("//*[text()='lated Transactions']"));
			String id = w.getAttribute("id");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.executeJavaScript("scroll(0,-1000)");
			//if(uiDriver.checkElementPresent_dynamic("reclassJEntry")){
			uiDriver.executeJavaScript("document.getElementById('"+id+"').click();");
			//uiDriver.click("reclassJEntry");
			SleepUtils.sleep(2);
			uiDriver.executeJavaScript("scroll(0,1500)");
			String s1 = uiDriver.getDyanmicData("DocNum");
			String s2 = s1.replace("#", Integer.toString(r));
			if (uiDriver.checkElementPresent_dynamic(s2)) {

				SleepUtils.sleep(5);
				uiDriver.click(s2);
				SleepUtils.sleep(5);
				uiDriver.executeJavaScript("scroll(0,800)");
				int invoiceRow = 2;
				int transRows = uiDriver.webDr.findElements(By.xpath("//*[@id='line_splits']//tbody/tr")).size();
				for (i = 0; i < transRows - 1; i++) {
					uiDriver.executeJavaScript("scroll(0,100);");
					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Deferred Rev - Generic")) {
						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[2]").equals("")) {

							failed("Validating Debit Amount",
									"Validating Debit Amount should be successfull",
									"Debit amount is not Deferred Rev - Generic");
						} else {

							passed("Debit is Deferred Rev - Generic",
									"Debit is Deferred Rev - Generic",
									"Debit amount is Deferred Rev - Generic");

						}

					}

					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Bad Debt")) {

						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[2]").equals("")) {

							failed("Validating Debit Amount",
									"Validating Debit Amount should be successfull",
									"Debit amount is not Bad Debt");

						} else {
							passed("Debit is Deferred Rev - Generic",
									"Debit is Bad Debt",
									"Debit amount is Bad Debt");
						}
					}
					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Internal Dom")) {

						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[2]").equals("")) {

							failed("Validating Debit Amount",
									"Validating Debit Amount should be successfull",
									"Debit amount is not Bad Debt");

						} else {
							passed("Debit is Internal Dom",
									"Debit is Bad Debt",
									"Debit amount is Bad Debt");
						}
					}

					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Generic Billed")) {
						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals("")) {		
							failed("Validating Credit Amount",
									"Validating Credit Amount should be successfull",
									"Credit amount is not Generic Billed");

						}

						else {
							passed("Debit is Generic Billed",
									"Credit is Generic Billed",
									"Credit amount is Generic Billed");

						}

					}

					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Contract revenue")) {
						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[2]").equals("")) {

							failed("Validating Debit Amount",
									"Validating Credit Amount should be successfull",
									"Credit amount is not Contract revenue");
						}

						else {
							passed("Debit is Contract revenue",
									"Credit is Contract revenue",
									"Credit amount is Contract revenue");

						}
					}

					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Bad Debt Revenue")) {
						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals("")) {

							failed("Validating Credit Amount",
									"Validating Credit Amount should be successfull",
									"Credit amount is not Bad Debt Revenue");
						}

						else

						{
							passed("Credit is Generic Billed",
									"Credit is Bad Debt Revenue",
									"Credit amount is Bad Debt Revenue");

						}
					}

					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Billed Intl")) {
						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals("")) {

							failed("Validating Credit Amount",
									"Validating Credit Amount should be successfull",
									"Credit amount is not Billed Intl");

						}

						else {
							passed("Debit is Billed Intl",
									"Credit is Billed Intl",
									"Credit amount is Billed Intl");

						}

					}

					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Deferred Rev - Unpaid")) {
						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals("")) {

							failed("Validating CREDIT Amount",
									"Validating CREDIT Amount should be successfull",
									"CREDIT amount is not Deferred Rev - Unpaid");

						}

						else {

							passed("CREDIT is Deferred Rev - Unpaid",
									"CREDIT is Deferred Rev - Unpaid",
									"CREDIT amount is Deferred Rev - Unpaid");

						}
					}
					
					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("HST ON")) {
						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals("")) {

							failed("Validating CREDIT Amount",
									"Validating CREDIT Amount should be successfull",
									"CREDIT amount is not HST ON");

						}

						else {

							passed("CREDIT is HST ON",
									"CREDIT is HST ON",
									"CREDIT amount is HST ON");

						}
					}

					invoiceRow++;
				}

				uiDriver.executeJavaScript("scroll(0,800)");
				SleepUtils.sleep(5);
				uiDriver.click("Back1");
				SleepUtils.sleep(5);
				uiDriver.executeJavaScript("scroll(0,-500)");
				SleepUtils.sleep(5);
			}

			else {
				// do nothindf
			}

		}

	}

	/****************************************
	 * Name: projectType
	 * Description: projectType 
	 * Date: 11-July-2018
	 ****************************************/
	public void projectType(DataRow input, DataRow output) {
		// new function
		uiDriver.setValue("projecttype", input.get("projecttype"));
		// Time taken to load Report page(end time)
		SleepUtils.sleep(TimeSlab.YIELD);
	}

	/****************************************
	 * Name: project
	 *  Description: project 
	 *  Date: 11-July-2018
	 ****************************************/
	public void project(DataRow input, DataRow output) {
		// new function
		uiDriver.click("project");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("project", input.get("project"));
		SleepUtils.sleep(TimeSlab.YIELD);

	}

	/****************************************
	 * Name: reportsearch 
	 * Description: reportsearch
	 *  Date: 11-July-2018
	 ****************************************/
	public void reportsearch(DataRow input, DataRow output) {

		// start time to load report search page
		uiDriver.click("reportsearch");
		SleepUtils.sleep(TimeSlab.MEDIUM);

	}

	/****************************************
	 * Name: contracts 
	 * Description: contracts
	 *  Date: 11-July-2018
	 ****************************************/
	public void contracts(DataRow input, DataRow output) {
		// end time to load report search page

		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("contracts");
		passed("Report Page", "Time taken to search the report",
				"Successfully searched the report");

	}

	/****************************************
	 * Name: contractSearchOption 
	 * Description: contractSearchOption
	 *  Date: 11-July-2018
	 ****************************************/
	public void contractSearchOption(DataRow input, DataRow output) {
		// start time to load contract search page
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("contractsearchoption");
		SleepUtils.sleep(TimeSlab.YIELD);
		passed("Contract Search Page", "Response time of Contract Search page",
				"Successfully loded the Contract Search page");
	}

	/****************************************
	 * Name: clickcontractSearchDescription 
	 * Description: clickcontractSearchDescription
	 * Date: 11-July-2018
	 ****************************************/
	public void clickcontractSearchDescription(DataRow input, DataRow output) {

		// end time to load contract search page
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("contractsearchdescription");
	}

	/****************************************
	 * Name: contractSearchDescription 
	 * Description: contractSearchDescription
	 * Date: 11-July-2018
	 ****************************************/
	public void contractSearchDescription(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("contractsearchdescription",
				input.get("contractsearchdescription"));
	}

	/****************************************
	 * Name: contactsearch 
	 * Description: contactsearch
	 *  Date: 11-July-2018
	 ****************************************/
	public void contactsearch(DataRow input, DataRow output) { // start time to
																// load search
																// time
																// (contract
																// search)
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("contactsearch");

	}

	/****************************************
	 * Name: contractcard Description: contractcard Date: 11-July-2018
	 ****************************************/

	public void contractcard(DataRow input, DataRow output) { // end time to
																// load search
																// time(contract
																// search)
		SleepUtils.sleep(TimeSlab.LOW);

		SleepUtils.sleep(TimeSlab.LOW);
		// page loadlin time of contract card(start time)
		uiDriver.click("contractcard");
		SleepUtils.sleep(TimeSlab.YIELD);
		passed("Contract Search Page", "Time taken to perform search",
				"Successfully searched the contract");
	}

	/****************************************
	 * Name: contractcarddescription 
	 * Description: contractcarddescription 
	 * Date: 11-July-2018
	 ****************************************/
	public void contractcarddescription(DataRow input, DataRow output) {
		uiDriver.click("contractcarddescription");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("contractcarddescription",
				input.get("contractcarddescription"));
		passed("Contract card Search Page",
				"Response time of Contract Search page",
				"Successfully loded the Contract card Search page");
	}

	/****************************************
	 * Name: contractcardsearch 
	 * Description: contractcardsearch
	 * Date:11-July-2018
	 ****************************************/

	public void contractcardsearch(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("contractcardsearch");

	}

	/****************************************
	 * Name: contractInfo
	 *  Description: contractInfo 
	 *  Date: 11-July-2018
	 ****************************************/

	public void contractInfo(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("contractInfo");
		passed("contract card search page",
				"Time taken to perform contract card search",
				"Successfully searched the contract card");

	}

	/****************************************
	 * Name: contractFilter
	 * Description: contractFilter
	 *  Date: 11-July-2018
	 ****************************************/
	public void contractFilter(DataRow input, DataRow output) {
		// start time to load contract search page
		SleepUtils.sleep(TimeSlab.YIELD);
		String Contract = input.get("contract");
		String ContractNetsuite = Contract;
		String Contract1 = ContractNetsuite + "*";
		String NSContract=ContractNetsuite+"A";
		String NSContract1=ContractNetsuite+"B";
		uiDriver.setValue("ContractSearch", Contract1);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Search");
		// SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		passed("Contract Search Page", "Response time of Contract Search page",
				"Successfully loded the Contract Search page");
		uiDriver.click("ContractID");
		output.put("ContractId", Contract1);
		output.put("ContractNetSuite", ContractNetsuite);
		output.put("NSContract",NSContract);
		output.put("NSContractB",NSContract1);

	}
	
	public void EditBillinggroupScen28(DataRow input, DataRow output) {
		// start time to load contract search page
		uiDriver.click("//a[@class='k-button k-button-icontext k-grid-Edit']");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.setValue("//input[@id='ContractBillingGroup_Name']", input.get("Flatfees"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//span[@class='k-dropdown-wrap k-state-default']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//li[text()='"+ input.get("Manual")+"']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//button[@id='Save']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//tr[@class='projectcategories']/td/..//a");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//span[contains(text(),'Library')]/../../..//span[@class='k-checkbox-wrapper']//input");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//button[@class='add-btn']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//button[@id='Save']");
		SleepUtils.sleep(TimeSlab.LOW);
         uiDriver.click("//button[@id='Return']");
     	SleepUtils.sleep(TimeSlab.MEDIUM);
         uiDriver.click("//*[@id='contract-billing-groups-grid']/div[1]/a");
     	SleepUtils.sleep(TimeSlab.MEDIUM);
         uiDriver.setValue("//input[@id='ContractBillingGroup_Name']", input.get("feecalc"));
         SleepUtils.sleep(TimeSlab.LOW);
         uiDriver.click("//span[@class='k-dropdown-wrap k-state-default']");
 		SleepUtils.sleep(TimeSlab.LOW);
 		uiDriver.click("//li[text()='"+ input.get("Manual")+"']");
 		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//button[@id='Save']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//tr[@class='projectcategories']/td/..//a");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//span[contains(text(),'Current A')]/../../..//span[@class='k-checkbox-wrapper']//input");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//span[contains(text(),'Current B')]/../../..//span[@class='k-checkbox-wrapper']//input");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//span[contains(text(),'Current C')]/../../..//span[@class='k-checkbox-wrapper']//input");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//span[contains(text(),'Current Megahit')]/../../..//span[@class='k-checkbox-wrapper']//input");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//button[@class='add-btn']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//button[@id='Save']");
		SleepUtils.sleep(TimeSlab.LOW);
         uiDriver.click("//button[@id='Return']");
     	SleepUtils.sleep(TimeSlab.MEDIUM);
     	SleepUtils.sleep(TimeSlab.MEDIUM);
     	SleepUtils.sleep(TimeSlab.MEDIUM);
     	SleepUtils.sleep(TimeSlab.MEDIUM);
	}
	
	/****************************************
	 * Name: VerifySubsidiary Description: VerifySubsidiary
	 * Date: 05-March-2019
	 ****************************************/
	public void VerifySubsidiary(DataRow input, DataRow output) {
		uiDriver.click("//a[text()='Information']");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("//a[text()='Additional Info']");
		if(uiDriver.checkElementPresent("//span[text()='Subsidiary']/../..//td[3]//span[text()='"+input.get("Subsidiary")+"']")) {
				passed("Verify the Subsidiary ID",
						"Subsidiary should be "+input.get("Subsidiary"), "Subsidiary is "+input.get("Subsidiary"));
			} else {				
	            	uiDriver.click("//span[text()='Subsidiary']//../preceding-sibling::td/input");
	            	SleepUtils.sleep(TimeSlab.HIGH);
	            	uiDriver.setValue("//td[contains(text(),'Value')]/following-sibling::td/span/textarea", input.get("Subsidiary"));
	            	SleepUtils.sleep(TimeSlab.YIELD);
	            	uiDriver.click("//input[@type='button' and @value='Save']");
	            	SleepUtils.sleep(TimeSlab.LOW);
	            	
	            	String Subsidiary = uiDriver.getValue_Text("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_OtherDataAttributeValueGrid_ctl00_ctl16_ValueLabel']");
	                if(input.get("Subsidiary").equals(Subsidiary)){
	                	passed("Verify the Subsidiary displayed",
	                                   "Subsidiary should be Checked successfully as " + input.get("Subsidiary") + "",
	                                    "Subsidiary is Checked successfully as" + Subsidiary + "");
	                } else {
	                   failed("Verify the Subsidiary displayed",
	                                "Subsidiary should be checked successfully as " + input.get("Subsidiary") + "",
	                                "Subsidiary is not checked successfully as" + Subsidiary + "");
	                }
			}	           
		}
	
	
	
	/****************************************
	 * Name: VerifyEstimate
	 * Description: VerifyEstimate
	 *  Date: 11-July-2018
	 ****************************************/
	public void ValidateEstimate(DataRow input, DataRow output) {
		// start time to load contract search page
		uiDriver.click("RelatedTransactions");
		SleepUtils.sleep(TimeSlab.LOW);
		String estimate=uiDriver.getDyanmicData("Estimate");
		String salesnum = input.get("conf");
		String mastercontract = salesnum.substring(0, salesnum.length()-1);
		String conf1=mastercontract+"-1A";
		String estimate1=estimate.replace("#", conf1);
		uiDriver.click_dynamic(estimate1);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String validation=input.get("validation");
		if(validation.equalsIgnoreCase("y"))
		{
			uiDriver.executeJavaScript("document.getElementById('custpage_validate_est').click();");
			SleepUtils.sleep(TimeSlab.HIGH);
			String ContractValidation = uiDriver.getValue_Text("ContractValidation");
		if (ContractValidation.contains("This revision is valid for committing")) {

			passed("Validating the estimate",
					"Estimate should be displayed as This revision is valid for committing",
					"ContractValidation is displayed as"+ContractValidation+"");
		} 

		else {
			failed("Validating the estimate",
					"Estimate should be displayed as This revision is valid for committing.",
					"ContractValidation is displayed as"+ContractValidation+"");
		}

		uiDriver.click("OK");
		SleepUtils.sleep(TimeSlab.HIGH);
		}
		else
		{
			SleepUtils.sleep(30);
			uiDriver.refresh();
			SleepUtils.sleep(30);
			uiDriver.refresh();
			SleepUtils.sleep(30);
			uiDriver.refresh();
			SleepUtils.sleep(30);
			uiDriver.refresh();
			SleepUtils.sleep(30);
			uiDriver.refresh();
			SleepUtils.sleep(30);
			uiDriver.refresh();
			uiDriver.refresh();
			uiDriver.refresh();
			WebElement email = uiDriver.webDr.findElement(By.xpath("//*[@id='custbody_nbcu_transaction_isinactive_fs']/img"));
			String estimatecheckboxvalue = email.getAttribute("alt");
			if (estimatecheckboxvalue.equalsIgnoreCase("checked")) {
				passed("Verify Estimate",
						"Estimate should be committed",

						"Estimate is committed");

			} else {
				failed("Verify Estimate",
						"Estimate should be committed",

						"Estimate is not committed");

			}			
			uiDriver.click("masterestimate");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			String masterestimatestatus = uiDriver.getValue("masterestimatestatus");
			if(masterestimatestatus.equalsIgnoreCase("Committed"))
			{
				passed("verifying the master estimate status",
						"Master Estimate status should be committed",
						"Master Estimate status is committed");
			}
			else
			{
				failed("verifying the master estimate status",
						"Master Estimate status should be committed",
						"Master Estimate status is not committed");
			}
			
			}

	}

	/****************************************
	 * Name: checkFinancestatus
	 * Description: checkFinancestatus Date:
	 * 26-March-2019
	 ****************************************/
	public void checkFinanceStatus(DataRow input, DataRow output) {
uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.LOW);		uiDriver.click("FinanceSummary");
		SleepUtils.sleep(TimeSlab.LOW);
		Actions action = new Actions(uiDriver.webDr);
        WebElement ele = uiDriver.webDr.findElement(By
                    .xpath("(//*[@class='k-numeric-wrap k-state-default k-expand-padding']//input)[1]"));
            ele.clear();   
            SleepUtils.sleep(TimeSlab.LOW);
        action.sendKeys(Keys.CONTROL,"a",Keys.BACK_SPACE).build().perform();
        SleepUtils.sleep(1);
         uiDriver.setText(input.get("count"));
         SleepUtils.sleep(1);
         uiDriver.click("//*[@id='search-btn']");
         SleepUtils.sleep(TimeSlab.LOW);

		
		/*
		 * if(uiDriver.checkElementPresent("//td//span[@title='"+input.get("Title")+"']")){
			String UI_Amount = uiDriver.getAttribute("//td//span[@title='"+input.get("Title")+"']//..//..//td//input[@class='amount-value']", "value");
			if(UI_Amount == input.get("Amount")) {
			
				passed("checkFinancestatus ",
						"Amount for Title "+input.get("Title")+" should be "+input.get("Amount"),
						"Amount for Title "+input.get("Title")+" is : "+UI_Amount);
				}
				else{
					failed("checkFinancestatus ",
							"Amount for Title '"+input.get("Title")+"' should be : "+input.get("Amount"),
							"Amount for Title "+input.get("Title")+" is : "+UI_Amount);
				}
		}
		*/
		
		
			int actualCount = uiDriver.getSizeOfElement("//input[@value='"+input.get("Amount")+"']");
			int expectedCount = Integer.parseInt(input.get("Count"));
			if(actualCount == expectedCount) {
			
				passed("checkFinancestatus ",
						"Number of Amount '"+input.get("Amount")+"' should be : "+expectedCount,
						"Number of Amount '"+input.get("Amount")+"' is : "+actualCount);
			}
			else {
				failed("checkFinancestatus ",
						"Number of Amount '"+input.get("Amount")+"' should be : "+expectedCount,
						"Number of Amount '"+input.get("Amount")+"' is : "+actualCount);
				}
		

	}
	
	/****************************************
	 * Name: updateFinancestatus
	 * Description: updateFinancestatus Date:
	 * 11-July-2018
	 ****************************************/
	public void updateFinancestatus(DataRow input, DataRow output) {

		uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("FinanceSummary");
		/*uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.refresh();
		String difference = uiDriver.getValue("difference");
		if (difference.equalsIgnoreCase("0.00")) {
			passed("Verify difference field", "Difference should be 0",
					"Difference is 0");
		} else {
			uiDriver.click("updatecontract");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Yes");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("updatecontract");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Yes");
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
		}
		
		String finaldifference = uiDriver.getValue("difference");
		if (finaldifference.equalsIgnoreCase("0.00")) {
			passed("Verify difference field", 
					"Difference should be 0",
					"Difference is 0");
		}
		*/
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.setValue("title", input.get("SearchKey"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("search");
		SleepUtils.sleep(TimeSlab.LOW);
		SleepUtils.sleep(TimeSlab.LOW);
		if(uiDriver.checkElementPresent("//span[@title='"+input.get("Title")+"']")){
		passed("updateFinancestatus ",
				input.get("Title")+" Title Should be present",
				input.get("Title")+" Title is checked Successfully");
		}
		else{
			failed("updateFinancestatus ",
					input.get("Title")+" Title Should be present",
					input.get("Title")+" Title is not present");
		}
		
		uiDriver.click("//span[@title='"+input.get("Title")+"']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("textfield_Amount");
		SleepUtils.sleep(TimeSlab.YIELD);
		Robot robot;
		try {
	robot = new Robot();
		robot.keyPress(KeyEvent.VK_DELETE);
			robot.keyRelease(KeyEvent.VK_DELETE);
			Actions act = new Actions(uiDriver.webDr);
			act.sendKeys(input.get("Amount")).build().perform();
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		uiDriver.setValue("textfield_Amount", input.get("Amount"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("button_UpdateContractTotal");
		SleepUtils.sleep(TimeSlab.YIELD);
		if(uiDriver.checkElementPresent("//div[text()='Are you sure you want to update the contract total?']//..//button[text()='Yes']")){			
			try {				
				uiDriver.webDr.findElement(By.xpath("//div[text()='Are you sure you want to update the contract total?']//..//button[text()='Yes']")).click();;
				SleepUtils.sleep(TimeSlab.MEDIUM);
			} catch(Exception e) {				
			}
		}
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		String text_ContractTotal = uiDriver.getValue("//span[@id='contract-total']");
		String text_AllocationsTotal = uiDriver.getValue("//span[@id='alloc-total']");
		if(text_ContractTotal.trim().equalsIgnoreCase(text_AllocationsTotal.trim())) {
			passed("updateFinancestatus",
					"Contract Total should be updated",
					"Contract Total is updated");
		} else {
			failed("updateFinancestatus",
					"Contract Total should be updated",
					"Contract Total is not updated");
		}
	}

	/****************************************
	 * Name: NavigateToStarCM
	 * Description: NavigateToStarCM 
	 * Date: 11-July-2018
	 ****************************************/
	public void NavigateToStarCM(DataRow input, DataRow output) {
		uiDriver.click("List");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("STARCM");
		passed("FilmTrack CMPage", "FilmTrack CMPage Should be displayed",
				"FilmTrack CMPage is displayed");
		uiDriver.switchToWindow("Welcome to the StarCm - FilmTrack *CM");
		if (uiDriver.checkElementPresent("//*[@id='UserName']")) {
			uiDriver.setValue("//*[@id='UserName']", "206525318");
			uiDriver.setValue("//*[@id='PassWord']", "Pa$$word123");
			uiDriver.click("//*[@id='LoginButton']");
			passed("Login to FilmTrack Application",
					"Should loginto the Application",
					"FilmTrack Application opened sucessfully!");

		} else {

			// do nothing
		}
		uiDriver.click("ProjectId");
		uiDriver.setValue("ProjectId", input.get("ProjectId"));
		// SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ProjectIDList");
		// SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("OtherData");
		// SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("OnNetwrkFlg");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String OnNetworkFlag = uiDriver.getValue_Text("OnNetworkFlag");
		SleepUtils.sleep(TimeSlab.LOW);
		if (OnNetworkFlag.equalsIgnoreCase("No")) {

			passed("Verify the OnNetwork Flag",
					"OnNetwork Flag should be unchecked Successfully",
					"OnNetwork Flag is unchecked Successfully");

		} else {
			passed("Verify the OnNetwork Flag",
					"OnNetwork Flag should be unchecked Successfully",
					"OnNetwork Flag is not unchecked Successfully");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContinuousProd");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String ContinuousProduction = uiDriver
				.getValue_Text("ContinuousProduction");
		if (ContinuousProduction.equalsIgnoreCase("Yes")) {

			passed("Verify the ContinuousProduction Flag",
					"ContinuousProduction Flag should be checked Successfully",
					"ContinuousProduction Flag is checked Successfully");

		} else {
			failed("Verify the ContinuousProduction Flag",
					"ContinuousProduction Flag should be checked Successfully",
					"ContinuousProduction Flag is not checked Successfully");

		}
		uiDriver.switchToWindow("Contract - Details");
		SleepUtils.sleep(TimeSlab.LOW);
	}

	/****************************************
	*Name: NavigateToStarCMAlltitles
	* Description: NavigateToStarCM 
	* Date: 11-July-2018
	 ****************************************/
	public void NavigateToStarCMAlltitles(DataRow input, DataRow output) {
		uiDriver.click("List");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("STARCM");
		passed("FilmTrack CMPage", "FilmTrack CMPage Should be displayed",
				"FilmTrack CMPage is displayed");
		uiDriver.switchToWindow("Welcome to the StarCm - FilmTrack *CM");
		if (uiDriver.checkElementPresent("//*[@id='UserName']")) {
			uiDriver.setValue("//*[@id='UserName']", "206525318");
			uiDriver.setValue("//*[@id='PassWord']", "Pa$$word123");
			uiDriver.click("//*[@id='LoginButton']");
			passed("Login to FilmTrack Application",
					"Should loginto the Application",
					"FilmTrack Application opened sucessfully!");

		} else {

			// do nothing
		}
		uiDriver.setValue("ProjectId", input.get("ProjectId"));
		SleepUtils.sleep(TimeSlab.HIGH);
		
	
		// SleepUtils.sleep(TimeSlab.LOW);
		List<WebElement> titlerow = uiDriver.webDr.findElements(By.xpath("(//table[@class='rgMasterTable rgClipCells'])[2]//tbody/tr"));
		for(int rown=1;rown<=titlerow.size();rown++)
		{
			
			
			String ProjectIDList =uiDriver.getDyanmicData("ProjectIDList");
			String ProjectIDList1 = ProjectIDList.replace("#", Integer.toString(rown));
			uiDriver.click(ProjectIDList1);
			
		// SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("OtherData");
		// SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("OnNetwrkFlg");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String OnNetworkFlag = uiDriver.getValue_Text("OnNetworkFlag");
		//SleepUtils.sleep(TimeSlab.LOW);
		if (OnNetworkFlag.equalsIgnoreCase("Yes")) {

			passed("Verify the OnNetwork Flag",
					"OnNetwork Flag should be checked Successfully",
					"OnNetwork Flag is checked Successfully");

		} else {
			failed("Verify the OnNetwork Flag",
					"OnNetwork Flag should be checked Successfully",
					"OnNetwork Flag is not unchecked Successfully");

		}
		uiDriver.setValue("ProjectId", input.get("ProjectId"));
		 SleepUtils.sleep(TimeSlab.MEDIUM);
		
	}
				
		uiDriver.switchToWindow("Contract - Timeline Items");
		SleepUtils.sleep(TimeSlab.HIGH);
	}
	
	/****************************************
	 * Name: Navigate to Parties 
	 * Description:Navigate to Parties
	 * Date:11-July-2018
	 ****************************************/
	public void AddMarketCode(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Information");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Additionalinfo");
		passed("Additional Info Page", 
				"PartySearch Page Should be displayed",
				"PartySearch Page is displayed");
		uiDriver.click("Add");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.setValue("Value", "First Run Canada");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Save");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);

	}

	/****************************************
	 * Name: Navigate to Parties Description:Navigate to Parties
	 * Date:11-July-2018
	 ****************************************/
	public void NavigateToParties(DataRow input, DataRow output) {
		uiDriver.click("Parties");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("PartySearch");
		passed("PartySearch Page",
				"PartySearch Page Should be displayed",
				"PartySearch Page is displayed");
		uiDriver.setValue("LegalName", input.get("Legal Name"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Search");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Customerlink");

	}

	/****************************************
	 * Name: Check Customer Additional information
	 * Description:Check CustomerAdditional information
	 * Date:11-July-2018
	 ****************************************/
	public void CustomerAdditionalInfo(DataRow input, DataRow output) {
		uiDriver.click("Information");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Additionalinfo");
		passed("Info Page", "Info Page Should be displayed",
				"Info Page is displayed");
		uiDriver.click("Customerlink");
		SleepUtils.sleep(TimeSlab.YIELD);
		String intercompany = uiDriver.getValue("Intercompanyvalue");
		if (intercompany.equals(input.get("intercompany"))) {
			passed("Validating Intercompany Flag",
					"Intercompany Flag Should be displayed as '"+ input.get("intercompany") + "' successfully",
					"Intercompany Flag is  displayed as '" + intercompany+ "' successfully");
		} else {
			failed("Validating Intercompany Flag",
					"Intercompany Flag Should be displayed as '"+ input.get("intercompany") + "' successfully",
					"Intercompany Flag is not displayed as '" + intercompany+ "' successfully");	
			}
	}
	
	
	/****************************************
	 * Name: Check Customer Additional information 
	 * Description:Check Customer Additional information 
	 * Date:11-July-2018
	 ****************************************/
	public void regenerateallocations(DataRow input, DataRow output) {
		uiDriver.click("allocations");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("recalculate");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		
	}

	/****************************************
	 * Name: UpdateDealType 
	 * Description: UpdateDealType
	 * Date: 11-July-2018
	 ****************************************/
	public void UpdateDealType(DataRow input, DataRow output) {
			
		uiDriver.click("DealType");
		SleepUtils.sleep(TimeSlab.LOW);
		String DealTypeName = uiDriver.getDyanmicData("DealTypeName");
		String DealName = input.get("DealType");
		String DealTypeName1 = DealTypeName.replace("#", DealName);
		uiDriver.click(DealTypeName1);
		SleepUtils.sleep(TimeSlab.LOW);
		passed("Verify the DealTypeName", 
				"DealTypeName" + DealName+ " should be set  Successfully", 
				"DealTypeName" + DealName+ " is set  Successfully");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Save");
		SleepUtils.sleep(TimeSlab.HIGH);
		

	}

	/****************************************
	 * Name: validateprojectdetails 
	 * Description: validateprojectdetails
	 * Date: 11-July-2018
	 ****************************************/
	public void validateprojectdetails(DataRow input, DataRow output)
			throws InterruptedException {
		uiDriver.click("projectdetails");
		SleepUtils.sleep(TimeSlab.YIELD);
		String expallocationname = input.get("AllocationRule");
		String numofbillschedules = input.get("numbill");
		int num = Integer.parseInt(numofbillschedules);
		for (int i = 1; i <= num; i++) {
			String actallocationname = uiDriver.getValue("allocationrule");
			if (actallocationname.equalsIgnoreCase(expallocationname)) {
				passed("verify allocation rule in project details",
				"Allocation rules should be" + expallocationname + "",
				"Allocation rules is" + actallocationname + "");
			}

			uiDriver.click("next");
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
		}

	}


	/****************************************
	 * Name: AddFMV 
	 * Description: AddFMV
	 * Date: 11-July-2018
	 ****************************************/
	public void AddFMV(DataRow input, DataRow output)throws InterruptedException {
		uiDriver.click("Edit");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.setValue("Title", input.get("Title"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("ApplyFilters");
		SleepUtils.sleep(TimeSlab.HIGH);
		List<WebElement> chkboxes = uiDriver.webDr.findElements(By.xpath("//img[@class='checkboximage']"));
		for(WebElement w:chkboxes)
		{
			w.click();
		}
		//uiDriver.click("checkbox");
		//SleepUtils.sleep(TimeSlab.YIELD);
		//uiDriver.setValue("productOwner", "TH");
		
		List<WebElement> productowner = uiDriver.webDr.findElements(By.xpath("//input[@class='inputreq uir-custom-field']"));
		for(WebElement w:productowner)
		{
			w.clear();
			w.sendKeys(input.get("Product Owner"));
		}
		
		List<WebElement> fmv = uiDriver.webDr.findElements(By.xpath("//input[contains(@name,'fmv')  and contains(@id,'fmv')]"));
		for(WebElement w:fmv)
		{
			w.clear();
			w.sendKeys(input.get("FMV Indicator"));
		}
		
		
		//SleepUtils.sleep(TimeSlab.YIELD);
		//uiDriver.setValue("fmv", "C");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("movedown");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Save");
		SleepUtils.sleep(TimeSlab.HIGH);

	}

	/****************************************
	 * Name: GeneratepartialInvoice 
	 * Description:GeneratepartialInvoice
	 * Date: 11-July-2018
	 ****************************************/
	public void GeneratepartialInvoice(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Invoices");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("BulkOperations");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("GenerateInvoices");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Filter");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("searchinput");
		String ContractId = input.get("contractId");
		uiDriver.setValue("searchinput", input.get("contractId"));
		// uiDriver.setValue("searchinput", "123178");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//*[@id=\"advancedSearchButton\"]");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("sortdate");	
		SleepUtils.sleep(TimeSlab.MEDIUM);
	    uiDriver.click("grid");
	    SleepUtils.sleep(TimeSlab.MEDIUM);
		String ContractNum = uiDriver.getDyanmicData("Contractnum");
		SleepUtils.sleep(TimeSlab.YIELD);
		String ContractNumber = ContractNum.replace("#", ContractId);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		List<WebElement> ele = uiDriver.webDr.findElements(By.xpath(ContractNumber));
		SleepUtils.sleep(TimeSlab.MEDIUM);
		int rowSize = Integer.parseInt(input.get("numtobebilled"));
		
		for (int b=0;b<rowSize;b++) {
			/*
			 * String RevenuechkBox = uiDriver.getDyanmicData("RevenueChkBox");
			 * String Revenuechkbox1=RevenuechkBox.replace("$",revenuenum);
			 * String RevchkBox = Revenuechkbox1.replace("#",
			 * Integer.toString(i)); if
			 * (uiDriver.checkElementPresent_dynamic(RevchkBox)) {
			 * 
			 * uiDriver.click_dynamic(RevchkBox); } else { // do nothing }
			 */
			SleepUtils.sleep(TimeSlab.MEDIUM);
			ele.get(b).click();
			
			SleepUtils.sleep(TimeSlab.MEDIUM);

		}

		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.executeJavaScript("scroll(0,-1000)");
		uiDriver.click("Createinvoice");
		SleepUtils.sleep(TimeSlab.LOW);
		String invoicenum = uiDriver.getValue("InvoiceID");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("InvoiceID");
		SleepUtils.sleep(TimeSlab.YIELD);
		
		
		passed("Verify the Invoice",
				"Invoice should be displayed successfully",
				"Invoice is displayed successfully");
		output.put("Invoice", invoicenum);

	}

	/****************************************
	 * Name: NaviagteToBillingSchedule
	 * Description: NaviagteToBillingSchedule
	 * Date: 11-July-2018
	 ****************************************/
	public void Multibilling(DataRow input, DataRow output) {
		uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billing");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billingschedules");
		SleepUtils.sleep(TimeSlab.HIGH);
		String accRows1 = input.get("num");
		SleepUtils.sleep(TimeSlab.YIELD);

		int accRows = Integer.parseInt(accRows1);
		
		String pages=uiDriver.getValue("//*[@id=\"contract-billing-schedules-grid\"]/div[5]/ul/li[2]/span");
		

		if (pages.contains("1")) {
			passed("Billing Schedule displayed ",
					"No. of Billing Schedule Should be displayed as" + accRows+ "",
					"No. of Billing Schedule is displayed"+ accRows + "");
		} else {
			failed("Billing Schedule not displayed",
					"Billing Schedule Should be displayed",
					"Billing Schedule is not displayed");
		}
		String actualproject = uiDriver.getValue("project");
		String actualamount = uiDriver.getValue("Amount");
		String actualduedate = uiDriver.getValue("DueDate");
		if (input.get("projects").contains(actualproject)|| actualproject.contains(input.get("projects"))) {
			passed("Validating Project",
				   "Project Should be displayed as '"+ input.get("projects") + "' successfully",
					"Project is  displayed as '" + actualproject+ "' successfully");
		} else {
			failed("Validating Project",
					"Project Flag Should be displayed as '"+ input.get("projects") + "' successfully",
					"Project Flag is  not displayed as '" + actualproject+ "' successfully");
		}

		if (input.get("Amount").contains(actualamount)) {
			passed("Validating Amount",
				   "Amount Should be displayed as '"+ input.get("Amount") + "' successfully",
					"Amount is  displayed as '" + actualamount+ "' successfully");
		} else {
			failed("Validating Amount",
					"Amount Should be displayed as '"+ input.get("Amount") + "' successfully",
					"Amount is  not displayed as '" + actualamount+ "' successfully");
		}
		if (input.get("DueDate").contains(actualduedate)) {
			passed("Validating Due Date", 
					"Due Date Should be displayed as '"+ input.get("DueDate") + "' successfully",
					"Due Date is  displayed as '" + actualduedate+ "' successfully");
		} else {
			failed("Validating Due Date", 
					"Due Date Should be displayed as '"	+ input.get("DueDate") + "' successfully",
					"Due Date is  displayed as '" + actualduedate+ "' successfully");	
			}

		output.put("num", accRows1);
	}

	/****************************************
	 * Name:NavigatetoContractDetailPage
	 * Description:Navigate to Contract
	 * Date:11-July-2018
	 ******AddFMVFilmTrack
**********************************/
	public void NavigatetoContractDetailPage(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Contracts");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("SearchContract");
		uiDriver.setValue("ContractSearch", input.get("contract"));
		SleepUtils.sleep(TimeSlab.LOW);
		passed("Contracts info", "Contracts info Should be displayed",
				"Contracts info is displayed");
		uiDriver.click("Search");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("ContractID");
		// SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
//		SleepUtils.sleep(TimeSlab.MEDIUM);
		if (uiDriver.checkPage("Contract - Details")) {

			passed("Verify the ContractDetailsPage",
					"ContractDetailsPage should be displayed Successfully",
					"ContractDetailsPage is displayed Successfully");

		} else {
			failed("Verify the ContractDetailsPage",
					"ContractDetailsPage should be displayed Successfully",
					"ContractDetailsPage is not displayed Successfully");

		}

	}

	/****************************************
	 * Name: ChangeStatusToProcessContract
	 * Description:ChangeStatusToProcessContract
	 * Date: 11-July-2018
	 ****************************************/
	public void ChangeStatusToProcessContract(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("StatusChange");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_WorkflowStateChangeCtrl_NextWorkflowStatesList_Arrow']");
		SleepUtils.sleep(TimeSlab.YIELD);
		String StatusInput = uiDriver.getDyanmicData("Status");
		String Status = StatusInput.replace("#", input.get("Status"));
		String CurrentStatus = uiDriver.getValueByText(Status);
		uiDriver.click_dynamic(Status);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.handleAlert("", "OK");
		SleepUtils.sleep(TimeSlab.HIGH);
		while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
			SleepUtils.sleep(TimeSlab.YIELD);
		}
		if (input.get("Status").equalsIgnoreCase(CurrentStatus)) {

			passed("Verify the Status " + CurrentStatus + " ",
					"Status should be Clicked Successfully as" + CurrentStatus+ "", 
					"Status is Clicked Successfully as"+ CurrentStatus + "");
		} else {

			failed("Verify the Status " + CurrentStatus + "",
					"Status should be Clicked Successfully as" + CurrentStatus+ "",
					"Status is not Clicked Successfully as"	+ CurrentStatus + "");

		}
	}
	
	
	public void GenerateBillingShedule28(DataRow input, DataRow output) throws AWTException
	{
	Actions action1 = new Actions(uiDriver.webDr);

	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("Finance");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("Billing");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("Billingschedules");
	SleepUtils.sleep(TimeSlab.MEDIUM);
	uiDriver.click("GenerateSchedule");
	SleepUtils.sleep(TimeSlab.HIGH);
	//SleepUtils.sleep(TimeSlab.HIGH);
	//if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Enter Schedule Item Information']")) {
//		passed("Generate Billing Schedule",
//				"Enter Schedule Item Information window should be displayed",
//				"Enter Schedule Item Information window is displayed");
	//} else {
//		failed("Generate Billing Schedule",
//				"Enter Schedule Item Information window should be displayed",
//				"Enter Schedule Item Information window is not displayed");
	//}

	uiDriver.click("Scheduleitem");
	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("//li[contains(text(),'"+input.get("Generate Schedule Item")+"')]");

	uiDriver.click("//*[@id='step1Form']/div[7]/div[2]/span[1]/span/span[2]");
	SleepUtils.sleep(5);
	uiDriver.click("//li[text()='"+input.get("billinggroup")+"']");
	SleepUtils.sleep(2);
	uiDriver.click("Next");
	SleepUtils.sleep(TimeSlab.LOW);
	//if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Enter Schedule Item Information']")) {
//		passed("Generate Billing Schedule",
//				"Enter Schedule Item Information window should be displayed",
//				"Enter Schedule Item Information window is displayed");
	//} else {
//		failed("Generate Billing Schedule",
//				"Enter Schedule Item Information window should be displayed",
//				"Enter Schedule Item Information window is not displayed");
	//}

	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("//strong[text()='Aggregate Function:']//..//..//following-sibling::div//span");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("//li[text()='"+input.get("Aggregate Function")+"']");

	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("//strong[text()='Evaluation Order:']//..//..//following-sibling::div//span");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("//li[text()='"+input.get("Evaluation Order")+"']");

	SleepUtils.sleep(TimeSlab.YIELD);
	if(input.get("Force last statement").equalsIgnoreCase("Yes")) {
		uiDriver.click("//strong[text()='Force last statement to use end date?:']//..//..//following-sibling::div//input");
	} else {
		// DO NOTHING
	}

	SleepUtils.sleep(TimeSlab.YIELD);
	if(input.get("Prorate first and last").equalsIgnoreCase("Yes")) {
		uiDriver.click("//strong[text()='Prorate first and last?:']//..//..//following-sibling::div//input");
	} else {
		// DO NOTHING
	}

	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("//strong[text()='Reallocation Method:']/../../following-sibling::div/span/span[1]");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("//*[@id='feeCalcsReallocationMethod_listbox']//li[text()='None']");

	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("//strong[text()='Days Threshold:']//..//..//following-sibling::div//span");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("//*[@id='feeCalcsThreshold_listbox']//li[text()='None']");

	String percent=input.get("percentage");
	//uiDriver.click("//*[@id='feeCalcsModifierPercent']/../input[1]");

	/*SleepUtils.sleep(TimeSlab.YIELD);
	Robot ref = new Robot();
	ref.keyPress(KeyEvent.VK_CONTROL);
	ref.keyPress(KeyEvent.VK_A);
	ref.keyPress(KeyEvent.VK_BACK_SPACE);
	ref.keyRelease(KeyEvent.VK_CONTROL);
	ref.keyRelease(KeyEvent.VK_A);
	ref.keyRelease(KeyEvent.VK_BACK_SPACE);
	ref.keyPress(KeyEvent.VK_2);
	ref.keyRelease(KeyEvent.VK_2);
	ref.keyPress(KeyEvent.VK_5);
	ref.keyRelease(KeyEvent.VK_5);*/


	uiDriver.sendKey("tab");
	uiDriver.click("//*[@id='feeCalcsModifierPercent']/../input[1]");
	uiDriver.sendKey("backspace");
	uiDriver.sendKey("backspace");
	uiDriver.sendKey("backspace");
	uiDriver.setText(percent);
	uiDriver.sendKey("enter");
	SleepUtils.sleep(TimeSlab.LOW);
	//uiDriver.setValue("//input[@id='feeCalcsModifierPercent']", input.get("percentage"));

	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.ScrollPageDown();
	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("Add");

	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("(((//tbody[@role='rowgroup']//tr)[1]//td)[1]//span)[1]");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("//li[text()='"+input.get("Calculation Trigger1")+"']");

	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("((//tbody[@role='rowgroup']//tr)[1]//td)[2]");
	uiDriver.click("(((//tbody[@role='rowgroup']//tr)[1]//td)[2]//span)[1]");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("//li[text()='"+input.get("Date Value1")+"']");

	if(input.get("Offset1").equalsIgnoreCase("NA")) {
	// DO NOTHING	
	} else {
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("((//tbody[@role='rowgroup']//tr)[1]//td)[3]");
	String Offset1=input.get("Offset1");
	uiDriver.sendKey("backspace");
	uiDriver.setText(Offset1);
	uiDriver.sendKey("enter");
	uiDriver.sendKey("tab");
	}

	if(input.get("Modifier1").equalsIgnoreCase("NA")) {
	// DO NOTHING	
	} else {
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("((//tbody[@role='rowgroup']//tr)[1]//td)[4]");
	String Modifier1=input.get("Modifier1");
	uiDriver.sendKey("backspace");
	uiDriver.sendKey("backspace");
	uiDriver.sendKey("backspace");
	uiDriver.setText(Modifier1);
	uiDriver.sendKey("enter");
	uiDriver.sendKey("tab");
	}

	if(input.get("Prorated As Of Date1").equalsIgnoreCase("NA")) {
	// DO NOTHING	
	} else {
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("(((//tbody[@role='rowgroup']//tr)[1]//td)[1]//span)[1]");
	uiDriver.click("(((//tbody[@role='rowgroup']//tr)[1]//td)[2]//span)[1]");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("//li[text()='"+input.get("Prorated As Of Date1")+"']");
	}

	/*if(input.get("Calculation Trigger2").equalsIgnoreCase("NA")) {
		// Do nothing
	} else {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Add");
		
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("(((//tbody[@role='rowgroup']//tr)[1]//td)[1]//span)[1]");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//li[text()='"+input.get("Calculation Trigger2")+"']");
		
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("((//tbody[@role='rowgroup']//tr)[1]//td)[2]");
		uiDriver.click("(((//tbody[@role='rowgroup']//tr)[1]//td)[2]//span)[1]");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//li[text()='"+input.get("Date Value2")+"']");
		
		if(input.get("Offset2").equalsIgnoreCase("NA")) {
		// DO NOTHING	
		} else {
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("((//tbody[@role='rowgroup']//tr)[1]//td)[3]");
		String Offset1=input.get("Offset2");
		uiDriver.sendKey("backspace");
		uiDriver.setText(Offset1);
		uiDriver.sendKey("enter");
		uiDriver.sendKey("tab");
		}
		
		if(input.get("Modifier2").equalsIgnoreCase("NA")) {
		// DO NOTHING	
		} else {
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("((//tbody[@role='rowgroup']//tr)[1]//td)[4]");
		String Modifier1=input.get("Modifier2");
		uiDriver.sendKey("backspace");
		uiDriver.setText(Modifier1);
		uiDriver.sendKey("enter");
		uiDriver.sendKey("tab");
		}
		
		if(input.get("Prorated As Of Date2").equalsIgnoreCase("NA")) {
		// DO NOTHING	
		} else {
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("((//tbody[@role='rowgroup']//tr)[1]//td)[5]");
		String ProratedDate2=input.get("Prorated As Of Date2");
		uiDriver.sendKey("backspace");
		uiDriver.setText(ProratedDate2);
		uiDriver.sendKey("enter");
		uiDriver.sendKey("tab");
		}
		
	}*/

		uiDriver.click("Savechanges");
	if(uiDriver.checkElementPresent("//*[contains(text(),'Save Successful')]")) {
		passed("Generate Billing Schedule",
				"Enter Schedule Item Information should be successful",
				"Enter Schedule Item Information is successful");
	} else {
		failed("Generate Billing Schedule",
				"Enter Schedule Item Information should be successful",
				"Enter Schedule Item Information is not successful");
	}	

	uiDriver.click("Next");
	SleepUtils.sleep(TimeSlab.HIGH);
	while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
		SleepUtils.sleep(TimeSlab.YIELD);
	}
	//if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Manually Add Schedule Items']")) {
//		passed("Generate Billing Schedule",
//				"Manually Add Schedule Items window should be displayed",
//				"Manually Add Schedule Items window is displayed");
	//} else {
//		failed("Generate Billing Schedule",
//				"Manually Add Schedule Items window should be displayed",
//				"Manually Add Schedule Items window is not displayed");
	//}
	uiDriver.executeJavaScript("scroll(0,0)");
	SleepUtils.sleep(TimeSlab.YIELD);
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("//div[@id='manualGrid']//a[text()='Add']");

	if(input.get("term").equalsIgnoreCase("NA")) {
	// DO NOTHING	
	} else {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.sendKey("tab");
		String CalcMethod=input.get("term");
		uiDriver.setText(CalcMethod);
		uiDriver.sendKey("enter");
	}

	if(input.get("amount").equalsIgnoreCase("NA")) {
	// DO NOTHING	
	} else {
	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.sendKey("tab");
	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.sendKey("tab");
	String Amount=input.get("amount");
	uiDriver.setText(Amount);
	uiDriver.sendKey("enter");
	}
	if(input.get("date").equalsIgnoreCase("NA")) {
		// DO NOTHING	
		} 
	else{
	SleepUtils.sleep(TimeSlab.HIGH);
	uiDriver.click("Duedate");
	uiDriver.setValue("Duedate1",input.get("date"));
	uiDriver.sendKey("enter");
	}
	if(input.get("Category").equalsIgnoreCase("NA")) {
	// DO NOTHING	
	} else {
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("((//tbody[@role='rowgroup']//tr)[2]//td)[11]");
		uiDriver.click("(((//tbody[@role='rowgroup']//tr)[2]//td)[11]//span)[1]");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//ul[@aria-hidden='false']//li[text()='"+input.get("Category")+"']");
		SleepUtils.sleep(TimeSlab.YIELD);
	}

	uiDriver.click("//div[@id='stepManual']//*[text()='Save changes']");
	if(uiDriver.checkElementPresent("//*[contains(text(),'Save Successful')]")) {
		passed("Generate Billing Schedule",
				"Add Schedule Item should be successful",
				"Add Schedule Item is successful");
	} else {
		failed("Generate Billing Schedule",
				"Add Schedule Item should be successful",
				"Add Schedule Item is not successful");
	}	

	uiDriver.click("Next");
	SleepUtils.sleep(TimeSlab.HIGH);
	while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
		SleepUtils.sleep(TimeSlab.YIELD);
	}
	if(uiDriver.checkElementPresent("//*[@id='stepProjects']//*[contains(text(),'Enter Project Allocations')]")) {
		passed("Generate Billing Schedule",
				"Enter Projects Allocations window should be displayed",
				"Enter Projects Allocations window is displayed");
	} else {
		failed("Generate Billing Schedule",
				"Enter Projects Allocations window should be displayed",
				"Enter Projects Allocations window is not displayed");
	}

	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("//span[@class='k-pager-sizes k-label']//span[@class='k-input']");
	SleepUtils.sleep(1);
	uiDriver.click("//li[text()='All']");
	/*try {
		List<WebElement> list1 = uiDriver.webDr.findElements(By.xpath("//div[@class='k-list-scroller']//ul[@aria-hidden='false']//li"));
		SleepUtils.sleep(TimeSlab.YIELD);
		int size = list1.size();
		SleepUtils.sleep(TimeSlab.YIELD);
		if(size > 0) {
			list1.get(size-1).click();
			SleepUtils.sleep(TimeSlab.HIGH);
		}
	} catch(Exception e) {			
	}*/

	/*for(int i=0; i<10; i++) {	
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.ScrollPageUp();
		SleepUtils.sleep(TimeSlab.YIELD);
	}*/

	uiDriver.click("//input[@class='include-check-all']");
	SleepUtils.sleep(TimeSlab.HIGH);
	SleepUtils.sleep(TimeSlab.HIGH);
	while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
		SleepUtils.sleep(TimeSlab.YIELD);
	}
	if(input.get("Name").equalsIgnoreCase("NA")) {			
	// DO NOTHING
	} else {
	uiDriver.click("Filter");
	uiDriver.setValue("Textfield",input.get("subtitle"));
	uiDriver.click("Filterbar");
	SleepUtils.sleep(TimeSlab.YIELD);
	SleepUtils.sleep(TimeSlab.YIELD);
	String titles = uiDriver.getDyanmicData("Title");
	String Actualtitle = titles.replace("#", input.get("Name"));
	uiDriver.click(Actualtitle);
	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.executeJavaScript("scroll(0,0)");

	uiDriver.click("Filter");
	SleepUtils.sleep(TimeSlab.LOW);
	try{
	uiDriver.click("//button[text()='Clear']");
	SleepUtils.sleep(TimeSlab.YIELD);
	SleepUtils.sleep(TimeSlab.YIELD);
	}
	catch(Exception e){
		uiDriver.click("(//*[text()='Clear'])[2]");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.YIELD);
	}
	while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
		SleepUtils.sleep(TimeSlab.YIELD);
	}
	}
	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("Next");
	SleepUtils.sleep(TimeSlab.HIGH);
	while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
		SleepUtils.sleep(TimeSlab.YIELD);
	}	
	//if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Enter Territories Allocations']")) {
//		passed("Generate Billing Schedule",
//				"Enter Territories Allocations window should be displayed",
//				"Enter Territories Allocations window is displayed");
	//} else {
//		failed("Generate Billing Schedule",
//				"Enter Territories Allocations window should be displayed",
//				"Enter Territories Allocations window is not displayed");
	//}

	/*WebElement ele = uiDriver.webDr.findElement(By
			.xpath("//*[@id='stepTerritories']//input[1]"));

	uiDriver.click("//div[@id='territoriesGrid']//input[@class='check-all']");
	SleepUtils.sleep(TimeSlab.LOW);
	action1.click(ele);
	SleepUtils.sleep(TimeSlab.YIELD);
	action1.sendKeys(ele, "").build().perform();
	action1.sendKeys(ele, "0.00").build().perform();
	SleepUtils.sleep(TimeSlab.YIELD);
	try{
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//div[@class='territory allocation-toolbar']//button[text()='Spread']");
		}
		catch(Exception e){
			uiDriver.click("//div[@class='rights allocation-toolbar']//button[text()='Spread']");
		}
	SleepUtils.sleep(TimeSlab.LOW);

	uiDriver.click("//*[@title='"+input.get("Territories")+"']/preceding::input[1]");
	for(int i=0; i<10; i++) {	
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.ScrollPageUp();
		SleepUtils.sleep(TimeSlab.YIELD);
	}
	action1.click(ele);
	SleepUtils.sleep(TimeSlab.YIELD);
	action1.sendKeys(ele, "").build().perform();
	SleepUtils.sleep(TimeSlab.YIELD);
	action1.sendKeys(ele, input.get("TerrPercent")).build().perform();
	SleepUtils.sleep(TimeSlab.YIELD);

	try{
	uiDriver.click("//div[@class='territory allocation-toolbar']//button[text()='Spread']");
	}
	catch(Exception e){
		uiDriver.click("//div[@class='rights allocation-toolbar']//button[text()='Spread']");
	}
	SleepUtils.sleep(TimeSlab.LOW);*/
	uiDriver.click("Next");
	SleepUtils.sleep(TimeSlab.HIGH);
	while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
		SleepUtils.sleep(TimeSlab.YIELD);
	}
	//if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Enter Rights Allocations']")) {
//		passed("Generate Billing Schedule",
//				"Enter Rights Allocations window should be displayed",
//				"Enter Rights Allocations window is displayed");
	//} else {
//		failed("Generate Billing Schedule",
//				"Enter Rights Allocations window should be displayed",
//				"Enter Rights Allocations window is not displayed");
	//}


	/*ele = uiDriver.webDr.findElement(By
			.xpath("//*[@id='stepRights']//input[1]"));

	uiDriver.click("//div[@id='rightsGrid']//input[@class='check-all']");
	SleepUtils.sleep(TimeSlab.LOW);
	action1.click(ele);
	SleepUtils.sleep(TimeSlab.YIELD);
	action1.sendKeys(ele, "").build().perform();
	action1.sendKeys(ele, "0.00").build().perform();
	SleepUtils.sleep(TimeSlab.YIELD);
	try{
		uiDriver.click("//div[@class='territory allocation-toolbar']//button[text()='Spread']");
		}
		catch(Exception e){
			uiDriver.click("//div[@class='rights allocation-toolbar']//button[text()='Spread']");
		}
	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("//div[@id='rightsGrid']//input[@class='check-all']");
	SleepUtils.sleep(TimeSlab.LOW);
	action1.click(ele);
	SleepUtils.sleep(TimeSlab.YIELD);
	action1.sendKeys(ele, "").build().perform();
	action1.sendKeys(ele, input.get("RightPercent")).build().perform();
	SleepUtils.sleep(TimeSlab.YIELD);
	try{
		uiDriver.click("//div[@class='territory allocation-toolbar']//button[text()='Spread']");
		}
		catch(Exception e){
			uiDriver.click("//div[@class='rights allocation-toolbar']//button[text()='Spread']");
		}*/
	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("Finish");
	SleepUtils.sleep(TimeSlab.HIGH);
	while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
		SleepUtils.sleep(TimeSlab.YIELD);
	}

	if(uiDriver.checkElementPresent("//a[contains(text(),'Recalculate All')]")) {
		passed("Generate Billing Schedule",
				"Billing schedule should generate",
				"Billing schedule is generated suscessfully");
	} else {
		passed("Generate Billing Schedule",
				"Billing schedule should generate",
				"Billing schedule is not generated suscessfully");
	}

	}
	
	
	
	
	
	
	
	
	/****************************************
	 * Name: AddCard
	 * Description: AddCard
	 * Date: 11-July-2018
	 *************************************/

	
	public void AddCard(DataRow input, DataRow output) throws InterruptedException 
	{ 
		
		uiDriver.click("//a[text()='Add Card']");
		SleepUtils.sleep(TimeSlab.LOW);		 
		uiDriver.click("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_ContractCardEdit1_ProjectAssignmentGrid_ctl00_ctl02_ctl00_AddProjectRecordImage']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setFrame("//iframe[@name='ProjectSelectionWindow']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("//input[@id='NameTxt']", input.get("ProjectName"));
		//uiDriver.setValue("ProjectName",input.get("ProjectName"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//*[@id='MultiProjectSelectTree']/div[2]/div/ul/li/div/span[1]/input");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//button[text()='Add Selected �']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//*[@id='ctl00_MainContent_FinishButton']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.resetFrame();
		if(uiDriver.checkElementPresent("//td[@title='"+input.get("ProjectName")+"']")){
			passed("AddProjectInAddCard",
					input.get("ProjectName")+" Should be present",
					input.get("ProjectName")+" is checked Successfully");
			}
			else{
				failed("AddProjectInAddCard ",
						input.get("ProjectName")+" Should be present",
						input.get("ProjectName")+" is not present");
			}
		uiDriver.click("//span[text()='Add/Update']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setFrame("//*[@id='RadWindowWrapper_ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_ContractCardEdit1_TerritorySelectionWindow']/table/tbody/tr[2]/td[2]/iframe");
		SleepUtils.sleep(TimeSlab.LOW);
		//uiDriver.click("//*[@id='ctl00_MainContent_TerritorySelectionControl_TerritoryTree']/ul/li[29]/div/span[2]");
		SleepUtils.sleep(TimeSlab.LOW);
		//uiDriver.click("//*[@id='ctl00_MainContent_TerritorySelectionControl_TerritoryTree']/ul/li[29]/ul/li[3]/div/span[2]");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//span[text()='"+input.get("Territory")+"']/../..//input");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//*[@id='ctl00_MainContent_TerritorySelectionControl_AddButton']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//*[@id='ctl00_MainContent_OkButton']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.resetFrame();
		if(uiDriver.checkElementPresent("//td[contains(text(),'"+input.get("Territory")+"')]")){
			passed("AddTerritoryInAddCard",
					input.get("Territory")+" Should be present",
					input.get("Territory")+" is checked Successfully");
			}
			else{
				failed("AddTerritoryInAddCard ",
						input.get("Territory")+" Should be present",
						input.get("Territory")+" is not present");
			}
		uiDriver.click("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_ContractCardEdit1_RightGroupAssignmentGrid_ctl00_ctl02_ctl00_AddRightLinkButton']/div[1]");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setFrame("//iframe[@name='RightSelectionWindow']");		
		try{
			List <WebElement> list_ExpandIcons = uiDriver.webDr.findElements(By.xpath("//div[@id='rightSelectionDiv']//span[@class='rtPlus']"));
			for(int i=0; i<list_ExpandIcons.size(); i++) {
				list_ExpandIcons.get(i).click();
			}
		} catch(Exception e){
			e.printStackTrace();
		}		
		uiDriver.click("//span[text()='"+input.get("Rights")+"']/../../label/input");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.ScrollPageUp();
		uiDriver.click("//*[@id='ctl00_MainContent_RightSelectionControl_AddButton']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("//*[@id='ctl00_MainContent_StartDateEdit_dateInput']", input.get("StartDate"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("//*[@id='ctl00_MainContent_EndDateEdit_dateInput']", input.get("EndDate"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//*[@id='ctl00_MainContent_IsStartDateEst']");
		uiDriver.click("//*[@id='ctl00_MainContent_IsEndDateEst']");
		uiDriver.click("//*[@id='ctl00_MainContent_OkButton']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.resetFrame();
		if(uiDriver.checkElementPresent("//td[contains(text(),'"+input.get("Rights")+"')]")){
			passed("AddRightsInAddCard",
					input.get("Rights")+" Should be present",
					input.get("Rights")+" is checked Successfully");
			}
			else{
				failed("AddRightsInAddCard ",
						input.get("Rights")+" Should be present",
						input.get("Rights")+" is not present");
			}
		uiDriver.click("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_ContractCardEdit1_LicenseTypeEdit_Arrow']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//li[text()='Non-Exclusive']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_ContractCardEdit1_SaveButton']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.resetFrame();
		if(uiDriver.checkElementPresent("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_ContractCardEdit1_SaveButton']")){
			passed("SavingAddCard",
					"AddCard should be successful",
					"AddCard is successful");
		}
		else{
			failed("SavingAddCard ",
					"AddCard should be successful",
					"AddCard is not successful");
		}
	}		
	

	/****************************************
	 * Name: VerifyNewlyGeneratedCustomerCredit
	 * Description:VerifyNewlyGeneratedCustomerCredit 
	 * Date: 31-October-2018
	 ****************************************/
	public void VerifyNewlyGeneratedCustomerCredit(DataRow input, DataRow output) {

		uiDriver.click("RelatedRecords");
		SleepUtils.sleep(TimeSlab.YIELD);
		String RevenueArrangement = uiDriver.getValueByText("RevenueArrangement");
		passed("Verify the Status " + RevenueArrangement + " ",
				"RevenueArrangement is displayed as" + RevenueArrangement+ "",
				"Newly Generated Customer Credit is Successfully displayed as"+ RevenueArrangement + "");
		
	}
	
	/****************************************
	 * Name: Update Deal Type
	 * Description:Update Deal Type 
	 * Date:11-July-2018
	 ****************************************/
	public void UpdateDealType1(DataRow input, DataRow output) {

		uiDriver.setValue("DealType", input.get("DealType"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("SaveDeal");
	}

	/****************************************
	 * Name: Billing Schedule
	 * Description:Billing Schedule
	 * Date:11-July-2018
	 ****************************************/
	public void BillingSchedule(DataRow input, DataRow output) {

		uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billing");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billingschedules");
		SleepUtils.sleep(TimeSlab.MEDIUM);
	}

	/****************************************
	 * Name: NavigateToAllocationRules
	 * Description: NavigateToAllocationRules
	 * Date: 11-July-2018
	 ****************************************/
	public void NavigateToAllocationRules(DataRow input, DataRow output) {
//		String test = input.get("numbill");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("AllocationRule");
		SleepUtils.sleep(TimeSlab.YIELD);
		if(uiDriver.checkElementPresent("//a[text()='Add Allocation Rule']")) {
			passed("NavigateToAllocationRules", "Allocation Rule window should be displayed", 
					"Allocation Rule window is displayed");
		} else {
			failed("NavigateToAllocationRules", "Allocation Rule window should be displayed", 
					"Allocation Rule window is displayed");
		}
	}

	/****************************************
	 * Name: AddAllocationRules 
	 * Description: AddAllocationRules Date:
	 * 11-July-2018
	 ****************************************/
	public void AddAllocationRules(DataRow input, DataRow output) {
		uiDriver.click("AddAllocationButton");
		String Name = input.get("Name");
		uiDriver.setValue("Name", Name);
		uiDriver.setValue("Note", input.get("Note"));
		uiDriver.click("InvoiceItemCategory");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("InvoiceItemCategoryInput");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Territories");
		uiDriver.click("Rights");
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.executeJavaScript("document.getElementsByClassName('k-formatted-value k-input')[0].value=100;");
		Actions action = new Actions(uiDriver.webDr);
		WebElement ele = uiDriver.webDr.findElement(By.xpath("//*[@id='allocationWidget']/div/span/span/input[1]"));
		action.sendKeys("ele", "").build().perform();
		action.sendKeys(ele, "100.00").build().perform();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("NameChkBox");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("NameChkBoxNext");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Finish");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		output.put("Name", Name);

	}

	/****************************************
	 * Name: AddAllocationRulesTerritory NavigateToBillingSchedule

	 * Description: AddAllocationRules Date:
	 * 12-November-2018
	 ****************************************/
	public void AddAllocationRulesTerritory(DataRow input, DataRow output) {
		
		//Deleting Default Allocation
		SleepUtils.sleep(TimeSlab.HIGH);
		if(uiDriver.checkElementPresent("(//td[contains(text(),'Default')]//..//td//input[@type='image'])[2]")) {
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("(//td[contains(text(),'Default')]//..//td//input[@type='image'])[2]");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.handleAlert("", "OK");
			SleepUtils.sleep(TimeSlab.LOW);
		}
		
		uiDriver.click("button_AddAllocationRule");
		SleepUtils.sleep(TimeSlab.HIGH);
		if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Enter Allocation Rule Information']")) {
			passed("Add Allocation Rules Territory",
					"Enter Allocation Rule Information window should be displayed",
					"Enter Allocation Rule Information window is displayed");
		} else {
			failed("Add Allocation Rules Territory",
					"Enter Allocation Rule Information window should be displayed",
					"Enter Allocation Rule Information window is not displayed");
		}
		String Name = input.get("Name");
		uiDriver.setValue("Name", Name);
		SleepUtils.sleep(TimeSlab.YIELD);
		//uiDriver.setValue("Note", input.get("Note"));
		uiDriver.click("Note");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("InvoiceItemCategory");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//li[contains(text(),'"+input.get("Invoice Item Category")+"')]");
		SleepUtils.sleep(TimeSlab.YIELD);
		//uiDriver.click("InvoiceItemCategoryInput");
		//SleepUtils.sleep(TimeSlab.YIELD);
		if(input.get("Territories").trim().toLowerCase().equals("yes")) {			
			uiDriver.click("Territories");
			SleepUtils.sleep(TimeSlab.YIELD);
		}	
		if(input.get("Languages").trim().toLowerCase().equals("yes")) {			
			uiDriver.click("Languages");
			SleepUtils.sleep(TimeSlab.YIELD);
		}
		if(input.get("Rights").trim().toLowerCase().equals("yes")) {			
			uiDriver.click("Rights");
			SleepUtils.sleep(TimeSlab.YIELD);
		}
		if(input.get("Channels").trim().toLowerCase().equals("yes")) {			
			uiDriver.click("Channels");
			SleepUtils.sleep(TimeSlab.YIELD);
		}
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Enter Territories Allocations']")) {
			passed("Add Allocation Rules Territory",
					"Enter Territories Allocations window should be displayed",
					"Enter Territories Allocations window is displayed");
		} else {
			failed("Add Allocation Rules Territory",
					"Enter Territories Allocations window should be displayed",
					"Enter Territories Allocations window is not displayed");
		}
		// uiDriver.executeJavaScript("document.getElementsByClassName('k-formatted-value k-input')[0].value=100;");
		Actions action = new Actions(uiDriver.webDr);
		WebElement ele = uiDriver.webDr.findElement(By
				.xpath("//*[@id='allocationWidget']/div/span/span/input[1]"));
		action.sendKeys("ele", "").build().perform();
		SleepUtils.sleep(TimeSlab.YIELD);
		action.sendKeys(ele, input.get("Percent")).build().perform();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//span[@title='"+input.get("TerritoryName")+"']");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.executeJavaScript("scroll(0,-1000)");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Enter Rights Allocations']")) {
			passed("Add Allocation Rules Territory",
					"Enter Rights Allocations window should be displayed",
					"Enter Rights Allocations window is displayed");
		} else {
			failed("Add Allocation Rules Territory",
					"Enter Rights Allocations window should be displayed",
					"Enter Rights Allocations window is not displayed");
		}
		uiDriver.click("//span[@title='"+input.get("RightsName")+"']");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Finish");
		SleepUtils.sleep(TimeSlab.HIGH);
		if(uiDriver.checkElementPresent("//table[contains(@id,'AllocationRulesGrid')]//td[contains(text(),'"+input.get("Name")+"')]")) {
			passed("Add Allocation Rules Territory",
					"Allocation should be added successfully",
					"Allocation should is successfully");
		} else {
			failed("Add Allocation Rules Territory",
					"Allocation should be added successfully",
					"Allocation is not added successfully");
		}
		output.put("Name", Name);

	}
	
	/****************************************
	 * Name: AllocationRuleAssignedToBillingSchedule
	 * Description:AllocationRuleAssignedToBillingSchedule 
	 * Date: 11-July-2018
	 ****************************************/
	public void AllocationRuleAssignedToBillingSchedule(DataRow input,
			DataRow output) {
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Edit");
		uiDriver.executeJavaScript("scroll(900,0)");
		uiDriver.setValue("AllocationRule", input.get("AllocationRule"));
		Boolean Result = uiDriver.webDr.findElement(By.id("TerritoriesCheckbox")).isSelected();
		if (Result.equals(false)) {
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.executeJavaScript("document.getElementById('TerritoriesCheckbox').click();");
		} else {
			// do nothing
		}

		Boolean RightResult = uiDriver.webDr.findElement(
				By.id("RightsCheckbox")).isSelected();
		if (RightResult.equals(false)) {

			uiDriver.click("Rights");
		} else {
			// do nothing
		}
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		Actions action = new Actions(uiDriver.webDr);
		WebElement ele = uiDriver.webDr.findElement(By.xpath("//*[@id='allocationWidget']/div/span/span/input[1]"));
		action.sendKeys("ele", "").build().perform();
		String amount = uiDriver.getValue("Amountfield");
		action.sendKeys(ele, amount).build().perform();
		uiDriver.click("SelectChkBox");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("SelectChkBoxes");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Finish");
		SleepUtils.sleep(TimeSlab.HIGH);

	}

	/****************************************
	 * Name: VerifyCustomerbillingpreference
	 * Description:AllocationRuleAssignedToBillingSchedule
	 * Date: 13-August-2018
	 ****************************************/
	public void VerifyCustomerbilling(DataRow input, DataRow output) {
		String cust = input.get("customer");
		uiDriver.setValue("SearchCust", cust);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Customer");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("preferences");
		WebElement email = uiDriver.webDr.findElement(By.xpath("//*[@id='custentity_nbcu_email_fs']/img"));
		String emailcheckboxvalue = email.getAttribute("alt");
		if (emailcheckboxvalue.equalsIgnoreCase("checked")) {
			passed("Verify Customer delivery preference",
					"Delivery preference Should be set to email",

					"Delivery preference is set to email");

		} else {
			failed("Verify Customer delivery preference",
					"Delivery preference Should be set to email",

					"Delivery preference is not set to email");

		}
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("custom");
		WebElement eastcoastcheckbox = uiDriver.webDr.findElement(By.xpath("(//a[text()='Email'])[2]/../../..//img"));
		String eastcoastcheckboxvalue = eastcoastcheckbox.getAttribute("alt");
		if (eastcoastcheckboxvalue.equalsIgnoreCase("checked")) {
			passed("Verify East coast check box is checked",
					"East coast Should be  to checked",

					"East coast is set to checked");

		} else {
			failed("Verify East coast check box is checked",
					"East coast Should be set to checked",

					"East coast is not set to checked");

		}

	}

	/****************************************
	 * Name: ValidatetheContractNumInNetSuite
	 * Description:ValidatetheContractNumInNetSuite
	 * Date: 11-July-2018
	 ****************************************/
	public void ValidatetheContractNumInNetSuite(DataRow input, DataRow output) {
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();
		// SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();
		String ContractNum = input.get("ContractNum");
		uiDriver.click("QuickSort");
		uiDriver.click("RecentlyCreated");
		String DocNum = uiDriver.getDyanmicData("DocumentNum");
		String DocumentNum = DocNum.replace("#", ContractNum);
		if (uiDriver.checkElementPresent_dynamic(DocumentNum)) {

			passed("Verify the ContractNum",
					"ContractNum Should be displayed Successfully",
					"ContractNum is displayed Successfully");

		} else {
			failed("Verify the ContractNum",
					"ContractNum Should be displayed Successfully",
					"ContractNum is not displayed Successfully");

		}
		uiDriver.click_dynamic(DocumentNum);
		SleepUtils.sleep(TimeSlab.LOW);
		if (uiDriver
				.checkPage("Sales Order - NetSuite (NBCUniversal Media, LLC 10K QA)")) {
			passed("Verify SalesOrderPage",
					"SalesOrder Page Should be displayed Successfully",
					"SalesOrder Page  is displayed Successfully");

		} else {

			failed("Verify SalesOrderPage",
					"SalesOrder Page Should be displayed Successfully",
					"SalesOrder Page is not displayed Successfully");

		}

		String SalesNum = uiDriver.getValue("SalesNum");
		output.put("SalesOrderNum", SalesNum);

	}

	/****************************************
	 * Name:ValidateTheFieldsInNetSuite 
	 * Description ValidatetheContractNumInNetSuite
	 * Date: 11-July-2018
	 ****************************************/
	public void ValidateTheFieldsInNetSuite(DataRow input, DataRow output) {
		String tableRows = uiDriver.getObjMap("tableRows");

		uiDriver.executeJavaScript("scroll(0,500)");
		/* *********Uncomment for scenario 9**** */
		/*
		 * String actualMARKETCODE = uiDriver.getValue(tableRows + nextRow +
		 * uiDriver.getObjMap("marketcode")); String actualItemType =
		 * uiDriver.getValue(tableRows + nextRow+
		 * uiDriver.getObjMap("Itemtype")); String actualRevRecMethod =
		 * uiDriver.getValue(tableRows + nextRow+
		 * uiDriver.getObjMap("RevRecMethod")); String
		 * actualContinuousProduction = uiDriver.getValue(tableRows + nextRow +
		 * uiDriver.getObjMap("ContinuousProduction")); String actualOnNetwork =
		 * uiDriver.getValue(tableRows + nextRow+
		 * uiDriver.getObjMap("OnNetwork"));
		 */
		String Customer = uiDriver.getValue("Customer");
		String Subsidairy = uiDriver.getValue("Subsidairy");
		String Payship = uiDriver.getValue("PayShip");
		String RevisionNumber = uiDriver.getValue("RevisionNumber");
		String InterCompanyFlag = uiDriver.getValue("InterCompanyFlag");
		String LicenseFeeType = uiDriver.getValue("LicenseFeeType");
		String CashBasis = uiDriver.getValue("CashBasis");
		String Status = uiDriver.getValue("Status");

		/*
		 * String Marketcode = input.get("marketCode");
		 * SleepUtils.sleep(TimeSlab.YIELD); if
		 * (Marketcode.contains(actualMARKETCODE.trim())) { passed(
		 * "Verifying the  marketCode", "marketCode should be displayed as '" +
		 * Marketcode + "' Successfully", "marketCode " + actualMARKETCODE +
		 * " is displayed Successfully"); } else { failed(
		 * "Verifying the  marketCode", "marketCode should be displayed as '" +
		 * Marketcode + "' Successfully", "marketCode " + actualMARKETCODE +
		 * " is not displayed Successfully"); }
		 */

		/*
		 * String Itemtype = input.get("Itemtype");
		 * SleepUtils.sleep(TimeSlab.YIELD); if
		 * (Itemtype.contains(actualItemType.trim())) { passed(
		 * "Verifying the  Itemtype", "Itemtype should be displayed as '" +
		 * Itemtype+ "' Successfully", "Itemtype " + actualItemType+
		 * " is displayed Successfully"); } else { failed(
		 * "Verifying the  Itemtype", "Itemtype should be displayed as '" +
		 * Itemtype+ "' Successfully", "Itemtype " + actualItemType+
		 * " is not displayed Successfully"); }
		 * 
		 * String RevRecMethod = input.get("RevRecMethod");
		 * SleepUtils.sleep(TimeSlab.YIELD); if
		 * (RevRecMethod.contains(actualRevRecMethod.trim())) { passed(
		 * "Verifying the  RevRecMethod",
		 * "RevRecMethod should be displayed as '" + RevRecMethod+
		 * "' Successfully", "RevRecMethod " + actualRevRecMethod +
		 * " is displayed Successfully"); } else { failed(
		 * "Verifying the  RevRecMethod",
		 * "RevRecMethod should be displayed as '" + RevRecMethod+
		 * "' Successfully", "RevRecMethod "+ actualRevRecMethod+
		 * " is not displayed Successfully"); }
		 * 
		 * String ContinuousProduction = input.get("ContinuousProduction"); if
		 * (ContinuousProduction.contains(actualContinuousProduction.trim())) {
		 * passed("Verifying the  ContinuousProduction",
		 * "ContinuousProduction should be displayed as '" +
		 * ContinuousProduction + "' Successfully", "ContinuousProduction " +
		 * ContinuousProduction+ " is displayed Successfully"); } else { failed(
		 * "Verifying the  ContinuousProduction",
		 * "ContinuousProduction should be displayed as '" +
		 * ContinuousProduction + "' Successfully", "ContinuousProduction " +
		 * actualContinuousProduction+ " is not displayed Successfully"); }
		 * 
		 * String OnNetwork = input.get("OnNetwork");
		 * SleepUtils.sleep(TimeSlab.YIELD); if
		 * (OnNetwork.contains(actualOnNetwork.trim())) { passed(
		 * "Verifying the  OnNetwork", "OnNetwork should be displayed as '" +
		 * OnNetwork+ "' Successfully", "OnNetwork " + OnNetwork+
		 * " is displayed Successfully"); } else { failed(
		 * "Verifying the  OnNetwork", "OnNetwork should be displayed as '" +
		 * OnNetwork+ "' Successfully", "OnNetwork " + actualOnNetwork+
		 * " is not displayed Successfully"); }
		 */

		SleepUtils.sleep(TimeSlab.YIELD);
		if (input.get("Customer").toLowerCase().trim().contains(Customer.toLowerCase().trim()) 
				|| Customer.toLowerCase().trim().contains(input.get("Customer").toLowerCase().trim())) {
			passed("Verifying the  Customer", "Customer should be displayed as : " + input.get("Customer"),
					"Customer is displayed as : "+Customer);
		} else {
			failed("Verifying the  Customer", "Customer should be displayed as : " + input.get("Customer"),
					"Customer is displayed as : "+Customer);
		}

		SleepUtils.sleep(TimeSlab.YIELD);
		if (input.get("Subsidairy").toLowerCase().trim().contains(Subsidairy.toLowerCase().trim()) 
				|| Subsidairy.toLowerCase().trim().contains(input.get("Subsidairy").toLowerCase().trim())) {
			passed("Verifying the  Subsidairy", "Subsidairy should be displayed as : " + input.get("Subsidairy"),
					"Subsidairy is displayed as : "+Subsidairy);
		} else {
			failed("Verifying the  Subsidairy", "Subsidairy should be displayed as : " + input.get("Subsidairy"),
					"Subsidairy is displayed as : "+Subsidairy);
		}

		SleepUtils.sleep(TimeSlab.YIELD);
		if (input.get("Payship").toLowerCase().trim().contains(Payship.toLowerCase().trim()) 
				|| Payship.toLowerCase().trim().contains(input.get("Payship").toLowerCase().trim())) {
			passed("Verifying the  Payship", "Payship should be displayed as : " + input.get("Payship"),
					"Payship is displayed as : "+Payship);
		} else {
			failed("Verifying the  Payship", "Payship should be displayed as : " + input.get("Payship"),
					"Payship is displayed as : "+Payship);
		}

		SleepUtils.sleep(TimeSlab.YIELD);
		if (input.get("RevisionNumber").toLowerCase().trim().contains(RevisionNumber.toLowerCase().trim()) 
				|| RevisionNumber.toLowerCase().trim().contains(input.get("RevisionNumber").toLowerCase().trim())) {
			passed("Verifying the  RevisionNumber",
					"RevisionNumber should be displayed as : " + input.get("RevisionNumber"),
					"RevisionNumber is displayed as : "+RevisionNumber);
		} else {
			failed("Verifying the  RevisionNumber",
					"RevisionNumber should be displayed as : " + input.get("RevisionNumber"),
					"RevisionNumber is displayed as : "+RevisionNumber);
		}

		SleepUtils.sleep(TimeSlab.YIELD);
		if (input.get("InterCompanyFlag").toLowerCase().trim().contains(InterCompanyFlag.toLowerCase().trim()) 
				|| InterCompanyFlag.toLowerCase().trim().contains(input.get("InterCompanyFlag").toLowerCase().trim())) {
			passed("Verifying the  InterCompanyFlag",
					"InterCompanyFlag should be displayed as : " + input.get("InterCompanyFlag"),
					"InterCompanyFlag is displayed as : "+InterCompanyFlag);
		} else {
			failed("Verifying the  InterCompanyFlag",
					"InterCompanyFlag should be displayed as : " + input.get("InterCompanyFlag"),
					"InterCompanyFlag is displayed as : "+InterCompanyFlag);
		}

		SleepUtils.sleep(TimeSlab.YIELD);
		if (input.get("LicenseFeeType").toLowerCase().trim().contains(LicenseFeeType.toLowerCase().trim()) 
				|| LicenseFeeType.toLowerCase().trim().contains(input.get("LicenseFeeType").toLowerCase().trim())) {
			passed("Verifying the  LicenseFeeType",
					"LicenseFeeType should be displayed as : " + input.get("LicenseFeeType"),
					"LicenseFeeType is displayed as : "+LicenseFeeType);
		} else {
			failed("Verifying the  LicenseFeeType",
					"LicenseFeeType should be displayed as : " + input.get("LicenseFeeType"),
					"LicenseFeeType is displayed as : "+LicenseFeeType);
		}

		SleepUtils.sleep(TimeSlab.YIELD);
		if (input.get("Status").toLowerCase().trim().contains(Status.toLowerCase().trim()) 
				|| Status.toLowerCase().trim().contains(input.get("Status").toLowerCase().trim())) {
			passed("Verifying the  Status", "Status should be displayed as : " + input.get("Status"),
					"Status is displayed as : "+Status);
		} else {
			failed("Verifying the  Status", "Status should be displayed as : " + input.get("Status"),
					"Status is displayed as : "+Status);
		}

		SleepUtils.sleep(TimeSlab.YIELD);
		if (input.get("CashBasis").toLowerCase().trim().contains(CashBasis.toLowerCase().trim()) 
				|| CashBasis.toLowerCase().trim().contains(input.get("CashBasis").toLowerCase().trim())) {
			passed("Verifying the  CashBasis",
					"CashBasis should be displayed as : " + input.get("CashBasis"),
					"CashBasis is displayed as : "+CashBasis);
		} else {
			failed("Verifying the  CashBasis", "CashBasis should be displayed as : " + input.get("CashBasis"),
					"CashBasis is displayed as : "+CashBasis);
		}

	}

	/****************************************
	 * Name: VerifytheLineitemsinNetsuite
	 * Description: ValidateSalesOrder Date:
	 * 11-July-2018
	 ****************************************/
	public void VerifytheLineitemsinNetsuite(DataRow input, DataRow output) {
		List<WebElement> rowitems = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody/tr[contains(@class,'uir-machine-row')]"));
		int rowsize = rowitems.size();
		for(int rown=2;rown<rowsize+1;rown++)
		{
			String Rights = uiDriver.getDyanmicData("Rights");
			String Rights1 = Rights.replace("#", Integer.toString(rown));
			String Rightsvalue = uiDriver.getValueByText(Rights1);
			String MarketCode = uiDriver.getDyanmicData("MarketCode");
			String MarketCode1 = MarketCode.replace("#", Integer.toString(rown));
			String MarketCodevalue = uiDriver.getValueByText(MarketCode1);
			String OnNetworkflag = uiDriver.getDyanmicData("OnNetworkflag");
			String OnNetworkflag1 = OnNetworkflag.replace("#", Integer.toString(rown));
			String OnNetworkflagvalue = uiDriver.getValueByText(OnNetworkflag1);
			if(Rightsvalue.equalsIgnoreCase("FTV"))
			{
				if(MarketCodevalue.equalsIgnoreCase("CNWS"))
				{
					passed("Verifying the  The lines with Free TV rights should have Market Code CNWS",
							"The lines with Free TV rights should have Market Code CNWS",
							"The lines with Free TV rights is having Market Code CNWS");
				}
				else
				{
					failed("Verifying the  The lines with Free TV rights should have Market Code CNWS",
							"The lines with Free TV rights should have Market Code CNWS",
							"The lines with Free TV rights is not having Market Code CNWS");
				}
			}
			if(Rightsvalue.equalsIgnoreCase("BAS"))
			{
				if(MarketCodevalue.equalsIgnoreCase("CNWB"))
				{
					passed("Verifying the  The lines with BAS rights should have Market Code CNWB",
							"The lines with BAS rights should have Market Code CNWB",
							"The lines with BAS rights is having Market Code CNWB");
				}
				else
				{
					failed("Verifying the  The lines with BAS rights should have Market Code CNWB",
							"The lines with BAS rights should have Market Code CNWB",
							"The lines with BAS rights is not having Market Code CNWB");
				}
			}
			
			if(OnNetworkflagvalue.equalsIgnoreCase(input.get("Onnetwork")))
			{
				passed("Verifying the  On network flag",
							"The lines should have On network flag has yes",
							"The lines is having On network flag as yes");
			}
				else
				{
					failed("Verifying the  On network flag",
							"The lines should have On network flag as yes",
							"The lines is NOT having On network flag as yes");
				}
			}
			
		}
		


	/****************************************
	 * Name: ValidateSalesOrder 
	 * Description:ValidateSalesOrder 
	 * Date: 11-July-2018
	 ****************************************/
	public void ValidateSalesOrder(DataRow input, DataRow output) {
		
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("scroll(0,-500)");
		uiDriver.click("ValidateSalesOrder");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		String ContractValidation = uiDriver.getValue_Text("ContractValidation");
		if (ContractValidation.contains("This contract is valid for approval.")) {

			passed("Verifying the  ContractValidation",
					"ContractValidation should be displayed as This contract is valid for approval",
					"ContractValidation is displayed as This contract is valid for approval");
		} else if (ContractValidation
				.contains("This contract is not valid for approval.")) {
			passed("Verifying the  ContractValidation error",
					"ContractValidation should be displayed as"	+ ContractValidation + "",
					"ContractValidation is displayed as" + ContractValidation+ "");
		}

		else {
			failed("Verifying the  ContractValidation",
					"ContractValidation should be displayed as This contract is valid for approval",
					"ContractValidation is not displayed as This contract is valid for approval");
		}

		uiDriver.click("OK");
		SleepUtils.sleep(TimeSlab.HIGH);
		
		

	}

	/****************************************
	 * Name: NavigateToAcceptCustomerPayment 
	 * Description:NavigateToAcceptCustomerPayment
	 * Date: 11-July-2018
	 ****************************************/
	public void NavigateToAcceptCustomerPayment(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("transactions");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("CustomerPay");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("AcceptPayment");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.YIELD);

		uiDriver.click("AcceptPayment");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.YIELD);
		String cust = input.get("customer");
		uiDriver.click("customerdropdownimage");
		SleepUtils.sleep(5);
		uiDriver.click("customerlist");
		SleepUtils.sleep(5);
		uiDriver.setValue("searchcustomerinput", cust);
		SleepUtils.sleep(5);
		uiDriver.click("searchcustomerbutton");
		SleepUtils.sleep(5);
		uiDriver.click("cussearchresult");

	}

	/********************************************
	 * Name: GenerateInvoice
	 * Description: GenerateInvoice
	 * Date: 13-July-2018
	 ****************************************/
	public void GenerateInvoice(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Invoices");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("BulkOperations");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("GenerateInvoices");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Filter");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("searchinput");
		String ContractId = input.get("ContractId");
		uiDriver.setValue("searchinput", input.get("ContractId"));
		// uiDriver.setValue("searchinput", "123178");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//*[@id=\"advancedSearchButton\"]");
		//uiDriver.sendKey("enter");
		//uiDriver.sendKey("enter");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		//uiDriver.executeJavaScript("document.getElementById('checkAllRows').click();");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("//a[text()='Create All']");
		SleepUtils.sleep(TimeSlab.HIGH);
uiDriver.click("//div[@class='actions']//button[text()='Create Invoices']");
		
		uiDriver.click("//*[@id='msg-alert']/a");
		SleepUtils.sleep(TimeSlab.HIGH);
		/*uiDriver.click("//*[@id='generateAll']/div/div[2]/button[2]");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		String invoicenum = uiDriver.getValue("//*[@id='msg-alert']/a");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("InvoiceID");
		SleepUtils.sleep(TimeSlab.YIELD);*/
		passed("Verify the Invoice",
				"Invoice should be displayed successfully",
				"Invoice is displayed successfully");
		//output.put("Invoice", invoicenum);

	}

	/****************************************
	 * Name: Change Invoice Status Description: Change Invoice Status Date:
	 * 13-July-2018
	 ****************************************/
	public void ChangeInvoiceStatus(DataRow input, DataRow output) {

		// uiDriver.click("Menu");
		// SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("Avails");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Invoices");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("BulkOperations");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("ChangeWFStates");
		SleepUtils.sleep(TimeSlab.YIELD);
		String invoicenum = input.get("Invoice");
		// String invoicenum="INV-990";
		String Invoicecheckbox = uiDriver.getDyanmicData("Invoicecheckbox");
		SleepUtils.sleep(TimeSlab.YIELD);
		String InvoiceNumber = Invoicecheckbox.replace("#", invoicenum);
		SleepUtils.sleep(TimeSlab.YIELD);

		String numofpages = uiDriver.getValue("lastpagenum");
		int pagenum = Integer.parseInt(numofpages);
		for (int i = 1; i <= pagenum; i++) {
			if (uiDriver.checkElementPresent_dynamic(InvoiceNumber)) {

				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.click_dynamic(InvoiceNumber);
				break;

			} else {

				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.executeJavaScript("scroll(0,1500)");
				uiDriver.click("nextbutton");
				SleepUtils.sleep(TimeSlab.HIGH);
			}
		}
		// uiDriver.click_dynamic(InvoiceNumber);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.executeJavaScript("scroll(0,-1000)");
		uiDriver.click("Invoicedropdown");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("SendforInvoice");
		uiDriver.click("SendforInvoice");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Transitiontoworkflow");
		passed("Verify the Invoice is posted", 
				"Invoice posted successfully",
				"Invoice posted successfully");

	}

	/****************************************
	 * Name: NavigateToInvoiceList Description: NavigateToInvoiceList Date:
	 * 30-Nov-2017
	 ****************************************/

	public void NavigateToSalesList(DataRow input, DataRow output)
			throws InterruptedException {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setFrame("frame");
		uiDriver.mouseOver("transactions");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("sales");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("enterSalesOrder");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("list");
		passed("Verify the ListPage",
				"ListPage should be displayed successfully",
				"ListPage is displayed successfully");

	}

	/****************************************
	 * Name: ViewInvoiceRecord Description: ViewInvoiceRecord Date: 30-Nov-2017
	 ****************************************/

	public void ViewInvoiceRecord(DataRow input, DataRow output)
			throws InterruptedException {

		/*
		 * String ContractNum = input.get("ContractId");
		 * uiDriver.click("QuickSort"); uiDriver.click("RecentlyCreated");
		 * String DocNum = uiDriver.getDyanmicData("DocumentNum"); String
		 * DocumentNum = DocNum.replace("#", ContractNum);
		 * if(uiDriver.checkElementPresent_dynamic(DocumentNum)){
		 * 
		 * passed("Verify the ContractNum",
		 * "ContractNum Should be displayed Successfully",
		 * "ContractNum is displayed Successfully");
		 * 
		 * } else{ failed("Verify the ContractNum",
		 * "ContractNum Should be displayed Successfully",
		 * "ContractNum is not displayed Successfully");
		 * 
		 * } uiDriver.click_dynamic(DocumentNum);
		 * uiDriver.click("relatedRecord"); uiDriver.click("date");
		 */
		String Status = uiDriver.getValue_Text("Status");
		String InvoiceType = uiDriver.getValue_Text("InvoiceType");
		if (Status.equalsIgnoreCase("Open")) {

			passed("Verifying the Status", "Status should be displayed as "
					+ Status + "  ", "Status is displayed as " + Status + "  ");
		} else {
			passed("Verifying the Status", "Status should be displayed as "
					+ Status + "  ", "Status is not displayed as " + Status
					+ "  ");
		}

		if (InvoiceType.equalsIgnoreCase("Title Invoice")) {

			passed("Verifying the InvoiceType",
					"InvoiceType should be displayed as " + InvoiceType + "  ",
					"InvoiceType is displayed as " + InvoiceType + "  ");
		} else {
			failed("Verifying the InvoiceType",
					"InvoiceType should be displayed as " + InvoiceType + "  ",
					"InvoiceType is not displayed as " + InvoiceType + "  ");
		}

	}
	/****************************************
	 * Name: verifyPaymentunapplied Description: verifyPaymentunapplied Date: 30-Nov-2017
	 ****************************************/
	public void verifyPaymentunapplied(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.click("custom");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.executeJavaScript("scroll(0,1000)");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("tapinvoice");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("payment");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String paymentnum=uiDriver.getValue("paymentvalue");
		String applied=uiDriver.getValue("applied");
		String unapplied=uiDriver.getValue("unapplied");
		String expunapplied=input.get("unapplied");
		if(applied.startsWith("0.00")|unapplied.equalsIgnoreCase(expunapplied))
		{
			passed("Verifying the payment is unapplied",
					"Payment should be unapplied",
					"Payment is unapplied ");
		}
		else
		{
			failed("Verifying the payment is unapplied",
					"Payment should be unapplied",
					"Payment is not unapplied ");

		}
		
		uiDriver.click("custom");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.executeJavaScript("scroll(0,1000)");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("tappayment");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.executeJavaScript("scroll(0,1500)");
		String creditmemo = uiDriver.getValue("creditmemototal");
		String appliedtoinvoice = uiDriver.getValue("appliedtoinvoice");
		if(appliedtoinvoice.startsWith("0.00")|creditmemo.equalsIgnoreCase(expunapplied))
		{
			passed("Verifying the payment is unapplied",
					"Payment should be unapplied",
					"Payment is unapplied ");
		}
		else
		{
			failed("Verifying the payment is unapplied",
					"Payment should be unapplied",
					"Payment is not unapplied ");

		}
		/*uiDriver.click("id");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("//*[text()='llocation Detail']");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Transactions");
		int accRows = uiDriver.webDr
				.findElements(
						By.xpath("//table[@id='recmachcustrecord_nbcu_titleallocpa_payment__tab']/tbody/tr"))
				.size();
		SleepUtils.sleep(TimeSlab.HIGH);
		for (int r = 0; r <= accRows - accRows; r++) {

			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.executeJavaScript("scroll(0,900)");
			SleepUtils.sleep(TimeSlab.HIGH);
			String s1 = uiDriver.getDyanmicData("DynamicTapid");
			SleepUtils.sleep(TimeSlab.HIGH);
			String s2 = s1.replace("#", Integer.toString(r));
			SleepUtils.sleep(TimeSlab.HIGH);
			if (uiDriver.checkElementPresent_dynamic(s2))
				SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click_dynamic(s2);
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.executeJavaScript("scroll(0,300)");
			SleepUtils.sleep(TimeSlab.HIGH);
			WebElement w = uiDriver.webDr.findElement(By.xpath("//*[text()='llocation Detail']"));
			String id = w.getAttribute("id");
		SleepUtils.sleep(TimeSlab.HIGH);
		//uiDriver.executeJavaScript("scroll(0,-1000)");
		//if(uiDriver.checkElementPresent_dynamic("reclassJEntry")){
		uiDriver.executeJavaScript("document.getElementById('"+id+"').click();");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Transactions");
			SleepUtils.sleep(TimeSlab.HIGH);
			List<WebElement> Journal = uiDriver.webDr
					.findElements(By
							.xpath("//*[@id='recmachcustbody_nbcu_titleallocation__tab']/tbody//tr"));
			SleepUtils.sleep(TimeSlab.HIGH);
			int Journals = Journal.size();
			for (int i = 0; i < Journals; i++) {

				SleepUtils.sleep(TimeSlab.HIGH);
				String JournalLink = uiDriver.getDyanmicData("Journal");
				String JournalLinkValue = JournalLink.replace("#",
						Integer.toString(i));
				uiDriver.click_dynamic(JournalLinkValue);
				SleepUtils.sleep(TimeSlab.HIGH);
				int invoiceRow = 2;
				SleepUtils.sleep(TimeSlab.HIGH);
				if (uiDriver.getValue(
						"//*[@id='line_splits']//tbody/tr[" + invoiceRow
								+ "]/td[1]").contains(
						"110051XX Generic Billed AR")||uiDriver.getValue(
						"//*[@id='line_splits']//tbody/tr[" + (invoiceRow + 1)
								+ "]/td[1]").contains(
						"11015052 Canada Cash Clearing")) {

					if (uiDriver.getValue(
							"//*[@id='line_splits']//tbody/tr[" + invoiceRow
									+ "]/td[2]").equals(""))

					{

						failed("Validating Debit Amount",

						"Validating Debit Amount should be successfull",

						"Debit amount is not Deferred Rev -Generic ");
					}

					else

					{

						passed("Debit is Deferred Rev - Generic",

								"Debit is Deferred Rev - Generic",

								"110051XX Generic Billed AR");
					}

				}

				SleepUtils.sleep(TimeSlab.HIGH);
				if (uiDriver.getValue(
						"//*[@id='line_splits']//tbody/tr[" + (invoiceRow + 1)
								+ "]/td[1]").contains(
						"11015102 Billed Intl AR FTV/BC")||uiDriver.getValue(
						"//*[@id='line_splits']//tbody/tr[" + (invoiceRow + 1)
								+ "]/td[1]").contains(
						"11015052 Canada Cash Clearing"))
				{

					if (uiDriver.getValue(
							"//*[@id='line_splits']//tbody/tr["
									+ (invoiceRow + 1) + "]/td[3]").equals("")) {
						failed("Validating Credit Amount",

						"Validating Credit Amount should be successfull",

						"Credit amount is not Generic billed AR");

					} else

					{

						passed("Credit is generic billed AR",

								"Credit is generic billed AR",

								"11015102 Billed Intl AR FTV/BC/11015052 Canada Cash Clearing	");

					}

				}
				
				
				
				SleepUtils.sleep(TimeSlab.HIGH);
				uiDriver.click("Back");
				SleepUtils.sleep(TimeSlab.MEDIUM);
				uiDriver.click("AllocationDetail");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.click("Transactions");*/

			//}

		//}

//output.put("paymentvalue",paymentnum);
	}

	/****************************************
	 * Name: NavigateToCommunicationFiles Description:
	 * NavigateToCommunicationFiles Date: 30-Nov-2017
	 ****************************************/

	public void NavigateToCommunicationFiles(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.executeJavaScript("scroll(0,300)");
		uiDriver.click("Communication");
		// uiDriver.click("Files");
		uiDriver.executeJavaScript("scroll(0,300)");
		if (uiDriver.checkElementPresent("PDFFile")) {

			passed("Verifying the PDFFile Link",
					"PDFFile Link should be displayed",
					"PDFFile Link is displayed ");
		} else {
			failed("Verifying the PDFFile Link",
					"PDFFile Link should be displayed",
					"PDFFile Link is displayed ");
		}

	}

	/****************************************
	 * Name: VerifyMasterContractStatus Description: VerifyStatus Date:
	 * 30-Nov-2017
	 ****************************************/

	public void VerifyMasterContractStatus(DataRow input, DataRow output)
			throws InterruptedException {
		uiDriver.refresh();
		SleepUtils.sleep(3);
		uiDriver.refresh();
//		SleepUtils.sleep(120);
//		uiDriver.refresh();
//		SleepUtils.sleep(120);
//		uiDriver.refresh();
		uiDriver.click("MasterContract");
		SleepUtils.sleep(TimeSlab.YIELD);
		String status = uiDriver.getValue("Status");
		if (status.equalsIgnoreCase("Posted")) {

			passed("Verifying the  Sales order Status",
					"Sales order Status should be displayed as '" + status
							+ "' Successfully", "Sales order Status " + status
							+ " is displayed Successfully");
		} else {
			failed("Verifying the  Sales order Status",
					"Sales order Status should be displayed as '" + status
							+ "' Successfully", "Sales order Status " + status
							+ " is not displayed Successfully");
		}

	}

	/****************************************
	 * Name: VerifyStatus Description: VerifyStatus Date: 30-Nov-2017
	 ****************************************/

	public void VerifyContractStatus(DataRow input, DataRow output)
			throws InterruptedException {
		/*uiDriver.refresh();
	    SleepUtils.sleep(120);
		uiDriver.refresh();
		SleepUtils.sleep(60);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		SleepUtils.sleep(60);
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		SleepUtils.sleep(60);
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		SleepUtils.sleep(60);
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		SleepUtils.sleep(60);
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();*/

//		SleepUtils.sleep(300);
		uiDriver.refresh();
		for(int i=1;i<=50;i++)
		{
			String ContractStatus = uiDriver.getValue("ContractStatus");
			if (ContractStatus.equalsIgnoreCase("Contract Processed")
					|| ContractStatus.equalsIgnoreCase("Posted Successfully")) {

				passed("Verifying the  Sales order Status",
						"Sales order Status should be displayed as '"
								+ input.get("Status") + "' Successfully",
						"Sales order Status " + ContractStatus
								+ " is displayed Successfully");
				break;
			} else {
				uiDriver.refresh();
				SleepUtils.sleep(TimeSlab.MEDIUM);
				uiDriver.refresh();
				SleepUtils.sleep(TimeSlab.MEDIUM);
				uiDriver.refresh();
				SleepUtils.sleep(5);
			}
		}
		

	}

	/****************************************
	 * Name: VerifyStatus Description: VerifyStatus Date: 30-Nov-2017
	 ****************************************/

	public void VerifyStatus(DataRow input, DataRow output)
			throws InterruptedException {
		SleepUtils.sleep(30);
		uiDriver.refresh();
		String CurrentStatus = uiDriver.getValue("CurrentStatus");
		if (CurrentStatus.equalsIgnoreCase(input.get("Status"))) {

			passed("Verifying the  Sales order Status",
					"Sales order Status should be displayed as '"
							+ input.get("Status") + "' Successfully",
					"Sales order Status " + CurrentStatus
							+ " is displayed Successfully");
		} else {
			failed("Verifying the  Sales order Status",
					"Sales order Status should be displayed as '"
							+ input.get("Status") + "' Successfully",
					"Sales order Status " + CurrentStatus
							+ " is not displayed Successfully");
		}

	}

	/****************************************
	 * Name: NavigateToCommunicationMessages Description:
	 * NavigateToCommunicationMessages Date: 30-Nov-2017
	 ****************************************/

	public void NavigateToCommunicationMessages(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.executeJavaScript("scroll(0,300)");
		uiDriver.click("Communication");
//		uiDriver.click("Messages");
		if (uiDriver.checkElementPresent("ToBeEmailedLink")) {

			passed("Verifying the ToBeEmailedLink Link",
					"ToBeEmailedLink Link should be displayed",
					"ToBeEmailedLink Link is displayed ");
		} else {
			failed("Verifying the ToBeEmailedLink Link",
					"ToBeEmailedLink Link should be displayed",
					"ToBeEmailedLink Link is not displayed ");
		}
	}

	/****************************************
	 * Name: ValidateMasterInvoice Description: ValidateMasterInvoice Date:
	 * 30-Nov-2017
	 * 
	 * @throws IOException
	 * @throws InvalidPasswordException
	 ****************************************/

	public void ValidateMasterInvoicePDF(DataRow input, DataRow output)
			throws InterruptedException, InvalidPasswordException, IOException {

		String Masterinvoice = uiDriver.getValue("MasterInvoice");
		uiDriver.click("MasterInvoice");
		String invoice = uiDriver.getValue("//*[@id='main_form']/table/tbody/tr[2]/td/table/tbody/tr/td[1]/table/tbody/tr[1]/td/div/span[2]");

		String masterinvoice1 = Masterinvoice ;
		if (invoice.equalsIgnoreCase(masterinvoice1)) {
			passed("Verify native invoice number is the master invoice number with an 'A' appended on the end",
					"Invoice number should be master invoice number with an 'A' appended on the end",
					"Invoice number is master invoice number with an 'A' appended on the end");
		} else {
			failed("Verify native invoice number is the master invoice number with an 'A' appended on the end",
					"Invoice number should be master invoice number with an 'A' appended on the end",
					"Invoice number is master invoice number with an 'A' appended on the end");
		}

//		String contractkey = uiDriver.getValue_Text("contractkey");
//		String contractnum = input.get("ContractId");
//		if (contractkey.equals(contractnum)) {
//
//			passed("Verify contractkey",
//					"Contract key in invoice record should match Contract Number",
//					"Contract key in invoice record is matching Contract Number");
//		}
//
//		else {
//			failed("Verify contractkey",
//					"Contract key in invoice record should match Contract Number",
//					"Contract key in invoice record is not matching Contract Number");
//		}
		
		for(int i=0; i<60; i++) {
			if(uiDriver.checkElementPresent("//a[text()='download']")) {	
				uiDriver.refresh();
				break;
			} else {
				SleepUtils.sleep(10);
				uiDriver.refresh();
			}
		}
		
		uiDriver.click("//a[text()='download']");
		String invoicevalue=uiDriver.getValue("//*[@id='main_form']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[3]/td/div/span[2]/a[1]");
		int val=invoicevalue.indexOf("NBCU");
		String pdfvalue=invoicevalue.substring(val,invoicevalue.length()-4);

				String presentwindow = uiDriver.webDr.getWindowHandle();
				// boolean flag = false;
				/*uiDriver.click("Communication");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.executeJavaScript("scroll(0,1000)");
				uiDriver.click("viewPDFattachment");
				SleepUtils.sleep(TimeSlab.LOW);

				Set<String> whandles = uiDriver.webDr.getWindowHandles();
				for (String w : whandles) {
					if (!w.equals(presentwindow)) {
						uiDriver.webDr.switchTo().window(w);
						String PDFWindowURL = uiDriver.webDr.getCurrentUrl();
						URL url = new URL(PDFWindowURL);
						SleepUtils.sleep(TimeSlab.LOW);
						uiDriver.sendKey("save");
						SleepUtils.sleep(TimeSlab.LOW);

						Random random = new Random();
						int limit = random.nextInt(1000);
						String inv = Integer.toString(limit);
						String text = "Invoice" + inv;
						StringSelection stringSelection = new StringSelection(text);
						Clipboard clipboard = Toolkit.getDefaultToolkit()
								.getSystemClipboard();
						clipboard.setContents(stringSelection, stringSelection);
						SleepUtils.sleep(TimeSlab.LOW);
						uiDriver.sendKey("paste");
						SleepUtils.sleep(TimeSlab.LOW);
						uiDriver.sendKey("enter");

						SleepUtils.sleep(TimeSlab.LOW);*/
						String path = System.getProperty("user.home");
						// try(PDDocument document = PDDocument.load(new
						// File(path+"/Downloads/"+FileName+".pdf"))){
						PDDocument document = PDDocument.load(new File(path
								+ "/Downloads/" + pdfvalue + ".pdf"));

						document.getClass();

						if (!document.isEncrypted()) {

							PDFTextStripperByArea stripper = new PDFTextStripperByArea();
							stripper.setSortByPosition(true);

							PDFTextStripper tStripper = new PDFTextStripper();
							
							String pdfFileInText = tStripper.getText(document);
							// System.out.println("Text:" + st);

							// split by whitespace
							String lines[] = pdfFileInText.split("\\r?\\n");
							for(int i=0;i<lines.length;i++){
							System.out.println(lines[i]);
							}
							for (String line : lines) {
								System.out.println(line);
								if (input.get("BilledBy").contains(line)) {
									passed("Verifying the BilledBy info in pdf",
											"BilledBy info should be displayed as "	+ input.get("BilledBy") + " ",
											"BilledBy info is displayed as "
													+ input.get("BilledBy") + " ");
								} else if ((input.get("Remit").contains(line))) {
									passed("Verifying the Remit info in pdf",
											"Remit info should be displayed as "
													+ input.get("Remit") + " ",
											"Remit info is displayed as "
													+ input.get("Remit") + " ");

								} else if (input.get("BillTo").contains(line)) {
									passed("Verifying the BillTo info in pdf",
											"BillTo info should be displayed as "
													+ input.get("BillTo") + " ",
											"BillTo info is displayed as "
													+ input.get("BillTo") + " ");
									;

								}

								else if (input.get("SendTo").contains(line)) {
									passed("Verifying the SendTo info in pdf",
											"SendTo info should be displayed as "
													+ input.get("SendTo") + " ",
											"SendTo info is displayed as "
													+ input.get("SendTo") + " ");
									;

								} else if (input.get("TotalAmount").contains(line)) {
									passed("Verifying the TotalAmount in pdf",
											"TotalAmount should be displayed as "
													+ input.get("TotalAmount") + " ",
											"TotalAmount is displayed as "
													+ input.get("TotalAmount") + " ");
									;

								} else if (input.get("RemitInformation").contains(line)) {
									passed("Verifying the RemitInformation in pdf",
											"RemitInformation should be displayed as "
													+ input.get("RemitInformation")
													+ " ",
											"RemitInformation is displayed as "
													+ input.get("RemitInformation")
													+ " ");
									;

								}

							}
						}
		//String presentwindow = uiDriver.webDr.getWindowHandle();
		// boolean flag = false;
		/*uiDriver.click("viewmasterpdf");
		SleepUtils.sleep(TimeSlab.LOW);

		SleepUtils.sleep(TimeSlab.LOW);

		Set<String> whandles = uiDriver.webDr.getWindowHandles();
		for (String w : whandles) {
			if (!w.equals(presentwindow)) {
				uiDriver.webDr.switchTo().window(w);
				String PDFWindowURL = uiDriver.webDr.getCurrentUrl();
				URL url = new URL(PDFWindowURL);
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.sendKey("save");
				SleepUtils.sleep(TimeSlab.LOW);

				Random random = new Random();
				int limit = random.nextInt(1000);
				String inv = Integer.toString(limit);
				String text = "MasterInvoice" + inv;
				StringSelection stringSelection = new StringSelection(text);
				Clipboard clipboard = Toolkit.getDefaultToolkit()
						.getSystemClipboard();
				clipboard.setContents(stringSelection, stringSelection);
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.sendKey("paste");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.sendKey("enter");

				SleepUtils.sleep(TimeSlab.LOW);
				String path = System.getProperty("user.home");
				// try(PDDocument document = PDDocument.load(new
				// File(path+"/Downloads/"+FileName+".pdf"))){
				PDDocument document = PDDocument.load(new File(path
						+ "/Downloads/" + text + ".pdf"));

				document.getClass();

				if (!document.isEncrypted()) {

					PDFTextStripperByArea stripper = new PDFTextStripperByArea();
					stripper.setSortByPosition(true);

					PDFTextStripper tStripper = new PDFTextStripper();

					String pdfFileInText = tStripper.getText(document);
					// System.out.println("Text:" + st);

					// split by whitespace
					String lines[] = pdfFileInText.split("\\r?\\n");
					for (String line : lines) {
						System.out.println(line);
						if (input.get("BilledBy").contains(line)) {
							passed("Verifying the BilledBy info in pdf",
									"BilledBy info should be displayed as "
											+ input.get("BilledBy") + " ",
									"BilledBy info is displayed as "
											+ input.get("BilledBy") + " ");
						} else if ((input.get("Remit").contains(line))) {
							passed("Verifying the Remit info in pdf",
									"Remit info should be displayed as "
											+ input.get("Remit") + " ",
									"Remit info is displayed as "
											+ input.get("Remit") + " ");

						} else if (input.get("BillTo").contains(line)) {
							passed("Verifying the BillTo info in pdf",
									"BillTo info should be displayed as "
											+ input.get("BillTo") + " ",
									"BillTo info is displayed as "
											+ input.get("BillTo") + " ");
							;

						}

						else if (input.get("SendTo").contains(line)) {
							passed("Verifying the SendTo info in pdf",
									"SendTo info should be displayed as "
											+ input.get("SendTo") + " ",
									"SendTo info is displayed as "
											+ input.get("SendTo") + " ");
							;

						} else if (input.get("TotalAmount").contains(line)) {
							passed("Verifying the TotalAmount in pdf",
									"TotalAmount should be displayed as "
											+ input.get("TotalAmount") + " ",
									"TotalAmount is displayed as "
											+ input.get("TotalAmount") + " ");
							;

						} else if (input.get("RemitInformation").contains(line)) {
							passed("Verifying the RemitInformation in pdf",
									"RemitInformation should be displayed as "
											+ input.get("RemitInformation")
											+ " ",
									"RemitInformation is displayed as "
											+ input.get("RemitInformation")
											+ " ");
							;

						}

					}
				}

				uiDriver.webDr.close();

			}
			uiDriver.webDr.switchTo().window(presentwindow);
			uiDriver.executeJavaScript("scroll(0,-1000)");
			// uiDriver.switchToWindow("Invoice - NetSuite (NBCUniversal Media, LLC 10K QA)");

		}*/

		uiDriver.click("invoicenum");

	}

	/****************************************
	 * Name: ValidateSalesOrderinMasterContract Description:
	 * ValidateSalesOrderinMasterContract Date: 30-Nov-2017
	 ****************************************/

	public void ValidateSalesOrderinMasterContract(DataRow input, DataRow output)
			throws InterruptedException {
		String mastercontract = uiDriver.getValue("mastercontractparent");
		uiDriver.click("mastercontractparent");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("transactions");
		SleepUtils.sleep(TimeSlab.YIELD);
		String salesordernum = uiDriver.getValue("SalesorderNum");
		String mastercontract1 = mastercontract + "A";
		if (salesordernum.equalsIgnoreCase(mastercontract1)) {
			passed("Verifying the contract is under master contract in transactions tab",
					"The contract should be under master contract in transactions tab",
					"The contract is under master contract in transactions tab");
		} else {
			failed("Verifying the contract is under master contract in transactions tab",
					"The contract should be under master contract in transactions tab",
					"The contract is not under master contract in transactions tab");
		}
		uiDriver.click("SalesorderNum");

	}

	/****************************************
	 * Name: NavigateToGLImpact Description: NavigateToGLImpact Date:
	 * 30-Nov-2017
	 ****************************************/

	public void NavigateToGLImpact(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.executeJavaScript("scroll(0,-1000)");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.mouseOver("action");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Glimpact");
		if(uiDriver.checkElementPresent("//h1[contains(text(),'GL Impact')]")) {
			passed("NavigateToGLImpact", "GL Impact screen should be displayed", "GL Impact screen is displayed");
		} else {
			failed("NavigateToGLImpact", "GL Impact screen should be displayed", "GL Impact screen is not displayed");
		}
	}

	/****************************************
	 * Name: ApproveJEByManager Description: ApproveJEByManager Date:
	 * 23-July-2018
	 ****************************************/
	public void ApproveJEByManager(DataRow input, DataRow output) {
		String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		SleepUtils.sleep(5);
		uiDriver.refresh();
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("relatedRecord");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("date");
		SleepUtils.sleep(TimeSlab.LOW);
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ApproveJE");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("goback");
		SleepUtils.sleep(TimeSlab.LOW);
	}

	/****************************************
	 * Name: ViewAndReadPDF Description: ViewAndReadPDF Date: 30-Nov-2017
	 ****************************************/

	public void ViewAndReadPDF(DataRow input, DataRow output)
			throws InterruptedException, InvalidPasswordException, IOException {

		/*
		 * uiDriver.click("Files"); String PDFLink =
		 * uiDriver.getValue("PDFLink"); String FileName =
		 * PDFLink.split("\\.")[0]; uiDriver.click("Edit");
		 * SleepUtils.sleep(TimeSlab.LOW); uiDriver.switchToWindow("File");
		 * SleepUtils.sleep(TimeSlab.LOW); String Name =
		 * uiDriver.getValue("FileName"); String ReplaceName =
		 * Name.replace("/",""); uiDriver.setValue("FileName",ReplaceName );
		 * uiDriver.click("Save"); SleepUtils.sleep(TimeSlab.HIGH);
		 * 
		 * uiDriver.switchToWindow(
		 * "Sales Order - NetSuite (NBCUniversal Media, LLC - DEV (New))");
		 * SleepUtils.sleep(TimeSlab.LOW); uiDriver.click("PDFDownload");
		 */
uiDriver.click("//a[text()='download']");
String invoicevalue=uiDriver.getValue("//*[@id=\"main_form\"]/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[3]/td/div/span[2]/a[1]");
int val=invoicevalue.indexOf("NBCU");
String pdfvalue=invoicevalue.substring(val,invoicevalue.length()-4);

		String presentwindow = uiDriver.webDr.getWindowHandle();
		// boolean flag = false;
		/*uiDriver.click("Communication");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,1000)");
		uiDriver.click("viewPDFattachment");
		SleepUtils.sleep(TimeSlab.LOW);

		Set<String> whandles = uiDriver.webDr.getWindowHandles();
		for (String w : whandles) {
			if (!w.equals(presentwindow)) {
				uiDriver.webDr.switchTo().window(w);
				String PDFWindowURL = uiDriver.webDr.getCurrentUrl();
				URL url = new URL(PDFWindowURL);
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.sendKey("save");
				SleepUtils.sleep(TimeSlab.LOW);

				Random random = new Random();
				int limit = random.nextInt(1000);
				String inv = Integer.toString(limit);
				String text = "Invoice" + inv;
				StringSelection stringSelection = new StringSelection(text);
				Clipboard clipboard = Toolkit.getDefaultToolkit()
						.getSystemClipboard();
				clipboard.setContents(stringSelection, stringSelection);
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.sendKey("paste");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.sendKey("enter");

				SleepUtils.sleep(TimeSlab.LOW);*/
				String path = System.getProperty("user.home");
				// try(PDDocument document = PDDocument.load(new
				// File(path+"/Downloads/"+FileName+".pdf"))){
				PDDocument document = PDDocument.load(new File(path
						+ "/Downloads/" + pdfvalue + ".pdf"));

				document.getClass();

				if (!document.isEncrypted()) {

					PDFTextStripperByArea stripper = new PDFTextStripperByArea();
					stripper.setSortByPosition(true);

					PDFTextStripper tStripper = new PDFTextStripper();

					String pdfFileInText = tStripper.getText(document);
					// System.out.println("Text:" + st);

					// split by whitespace
					String lines[] = pdfFileInText.split("\\r?\\n");
					for (String line : lines) {
						System.out.println(line);
						if (input.get("BilledBy").contains(line)) {
							passed("Verifying the BilledBy info in pdf",
									"BilledBy info should be displayed as "
											+ input.get("BilledBy") + " ",
									"BilledBy info is displayed as "
											+ input.get("BilledBy") + " ");
						} else if ((input.get("Remit").contains(line))) {
							passed("Verifying the Remit info in pdf",
									"Remit info should be displayed as "
											+ input.get("Remit") + " ",
									"Remit info is displayed as "
											+ input.get("Remit") + " ");

						} else if (input.get("BillTo").contains(line)) {
							passed("Verifying the BillTo info in pdf",
									"BillTo info should be displayed as "
											+ input.get("BillTo") + " ",
									"BillTo info is displayed as "
											+ input.get("BillTo") + " ");
							;

						}

						else if (input.get("SendTo").contains(line)) {
							passed("Verifying the SendTo info in pdf",
									"SendTo info should be displayed as "
											+ input.get("SendTo") + " ",
									"SendTo info is displayed as "
											+ input.get("SendTo") + " ");
							;

						} else if (input.get("TotalAmount").contains(line)) {
							passed("Verifying the TotalAmount in pdf",
									"TotalAmount should be displayed as "
											+ input.get("TotalAmount") + " ",
									"TotalAmount is displayed as "
											+ input.get("TotalAmount") + " ");
							;

						} else if (input.get("RemitInformation").contains(line)) {
							passed("Verifying the RemitInformation in pdf",
									"RemitInformation should be displayed as "
											+ input.get("RemitInformation")
											+ " ",
									"RemitInformation is displayed as "
											+ input.get("RemitInformation")
											+ " ");
							;

						}

					}
				}

				//uiDriver.webDr.close();

			}
			//uiDriver.webDr.switchTo().window(presentwindow);
			//uiDriver.executeJavaScript("scroll(0,-1000)");
			// uiDriver.switchToWindow("Invoice - NetSuite (NBCUniversal Media, LLC 10K QA)");

		
	

	/****************************************
	 * Name: VerifyPDFdeleivery Description: VerifyPDFdeleivery Date:
	 * 30-Nov-2017
	 ****************************************/

	public void VerifyPDFdelivery(DataRow input, DataRow output) {
		uiDriver.click("Communication");
		String deliverytype = uiDriver.getValue("type");

	}

	/****************************************
	 * Name: NavigatetoInvoice Description: NavigatetoInvoice Date: 23-July-2018
	 ****************************************/
	public void NavigatetoInvoice(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.MEDIUM);
		String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		SleepUtils.sleep(5);
		uiDriver.refresh();
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("relatedRecord");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("invoiceNo");
		SleepUtils.sleep(TimeSlab.LOW);
		SleepUtils.sleep(TimeSlab.LOW);
		String InvoiceNum = uiDriver.getValue("invoicenum");
		output.put("InvoiceNum", InvoiceNum);
		// uiDriver.click("writeOffRemainingAmount");
		// SleepUtils.sleep(TimeSlab.MEDIUM);
		// uiDriver.click("goback");
		// SleepUtils.sleep(TimeSlab.LOW);
	}

	/****************************************
	 * Name: AcceptPaymentForMultipleInvoices Description:
	 * AcceptPaymentForMultipleInvoices Date: 30-Nov-2017
	 ****************************************/
	public void acceptPaymentForMultipleInvoices(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.setFrame("frame");
		uiDriver.mouseOver("transactions");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("CustomerPay");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("AcceptPayment");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.YIELD);

		uiDriver.click("AcceptPayment");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.YIELD);
		String cust = input.get("customer");
		uiDriver.click("customerdropdownimage");
		SleepUtils.sleep(5);
		uiDriver.click("customerlist");
		SleepUtils.sleep(5);
		uiDriver.setValue("searchcustomerinput", cust);
		SleepUtils.sleep(5);
		uiDriver.click("searchcustomerbutton");
		SleepUtils.sleep(5);
		uiDriver.click("cussearchresult");
		uiDriver.click("acctradiobutton");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("Account", "30 Undeposited Funds");
		SleepUtils.sleep(TimeSlab.YIELD);
		String InvoiceNum = input.get("invoicenumber");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("scroll(0,900);");
		SleepUtils.sleep(TimeSlab.YIELD);
		String ReferenceNum = uiDriver.getDyanmicData("ReferenceNum");
		SleepUtils.sleep(TimeSlab.YIELD);
		String ReferenceVal = ReferenceNum.replace("#", InvoiceNum);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click_dynamic(ReferenceVal);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("saveacceptPayment");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("action");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Glimpact");
	}

	/****************************************
	 * Name: ReadInvoice Description:ReadInvoice Date: 30-Nov-2017
	 * 
	 * @return
	 ****************************************/
	public void ReadInvoice(DataRow input, DataRow output)
			throws InterruptedException {
		/*
		 * SleepUtils.sleep(TimeSlab.HIGH); String Num = input.get("conf");
		 * uiDriver.setValue("SearchSO", Num);
		 * SleepUtils.sleep(TimeSlab.MEDIUM); uiDriver.click("SalesOrder");
		 * passed("SalesOrder", "SalesOrder Should be displayed Successfully",
		 * "SalesOrder is displayed Successfully"); SleepUtils.sleep(5);
		 * uiDriver.refresh();
		 */
		uiDriver.executeJavaScript("scroll(0,400)");
		uiDriver.click("relatedRecord");
		SleepUtils.sleep(TimeSlab.LOW);
		List<WebElement> Inv = uiDriver.webDr
				.findElements(By
						.xpath("//*[@id='links_splits']/tbody//td[text()='Invoice']/../td[3]"));
		int invoiceSize = Inv.size();
		String invSize = Integer.toString(invoiceSize);
		output.put("InvoiceSize", invSize);
		for (int i = 1; i < invoiceSize; i++) {
			String ele = Inv.get(i).getText();
			System.out.println(ele);
			output.put("invoice" + i, ele);

		}

	}

	/****************************************
	 * Name: ReadSingleInvoice 
	 * Description:ReadSingleInvoice 
	 * Date: 30-Nov-2017
	 * @return
	 ****************************************/
	public void ReadSingleInvoice(DataRow input, DataRow output)
			throws InterruptedException {

		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.executeJavaScript("scroll(0,400)");
		uiDriver.click("//span[text()='R']");
		SleepUtils.sleep(TimeSlab.LOW);
		List<WebElement> Inv = uiDriver.webDr
				.findElements(By
						.xpath("//*[@id='links_splits']/tbody//td[text()='Invoice']/../td[3]"));
		int invoiceSize = Inv.size();
		String invSize = Integer.toString(invoiceSize);
		output.put("InvoiceSize", invSize);
	//	String invoice = uiDriver.getValue_Text("//td[text()='30,000.00']/../td[3]");
		String invoices = uiDriver.getDyanmicData("Invoices");
		String invoiceAmt = invoices.replace("#", input.get("invoiceAmount")); 
		String invoice = uiDriver.getValueByText(invoiceAmt);
		output.put("Invoices", invoice);
		if(invoice == null || invoice.equalsIgnoreCase("")) {
			failed("ReadSingleInvoice",
					"Invoice Number should be stored successfully",
					"Invoice Number is not stored successfully");
		} else {
			passed("ReadSingleInvoice",
					"Invoice Number should be stored successfully",
					"Invoice Number is stored successfully");
		}

	}

	/****************************************
	 * Name: WriteInvoice 
	 * Description:ReadInvoice Date: 30-Nov-2017
	 * 
	 * @return
	 ****************************************/
	/*
	 * public void WriteInvoice(DataRow input, DataRow output) throws
	 * InterruptedException {
	 * 
	 * List<String> i=ReadInvoice(input,output); for(int j=0;j<i.size();j++){
	 * 
	 * i.get(j);
	 * 
	 * 
	 * 
	 * }
	 * 
	 * }
	 */

	/****************************************
	 * Name: NavigateToChangeInvoiceStatus
	 * Description: NavigateToChangeInvoiceStatus 
	 * Date: 13-July-2018
	 ****************************************/
	public void NavigateToChangeInvoiceStatus(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Invoices");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("BulkOperations");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("ChangeWFStates");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);

		uiDriver.click("Filter");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("searchinput");
		String ContractId = input.get("ContractId");
		uiDriver.setValue("searchinput", input.get("ContractId"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//*[@id=\"advancedSearchButton\"]");
		//uiDriver.sendKey("enter");
		//uiDriver.sendKey("enter");
		SleepUtils.sleep(TimeSlab.MEDIUM);
	}

	/****************************************
	 * Name: ChangeInvoiceStatusForMultipleInvoices
	 * Description:ChangeInvoiceStatusForMultipleInvoices
	 * Date: 13-July-2018
	 ****************************************/
	public void ChangeInvoiceStatusForMultipleInvoices(DataRow input,
			DataRow output) {
		SleepUtils.sleep(TimeSlab.HIGH);
		String ContractId = input.get("ContractId");
		String ContractNum = uiDriver.getDyanmicData("Contractnumber");
		SleepUtils.sleep(TimeSlab.YIELD);
		String ContractNumber = ContractNum.replace("#", ContractId);
		List<WebElement> ele = uiDriver.webDr.findElements(By
				.xpath(ContractNumber));
		int rowSize = ele.size();
		for (int n = 0; n < rowSize; n++) {
			String ContractNum1 = uiDriver.getDyanmicData("Contractnumber1");
			String ContractNumber1 = ContractNum1.replace("#", ContractId);
			String RowContractNum = ContractNumber1.replace("$",
					Integer.toString(n + 1));
			WebElement ele1 = uiDriver.webDr.findElement(By
					.xpath(RowContractNum));
			SleepUtils.sleep(TimeSlab.LOW);
			ele1.click();
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.executeJavaScript("scroll(0,-1000)");
			uiDriver.click("Invoicedropdown");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("SendforInvoice");
			uiDriver.click("SendforInvoice");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("Transitiontoworkflow");
			SleepUtils.sleep(TimeSlab.HIGH);
			passed("Verify the Invoice is posted",
					"Invoice posted successfully",
					"Invoice posted successfully");

		}

	}

	/****************************************
	 * Name: ChangeInvoiceStatusForMultipleInvoices 
	 * Description:ChangeInvoiceStatusForMultipleInvoices
	 * Date: 13-July-2018
	 ****************************************/
	public void ChangeInvForSpecifiedInv(DataRow input,
			DataRow output) {
		
		uiDriver.click("Invoices");
		uiDriver.click("BulkOperations");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("ChangeWFStates");
		//SleepUtils.sleep(TimeSlab.HIGH);
		//SleepUtils.sleep(TimeSlab.HIGH);
		//SleepUtils.sleep(TimeSlab.HIGH);
		//SleepUtils.sleep(TimeSlab.HIGH);
		//SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Filter");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("searchinput");
		uiDriver.setValue("searchinput", input.get("ContractId"));
		SleepUtils.sleep(TimeSlab.MEDIUM);
		/*
		 * uiDriver.sendKey("enter"); uiDriver.sendKey("enter");
		 */
		uiDriver.click("Search");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		
		String amount = input.get("Amount");
		String amount1 = "//*[text()='#']//..//input[@class='rowCheckbox']"; //uiDriver.getDyanmicData("amount");
		SleepUtils.sleep(TimeSlab.YIELD);
		String amount2 = amount1.replace("#", amount);
		//*[text()='0.00']//..//input[@type='checkbox' and @name]
		//*[text()='0.00']//..//input[@class='rowCheckbox']
		List<WebElement> list_CheckBox = uiDriver.webDr.findElements(By.xpath(amount2));
		for(int i=0; i<list_CheckBox.size(); i++) {
			list_CheckBox.get(i).click();
		}
//		uiDriver.click_dynamic(amount2);
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.executeJavaScript("scroll(0,-1000)");
			uiDriver.click("Invoicedropdown");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("SendforInvoice");
			uiDriver.click("SendforInvoice");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("Transitiontoworkflow");
			SleepUtils.sleep(TimeSlab.HIGH);
			passed("Verify the Invoice is posted",
					"Invoice posted successfully",
					"Invoice posted successfully");

		}

	

	
	
	 /****************************************
	 * Name: NavigateToInvoiceScreen
	 * Description:Method to Navigate To Invoice Screen
	 *  Date:30-Nov-2017 
	****************************************/
	public void NavigateToRevisedInvoice(DataRow input, DataRow output) throws InterruptedException {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("//input[@id='_searchstring']", input.get("conf"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//a[contains(text(),'Sales Order:')]");
		SleepUtils.sleep(TimeSlab.LOW);
		if (uiDriver.checkElementPresent("//h1[text()='Sales Order']")) {
			passed("getExchangeNumber", "Sales Order Should be displayed", "Sales Order is displayed");
		} else {
			failed("getExchangeNumber", "Sales Order Should be displayed", "Sales Order is not displayed");
		}

		uiDriver.click("//a[@id='accntingtabtxt']");
		SleepUtils.sleep(TimeSlab.LOW);
		String ExchangeNumber = uiDriver.getValue("//span[@id='exchangerate_fs_lbl']//..//following-sibling::span");

		if (ExchangeNumber == null) {
			failed("getExchangeNumber", "Exchange Number should be stored successfully",
					"Exchange Number is not stored successfully");
		} else {
			passed("getExchangeNumber", "Exchange Number should be stored successfully",
					"Exchange Number is stored successfully as : " + ExchangeNumber);
		}

		uiDriver.click("//a[@id='itemstxt']");
		SleepUtils.sleep(TimeSlab.LOW);
		
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully", "SalesOrder is displayed Successfully");
		SleepUtils.sleep(5);
		//uiDriver.refresh();
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("relatedRecord");
		SleepUtils.sleep(5);
		uiDriver.click("relatedRecord");
		
		String invoice = uiDriver.getDyanmicData("invoice1");
		
		System.out.println("--START--");
		
		String InvAmount = input.get("amount");
		String Exchange = ExchangeNumber;
		
		InvAmount = InvAmount.replace(",", "");
		Exchange = Exchange.replace(",", "");
		
		Float temp1 = Float.parseFloat(InvAmount);
		Float temp2 = Float.parseFloat(Exchange);
		
		Float temp3 = temp1 * temp2;
		String temp4 = temp3.toString();
		
		int end = temp4.indexOf(".");
		String temp5 = temp4.substring(0, end);
//		String temp5 = "4595029";
		System.out.println(temp5);
		
		int length = temp5.length();

		ArrayList<String> t1 = new ArrayList<String>();
		for(int i=(length-1); i>=0; i--) {
				String t2 = temp5.substring(i, i+1);
				t1.add(t2);				
		}
		System.out.println(t1);
		System.out.println(t1.size());
		
		String finalAmount="";
		for(int i=0; i<t1.size(); i++) {
			finalAmount = t1.get(i)+finalAmount;
			
			if(i != t1.size()-1) {					
			if(i%3 == 2) {
				finalAmount = ","+finalAmount;
			}
			}
		}
		System.out.println(finalAmount);
		System.out.println("--END--");
		
		String invoice1 = invoice.replace("#", finalAmount);
		uiDriver.click_dynamic(invoice1);

		// uiDriver.click("invoiceNo");
		passed("InvoiceNo", "InvoiceNo Should be Clicked Successfully", "InvoiceNo is Clicked Successfully");
		String invoicenumber = uiDriver.getValue("Invoicenum");
		output.put("InvoiceNum", invoicenumber);
		String Masterinvoice = invoicenumber.substring(0, invoicenumber.length() - 1);
		output.put("MasterInvoice", Masterinvoice);
	}
	 
	
	/****************************************
	 * Name: VerifyRevPlanDates 
	 * Description: VerifyRevPlanDates 
	 * Date: 13-July-2018
	
	 ****************************************/
	public void VerifyRevPlanDates(DataRow input, DataRow output)
			throws ParseException {
		int planRows = uiDriver.webDr
				.findElements(
						By.xpath("(//*[@class='uir-machine-table'])[1]/tbody/tr[contains(@class,'uir-machine-row uir-machine-row')]"))
				.size();
		String viewicon = uiDriver.getDyanmicData("viewicon");
		String viewicon1 = viewicon.replace("#", Integer.toString(i));
		uiDriver.executeJavaScript("window.scrollBy(0,500)");
		WebElement ele = uiDriver.webDr.findElement(By.xpath(viewicon1));
		String ele1 = "(//*[@class='uir-machine-table'])[1]/tbody/tr[2]/td[17]";
		WebElement ele2 = uiDriver.webDr.findElement(By.xpath(ele1));
		Actions action = new Actions(uiDriver.webDr);
		action.moveToElement(ele2).build().perform();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click_dynamic(viewicon1);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setFrame("iconframe");
		SleepUtils.sleep(TimeSlab.YIELD);
		String actualRevRecStartDate = uiDriver.getValue("RevRecStartDate");
		String actualRevRecEndDate = uiDriver.getValue("RevRecEndDate");
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy ");
		Date date = new Date();
		String date1 = dateFormat.format(date);
		if (actualRevRecStartDate.contains(date1)) {
			passed("Verifying the Revenue Recognition StartDate",
					"Revenue Recognition StartDate should be displayed as "
							+ actualRevRecStartDate + " ",
					"Revenue Recognition StartDate is displayed as "
							+ actualRevRecStartDate + " ");
			;

		} else {
			failed("Verifying the Revenue Recognition StartDate",
					"Revenue Recognition StartDate should be displayed as "
							+ actualRevRecStartDate + " ",
					"Revenue Recognition StartDate is not displayed as "
							+ actualRevRecStartDate + " ");
			;

		}

		if (actualRevRecEndDate.contains(date1)) {
			passed("Verifying the Revenue Recognition EndDate",
					"Revenue Recognition EndDate should be displayed as "
							+ actualRevRecEndDate + " ",
					"Revenue Recognition EndDate is displayed as "
							+ actualRevRecEndDate + " ");
			;

		} else {
			failed("Verifying the Revenue Recognition EndDate",
					"Revenue Recognition EndDate should be displayed as "
							+ actualRevRecEndDate + " ",
					"Revenue Recognition EndDate is not displayed as "
							+ actualRevRecEndDate + " ");
			;

		}

	}

	/****************************************
	 * Name: NavigateToPaymentWizard 
	 * Description: NavigateToPaymentWizard 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void NavigateToPaymentWizard(DataRow input, DataRow output)
			throws InterruptedException

	{
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.mouseOver("transactions");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Customer");
		SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("ScrollDown");
		// SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("PaymentWizard");
		SleepUtils.sleep(TimeSlab.YIELD);
	}

	/****************************************
	 * Name: CreateUnpaidtounbilled
	 * Description: CreateUnpaidtounbilled 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void CreateUnpaidtounbilled(DataRow input, DataRow output)
			throws InterruptedException

	{
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.mouseOver("Customization");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Scripting");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Scripts");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Scripts");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.LOW);
		if(uiDriver.checkElementPresent("EditUnpaidtoUnbilled"))
		{
			uiDriver.click("EditUnpaidtoUnbilled");
		}
		else
		{
		uiDriver.click("dropdownbtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("NBCUFMV");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("EditUnpaidtoUnbilled");
		SleepUtils.sleep(TimeSlab.LOW);
		}
		uiDriver.click("Deployments");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("NBCUFMVCALCENGINE");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("EditScript");
		SleepUtils.sleep(TimeSlab.LOW);
		if(uiDriver.checkElementPresent("SaveAndExecute"))
		{	
			uiDriver.click("SaveAndExecute");
			uiDriver.handleAlert("", "OK");
		}
		else{
			for(int i=0;i<=50;i++){
				SleepUtils.sleep(30);
				uiDriver.refresh();		
				uiDriver.mouseOver("dropdown");
				System.out.println("***********************"+i);
				if(uiDriver.checkElementPresent("SaveAndExecute"))
				{	
					uiDriver.click("SaveAndExecute");
					uiDriver.handleAlert("", "OK");
					break;
				}
					
				
			}	
			}
		uiDriver.refresh();	
		SleepUtils.sleep(30);
		uiDriver.refresh();	
		for(int i=0;i<=50;i++){
			SleepUtils.sleep(30);
			uiDriver.refresh();			
			System.out.println("***********************"+i);
			System.out.println(uiDriver.getValue("Status"));
			if(uiDriver.getValue("Status").equalsIgnoreCase("Complete"))
				passed("Verify CompleteStatus",
						"CompleteStatus should be displayed successfully",
						"CompleteStatus is not displayed successfully");
			break;
			
		}	
  		
		

	}

	/****************************************
	 * Name: verifyrevenuedetails 
	 * Description: verifyrevenuedetails 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void verifyrevenuedetails(DataRow input, DataRow output)
			throws InterruptedException

	{
		//String amount = uiDriver.getValue("amount");
		String deferralaccount = uiDriver.getValue("deferredaccount");
		String recognitionaccount = uiDriver.getValue("recognitionaccount");
		//String recognitionstartdate = uiDriver.getValue("recognitionstartdate");
		//String recognitionenddate = uiDriver.getValue("recognitionenddate");
		/*
		 * if(amount.contains(input.get("amount"))) {
		 * 
		 * passed("Verifying the Amount",
		 * "Amount should be displayed as "+amount+" ",
		 * "Amount is displayed as "+input.get("amount")+" ");
		 * 
		 * 
		 * } else { failed("Verifying the Amount",
		 * "Amount should be displayed as "+amount+" ",
		 * "Amount is displayed as "+input.get("amount")+" ");
		 * 
		 * }
		 */
		String billaccount="//a[text()='#']";
		//String billaccount1=uiDriver.getDyanmicData(billaccount);
		String bc = billaccount.replaceAll("#", input.get("deferredaccount"));
		if(uiDriver.checkElementPresent(bc))
		{
			passed("Verifying the deferralaccount",
					"Amount should be displayed as " + input.get("deferredaccount") + " ",
					"Amount is displayed as " + deferralaccount
							+ " ");
		}
		else {
			failed("Verifying the deferralaccount",
					"Amount should be displayed as " + input.get("deferredaccount") + " ",
					"Amount is displayed as " + deferralaccount
							+ " ");

		}
		String ra = billaccount.replaceAll("#", input.get("recognitionaccount"));
		if(uiDriver.checkElementPresent(ra))
		{
			passed("Verifying the recognitionaccount",
					"recognitionaccount should be displayed as "
							+ input.get("recognitionaccount") + " ",
					"recognitionaccount is displayed as "
							+ recognitionaccount + " ");

		} else {
			failed("Verifying the recognitionaccount",
					"recognitionaccount should be displayed as "
							+ input.get("recognitionaccount") + " ",
					"recognitionaccount is displayed as "
							+ recognitionaccount + " ");


		}
		
		

		/*if (deferralaccount.contains(input.get("deferredaccount"))) {

			passed("Verifying the deferralaccount",
					"Amount should be displayed as " + deferralaccount + " ",
					"Amount is displayed as " + input.get("deferredaccount")
							+ " ");

		} else {
			failed("Verifying the deferralaccount",
					"Amount should be displayed as " + deferralaccount + " ",
					"Amount is displayed as " + input.get("deferredaccount")
							+ " ");

		}*/

		/*if (recognitionaccount.contains(input.get("recognitionaccount"))) {

			passed("Verifying the recognitionaccount",
					"recognitionaccount should be displayed as "
							+ recognitionaccount + " ",
					"recognitionaccount is displayed as "
							+ input.get("recognitionaccount") + " ");

		} else {
			failed("Verifying the recognitionaccount",
					"recognitionaccount should be displayed as "
							+ recognitionaccount + " ",
					"recognitionaccount is displayed as "
							+ input.get("recognitionaccount") + " ");

		}*/

		/*
		 * if(recognitionstartdate.contains(input.get("recognitionstartdate")))
		 * {
		 * 
		 * passed("Verifying the recognitionaccount",
		 * "recognitionaccount should be displayed as "
		 * +recognitionstartdate+" ",
		 * "recognitionaccount is displayed as "+input
		 * .get("recognitionstartdate")+" ");
		 * 
		 * 
		 * } else{ failed("Verifying the recognitionaccount",
		 * "recognitionaccount should be displayed as "
		 * +recognitionstartdate+" ",
		 * "recognitionaccount is displayed as "+input
		 * .get("recognitionstartdate")+" ");
		 * 
		 * }
		 * 
		 * 
		 * if(recognitionstartdate.contains(input.get("recognitionenddate"))) {
		 * 
		 * passed("Verifying the recognitionaccount",
		 * "recognitionaccount should be displayed as "+recognitionenddate+" ",
		 * "recognitionaccount is displayed as "
		 * +input.get("recognitionenddate")+" ");
		 * 
		 * 
		 * } else{ failed("Verifying the recognitionaccount",
		 * "recognitionaccount should be displayed as "+recognitionenddate+" ",
		 * "recognitionaccount is displayed as "
		 * +input.get("recognitionenddate")+" ");
		 * 
		 * }
		 */

	}

	/****************************************
	 * Name: AllocateCashtoTitleMapScriptDeployment 
	 * Description:Method to Allocate Cash to TitleMap 
	 * Date:30-Nov-2017
	 ****************************************/
	public void AllocateCashtoTitleMapScriptDeployment(DataRow input,
			DataRow output) throws InterruptedException { // method change
		SleepUtils.sleep(TimeSlab.MEDIUM);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.mouseOver("Customization");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Scripting");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Scripts");
		SleepUtils.sleep(TimeSlab.YIELD);
		if(uiDriver.checkElementPresent("EditBtnAllocateCashtoTitleMap"))
		{
			uiDriver.click("EditBtnAllocateCashtoTitleMap");
		}
		else
		{
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("EditBtnAllocateCashtoTitleMap");
		}
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("deployments");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("manualscript");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("edit");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.mouseOver("SaveBtndropdown");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("SaveAndExecute");
		uiDriver.handleAlert("", "OK");
		uiDriver.click("refresh");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("refresh");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refresh");
		uiDriver.click("refresh");
		uiDriver.click("refresh");
		uiDriver.click("refresh");
		passed("Verifying the batch job",
				"create cbt batch job should  be excuted", "create cbt batch job is excuted");
	
	}

	

	/****************************************
	 * Name: CorrectingtheSubsidiaryValue 
	 * Description: CorrectingtheSubsidiaryValue 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void CorrectingtheSubsidiaryValue(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.click("Information");
		uiDriver.click("AdditionalInfo");
		uiDriver.executeJavaScript("document.getElementById('ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_OtherDataAttributeValueGrid_ctl00_ctl14_EditButton').click()");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("document.getElementById('ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_OtherDataAttributeValueGrid_ctl00_ctl15_EditFormControl_ValueStringEdit').value=''");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.setValue("ValueField", input.get("SubsidiaryValue"));
		SleepUtils.sleep(TimeSlab.MEDIUM);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("save");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		passed("Verify the Subsidairy Value",
				"Subsidairy value should be set to F057 Successfully",
				"Subsidairy value is set to F057 Successfully");

	}

	/****************************************
	 * Name: NavigatingToBillingAllocation 
	 * Description:NavigatingToBillingAllocation 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void NavigatingToBillingAllocation(DataRow input, DataRow output)
			throws InterruptedException {

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billing");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Allocation");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Regenerate");
		SleepUtils.sleep(TimeSlab.YIELD);
		String numofbillschedules = input.get("numbill");
		int num = Integer.parseInt(numofbillschedules);
		for (int i = 1; i <= num; i++) {
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("Regenerate");
			SleepUtils.sleep(TimeSlab.HIGH);
			passed("Verifying the billing account generation",
					"Billing Account should be regenerated successfully",
					"Billing Account is regenerated successfully!");

			uiDriver.click("next");
			SleepUtils.sleep(TimeSlab.LOW);
		}

	}

	/****************************************
	* Name: NavigatingAllocation 
	* NavigatingAllocation 
	* Date: 28-May-2019
	****************************************/
	public void NavigatingAllocation(DataRow input, DataRow output)
	throws InterruptedException 
	{

	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("Finance");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("Billing");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("Allocation");
	SleepUtils.sleep(TimeSlab.HIGH);
	uiDriver.click("//div[@id='tabstrip']/ul/li[1]/a");
	SleepUtils.sleep(TimeSlab.HIGH);
	uiDriver.click("//span[@class='k-icon k-i-pencil']/..");
	SleepUtils.sleep(TimeSlab.HIGH);
	uiDriver.executeJavaScript("(scroll(0,800));");
	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("//label[text()='Territories']/input");
	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("//button[@id='next']");
	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("//button[@id='next']");
	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.executeJavaScript("(scroll(0,800));");
	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("//button[@id='next']");
	SleepUtils.sleep(TimeSlab.HIGH);
	uiDriver.click("//a[text()='Name']/../preceding-sibling::th[2]/input");
	SleepUtils.sleep(TimeSlab.HIGH);
	uiDriver.click("//button[@id='copy-amount-btn']/preceding-sibling::span[1]/span/input[1]");
	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.setText("100");
	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("//button[@id='spread-amount-btn']");
	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("//button[@id='next']");
	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("//div[@id='rightsGrid']/div/div/table/thead/tr/th[1]/input");
	SleepUtils.sleep(TimeSlab.LOW);
	String totalamnt=uiDriver.webDr.findElement(By.xpath("//span[@id='contract-total']")).getText();
	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("//span[text()='Amount']/../../following-sibling::span/span/input[1]");
	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.setText(totalamnt);
	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("//button[@id='spread-amount-btn']");
	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("//button[@id='finish']");
	SleepUtils.sleep(TimeSlab.HIGH);
	uiDriver.click("//button[@id='overrideSave']");
	SleepUtils.sleep(TimeSlab.HIGH);
	SleepUtils.sleep(TimeSlab.HIGH);
	}
	
	/****************************************
	 * Name: ApplyPaymentToInvoice1 
	 * Description: ApplyPaymentToInvoice1 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void ApplyPaymentToInvoice1(DataRow input, DataRow output)
			throws InterruptedException

	{
		
		System.out.println(input.get("invioice1"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Subsidiary");
		SleepUtils.sleep(TimeSlab.YIELD);
		String Subsidairy = uiDriver.getDyanmicData("SubsidiaryValue");
		String SubsidairyValue = Subsidairy.replace("#",
				input.get("SubsidairyVal"));
		uiDriver.click_dynamic(SubsidairyValue);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Customer");
		String Customer = uiDriver.getDyanmicData("SubsidiaryValue");
		String CustomerValue = Customer.replace("#", input.get("CustomerVal"));
		uiDriver.click_dynamic(CustomerValue);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("USD");
		SleepUtils.sleep(TimeSlab.HIGH);
		
		
		if(input.get("USD").equals("Y"))
		{
		uiDriver.click("USDValue");
		}
		else
		{
			uiDriver.click("Canadadollar");
		}
		uiDriver.setValue("Account", input.get("Account"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("ARAccount");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("ARAccountValue");
		uiDriver.setValue("PaymentAmount", input.get("PaymentAmount"));
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.setValue(
				"//*[@id='custpage_cash_adj_bank_charges_formattedValue']", "");
		uiDriver.executeJavaScript("document.getElementById('secondarysubmitter').click();");
		SleepUtils.sleep(TimeSlab.HIGH);

		String InvoiceSize = input.get("InvoiceSize");
		int invsize = Integer.parseInt(InvoiceSize);
		if(input.get("USD").equals("Y"))
		{

		for (i = 1; i < invsize; i++) {
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy ");
			Date date = new Date();
			String date1 = dateFormat.format(date);
			// uiDriver.setValue("FromDate",date1 );
			// uiDriver.setValue("Todate",date1 );
			uiDriver.setValue("MI",input.get("invioice" + i).substring(0,input.get("invioice" + i).length() - 1));
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("ApplyFilters");
			SleepUtils.sleep(TimeSlab.HIGH);
			String invchk = uiDriver.getDyanmicData("InvoiceChkbox");
			String invoiceChk = invchk.replace("#", Integer.toString(i));
			uiDriver.click_dynamic(invoiceChk);
			SleepUtils.sleep(TimeSlab.LOW);
			/*
			 * uiDriver.sendKey("selectAll"); SleepUtils.sleep(TimeSlab.YIELD);
			 * uiDriver.sendKey("delete"); SleepUtils.sleep(TimeSlab.YIELD);
			 */
			uiDriver.executeJavaScript("document.getElementById('custpage_sublist_payment"
					+ Integer.toString(i) + "_formattedValue').value='';");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.setValue(invoiceChk, input.get("PaymentAmount"));
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("//*[@id='custpage_filter_from']");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.executeJavaScript("(scroll(0,-400));");

		}
		}
		else
		{
			uiDriver.setValue("MI",input.get("MasterInvoice"));	
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("ApplyFilters");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("invoice");
		}

		uiDriver.executeJavaScript("document.getElementById('submitter').click();");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.handleAlert("", "OK");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
	}
	/****************************************
	 * Name: UnapplyPaymentToInvoice1 
	 * Description: UnapplyPaymentToInvoice
	 * Date:30-Nov-2017
	 ****************************************/
	public void UnapplyPaymentToInvoice(DataRow input, DataRow output)
			throws InterruptedException

	{
		
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Subsidiary");
		SleepUtils.sleep(TimeSlab.YIELD);
		String Subsidairy = uiDriver.getDyanmicData("SubsidiaryValue");
		String SubsidairyValue = Subsidairy.replace("#",
				input.get("SubsidairyVal"));
		uiDriver.click_dynamic(SubsidairyValue);
		
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Customer");
		String Customer = uiDriver.getDyanmicData("SubsidiaryValue");
		String CustomerValue = Customer.replace("#", input.get("CustomerVal"));
		uiDriver.click_dynamic(CustomerValue);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("payment");
		String payment = uiDriver.getDyanmicData("paymentValue");
		String paymentValue = payment.replace("#", input.get("paymentval"));
		uiDriver.click_dynamic(paymentValue);
		SleepUtils.sleep(TimeSlab.YIELD);
		
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.executeJavaScript("document.getElementById('secondarysubmitter').click();");
		SleepUtils.sleep(TimeSlab.MEDIUM);

		
		
			uiDriver.setValue("MI",input.get("MasterInvoice"));	
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("ApplyFilters");
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("invoice");
		

		uiDriver.executeJavaScript("document.getElementById('submitter').click();");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
	}

	
	/****************************************
	 * Name: ApplyPaymentToInvoice 
	 * Description: ApplyPaymentToInvoice 
	 * Date: 30-Nov-2017
	 ****************************************/

	public void ApplyPaymentToInvoice(DataRow input, DataRow output)
			throws InterruptedException

	{
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Subsidiary");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("SubsidiaryValue");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Customer");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("CustomerValue");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("USD");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("USDValue");
		//uiDriver.setValue("Account", "TBD");
		uiDriver.click("//*[@id='custpage_account_fs']/div[1]/span");
	    uiDriver.click("Account");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("ARAccount");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("ARAccountValue");
		uiDriver.setValue("PaymentAmount", "69333.28");
		uiDriver.click("NextPage");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String InvoiceSize = input.get("InvoiceSize");
		int invsize = Integer.parseInt(InvoiceSize);
		for (i = 1; i < invsize; i++) {
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy ");
			Date date = new Date();
			String date1 = dateFormat.format(date);
			// uiDriver.setValue("FromDate",date1 );
			// uiDriver.setValue("Todate",date1 );
			uiDriver.setValue(
					"MI",
					input.get("invioice" + i).substring(0,
							input.get("invioice" + i).length() - 1));
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("ApplyFilters");
			SleepUtils.sleep(TimeSlab.HIGH);
			String invchk = uiDriver.getDyanmicData("InvoiceChkbox");
			String invoiceChk = invchk.replace("#", Integer.toString(i));
			uiDriver.click_dynamic(invoiceChk);
			SleepUtils.sleep(TimeSlab.LOW);
			/*
			 * uiDriver.sendKey("selectAll"); SleepUtils.sleep(TimeSlab.YIELD);
			 * uiDriver.sendKey("delete"); SleepUtils.sleep(TimeSlab.YIELD);
			 */
			uiDriver.executeJavaScript("document.getElementById('custpage_sublist_payment"
					+ Integer.toString(i) + "_formattedValue').value='';");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.setValue(invoiceChk, "8666.66");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.executeJavaScript("(scroll(0,-400));");

		}
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("//*[@id='custpage_filter_from']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("document.getElementById('submitter').click();");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.LOW);
	}

	/****************************************
	 * Name: ChangeRoleToQA10K
	 * Description: Changing the role from administrator to QA
	 * Date: 30-Nov-2017
	 ****************************************/
	public void ChangeRoleToQA10K(DataRow input, DataRow output)
	{
		SleepUtils.sleep(10);
		uiDriver.mouseOver("//*[@id='spn_cRR_d1']/a/div[2]/span[1]");
		SleepUtils.sleep(5);
		uiDriver.click("//*[text()='NBCUniversal Media, LLC 10KQA  -  NBCU: QA']");
		SleepUtils.sleep(5);
		if(uiDriver.checkElementPresent("//*[text()='NBCUniversal Media, LLC 10KQA']")){
		//uiDriver.click("Manager1");
				passed("Verify Changing the role to QA",
				"QA Role must be changed Successfully",
				"QA Role is changed Successfully");
		SleepUtils.sleep(5);
		}
	}
	
	/****************************************
	 * Name: ChangeRoleToManager2UAT
	 * Description: Changing the role from administrator to ChangeRoleToManager2UAT
	 * Date: 30-Nov-2017
	 ****************************************/
	public void ChangeRoleToManager2UAT(DataRow input, DataRow output)
	{
		SleepUtils.sleep(10);
		uiDriver.mouseOver("//*[@id='spn_cRR_d1']/a/div[2]/span[1]");
		SleepUtils.sleep(5);
		uiDriver.click("//span[contains(text(),'NBCUniversal Media, LLC UAT  -  NBCU: Manager 2')]");
		SleepUtils.sleep(5);
		if(uiDriver.checkElementPresent("//span[contains(text(),'NBCUniversal Media, LLC UAT  -  NBCU: Manager 2')]")){
		//uiDriver.click("Manager1");
				passed("Verify Changing the role to Manager2UATRole",
				"Manager2UATRole Role must be changed Successfully",
				"Manager2UATRole Role is changed Successfully");
		SleepUtils.sleep(5);
		}
	}	
	
	
	/****************************************
	 * Name: ChangeRoleToManager1UAT
	 * Description: Changing the role from administrator to ChangeRoleToManager1UAT
	 * Date: 30-Nov-2017
	 ****************************************/
	public void ChangeRoleToManager1UAT(DataRow input, DataRow output)
	{
		SleepUtils.sleep(10);
		uiDriver.mouseOver("//*[@id='spn_cRR_d1']/a/div[2]/span[1]");
		SleepUtils.sleep(5);
		uiDriver.click("//span[contains(text(),'NBCUniversal Media, LLC UAT  -  NBCU: Manager 1')]");
		SleepUtils.sleep(5);
		if(uiDriver.checkElementPresent("//span[contains(text(),'NBCUniversal Media, LLC UAT  -  NBCU: Manager 1')]")){
		//uiDriver.click("Manager1");
				passed("Verify Changing the role to ChangeRoleToManager1UAT",
				"ChangeRoleToManager1UAT Role must be changed Successfully",
				"ChangeRoleToManager1UAT Role is changed Successfully");
		SleepUtils.sleep(5);
		}
	}	
	
	
	/****************************************
	 * Name: ChangeRoleToQAUAT
	 * Description: Changing the role from administrator to ChangeRoleToQAUAT
	 * Date: 30-Nov-2017
	 ****************************************/
	public void ChangeRoleToQAUAT(DataRow input, DataRow output)
	{
		SleepUtils.sleep(10);
		uiDriver.mouseOver("//*[@id='spn_cRR_d1']/a/div[2]/span[1]");
		SleepUtils.sleep(5);
		uiDriver.click("//span[contains(text(),'NBCUniversal Media, LLC UAT  -  NBCU: QA')]");
		SleepUtils.sleep(5);
		if(uiDriver.checkElementPresent("//span[contains(text(),'NBCUniversal Media, LLC UAT  -  NBCU: QA')]")){
		//uiDriver.click("Manager1");
				passed("Verify Changing the role to QAUAT",
				"QAUAT Role must be changed Successfully",
				"QAUAT Role is changed Successfully");
		SleepUtils.sleep(5);
		}
	}	
	
	/****************************************
	 * Name: VerifyTransactionAllocationDetails 
	 * Description: VerifyTransactionAllocationDetails 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void VerifyTransactionAllocationDetails(DataRow input, DataRow output)
			throws InterruptedException {
		/*SleepUtils.sleep(5);
	    uiDriver.refresh();
	    uiDriver.refresh();
	    uiDriver.refresh();
	    SleepUtils.sleep(10);
	    uiDriver.refresh();
	    SleepUtils.sleep(100);
	    SleepUtils.sleep(500);
	    uiDriver.refresh();
	    uiDriver.refresh();*/
	    uiDriver.refresh();
	    SleepUtils.sleep(10);
		uiDriver.click("Custom");
		SleepUtils.sleep(TimeSlab.LOW);
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,800)");
		uiDriver.executeJavaScript("document.getElementById('recmachcustrecord_nbcu_titleallocpa_contracttxt').click();");
		//uiDriver.click("TitleAllocationParent");
		SleepUtils.sleep(TimeSlab.LOW);
		SleepUtils.sleep(TimeSlab.LOW);
		
		
		uiDriver.executeJavaScript("scroll(0,1200)");
		SleepUtils.sleep(TimeSlab.LOW);
		int accRows = uiDriver.webDr.findElements(By.xpath("//table[@id='recmachcustrecord_nbcu_titleallocpa_contract__tab']/tbody/tr")).size();
		SleepUtils.sleep(TimeSlab.HIGH);
		for (int r = 0; r < accRows; r++) {

			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.executeJavaScript("scroll(0,900)");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			String s1 = uiDriver.getDyanmicData("DynamicTapid");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			String s2 = s1.replace("#", Integer.toString(r));
			//SleepUtils.sleep(TimeSlab.HIGH);
			for(int x=0;x<50;x++){
			if (uiDriver.checkElementPresent_dynamic(s2)){
				break;
			}
			else{ 
				uiDriver.refresh();
				uiDriver.refresh();
				uiDriver.refresh();
				uiDriver.refresh();
				uiDriver.refresh();
				uiDriver.refresh();
				SleepUtils.sleep(10);
				uiDriver.executeJavaScript("scroll(0,-500)");
				uiDriver.click("Custom");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.executeJavaScript("scroll(0,800)");
				uiDriver.executeJavaScript("document.getElementById('recmachcustrecord_nbcu_titleallocpa_contracttxt').click();");
				//uiDriver.click("TitleAllocationParent");
				SleepUtils.sleep(TimeSlab.LOW);
					
			}
			
			}
				SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click_dynamic(s2);
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.executeJavaScript("scroll(0,500)");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("AllocationDetail");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("Transactions");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			List<WebElement> Journal = uiDriver.webDr.findElements(By.xpath("//*[@id='recmachcustbody_nbcu_titleallocation__tab']/tbody//tr"));
			SleepUtils.sleep(TimeSlab.MEDIUM);
			int Journals = Journal.size();
			for (int i = 0; i < Journals; i++) {

				SleepUtils.sleep(TimeSlab.MEDIUM);
				String JournalLink = uiDriver.getDyanmicData("Journal");
				String JournalLinkValue = JournalLink.replace("#",
						Integer.toString(i));
				if(uiDriver.checkElementPresent_dynamic(JournalLinkValue))
				{
				uiDriver.click_dynamic(JournalLinkValue);
				SleepUtils.sleep(TimeSlab.MEDIUM);
				int invoiceRow = 2;
				SleepUtils.sleep(TimeSlab.MEDIUM);
				if (uiDriver.getValue("//*[@id='line_splits']//tbody/tr[" + invoiceRow+ "]/td[1]").contains("110051XX Generic Billed AR")|| uiDriver.getValue("//*[@id='line_splits']//tbody/tr["+ invoiceRow + "]/td[1]").contains("TBD - Placeholder (First Run) Cash Account for Syndication")) {

					if (uiDriver.getValue("//*[@id='line_splits']//tbody/tr[" + invoiceRow+ "]/td[2]").equals(""))

					{

						failed("Validating Debit Amount",

						"Validating Debit Amount should be successfull",

						"Debit amount is not Deferred Rev -Generic ");
					}

					else

					{

						passed("Debit is Deferred Rev - Generic",

								"Debit is Deferred Rev - Generic",

								"Debit amount is 110051XX Generic Billed AR/ TBD - Placeholder (First Run) Cash Account for Syndication");
					}

				}

				SleepUtils.sleep(TimeSlab.HIGH);
				if (uiDriver.getValue("//*[@id='line_splits']//tbody/tr[" + (invoiceRow + 1)+ "]/td[1]").contains("11005104 Billed Dom AR - First Run Cash Syn")|| uiDriver.getValue("//*[@id='line_splits']//tbody/tr["+ (invoiceRow + 1) + "]/td[1]")	.contains("TBD - Placeholder (First Run) Cash Account for Syndication")) {
					if (uiDriver.getValue("//*[@id='line_splits']//tbody/tr["+ (invoiceRow + 1) + "]/td[3]").equals("")) {
						failed("Validating Credit Amount",
								"Validating Credit Amount should be successfull",
								"Credit amount is not Generic billed AR");

					} else

					{

						passed("Credit is generic billed AR",
								"Credit is generic billed AR",
								"Credit amount is 11005104 Billed Dom AR - First Run Cash Syn/TBD - Placeholder (First Run) Cash Account for Syndication");

					}

				}
				
				if (uiDriver.getValue("//*[@id='line_splits']//tbody/tr[" + (invoiceRow + 1)+ "]/td[1]").contains("11015052 Canada Cash Clearing")|| uiDriver.getValue("//*[@id='line_splits']//tbody/tr["+ (invoiceRow + 1) + "]/td[1]").contains("11015052 Canada Cash Clearing")) {

					if (uiDriver.getValue("//*[@id='line_splits']//tbody/tr["+ (invoiceRow + 1) + "]/td[3]").equals("")) {
						failed("Validating Credit Amount",
							   "Validating Credit Amount should be successfull",
        						"Credit amount is not Generic billed AR");

					} else

					{

						passed("Credit is generic billed AR",
								"Credit is generic billed AR",
								"Credit amount is 11005104 Billed Dom AR - First Run Cash Syn/TBD - Placeholder (First Run) Cash Account for Syndication");

					}

				}
				}
				SleepUtils.sleep(TimeSlab.MEDIUM);
				uiDriver.click("Back");
				SleepUtils.sleep(TimeSlab.MEDIUM);
				uiDriver.click("AllocationDetail");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.click("Transactions");
				uiDriver.executeJavaScript("scroll(0,1000)");

			}
uiDriver.back();
SleepUtils.sleep(TimeSlab.MEDIUM);
uiDriver.click("Salesnum");
SleepUtils.sleep(TimeSlab.MEDIUM);
uiDriver.click("Custom");
SleepUtils.sleep(TimeSlab.LOW);
uiDriver.executeJavaScript("scroll(0,800)");
uiDriver.click("TitleAllocationParent");
SleepUtils.sleep(TimeSlab.LOW);

		}

	}

	/****************************************
	 * Name: VerifyPaidInFullInvoice 
	 * Description: VerifyPaidInFullInvoice 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void VerifyPaidInFullInvoice(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.executeJavaScript("scroll(0,400)");
		uiDriver.click("Custom");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,1100)");
		uiDriver.click("//*[@id='recmachcustrecord_nbcu_titleallocpa_contracttxt']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("(//td/a[contains(text(),'Payment #')])[1]");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,500)");
		List<WebElement> InvoicesPaid = uiDriver.webDr.findElements(By
				.xpath("//*[@id='apply_splits']//tbody//tr"));
		int InvPaid = InvoicesPaid.size();
		for (int i = 0; i <InvPaid - 1; i++) {
			
			String inv = uiDriver.getDyanmicData("Invoices");
			String invoices = inv.replace("#", Integer.toString(i));
			for(int g=1;g<=10;g++)
			{
			if(uiDriver.checkElementPresent_dynamic(invoices))
			{
			uiDriver.click_dynamic(invoices);
			break;
			}
			else
			{
				uiDriver.refresh();
				SleepUtils.sleep(30);
				uiDriver.refresh();
			}
			}
			SleepUtils.sleep(TimeSlab.MEDIUM);
			String PaidInvoices = uiDriver.getValue_Text("InvPaid");
			SleepUtils.sleep(TimeSlab.LOW);
			if (PaidInvoices.equalsIgnoreCase("Paid In Full") || PaidInvoices.equalsIgnoreCase("OPEN") ) {
				passed("Verify Paid In Full Invoice",
						"Paid In Full should be displayed as" + PaidInvoices+ "",
						"Paid In Full is displayed as"+ PaidInvoices + "");
			} else {
				passed("Verify Paid In Full Invoice",
						"Paid In Full should be displayed as" + PaidInvoices+ "", 
						"Paid In Full is displayed as"+ PaidInvoices + "");
			}
			uiDriver.back();
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.executeJavaScript("scroll(0,500)");
		}

	}

	/****************************************
	 * Name: EditTheAllocationRule 
	 * Description: EditTheAllocationRule 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void EditTheAllocationRule(DataRow input, DataRow output)
			throws InterruptedException {

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("DefaultEdit");
		SleepUtils.sleep(TimeSlab.LOW);
	}

	/****************************************
	 * Name: EditTheAllocationRuleAssigned 
	 * Description: EditTheAllocationRuleAssigned 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void EditTheAllocationRuleAssigned(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.setValue("Name", input.get("Name"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("Note", input.get("Note"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("InvoiceItemCategory");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("InvoiceItemCategoryInput");
		SleepUtils.sleep(TimeSlab.YIELD);
		Boolean Result = uiDriver.webDr.findElement(
				By.id("TerritoriesCheckbox")).isSelected();
		if (Result.equals(false)) {

			uiDriver.click("Territories");
		} else {
			// do nothing
		}

		Boolean RightResult = uiDriver.webDr.findElement(
				By.id("RightsCheckbox")).isSelected();
		if (RightResult.equals(false)) {

			uiDriver.click("Rights");
		} else {
			// do nothing
		}

		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("(scroll(0,1700));");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("document.getElementsByClassName('amount-value weight')[27].value='';");
		Actions action = new Actions(uiDriver.webDr);
		WebElement ele = uiDriver.webDr
				.findElement(By
						.xpath("//*[@id='territoriesGrid']/div[2]/table/tbody/tr[28]/td[4]/div[1]/div/input"));
		action.sendKeys("ele", "").build().perform();
		action.sendKeys(ele, "100.00").build().perform();
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("document.getElementsByClassName('amount-value weight')[29].value='';");
		SleepUtils.sleep(TimeSlab.LOW);
		// uiDriver.executeJavaScript("document.getElementById('line_addedit').value='100';");
		WebElement ele1 = uiDriver.webDr
				.findElement(By
						.xpath("//*[@id='rightsGrid']/div[2]/table/tbody/tr[1]/td[4]/div[1]/div/input"));
		action.sendKeys("ele1", "").build().perform();
		action.sendKeys(ele1, "100.00").build().perform();
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("document.getElementsByClassName('amount-value weight')[30].value='';");
		SleepUtils.sleep(TimeSlab.LOW);
		// uiDriver.executeJavaScript("document.getElementById('line_addedit').value='100';");
		WebElement ele2 = uiDriver.webDr.findElement(By.xpath("//*[@id='rightsGrid']/div[2]/table/tbody/tr[2]/td[4]/div[1]/div/input"));
		action.sendKeys("ele2", "").build().perform();
		action.sendKeys(ele2, "0.00").build().perform();
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Finish");
		// uiDriver.executeJavaScript("document.getElementById('finish').click();");
		/*
		 * finish=new Actions(uiDriver.webDr); WebElement finishele =
		 * uiDriver.webDr.findElement(By.xpath("//*[@id='finish']"));
		 * action.click(finishele);
		 */
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		output.put("Name", input.get("Name"));
	}
	/****************************************
	 * Name: EditTheAllocationRuleGreece Description:
	 * EditTheAllocationRuleGreece Date: 10-Oct-20178	 ****************************************/
	public void EditTheAllocationRulGreece(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.setValue("Name", input.get("Name"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("Note", input.get("Note"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("InvoiceItemCategory");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("InvoiceItemCategoryInput");
		SleepUtils.sleep(TimeSlab.YIELD);
		Boolean Result = uiDriver.webDr.findElement(
				By.id("TerritoriesCheckbox")).isSelected();
		if (Result.equals(false)) {

			uiDriver.click("Territories");
		} else {
			// do nothing
		}

		Boolean RightResult = uiDriver.webDr.findElement(
				By.id("RightsCheckbox")).isSelected();
		if (RightResult.equals(false)) {

			uiDriver.click("Rights");
		} else {
			// do nothing
		}

		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("(scroll(0,1700));");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("document.getElementsByClassName('amount-value weight')[0].value='';");
		Actions action = new Actions(uiDriver.webDr);
		WebElement ele = uiDriver.webDr
				.findElement(By
						.xpath("//*[@id='territoriesGrid']/div[2]/table/tbody/tr/td[4]/div[1]/div/input"));
		action.sendKeys("ele", "").build().perform();
		action.sendKeys(ele, "100.00").build().perform();
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("document.getElementsByClassName('amount-value weight')[1].value='';");
		SleepUtils.sleep(TimeSlab.LOW);
		// uiDriver.executeJavaScript("document.getElementById('line_addedit').value='100';");
		WebElement ele1 = uiDriver.webDr
				.findElement(By
						.xpath("//*[@id='rightsGrid']/div[2]/table/tbody/tr/td[4]/div[1]/div/input"));
		action.sendKeys("ele1", "").build().perform();
		action.sendKeys(ele1, "100.00").build().perform();
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Finish");
		// uiDriver.executeJavaScript("document.getElementById('finish').click();");
		/*
		 * finish=new Actions(uiDriver.webDr); WebElement finishele =
		 * uiDriver.webDr.findElement(By.xpath("//*[@id='finish']"));
		 * action.click(finishele);
		 */
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		output.put("Name", input.get("Name"));
	}


	/****************************************
	 * Name: AddingSingleAllocationRule 
	 * Description: AddAllocationRules 
	 * Date: 11-July-2018
	 ****************************************/
	public void AddingSingleAllocationRule(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("AddAllocationButton");
		SleepUtils.sleep(TimeSlab.YIELD);

	}

	/****************************************
	 * Name: EditContractWizard
	 * Description: EditContractWizard 
	 * Date: 11-July-2018
	 ****************************************/
	public void EditContractWizard(DataRow input, DataRow output) {
		uiDriver.executeJavaScript("(scroll(0,-300));");
		uiDriver.click("Edit");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("MarketCode");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("MarketCodeValue");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("ApplyFilters");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		List<WebElement> MarketCode = uiDriver.webDr.findElements(By.xpath("//*[@id='contract_lines_splits']//tr"));
		int MC = MarketCode.size();
		for (int i = 0; i < MC - 1; i++) {
			String MarCode = uiDriver.getDyanmicData("MarketCodes");
			String MarCodes = MarCode.replace("#", Integer.toString(i));
			String MarketCodeVal = uiDriver.getValue(MarCodes);
			if (MarketCodeVal.contains("BC")) {
				passed("Verify the MarketCode Value",
						"MarketCode Value should be displayed as "+ MarketCodeVal + "",		
						"MarketCode Value is displayed as " + MarketCodeVal+ "");
			} else {

				failed("Verify the MarketCode Value",
						"MarketCode Value should be displayed as "+ MarketCodeVal + "",
						"MarketCode Value is not displayed as " + MarketCodeVal	+ "");
			}

			String FMV = uiDriver.getDyanmicData("FMV");
			String FMVVal = FMV.replace("#", Integer.toString(i));
			uiDriver.setValue(FMVVal, "L");
			SleepUtils.sleep(TimeSlab.LOW);
		}
		
		uiDriver.executeJavaScript("(scroll(0,-600));");
		for (int j = 1; j < MC; j++) {
			
			String chkboxStatuses = uiDriver.getAttribute("Chkboxes", "class");
			String Chkbox = uiDriver.getDyanmicData("chkbox");
			String ChkboxChk = Chkbox.replace("#", Integer.toString(j));
			String chkboxArr[] = ChkboxChk.split("=");
			String chkboxVal = chkboxArr[1];
			String SelectedChkbox = chkboxVal.replace("\"", "");
			String actualSelectedValue = SelectedChkbox.replace("]", "");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.executeJavaScript("document.getElementById('"+actualSelectedValue+"').click();");
			/*Actions action = new Actions(uiDriver.webDr);
            WebElement ele = uiDriver.webDr.findElement(By.xpath(ChkboxChk));
        	SleepUtils.sleep(TimeSlabLOW);
            action.moveToElement(ele).click().build().perform();*/
            SleepUtils.sleep(TimeSlab.MEDIUM);
		}  
	

		uiDriver.executeJavaScript("(scroll(0,-300));");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("(scroll(0,-1500));");
		uiDriver.click("MoveDown");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Save");
		SleepUtils.sleep(TimeSlab.HIGH);
		}

	/****************************************
	 * Name: RevisionInFT 
	 * Description: RevisionInFT 
	 * Date: 11-July-2018
	 ****************************************/
	public void RevisionInFT(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Action");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Versioning");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("CreateRevision");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("VersionInitiated");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("VersionInitiatedBy");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.setValue("VersionReason", "QA Testing");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("CreateVersion");
		SleepUtils.sleep(TimeSlab.MEDIUM);

	}

	/****************************************
	 * Name: AddTimeLineItems 
	 * Description: AddTimeLineItems 
	 * Date: 12-Sept-2018
	 ****************************************/
	public void AddTimeLineItems(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Dates");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimeLineItems");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("AddTimeLineItem");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setFrame("//*[@id='RadWindowWrapper_ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_TimelineItemWindow']/table/tbody/tr[2]/td[2]/iframe");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimelineItemType");
		// uiDriver.setValue("TimelineItemType",input.get("Type"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimelineItemTypeValue");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("EST");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("Date", input.get("Date"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Notes");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Project");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("WaistDeep");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Add");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("BOWFinger");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Add");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Finish");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.resetFrame();
	}

	/****************************************
	 * Name: AddTimeLineItemsAllproj
	 * Description: AddTimeLineItems by checking all projects
	 * Date: 12-Sept-2018
	 ****************************************/
	public void AddTimeLineItemsAllproj(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Dates");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimeLineItems");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("AddTimeLineItem");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.setFrame("//*[@id='RadWindowWrapper_ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_TimelineItemWindow']/table/tbody/tr[2]/td[2]/iframe");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimelineItemType");
		// uiDriver.setValue("TimelineItemType",input.get("Type"));
		SleepUtils.sleep(TimeSlab.LOW);
		String Timeline = uiDriver.getDyanmicData("TimelineItemTypeValue");
		String Timeline1 = Timeline.replace("#",input.get("Type"));
		uiDriver.click(Timeline1);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("EST");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("Date", input.get("Date"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Notes");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Project");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("checkAll");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Add");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Finish");
		SleepUtils.sleep(TimeSlab.HIGH);
		while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
			SleepUtils.sleep(TimeSlab.YIELD);
		}
		uiDriver.resetFrame();
	}

	
	/****************************************
	 * Name: ValidateFMVAdjustment
	 * Description: ValidateFMVAdjustment 
	 * Date: 12-Sept-2018
	 ****************************************/
	public void ValidateFMVAdjustment(DataRow input, DataRow output) {
//		SleepUtils.sleep(600);
		uiDriver.executeJavaScript("(scroll(0,300));");
		uiDriver.click("//*[@id='customlnk']/a");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.executeJavaScript("(scroll(0,900));");
		uiDriver.click("//*[@id='recmachcustrecord_nbcu_solnk']/a");
		SleepUtils.sleep(TimeSlab.HIGH);
		//uiDriver.executeJavaScript("(scroll(0,1500));");
		//uiDriver.click("2257BowFinger");
		Actions action = new Actions(uiDriver.webDr);
		String Num = input.get("conf");
		Num = Num.substring(0, Num.length()-1);
        List<WebElement> ele = uiDriver.webDr.findElements(By.xpath("//td[contains(text(),'"+Num+"')]/../td/a"));
        int count = ele.size();
        for(int i=0; i<count; i++) {   
        	if(i>0) {
        		uiDriver.executeJavaScript("(scroll(0,300));");
        		uiDriver.click("//*[@id='customlnk']/a");
        		SleepUtils.sleep(TimeSlab.YIELD);
        		uiDriver.executeJavaScript("(scroll(0,900));");
        		uiDriver.click("//*[@id='recmachcustrecord_nbcu_solnk']/a");
        		SleepUtils.sleep(TimeSlab.YIELD);
        	}
        try {
        if(ele.get(i).isDisplayed()) {        	
        action.moveToElement(ele.get(i)).click().build().perform();
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("(scroll(0,600));");
		uiDriver.click("ContractBilledRevenue");
		SleepUtils.sleep(TimeSlab.YIELD);
		String FMVBilledRevenue = uiDriver.getValue_Text("FMVBilledRevenue");
		SleepUtils.sleep(TimeSlab.YIELD);
		//if (FMVBilledRevenue.contains("0")) {
			passed("Verify the FMVBilledRevenue",
					"FMVBilledRevenue  should be displayed Successfully as "+ FMVBilledRevenue + "",
					"FMVBilledRevenue is displayed Successfully as "+ FMVBilledRevenue + "");

	//	} 
	/*else {
			failed("Verify the FMVBilledRevenue",
					"FMVBilledRevenue should be displayed Successfully as "
							+ FMVBilledRevenue + "",
					"FMVBilledRevenue is not displayed Successfully as "
							+ FMVBilledRevenue + "");

		}*/

		String FMVBilledRevenueAdjustment = uiDriver.getValue_Text("FMVBilledRevenueAdjustment");
		SleepUtils.sleep(TimeSlab.YIELD);
	//	if (FMVBilledRevenueAdjustment.contains("0")) {
			passed("Verify the FMVBilledRevenueAdjustment",
					"FMVBilledRevenueAdjustment  should be displayed Successfully as "
							+ FMVBilledRevenueAdjustment + "",
					"FMVBilledRevenueAdjustment is displayed Successfully as "
							+ FMVBilledRevenueAdjustment + "");

		/*} else {
			failed("Verify the FMVBilledRevenueAdjustment",
					"FMVBilledRevenueAdjustment  should be displayed Successfully as "
							+ FMVBilledRevenueAdjustment + "",
					"FMVBilledRevenueAdjustment is not displayed Successfully as "
							+ FMVBilledRevenueAdjustment + "");

		}*/

		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("ContractUnBilledRevenue");
		SleepUtils.sleep(TimeSlab.YIELD);
		String FMVUnBilledRevenue = uiDriver.getValue_Text("FMVUnBilledRevenue");
		SleepUtils.sleep(TimeSlab.YIELD);
	//	if (FMVUnBilledRevenue.contains("0")) {
			passed("Verify the FMVUnBilledRevenue",
					"FMVUnBilledRevenue  should be displayed Successfully as "
							+ FMVUnBilledRevenue + "",
					"FMVUnBilledRevenue is displayed Successfully as "
							+ FMVUnBilledRevenue + "");

		/*} else {
			failed("Verify the FMVUnBilledRevenue",
					"FMVUnBilledRevenue should be displayed Successfully as "
							+ FMVUnBilledRevenue + "",
					"FMVUnBilledRevenue is not displayed Successfully as "
							+ FMVUnBilledRevenue + "");

		}*/

		String FMVUnBilledRevenueAdjustment = uiDriver.getValue_Text("FMVUnBilledRevenueAdjustment");
		SleepUtils.sleep(TimeSlab.YIELD);
		//if (FMVUnBilledRevenueAdjustment.contains("0")) {
			passed("Verify the FMVUnBilledRevenueAdjustment",
					"FMVUnBilledRevenueAdjustment  should be displayed Successfully as "
							+ FMVUnBilledRevenueAdjustment + "",
					"FMVUnBilledRevenueAdjustment is displayed Successfully as "
							+ FMVUnBilledRevenueAdjustment + "");

	/*	} else {
			failed("Verify the FMVUnBilledRevenueAdjustment",
					"FMVUnBilledRevenueAdjustment  should be displayed Successfully as "
							+ FMVUnBilledRevenueAdjustment + "",
					"FMVUnBilledRevenueAdjustment is not displayed Successfully as "
							+ FMVUnBilledRevenueAdjustment + "");

		}*/

		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("ContractBilledAR");
		SleepUtils.sleep(TimeSlab.YIELD);
		String FMVBilledAR = uiDriver.getValue_Text("FMVBilledAR");
		SleepUtils.sleep(TimeSlab.YIELD);
		//if (FMVBilledAR.contains("0")) {
			passed("Verify the FMVBilledAR",
					"FMVBilledAR  should be displayed Successfully as "	+ FMVBilledAR + "",
					"FMVBilledAR is displayed Successfully as " + FMVBilledAR+ "");

		/*} else {
			failed("Verify the FMVBilledAR",
					"FMVBilledAR should be displayed Successfully as "
							+ FMVBilledAR + "",
					"FMVBilledAR is not displayed Successfully as "
							+ FMVBilledAR + "");

		}*/

		String FMVBilledARAdjustment = uiDriver.getValue_Text("FMVBilledARAdjustment");
		SleepUtils.sleep(TimeSlab.YIELD);
		//if (FMVBilledARAdjustment.contains("0")) {
			passed("Verify the FMVBilledARAdjustment",
					"FMVBilledARAdjustment  should be displayed Successfully as "
							+ FMVBilledARAdjustment + "",
					"FMVBilledARAdjustment is displayed Successfully as "
							+ FMVBilledARAdjustment + "");

		/*} else {
			failed("Verify the FMVBilledARAdjustment",
					"FMVBilledARAdjustment  should be displayed Successfully as "
							+ FMVBilledARAdjustment + "",
					"FMVBilledARAdjustment is not displayed Successfully as "
							+ FMVBilledARAdjustment + "");

		}*/

		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("ContractUnBilledAR");
		SleepUtils.sleep(TimeSlab.YIELD);
		String FMVUnBilledAR = uiDriver.getValue_Text("FMVUnBilledAR");
		SleepUtils.sleep(TimeSlab.YIELD);
	//	if (FMVUnBilledAR.contains("0")) {
			passed("Verify the FMVUnBilledAR",
					"FMVUnBilledAR  should be displayed Successfully as "
							+ FMVUnBilledAR + "",
					"FMVUnBilledAR is displayed Successfully as "
							+ FMVUnBilledAR + "");

		/*} else {
			failed("Verify the FMVUnBilledAR",
					"FMVUnBilledAR should be displayed Successfully as "
							+ FMVUnBilledAR + "",
					"FMVUnBilledAR is not displayed Successfully as "
							+ FMVUnBilledAR + "");

		}*/

		String FMVUnBilledARAdjustment = uiDriver.getValue_Text("FMVUnBilledARAdjustment");
		SleepUtils.sleep(TimeSlab.YIELD);
		//if (FMVUnBilledARAdjustment.contains("0")) {
			passed("Verify the FMVUnBilledARAdjustment",
					"FMVUnBilledARAdjustment  should be displayed Successfully as "
							+ FMVUnBilledARAdjustment + "",
					"FMVUnBilledARAdjustment is displayed Successfully as "
							+ FMVUnBilledARAdjustment + "");

		/*} else {
			failed("Verify the FMVUnBilledARAdjustment",
					"FMVUnBilledARAdjustment  should be displayed Successfully as "
							+ FMVUnBilledARAdjustment + "",
					"FMVUnBilledARAdjustment is not displayed Successfully as "
							+ FMVUnBilledARAdjustment + "");

		}*/

		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("ContractUnpaidDeferred");
		SleepUtils.sleep(TimeSlab.YIELD);
		String FMVUnpaidDeferred = uiDriver.getValue_Text("FMVUnpaidDeferred");
		SleepUtils.sleep(TimeSlab.YIELD);
	//	if (FMVUnpaidDeferred.contains("0")) {
			passed("Verify the FMVUnpaidDeferred",
					"FMVUnpaidDeferred  should be displayed Successfully as "
							+ FMVUnpaidDeferred + "",
					"FMVUnpaidDeferred is displayed Successfully as "
							+ FMVUnpaidDeferred + "");

		/*} else {
			failed("Verify the FMVUnpaidDeferred",
					"FMVUnpaidDeferred should be displayed Successfully as "
							+ FMVUnpaidDeferred + "",
					"FMVUnpaidDeferred is not displayed Successfully as "
							+ FMVUnpaidDeferred + "");

		}*/

		String FMVUnpaidDeferredAdjustment = uiDriver
				.getValue_Text("FMVUnpaidDeferredAdjustment");
		SleepUtils.sleep(TimeSlab.YIELD);
		//if (FMVUnpaidDeferredAdjustment.contains("0")) {
			passed("Verify the FMVUnpaidDeferredAdjustment",
					"FMVUnpaidDeferredAdjustment  should be displayed Successfully as "
							+ FMVUnpaidDeferredAdjustment + "",
					"FMVUnpaidDeferredAdjustment is displayed Successfully as "
							+ FMVUnpaidDeferredAdjustment + "");

		/*} else {
			failed("Verify the FMVUnpaidDeferredAdjustment",
					"FMVUnpaidDeferredAdjustment  should be displayed Successfully as "
							+ FMVUnpaidDeferredAdjustment + "",
					"FMVUnpaidDeferredAdjustment is not displayed Successfully as "
							+ FMVUnpaidDeferredAdjustment + "");

		}*/

		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("ContractPaidDeferred");
		SleepUtils.sleep(TimeSlab.YIELD);
		String FMVPaidDeferred = uiDriver.getValue_Text("FMVPaidDeferred");
		SleepUtils.sleep(TimeSlab.YIELD);
		//if (FMVPaidDeferred.contains("0")) {
			passed("Verify the FMVPaidDeferred",
					"FMVPaidDeferred  should be displayed Successfully as "
							+ FMVPaidDeferred + "",
					"FMVPaidDeferred is displayed Successfully as "
							+ FMVPaidDeferred + "");

		/*} else {
			failed("Verify the FMVPaidDeferred",
					"FMVPaidDeferred should be displayed Successfully as "
							+ FMVPaidDeferred + "",
					"FMVPaidDeferred is not displayed Successfully as "
							+ FMVPaidDeferred + "");

		}*/

		String FMVPaidDeferredAdjustment = uiDriver
				.getValue_Text("FMVPaidDeferredAdjustment");
		SleepUtils.sleep(TimeSlab.YIELD);
	//	if (FMVPaidDeferredAdjustment.contains("0")) {
			passed("Verify the FMVPaidDeferredAdjustment",
					"FMVPaidDeferredAdjustment  should be displayed Successfully as "
							+ FMVPaidDeferredAdjustment + "",
					"FMVPaidDeferredAdjustment is displayed Successfully as "
							+ FMVPaidDeferredAdjustment + "");

		/*} else {
			failed("Verify the FMVPaidDeferredAdjustment",
					"FMVPaidDeferredAdjustment  should be displayed Successfully as "
							+ FMVPaidDeferredAdjustment + "",
					"FMVPaidDeferredAdjustment is not displayed Successfully as "
							+ FMVPaidDeferredAdjustment + "");

		}*/

		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("ContractFXGainLoss");
		SleepUtils.sleep(TimeSlab.YIELD);
		String FMVFXGainLoss = uiDriver.getValue_Text("FMVFXGainLoss");
		SleepUtils.sleep(TimeSlab.YIELD);
		//if (FMVFXGainLoss.contains("0")) {
			passed("Verify the FMVFXGainLoss",
					"FMVFXGainLoss  should be displayed Successfully as "
							+ FMVFXGainLoss + "",
					"FMVFXGainLoss is displayed Successfully as "
							+ FMVFXGainLoss + "");

	/*	} else {
			failed("Verify the FMVFXGainLoss",
					"FMVFXGainLoss should be displayed Successfully as "
							+ FMVFXGainLoss + "",
					"FMVFXGainLoss is not displayed Successfully as "
							+ FMVFXGainLoss + "");

		}*/

//		String FMVFXGainLossAdjustment = uiDriver
//				.getValue_Text("FMVFXGainLossAdjustment");
//		SleepUtils.sleep(TimeSlab.YIELD);
//	//	if (FMVFXGainLossAdjustment.contains("0")) {
//			passed("Verify the FMVFXGainLossAdjustment",
//					"FMVFXGainLossAdjustment  should be displayed Successfully as "
//							+ FMVFXGainLossAdjustment + "",
//					"FMVFXGainLossAdjustment is displayed Successfully as "
//							+ FMVFXGainLossAdjustment + "");

		/*} else {
			failed("Verify the FMVFXGainLossAdjustment",
					"FMVFXGainLossAdjustment  should be displayed Successfully as "
							+ FMVFXGainLossAdjustment + "",
					"FMVFXGainLossAdjustment is not displayed Successfully as "
							+ FMVFXGainLossAdjustment + "");

		}*/

		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("ContractWHT");
		SleepUtils.sleep(TimeSlab.YIELD);
		String FMVWHT = uiDriver.getValue_Text("FMVWHT");
		SleepUtils.sleep(TimeSlab.YIELD);
	//	if (FMVWHT.contains("0")) {
			passed("Verify the FMVWHT",
					"FMVWHT  should be displayed Successfully as " + FMVWHT
							+ "", "FMVWHT is displayed Successfully as "
							+ FMVWHT + "");

		/*} else {
			failed("Verify the FMVWHT",
					"FMVWHT should be displayed Successfully as " + FMVWHT + "",
					"FMVWHT is not displayed Successfully as " + FMVWHT + "");

		}*/

		String FMVWHTAdjustment = uiDriver.getValue_Text("FMVWHTAdjustment");
		SleepUtils.sleep(TimeSlab.YIELD);
	//	if (FMVWHTAdjustment.contains("0")) {
			passed("Verify the FMVWHTAdjustment",
					"FMVWHTAdjustment  should be displayed Successfully as "
							+ FMVWHTAdjustment + "",
					"FMVWHTAdjustment is displayed Successfully as "
							+ FMVWHTAdjustment + "");

	/*	} else {
			failed("Verify the FMVWHTAdjustment",
					"FMVWHTAdjustment  should be displayed Successfully as "
							+ FMVWHTAdjustment + "",
					"FMVWHTAdjustment is not displayed Successfully as "
							+ FMVWHTAdjustment + "");

		}*/

			uiDriver.back();   
        }
        } catch(Exception e) {
        	
        }
        }
	}
	/****************************************
	 * Name: ValidateFMVForHighlander 
	 * Description: ValidateFMVForHighlander 
	 * Date: 14-November-2018
	 ****************************************/
	public void FMVAdjustmentHighLucy(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.executeJavaScript("(scroll(0,300));");
		uiDriver.click("CustomTab");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.executeJavaScript("(scroll(0,900));");
		uiDriver.click("FMVAdjustment");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Dropdown");		
		List<WebElement> dropdown = uiDriver.webDr.findElements(By.xpath("//div[@class='dropdownDiv']/div"));
		int dropdownsize = dropdown.size();
		highlandersearch:
		for(int k=1;k<=dropdownsize;k++)
		{
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("FMVAdjustment");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Dropdown");
		//	uiDriver.click("//input[@name='inpt_recmachcustrecord_nbcu_sorange']");
			SleepUtils.sleep(TimeSlab.HIGH);
		//	uiDriver.click_dynamic("//div[@class='dropdownDiv']/div["+k+"]");
			String sheets = uiDriver.getDyanmicData("sheets");
			String sheetno = sheets.replace("#", Integer.toString(k));
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click_dynamic(sheetno);
			List<WebElement> titles = uiDriver.webDr.findElements(By.xpath("(//div[text()='Title'])[2]/../../../following-sibling::tbody/tr"));
			int titlesize = titles.size();
			for(int l=0;l<titlesize;l++)
			{
				String random = uiDriver.getDyanmicData("titlenames");
				String randomno = random.replace("#", Integer.toString(l));
				String titlevalue=uiDriver.getValue_Text(randomno);
				String Title = input.get("title");
				SleepUtils.sleep(TimeSlab.YIELD);
				if (Title.equalsIgnoreCase(titlevalue))
				{
					passed("Verify the Title",
							""+ Title +" should be displayed Successfully as "+ titlevalue + "",
							""+ Title +" is displayed Successfully as "+ titlevalue + "");
					SleepUtils.sleep(TimeSlab.HIGH);
					//uiDriver.executeJavaScript("(scroll(0,2500));");
				//	uiDriver.click("HighlanderID");	
					String FMVTitles = uiDriver.getDyanmicData("FMVTitles");
					String FMVActualtitle = FMVTitles.replace("#", input.get("title"));
					uiDriver.click_dynamic(FMVActualtitle);
					
					
					SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("(scroll(0,2500));");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("ContractBilledRevenue");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String ContractBilledRevenue = uiDriver.getValue_Text("Contractual");		
		SleepUtils.sleep(TimeSlab.YIELD);
		if (ContractBilledRevenue.contains(input.get("ContractualBilledRevenue"))) {
			passed("Verify the ContractBilledRevenue",
					"ContractBilledRevenue  should be displayed Successfully as "+ ContractBilledRevenue + "",
					"ContractBilledRevenue is displayed Successfully as "+ ContractBilledRevenue + "");

		} else {
			failed("Verify the ContractBilledRevenue",
					"ContractBilledRevenue should be displayed Successfully as "+ ContractBilledRevenue + "",
					"ContractBilledRevenue is not displayed Successfully as "+ ContractBilledRevenue + "");

		}
		
		String FMVBilledRevenueAdjustment = uiDriver.getValue_Text("FMVBilledRevenueAdjustment");		
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVBilledRevenueAdjustment.contains(input.get("BilledRevenueAdjustment"))) {
			passed("Verify the FMVBilledRevenueAdjustment",
					"FMVBilledRevenueAdjustment  should be displayed Successfully as "+ FMVBilledRevenueAdjustment + "",
					"FMVBilledRevenueAdjustment is displayed Successfully as "+ FMVBilledRevenueAdjustment + "");

		} else {
			failed("Verify the FMVBilledRevenueAdjustment",
					"FMVBilledRevenueAdjustment  should be displayed Successfully as "+ FMVBilledRevenueAdjustment + "",
					"FMVBilledRevenueAdjustment is not displayed Successfully as "+ FMVBilledRevenueAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractUnBilledRevenue");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVUnBilledRevenue = uiDriver.getValue_Text("FMVUnBilledRevenue");		
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVUnBilledRevenue.contains(input.get("ContractUnbilledRevenue"))){
			passed("Verify the FMVUnBilledRevenue",
					"FMVUnBilledRevenue  should be displayed Successfully as "+ FMVUnBilledRevenue + "",
					"FMVUnBilledRevenue is displayed Successfully as "+ FMVUnBilledRevenue + "");

		} else {
			failed("Verify the FMVUnBilledRevenue",
					"FMVUnBilledRevenue should be displayed Successfully as "
							+ FMVUnBilledRevenue + "",
					"FMVUnBilledRevenue is not displayed Successfully as "
							+ FMVUnBilledRevenue + "");

		}
		
		String FMVUnBilledRevenueAdjustment = uiDriver.getValue_Text("FMVBilledRevenueAdjustment");		
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVUnBilledRevenueAdjustment.contains(input.get("UnBilledRevenueAdjustment"))) {
			passed("Verify the FMVUnBilledRevenueAdjustment",
					"FMVUnBilledRevenueAdjustment  should be displayed Successfully as "
							+ FMVUnBilledRevenueAdjustment + "",
					"FMVUnBilledRevenueAdjustment is displayed Successfully as "
							+ FMVUnBilledRevenueAdjustment + "");

		} else {
			failed("Verify the FMVUnBilledRevenueAdjustment",
					"FMVUnBilledRevenueAdjustment  should be displayed Successfully as "
							+ FMVUnBilledRevenueAdjustment + "",
					"FMVUnBilledRevenueAdjustment is not displayed Successfully as "
							+ FMVUnBilledRevenueAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractBilledAR");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVBilledAR = uiDriver.getValue_Text("FMVBilledAR");		
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVBilledAR.contains(input.get("BilledAR"))) {
			passed("Verify the FMVBilledAR",
					"FMVBilledAR  should be displayed Successfully as "
							+ FMVBilledAR + "",
					"FMVBilledAR is displayed Successfully as " + FMVBilledAR
							+ "");

		} else {
			failed("Verify the FMVBilledAR",
					"FMVBilledAR should be displayed Successfully as "
							+ FMVBilledAR + "",
					"FMVBilledAR is not displayed Successfully as "
							+ FMVBilledAR + "");

		}

		String FMVBilledARAdjustment = uiDriver.getValue_Text("FMVBilledARAdjustment");		
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVBilledARAdjustment.contains(input.get("BilledARAdjustment"))) {
			passed("Verify the FMVBilledARAdjustment",
					"FMVBilledARAdjustment  should be displayed Successfully as "
							+ FMVBilledARAdjustment + "",
					"FMVBilledARAdjustment is displayed Successfully as "
							+ FMVBilledARAdjustment + "");

		} else {
			failed("Verify the FMVBilledARAdjustment",
					"FMVBilledARAdjustment  should be displayed Successfully as "
							+ FMVBilledARAdjustment + "",
					"FMVBilledARAdjustment is not displayed Successfully as "
							+ FMVBilledARAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractUnBilledAR");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVUnBilledAR = uiDriver.getValue_Text("FMVUnBilledAR");		
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVUnBilledAR.contains("UnBilledAR")) {
			passed("Verify the FMVUnBilledAR",
					"FMVUnBilledAR  should be displayed Successfully as "
							+ FMVUnBilledAR + "",
					"FMVUnBilledAR is displayed Successfully as "
							+ FMVUnBilledAR + "");

		} else {
			failed("Verify the FMVUnBilledAR",
					"FMVUnBilledAR should be displayed Successfully as "
							+ FMVUnBilledAR + "",
					"FMVUnBilledAR is not displayed Successfully as "
							+ FMVUnBilledAR + "");

		}

		String FMVUnBilledARAdjustment = uiDriver.getValue_Text("FMVUnBilledARAdjustment");		
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVUnBilledARAdjustment.contains("UnBilledARAdjustment")) {
			passed("Verify the FMVUnBilledARAdjustment",
					"FMVUnBilledARAdjustment  should be displayed Successfully as "
							+ FMVUnBilledARAdjustment + "",
					"FMVUnBilledARAdjustment is displayed Successfully as "
							+ FMVUnBilledARAdjustment + "");

		} else {
			failed("Verify the FMVUnBilledARAdjustment",
					"FMVUnBilledARAdjustment  should be displayed Successfully as "
							+ FMVUnBilledARAdjustment + "",
					"FMVUnBilledARAdjustment is not displayed Successfully as "
							+ FMVUnBilledARAdjustment + "");
//-------
		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractUnpaidDeferred");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVUnpaidDeferred = uiDriver.getValue_Text("FMVUnpaidDeferred");		
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVUnpaidDeferred.contains("UnpaidDeferred")) {
			passed("Verify the FMVUnpaidDeferred",
					"FMVUnpaidDeferred  should be displayed Successfully as "
							+ FMVUnpaidDeferred + "",
					"FMVUnpaidDeferred is displayed Successfully as "
							+ FMVUnpaidDeferred + "");

		} else {
			failed("Verify the FMVUnpaidDeferred",
					"FMVUnpaidDeferred should be displayed Successfully as "
							+ FMVUnpaidDeferred + "",
					"FMVUnpaidDeferred is not displayed Successfully as "
							+ FMVUnpaidDeferred + "");

		}															

		String FMVUnpaidDeferredAdjustment = uiDriver.getValue_Text("FMVUnpaidDeferredAdjustment");		
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVUnpaidDeferredAdjustment.contains("UnpaidDeferredAdjustment")) {
			passed("Verify the FMVUnpaidDeferredAdjustment",
					"FMVUnpaidDeferredAdjustment  should be displayed Successfully as "
							+ FMVUnpaidDeferredAdjustment + "",
					"FMVUnpaidDeferredAdjustment is displayed Successfully as "
							+ FMVUnpaidDeferredAdjustment + "");

		} else {
			failed("Verify the FMVUnpaidDeferredAdjustment",
					"FMVUnpaidDeferredAdjustment  should be displayed Successfully as "
							+ FMVUnpaidDeferredAdjustment + "",
					"FMVUnpaidDeferredAdjustment is not displayed Successfully as "
							+ FMVUnpaidDeferredAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractPaidDeferred");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVPaidDeferred = uiDriver.getValue_Text("FMVPaidDeferred");		
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVPaidDeferred.contains("PaidDeferred")) {
			passed("Verify the FMVPaidDeferred",
					"FMVPaidDeferred  should be displayed Successfully as "
							+ FMVPaidDeferred + "",
					"FMVPaidDeferred is displayed Successfully as "
							+ FMVPaidDeferred + "");

		} else {
			failed("Verify the FMVPaidDeferred",
					"FMVPaidDeferred should be displayed Successfully as "
							+ FMVPaidDeferred + "",
					"FMVPaidDeferred is not displayed Successfully as "
							+ FMVPaidDeferred + "");

		}

		String FMVPaidDeferredAdjustment = uiDriver.getValue_Text("FMVPaidDeferredAdjustment");		
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVPaidDeferredAdjustment.contains("PaidDeferredAdjustment")) {
			passed("Verify the FMVPaidDeferredAdjustment",
					"FMVPaidDeferredAdjustment  should be displayed Successfully as "
							+ FMVPaidDeferredAdjustment + "",
					"FMVPaidDeferredAdjustment is displayed Successfully as "
							+ FMVPaidDeferredAdjustment + "");

		} else {
			failed("Verify the FMVPaidDeferredAdjustment",
					"FMVPaidDeferredAdjustment  should be displayed Successfully as "
							+ FMVPaidDeferredAdjustment + "",
					"FMVPaidDeferredAdjustment is not displayed Successfully as "
							+ FMVPaidDeferredAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractFXGainLoss");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVFXGainLoss = uiDriver.getValue_Text("FMVFXGainLoss");		
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVFXGainLoss.contains("FXGainLoss")) {
			passed("Verify the FMVFXGainLoss",
					"FMVFXGainLoss  should be displayed Successfully as "
							+ FMVFXGainLoss + "",
					"FMVFXGainLoss is displayed Successfully as "
							+ FMVFXGainLoss + "");

		} else {
			failed("Verify the FMVFXGainLoss",
					"FMVFXGainLoss should be displayed Successfully as "
							+ FMVFXGainLoss + "",
					"FMVFXGainLoss is not displayed Successfully as "
							+ FMVFXGainLoss + "");

		}

		String FMVFXGainLossAdjustment = uiDriver.getValue_Text("FMVFXGainLossAdjustment");		
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVFXGainLossAdjustment.contains("FXGainLossAdjustment")) {
			passed("Verify the FMVFXGainLossAdjustment",
					"FMVFXGainLossAdjustment  should be displayed Successfully as "
							+ FMVFXGainLossAdjustment + "",
					"FMVFXGainLossAdjustment is displayed Successfully as "
							+ FMVFXGainLossAdjustment + "");

		} else {
			failed("Verify the FMVFXGainLossAdjustment",
					"FMVFXGainLossAdjustment  should be displayed Successfully as "
							+ FMVFXGainLossAdjustment + "",
					"FMVFXGainLossAdjustment is not displayed Successfully as "
							+ FMVFXGainLossAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractWHT");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVWHT = uiDriver.getValue_Text("FMVWHT");		
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVWHT.contains("WHT")) {
			passed("Verify the FMVWHT",
					"FMVWHT  should be displayed Successfully as " + FMVWHT
							+ "", "FMVWHT is displayed Successfully as "
							+ FMVWHT + "");

		} else {
			failed("Verify the FMVWHT",
					"FMVWHT should be displayed Successfully as " + FMVWHT + "",
					"FMVWHT is not displayed Successfully as " + FMVWHT + "");

		}

		String FMVWHTAdjustment = uiDriver.getValue_Text("FMVWHTAdjustment");		
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVWHTAdjustment.contains("WHTAdjustment")) {
			passed("Verify the FMVWHTAdjustment",
					"FMVWHTAdjustment  should be displayed Successfully as "
							+ FMVWHTAdjustment + "",
					"FMVWHTAdjustment is displayed Successfully as "
							+ FMVWHTAdjustment + "");

		} else {
			failed("Verify the FMVWHTAdjustment",
					"FMVWHTAdjustment  should be displayed Successfully as "
							+ FMVWHTAdjustment + "",
					"FMVWHTAdjustment is not displayed Successfully as "
							+ FMVWHTAdjustment + "");

		}
					break highlandersearch;
				}

	}
	
		}
		
//		uiDriver.executeJavaScript("(scroll(0,1500));");
//		SleepUtils.sleep(TimeSlab.MEDIUM);
//		uiDriver.click("HighlanderID");
		

	}
	
	/****************************************
	 * Name: VerifyEstimateReason 
	 * Description: VerifyEstimateReason 
	 * Date: 12-Sept-2018
	 ****************************************/
	public void VerifyEstimateReason(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("(scroll(0,500));");
		uiDriver.executeJavaScript("document.getElementsByClassName('formtabtext formtabtextoff')[6].click();");
		//uiDriver.click("RelatedTransactions");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("DocumentNumber");
		SleepUtils.sleep(TimeSlab.LOW);
		String Action = uiDriver.getValue_Text("Action");
		if (Action.contains("Update SO Line")) {
			passed("Verify the Action",
					"Action  should be displayed Successfully as " + Action
							+ "", "Action is displayed Successfully as "
							+ Action + "");

		} else {
			failed("Verify the Action",
					"Action  should be displayed Successfully as " + Action
							+ "", "Action is not displayed Successfully as "
							+ Action + "");

		}

		String RevrecMethod = uiDriver.getValue_Text("RevrecMethod");
		if (RevrecMethod.contains("License Period Start Date")) {
			passed("Verify the RevrecMethod",
					"RevrecMethod  should be displayed Successfully as "
							+ RevrecMethod + "",
					"RevrecMethod is displayed Successfully as " + RevrecMethod
							+ "");

		} else {
			failed("Verify the RevrecMethod",
					"RevrecMethod  should be displayed Successfully as "
							+ RevrecMethod + "",
					"RevrecMethod is not displayed Successfully as "
							+ RevrecMethod + "");

		}
		String LicensePeriodStartDate = uiDriver
				.getValue_Text("LicensePeriodStartDate");
		if (LicensePeriodStartDate.contains("12/31/2017")) {
			passed("Verify the LicensePeriodStartDate",
					"LicensePeriodStartDate  should be displayed Successfully as "
							+ LicensePeriodStartDate + "",
					"LicensePeriodStartDate is displayed Successfully as "
							+ LicensePeriodStartDate + "");

		} else {
			failed("Verify the LicensePeriodStartDate",
					"LicensePeriodStartDate  should be displayed Successfully as "
							+ LicensePeriodStartDate + "",
					"LicensePeriodStartDate is not displayed Successfully as "
							+ LicensePeriodStartDate + "");

		}

		String LicensePeriodEndDate = uiDriver
				.getValue_Text("LicensePeriodEndDate");
		if (LicensePeriodEndDate.contains("12/1/2017")) {
			passed("Verify the LicensePeriodEndDate",
					"LicensePeriodEndDate  should be displayed Successfully as "
							+ LicensePeriodEndDate + "",
					"LicensePeriodEndDate is displayed Successfully as "
							+ LicensePeriodEndDate + "");

		} else {
			failed("Verify the LicensePeriodEndDate",
					"LicensePeriodEndDate  should be displayed Successfully as "
							+ LicensePeriodEndDate + "",
					"LicensePeriodEndDate is not displayed Successfully as "
							+ LicensePeriodEndDate + "");

		}
		String DeliveryDate = uiDriver.getValue_Text("DeliveryDate");
		if (DeliveryDate.contains("1/8/2018")) {
			passed("Verify the DeliveryDate",
					"DeliveryDate  should be displayed Successfully as "
							+ DeliveryDate + "",
					"DeliveryDate is displayed Successfully as " + DeliveryDate
							+ "");

		} else {
			failed("Verify the DeliveryDate",
					"DeliveryDate  should be displayed Successfully as "
							+ DeliveryDate + "",
					"DeliveryDate is not displayed Successfully as "
							+ DeliveryDate + "");

		}

		String RevRecStartDate = uiDriver.getValue_Text("RevRecStartDate");
		if (RevRecStartDate.contains("1/8/2018")) {
			passed("Verify the RevRecStartDate",
					"RevRecStartDate  should be displayed Successfully as "
							+ RevRecStartDate + "",
					"RevRecStartDate is displayed Successfully as "
							+ RevRecStartDate + "");

		} else {
			failed("Verify the RevRecStartDate",
					"RevRecStartDate  should be displayed Successfully as "
							+ RevRecStartDate + "",
					"RevRecStartDate is not displayed Successfully as "
							+ RevRecStartDate + "");

		}

		String RevRecEndDate = uiDriver.getValue_Text("RevRecEndDate");
		if (RevRecEndDate.contains("1/8/2018")) {
			passed("Verify the RevRecEndDate",
					"RevRecEndDate  should be displayed Successfully as "
							+ RevRecEndDate + "",
					"RevRecEndDate is displayed Successfully as "
							+ RevRecEndDate + "");

		} else {
			failed("Verify the RevRecEndDate",
					"RevRecEndDate  should be displayed Successfully as "
							+ RevRecEndDate + "",
					"RevRecEndDate is not displayed Successfully as "
							+ RevRecEndDate + "");

		}
	}

	
	/****************************************
	 * Name: VerifyEstimateReasonRemoveSO 
	 * Description: VerifyEstimateReasonRemoveSO 
	 * Date: 31-October-2018
	 ****************************************/
	public void VerifyEstimateReasonRemoveSO(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("(scroll(0,500));");
		uiDriver.click("RelatedTransactions");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("DocumentNumber");
		SleepUtils.sleep(TimeSlab.LOW);
		String RemoveSoLine = uiDriver.getValue_Text("RemoveSoLine");
		if (RemoveSoLine.contains("Remove SO Line")) {
			passed("Verify the RemoveSoLine",
					"RemoveSoLine  should be displayed Successfully as " + RemoveSoLine
							+ "", "RemoveSoLine is displayed Successfully as "
							+ RemoveSoLine + "");

		} else {
			failed("Verify the RemoveSoLine",
					"RemoveSoLine  should be displayed Successfully as " + RemoveSoLine
							+ "", "RemoveSoLine is not displayed Successfully as "
							+ RemoveSoLine + "");

		}

		String Title = uiDriver.getValue_Text("Title");
		if (Title.contains("BNI-05|I3522|JAKE & AMY")) {
			passed("Verify the Title",
					"Title  should be displayed Successfully as "
							+ Title + "",
					"Title is displayed Successfully as " + Title
							+ "");

		} else {
			failed("Verify the Title",
					"Title  should be displayed Successfully as "
							+ Title + "",
					"Title is not displayed Successfully as "
							+ Title + "");

		}
		
		
	}

	
	/****************************************
	 * Name: ValidateRevision 
	 * Description: ValidateRevision 
	 * Date: 31-October-2018
	 ****************************************/
	public void ValidateRevision(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("(scroll(0,-1500));");
		uiDriver.click("ValidateRevision");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.handleAlert("", "OK");
		SleepUtils.sleep(TimeSlab.LOW);
		
	}
	
	/****************************************
	 * Name: VerifyEstimateReason 
	 * Description: VerifyEstimateReason 
	 * Date: 12-Sept-2018
	 ****************************************/
	public void VerifyMasterRevisionEstimateStatus(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.executeJavaScript("(scroll(0,500));");
		uiDriver.executeJavaScript("document.getElementsByClassName('formtabtext formtabtextoff')[6].click();");
		//uiDriver.click("RelatedTransactions");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("DocumentNumber");
		SleepUtils.sleep(TimeSlab.LOW);
		String CommittedChk = uiDriver.getAttribute("CommittedChk", "class");
		if (CommittedChk.contains("checkbox_read_ck")) {
			passed("Verify the Committed Check box",
					"Committed check box should be Checked Successfully",
					"Committed check box is Checked Successfully");

		} else {
			failed("Verify the Committed Check box",
					"Committed check box should be Checked Successfully",
					"Committed check box is not Checked Successfully");

		}
	}
	/****************************************
	 * Name: AllocationRuleAssignedToMultipleBillingSchedule 
	 * Description: AllocationRuleAssignedToMultipleBillingSchedule
	 * Date: 12-Sept-2018
	 ****************************************/
	public void AllocationRuleAssignedToMultipleBillingSchedule(DataRow input,
			DataRow output) {
		SleepUtils.sleep(TimeSlab.HIGH);

		List<WebElement> Billing = uiDriver.webDr.findElements(By.xpath("//*[@id='contract-billing-schedules-grid']/div[3]/table//tr"));
		int size = Billing.size();
		for(i=1;i<size;i++)
		{
			String Edit = uiDriver.getDyanmicData("Edit");
			String EditField = Edit.replace("#", Integer.toString(i));
			uiDriver.click_dynamic(EditField);
			uiDriver.executeJavaScript("scroll(900,0)");
			//uiDriver.setValue("AllocationRule", input.get("AllocationRule"));
			//uiDriver.setValue("//input[@name='ContractBillingGroupId_input']", input);
			//uiDriver.setValue("//input[@name='ContractBillingGroupId_input']",input.get("AllocationRule"));
		uiDriver.click("//*[@id='AllocationRuleNote']");
			Boolean Result = uiDriver.webDr.findElement(By.id("TerritoriesCheckbox")).isSelected();
			if (Result.equals(false)) {

				uiDriver.click("Territories");
			} else {
				// do nothing
			}

			Boolean RightResult = uiDriver.webDr.findElement(By.id("RightsCheckbox")).isSelected();
			if (RightResult.equals(false)) {

				uiDriver.click("Rights");
			} else {
				// do nothing
			}
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Next");
			Boolean Result1 = uiDriver.webDr.findElement(
					By.id("TerritoriesCheckbox")).isSelected();
		if (Result1.equals(false)) {

				uiDriver.click("Territories");
			} else {
				// do nothing
			}

			Boolean RightResult1 = uiDriver.webDr.findElement(
					By.id("RightsCheckbox")).isSelected();
			if (RightResult1.equals(false)) {

				uiDriver.click("Rights");
			} else {
				// do nothing
			}
			//SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Next");
			SleepUtils.sleep(TimeSlab.HIGH);
		    uiDriver.click("Next");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.executeJavaScript("scroll(0,600)");
			uiDriver.click("Next");

			//uiDriver.click("//*[@id='return']//preceding::span[5]"); //oly for 10k uncomment
			//uiDriver.click("/html/body/div[17]/div/div[2]/ul/li[3]");
			
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Finish");
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
		//SleepUtils.sleep(TimeSlab.HIGH);	
			}
	}	
	
	/****************************************
	 * Name: GenerateMultipleInvoices
	 * Description: GenerateMultipleInvoices
	 * Date: 12-Sept-2018
	 ****************************************/
	public void GenerateMultipleInvoices(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Invoices");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("BulkOperations");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("GenerateInvoices");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Filter");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("searchinput");
		String ContractId = input.get("ContractId");
		uiDriver.setValue("searchinput", input.get("ContractId"));
		// uiDriver.setValue("searchinput", "123178");
		if(input.get("Title").equals("Y"))
		{
			uiDriver.click("TitleAll");
			uiDriver.setValue("TitleAllGetText",input.get("Titlename"));
			SleepUtils.sleep(TimeSlab.MEDIUM);
				
		}
		/*if(input.get("DueDate").equals("Y")){
			
			uiDriver.click("//*[text()='Effective Due Date: All']");
			uiDriver.setValue("//*[text()='On or after']/following::input[1]", input.get("StartDate"));
			uiDriver.setValue("//*[text()='Before']/following::input[1]", input.get("EndDate"));
			}*/
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Search");	
//		SleepUtils.sleep(TimeSlab.MEDIUM);
//		uiDriver.click("//*[@id='CriteriaDropdown']/button[1]");
//		SleepUtils.sleep(TimeSlab.MEDIUM);
//		uiDriver.click("//*[@id='FilterSelector']/li[30]/label/input");
//		SleepUtils.sleep(TimeSlab.MEDIUM);
//		uiDriver.click("//*[@id='CriteriaContainer']/div[4]/div/span[2]");
//		SleepUtils.sleep(TimeSlab.MEDIUM);
//		//uiDriver.setValue("//*[@id='CriteriaContainer']/div[4]/ul/li[4]/span[1]/span/input",input.get("StartDate"));
//		SleepUtils.sleep(TimeSlab.MEDIUM);
//		uiDriver.setValue("//*[@id='CriteriaContainer']/div[4]/ul/li[4]/span[2]/span/input",input.get("EndDate"));
//		SleepUtils.sleep(TimeSlab.MEDIUM);
//		uiDriver.click("Search");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.LOW);
		if(input.get("Pagination").equals("Y")){
			uiDriver.executeJavaScript("scroll(0,2000)");
			String pages = uiDriver.getValue_Text("No.of.pages");
			String PageArr[] = pages.split(" ");
			String SetPage = PageArr[4];
			Integer page = Integer.parseInt(SetPage)- 50;
			SleepUtils.sleep(TimeSlab.LOW);
			for(int n=0;n<page;n++){
				uiDriver.click("//*[@id='AdvancedSearchResultsGrid']/div[4]/span[1]/span/span/span[2]/span[1]/span");
				SleepUtils.sleep(3);	
			}
			SleepUtils.sleep(TimeSlab.HIGH);	
			uiDriver.executeJavaScript("scroll(0,-2500)");
			uiDriver.click("Search");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("button_CreateAll");
			//uiDriver.webDr.findElement(By.xpath("//*[@id='AdvancedSearchResultsGrid']/div[4]/span[1]/span/span/input[1]")).sendKeys(Keys.ENTER);
//			SleepUtils.sleep(TimeSlab.LOW);
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("button_CreateInvoice");
			SleepUtils.sleep(TimeSlab.MEDIUM);
//			String invoicenum = uiDriver.getValue("InvoiceID");
//			SleepUtils.sleep(TimeSlab.MEDIUM);
//			uiDriver.click("InvoiceID");
//			SleepUtils.sleep(TimeSlab.MEDIUM);
			passed("Verify the Invoice",
					"Invoice should be displayed successfully",
					"Invoice is displayed successfully");
//			output.put("Invoice", invoicenum);
//			SleepUtils.sleep(TimeSlab.LOW);
//			uiDriver.click("Invoices");
//			SleepUtils.sleep(TimeSlab.YIELD);
//			output.put("Invoice", invoicenum);
							
		}
		else{

//		uiDriver.click("CheckAllRows");
////		uiDriver.click("button_CreateAll");
//		SleepUtils.sleep(TimeSlab.MEDIUM);
//		uiDriver.click("Createinvoice");
////		uiDriver.click("button_CreateInvoice");
//		SleepUtils.sleep(TimeSlab.MEDIUM);
//		String invoicenum = uiDriver.getValue("InvoiceID");
//		SleepUtils.sleep(TimeSlab.MEDIUM);
//		uiDriver.click("InvoiceID");
//		SleepUtils.sleep(TimeSlab.MEDIUM);
//		passed("Verify the Invoice",
//				"Invoice should be displayed successfully",
//				"Invoice is displayed successfully");
//		output.put("Invoice", invoicenum);
//		SleepUtils.sleep(TimeSlab.LOW);
		//uiDriver.click("Invoices");
		//SleepUtils.sleep(TimeSlab.YIELD);
//		output.put("Invoice", invoicenum);
			
			uiDriver.click("button_CreateAll");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("button_CreateInvoice");
			SleepUtils.sleep(TimeSlab.LOW);
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("//a[text()='Invoice Queue']");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.refresh();
			SleepUtils.sleep(TimeSlab.LOW);
			List<WebElement> list_Invoices = uiDriver.webDr.findElements(By.xpath("//td//a[contains(text(),'"+input.get(ContractId)+"')]//..//../td[10]"));
			int flag = 0;
			for(int i=0; i<list_Invoices.size(); i++) {
				String status = list_Invoices.get(i).getText();
				if(status.trim().equalsIgnoreCase("Completed")) {
					String InvoiceNumber = uiDriver.webDr.findElements(By.xpath("//td//a[contains(text(),'"+input.get(ContractId)+"')]//..//../td[10]")).get(i).getText().trim();
					list_InvoiceNumbers.add(InvoiceNumber);
				} else {
					flag = 1;
				}
			}
			if(flag == 0) {
				passed("GenerateMultipleInvoices",
						"Invoice should be generated successfully",
						"Invoice is generated successfully");
			} else {
				failed("GenerateMultipleInvoices",
						"Invoice should be generated successfully",
						"Invoice is not generated successfully");
			}
		}	
	}

	
	/****************************************
	 * Name: ChangeWFStatusToMultipleInvoices 
	 * Description:ChangeWFStatusToMultipleInvoices
	 * Date: 11-July-2018
	 ****************************************/
	public void ChangeWFStatusToMultipleInvoices(DataRow input, DataRow output) {
		uiDriver.click("Invoices");
		uiDriver.click("BulkOperations");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("ChangeWFStates");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		/*SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);*/
		while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
            SleepUtils.sleep(TimeSlab.LOW);
        }
		uiDriver.click("Filter");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("searchinput");
		uiDriver.setValue("searchinput", input.get("ContractId"));
		SleepUtils.sleep(TimeSlab.MEDIUM);
		/*
		 * uiDriver.sendKey("enter"); uiDriver.sendKey("enter");
		 */
		uiDriver.click("Search");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		/*if(input.get("Armrinv").contains("Y")) {
			 String Invoice = uiDriver.getDyanmicData("ArmInvoice1");
			 String Amount=input.get("Amount");
			 System.out.println(Amount);
				String ActualInvoice= Invoice.replace("#", Amount);
			
			
			
			
		}
		else {*/
		while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
            SleepUtils.sleep(TimeSlab.LOW);
        }
		uiDriver.click("CheckAllRows");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("scroll(0,-1000)");
//		}
		uiDriver.click("Invoicedropdown");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("SendforInvoice");
//		uiDriver.click("SendforInvoice");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Transitiontoworkflow");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		passed("Verify the Invoice is posted", "Invoice posted successfully",
				"Invoice posted successfully");
		
		for(int i=0;i<30;i++)
		{
		SleepUtils.sleep(30);
		uiDriver.refresh();
		SleepUtils.sleep(30);
		}
		
	}
	
	/****************************************
	 * Name: VerifyInvoiceWorkflowState 
	 * Description : VerifyInvoiceWorkflowState
	 * Date: 01-April-2019
	 ****************************************/
	public void VerifyInvoiceWorkflowState(DataRow input, DataRow output) {
		try {
			uiDriver.click("//a[text()='Invoice Queue']");
			SleepUtils.sleep(TimeSlab.HIGH);
			while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
	            SleepUtils.sleep(TimeSlab.LOW);
	        }
			int flag = 0;
			for(int j=0; j<list_InvoiceNumbers.size(); j++) {
				uiDriver.click("//td//a[contains(text(),'"+list_InvoiceNumbers.get(j)+"')]");
				SleepUtils.sleep(TimeSlab.LOW);
				SleepUtils.sleep(60);
				uiDriver.refresh();
				SleepUtils.sleep(TimeSlab.LOW);
				String message_Actual = uiDriver.getValue_Text("//span[@class='workflow-state']");
				String message_Expected = input.get("Current Status");
				if(message_Expected.trim().equalsIgnoreCase(message_Actual.trim())) {
					uiDriver.back();
					SleepUtils.sleep(TimeSlab.HIGH);
				} else {
					flag=1;
				}
			}
			if(flag == 0) {
				passed("Verify Invoice Workflow State", "Invoice Workflow State should be validated successfully",
						"Invoice Workflow State is validated successfully");
			} else {
				failed("Verify Invoice Workflow State", "Invoice Workflow State should be validated successfully",
						"Invoice Workflow State is not validated successfully");
			}
		} catch(Exception e) {
			failed("Verify Invoice Workflow State", "Invoice Workflow State should be validated successfully",
					"Error in Invoice Workflow State Validation");
			
		}
	}

	/****************************************
	 * Name: NavigateToFinancialSummary 
	 * Description: NavigateToFinancialSummary
	 * Date: 11-July-2018
	 ****************************************/
	public void NavigateToFinancialSummary(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("FinancialSummary");
		SleepUtils.sleep(TimeSlab.LOW);
		String Difference = uiDriver.getValue_Text("Difference");
		if (Difference != "0.00") {

			uiDriver.click("UpdateContractTotal");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("Yes");
			SleepUtils.sleep(TimeSlab.HIGH);
		} else {
			// do nothing
		}

	}
	
	

	/****************************************
	 * Name: AddTimeLineItemsForMultipledate Description: AddTimeLineItemsForMultipledate Date: 11-October-2018
	 ****************************************/
	public void AddTimeLineItemsForMultipledate(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Dates");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimeLineItems");
		SleepUtils.sleep(TimeSlab.LOW);
		
		for(int i = 1;i<=3;i++)
		{
		uiDriver.click("AddTimeLineItem");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setFrame("//*[@id='RadWindowWrapper_ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_TimelineItemWindow']/table/tbody/tr[2]/td[2]/iframe");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimelineItemType");
		// uiDriver.setValue("TimelineItemType",input.get("Type"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimelineItemTypeValue"+i);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("EST");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("Date", input.get("Date"+i));		
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Notes");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Project");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("WaistDeep");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("AddAll");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Finish");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.resetFrame();
		}
	}
	
	
	/****************************************
	 * Name: NavigateToFinancialSummary 
	 * Description: NavigateToFinancialSummary
	 * Date: 11-July-2018
	 ****************************************/
	public void VerifyNoLaterThanDate(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billing");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billingschedules");
		SleepUtils.sleep(TimeSlab.YIELD);
		List<WebElement> rows=uiDriver.webDr.findElements(By.xpath("//*[@id='contract-billing-schedules-grid']/div[3]/table/tbody/tr"));
		int rowSize=rows.size();
		for(int rown=2;rown<rowSize+1;rown++)
		{
			String Date = uiDriver.getDyanmicData("NoLaterThanDate");
			String Date1 = Date.replace("#",Integer.toString(rown));
			String nolaterdate=uiDriver.getValue(Date1);
			if(nolaterdate.isEmpty())
			{
				failed("Verify the NoLaterThanDate displayed",
						"NoLaterThanDate should be displayed successfully",
						"NoLaterThanDate is not displayed successfully");

			}
			
			else
			{
				passed("Verify the NoLaterThanDate displayed",
						"NoLaterThanDate should be displayed successfully",
						"NoLaterThanDate is not displayed successfully");

			}
			
			
		}
		
		WebElement tcst = uiDriver.webDr.findElement(By.xpath("//*[@id='contract-billing-schedules-grid']/div[3]/table/tbody/tr[2]/td[14]/div/a"));
		 String tooltip=tcst.getAttribute("title");
		
		if(tooltip.contains("TCST1"))
		{
			passed("Verify the Tooltip",
					"Tooltip should contain TCST1",
					"Tooltip does contain TCST1");

		}
		
		else
		{
			failed("Verify the Tooltip",
					"Tooltip should contain TCST1",
					"Tooltip does not  contain TCST1");
		}
		

	}

	/****************************************

     * Name: VerifyPayShipValue

     * Description: VerifyPayShipValue

     * Date: 02-Oct-2018

     ****************************************/

     public void VerifyPayShipValue(DataRow input, DataRow output)

                   throws InterruptedException {



            uiDriver.click("//a[text()=\"Information\"]");

            uiDriver.click("//a[text()='Additional Info']");
            SleepUtils.sleep(TimeSlab.HIGH);
            String Payship = uiDriver.getValue_Text("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_OtherDataAttributeValueGrid_ctl00_ctl10_ValueLabel']");
            if(input.get("Payship").equals(Payship)){
            	passed("Verify the Payship displayed",
                               "Payship should be Checked successfully as " + input.get("Payship") + "",
                                "Payship is Checked successfully as" + Payship + "");
            } else {
            	uiDriver.click("//span[text()='Pay Ship']//../preceding-sibling::td/input");
            	SleepUtils.sleep(TimeSlab.HIGH);
            	SleepUtils.sleep(TimeSlab.HIGH);
            	uiDriver.setValue("//td[contains(text(),'Value')]/following-sibling::td/span/textarea", input.get("Payship"));
            	SleepUtils.sleep(TimeSlab.YIELD);
            	uiDriver.click("//input[@type='button' and @value='Save']");
            	SleepUtils.sleep(TimeSlab.LOW);
            	
            	Payship = uiDriver.getValue_Text("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_OtherDataAttributeValueGrid_ctl00_ctl10_ValueLabel']");
                if(input.get("Payship").equals(Payship)){
                	passed("Verify the Payship displayed",
                                   "Payship should be Checked successfully as " + input.get("Payship") + "",
                                    "Payship is Checked successfully as" + Payship + "");
                } else {
                   failed("Verify the Payship displayed",
                                "Payship should be checked successfully as " + input.get("Payship") + "",
                                "Payship is not checked successfully as" + Payship + "");
                }
            }

            String XPG = uiDriver.getValue_Text("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_OtherDataAttributeValueGrid_ctl00_ctl18_ValueLabel']");          
            if (XPG.contains(input.get("XPG"))) {
                   passed("Verify the XPG displayed",
                                "XPG should be Checked successfully as " + input.get("XPG") + "",
                                "XPG is Checked successfully as" + XPG + "");
            } else {
            	uiDriver.click("//span[text()='XPG']//../preceding-sibling::td/input");
            	SleepUtils.sleep(TimeSlab.HIGH);
            	SleepUtils.sleep(TimeSlab.HIGH);
            	uiDriver.click("//td[contains(text(),'Value')]/following-sibling::td/input");
            	SleepUtils.sleep(TimeSlab.YIELD);
            	uiDriver.click("//input[@type='button' and @value='Save']");
            	SleepUtils.sleep(TimeSlab.LOW);
            	
            	XPG = uiDriver.getValue_Text("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_OtherDataAttributeValueGrid_ctl00_ctl18_ValueLabel']");
            	if (XPG.contains(input.get("XPG"))) {
                    passed("Verify the XPG displayed",
                                 "XPG should be Checked successfully as " + input.get("XPG") + "",
                                 "XPG is Checked successfully as" + XPG + "");
            	} else {
                   failed("Verify the XPG displayed",
                                "XPG should be checked successfully as " + input.get("XPG") + "",
                                "XPG is not checked successfully as" + XPG + "");
            	}
            }     

            String PTMG = uiDriver.getValue_Text("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_OtherDataAttributeValueGrid_ctl00_ctl12_ValueLabel']");
            if (PTMG.contains(input.get("PTMG"))) {
                   passed("Verify the PTMG displayed",
                                "PTMG should be Checked successfully as " + input.get("PTMG") + "",
                                "PTMG is Checked successfully as" + PTMG + "");
            } else {
            	uiDriver.click("//span[text()='PTMG']//../preceding-sibling::td/input");
            	SleepUtils.sleep(TimeSlab.HIGH);
            	SleepUtils.sleep(TimeSlab.HIGH);
            	uiDriver.click("//td[contains(text(),'Value')]/following-sibling::td/input");
            	SleepUtils.sleep(TimeSlab.YIELD);
            	uiDriver.click("//input[@type='button' and @value='Save']");
            	SleepUtils.sleep(TimeSlab.LOW);
            	
            	PTMG = uiDriver.getValue_Text("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_OtherDataAttributeValueGrid_ctl00_ctl12_ValueLabel']");
            	if (PTMG.contains(input.get("PTMG"))) {
                    passed("Verify the PTMG displayed",
                                 "PTMG should be Checked successfully as " + input.get("PTMG") + "",
                                 "PTMG is Checked successfully as" + PTMG + "");
	             } else {   
	            	failed("Verify the PTMG displayed",
                                "PTMG should be checked successfully as " + input.get("PTMG") + "",
                                "PTMG is not checked successfully as" + PTMG + "");
	             }
            }                                

     }

	 /****************************************
	 * Name: AssignAllocationBASvalue
	 * Description: VerifyPayShipValue
	 *  Date: 02-Oct-2018
	 ****************************************/
	public void AssignAllocationBAS(DataRow input, DataRow output)
			throws InterruptedException {

uiDriver.click("projectdetails");
SleepUtils.sleep(TimeSlab.MEDIUM);
		
		 uiDriver.executeJavaScript("(scroll(0,25000));");
		String numofpages = uiDriver.getValue("lastpagenum");
		int pagenum = Integer.parseInt(numofpages);
		 uiDriver.executeJavaScript("(scroll(0,-25000));");
		 SleepUtils.sleep(TimeSlab.MEDIUM);
		for (int i=1; i <= pagenum; i++) 
		{
			List<WebElement> rows=uiDriver.webDr.findElements(By.xpath("//table[@role='grid']//tr"));
			for( int rownum=1;rownum<=rows.size();rownum=rownum+2)
			{
				String Allocation = uiDriver.getDyanmicData("Allocation");
				String Allocation1 = Allocation.replace("#",Integer.toString(rownum));
				SleepUtils.sleep(TimeSlab.MEDIUM);
				if(uiDriver.checkElementPresent_dynamic(Allocation1))
				{
		uiDriver.click(Allocation1);
				}
				else
				{
					break;
				}
		
					
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("Allocationdropdown");
			  SleepUtils.sleep(TimeSlab.LOW);
			  String Rights = uiDriver.getDyanmicData("Allocationvalue");
				String rights1 = Rights.replace("#",input.get("Rights"));
				if(uiDriver.checkElementPresent_dynamic(rights1))
						{
				uiDriver.click(rights1);
						}
				  SleepUtils.sleep(TimeSlab.LOW);
				  uiDriver.executeJavaScript("(scroll(0,-1000));");
				uiDriver.click("Save");
				SleepUtils.sleep(TimeSlab.MEDIUM);
				if(rownum>9)
				{
					uiDriver.executeJavaScript("(scroll(0,800));");
				}		
				
				
				
						
			
		}
			 uiDriver.executeJavaScript("(scroll(0,-1000));");
			 SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("recalculate");
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.executeJavaScript("(scroll(0,1000));");
			if(uiDriver.checkElementPresent("nextpage"))
			{
				if(i==2)
				{
					uiDriver.click("nextpage");
					SleepUtils.sleep(TimeSlab.HIGH);
					uiDriver.click("nextpage");
					SleepUtils.sleep(TimeSlab.HIGH);
					uiDriver.executeJavaScript("(scroll(0,-1000));");
					SleepUtils.sleep(TimeSlab.HIGH);
				}
				
				 SleepUtils.sleep(TimeSlab.HIGH);
				 uiDriver.click("nextpage");
				 SleepUtils.sleep(TimeSlab.HIGH);
				 uiDriver.executeJavaScript("(scroll(0,-1000));");
				 SleepUtils.sleep(TimeSlab.HIGH);
			
			}
			else
			{
				break;	
		}
		
		
		
		
	}
		uiDriver.click("Nextbutton");
		
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Lastrecalculate");
		}
	
			
	 /****************************************
	 * Name: ValidatingBillingScheduleDetails
	 * Description:NaviagteToBillingSchedule 
	 * Date: 11-July-2018
	 ****************************************/
	public void ValidatingBillingSchedules(DataRow input, DataRow output) {
		List<WebElement> billingValues = uiDriver.webDr.findElements(By.xpath("//*[@id=\'contract-billing-schedules-grid\']/div[3]/table/tbody/tr"));
		int billingValuedetails = billingValues.size();
		for (i = 0; i < billingValuedetails; i++) {
			String Amount = uiDriver.getValue_Text("//*[@id=\"contract-billing-schedules-grid\"]/div[3]/table/tbody/tr[i]/td[10]/p");
			String Projects = uiDriver.getValue_Text("//*[@id=\"contract-billing-schedules-grid\"]/div[3]/table/tbody/tr[i]/td[7]/p");
			String duedate = uiDriver.getValue_Text("//*[@id=\\\"contract-billing-schedules-grid\\\"]/div[3]/table/tbody/tr[i]/td[12]/p");
			if (Amount.contains(input.get("Amount"))) {
				passed("Verify the Amount displayed",
						"Amount should be displayed successfully as " + Amount
								+ "", "Amount is displayed successfully as"
								+ Amount + "");

			}

			else {
				failed("Verify the Amount displayed",
						"Amount should be displayed successfully as " + Amount
								+ "", "Amount is not displayed successfully as"
								+ Amount + "");

			}

			if (Projects.contains(input.get("Projects"))) {
				passed("Verify the Projects displayed",
						"Projects should be displayed successfully as "
								+ Projects + "",
						"Projects is displayed successfully as" + Projects + "");

			} else {

				failed("Verify the Projects displayed",
						"Projects should be displayed successfully as "
								+ Projects + "",
						"Projects is not displayed successfully as" + Projects
								+ "");

			}

			if (duedate.contains(input.get("duedate"))) {
				passed("Verify the duedate displayed",
						"duedate should be displayed successfully as "
								+ duedate + "",
						"duedate is displayed successfully as" + duedate + "");

			} else {

				failed("Verify the duedate displayed",
						"duedate should be displayed successfully as "
								+ duedate + "",
						"duedate is not displayed successfully as" + duedate
								+ "");

			}
		}

	}
	
	/****************************************
	 * Name: AddMultipleTerritoriess
	 * Description: AddMultipleTerritoriess
	 * Date: 11-July-2018
	 ****************************************/
	public  void AddMultipleTerritories(DataRow input, DataRow output)
            throws InterruptedException {
      
      SleepUtils.sleep(TimeSlab.LOW);
      uiDriver.setValue("Name", input.get("Name"));
      SleepUtils.sleep(TimeSlab.LOW);
      uiDriver.setValue("Note", input.get("Note"));
      SleepUtils.sleep(TimeSlab.LOW);
      uiDriver.click("InvoiceItemCategory");
      SleepUtils.sleep(TimeSlab.LOW);
      uiDriver.click("InvoiceItemCategoryInput");
      SleepUtils.sleep(TimeSlab.LOW);
      Boolean Result = uiDriver.webDr.findElement(By.id("TerritoriesCheckbox")).isSelected();
      if(Result.equals(false)){
            
            uiDriver.click("Territories");
            SleepUtils.sleep(TimeSlab.LOW);
      }
      else{
            //do nothing 
      }
      
      Boolean RightResult = uiDriver.webDr.findElement(By.id("RightsCheckbox")).isSelected();
      if(RightResult.equals(false)){
            
            uiDriver.click("Rights");
            SleepUtils.sleep(TimeSlab.LOW);
      }
      else{
            //do nothing 
      }
      
      uiDriver.click("Next");
      SleepUtils.sleep(TimeSlab.HIGH);
      SleepUtils.sleep(TimeSlab.HIGH);
      SleepUtils.sleep(TimeSlab.HIGH);
      uiDriver.executeJavaScript("document.getElementsByClassName('amount-value weight')[0].value='';");
      SleepUtils.sleep(TimeSlab.LOW);
      Actions action=new Actions(uiDriver.webDr);
      WebElement ele = uiDriver.webDr.findElement(By.xpath("//*[@id='territoriesGrid']/div[2]/table/tbody/tr[1]/td[4]/div[1]/div/input"));
      action.sendKeys("ele","").build().perform();
      action.sendKeys(ele ,"50.00").build().perform();
	  SleepUtils.sleep(TimeSlab.LOW);
	  uiDriver.executeJavaScript("(scroll(0,300));");
	 uiDriver.executeJavaScript("document.getElementsByClassName('amount-value weight')[8].value='';");
      SleepUtils.sleep(TimeSlab.LOW);
      Actions action1=new Actions(uiDriver.webDr);
      WebElement ele1 = uiDriver.webDr.findElement(By.xpath("//*[@id='territoriesGrid']/div[2]/table/tbody/tr[9]/td[4]/div[1]/div/input"));
      action.sendKeys("ele1","").build().perform();
      action.sendKeys(ele1 ,"50.00").build().perform();
      uiDriver.click("Next");
      SleepUtils.sleep(TimeSlab.HIGH);
      SleepUtils.sleep(TimeSlab.HIGH);
      SleepUtils.sleep(TimeSlab.HIGH);
      uiDriver.executeJavaScript("document.getElementsByClassName('amount-value weight')[27].value='';");
      SleepUtils.sleep(TimeSlab.LOW);
      WebElement ele2 = uiDriver.webDr.findElement(By.xpath("//*[@id='rightsGrid']/div[2]/table/tbody/tr[1]/td[4]/div[1]/div/input"));
      action.sendKeys("ele2","").build().perform();
      action.sendKeys(ele2 ,"50.00").build().perform();
      SleepUtils.sleep(TimeSlab.HIGH);
      uiDriver.executeJavaScript("document.getElementsByClassName('amount-value weight')[28].value='';");
      SleepUtils.sleep(TimeSlab.LOW);
      WebElement ele3 = uiDriver.webDr.findElement(By.xpath("//*[@id='rightsGrid']/div[2]/table/tbody/tr[2]/td[4]/div[1]/div/input"));
      action.sendKeys("ele3","").build().perform();
      action.sendKeys(ele3 ,"50.00").build().perform();
      SleepUtils.sleep(TimeSlab.HIGH);
      uiDriver.click("Finish");
      SleepUtils.sleep(TimeSlab.HIGH);
      SleepUtils.sleep(TimeSlab.HIGH);
      SleepUtils.sleep(TimeSlab.HIGH);
      output.put("Name", input.get("Name"));
}      

	



























































































/****************************************
	 * Name: copyContractNum 
	 * Description: copyContractNum 
	 * Date: 10-Oct-2018
	 ****************************************/
	public void copyContractNum(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Copy");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.handleAlert("", "OK");
		SleepUtils.sleep(TimeSlab.LOW);
		
	}
	
	

	/****************************************
	 * Name: uploadingFilesViaFTP
	 * Description: uploadingFilesViaFTP
	 * Date: 11-July-2018
	 * @throws Exception 
	 ****************************************/
	public  void uploadingFilesViaFTP(DataRow input, DataRow output)
            throws Exception {
	
		String filePath = input.get("filePath");
		String fileName = input.get("fileName");
		uiDriver.FTPUploader("ftp.universalstudios.com", "webcollect-test", "Ln3D*54q");
        uiDriver.uploadFile(filePath,fileName);
        uiDriver.disconnect();
        passed("uploadingFilesViaFTP", "FTP operation should be successful",
				"FTP operation is successful");
    }
	
	/****************************************
	 * Name: initializeRow Description:Method to validate Debit and Credit
	 * Amount Date: 22-May-2018
	 ****************************************/

	public void initializeRow(DataRow input, DataRow output) {
		nextRow = 2;
		firstRow = 2;
		ItemCol = 2;

	}


	/****************************************
	 * Name: AddTimeLineItemsForMultidate1 
	*  Description: AddTimeLineItemsForMultidate1 
	*  Date: 12-November-2018
	 ****************************************/
	public void AddTimeLineItemsForMultidate1(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Dates");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimeLineItems");
		SleepUtils.sleep(TimeSlab.LOW);
		
		for(int i = 1;i<=2;i++)
		{
		uiDriver.click("AddTimeLineItem");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setFrame("//*[@id='RadWindowWrapper_ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_TimelineItemWindow']/table/tbody/tr[2]/td[2]/iframe");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimelineItemType");
		// uiDriver.setValue("TimelineItemType",input.get("Type"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimelineItemTypeValue"+i);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("EST");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("Date", input.get("Date"+i));		
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Notes");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Project");
//		SleepUtils.sleep(TimeSlab.MEDIUM);
//		uiDriver.click("WaistDeep");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		if(input.get("addall").equals("Y"))
		{
		uiDriver.click("AddAll");
		}
		if(input.get("project").equals("Y"))
		{
		//uiDriver.click("OnScreen");
		//uiDriver.executeJavaScript("scroll(0,2000)");
		uiDriver.click("PitchPerfect");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Add");
		}
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Finish");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.resetFrame();
		}
	}
	
	

	/****************************************
	 * Name: VerifyPIFandOpenInvoices 
	 * Description: VerifyPIFandOpenInvoices Date:
	 * 29-Oct-2018
	 ****************************************/
	public void VerifyPIFandOpenInvoices(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.executeJavaScript("scroll(0,400)");
		uiDriver.click("Custom");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,1600)");
		uiDriver.click("TitleAllocationParent");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Payment#");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,500)");
		List<WebElement> InvoicesPaid = uiDriver.webDr.findElements(By
				.xpath("//*[@id='apply_splits']//tbody//tr"));
		int InvPaid = InvoicesPaid.size();
		for (int i = 0; i < InvPaid - 1; i++) {

			String inv = uiDriver.getDyanmicData("Invoices");
			String invoices = inv.replace("#", Integer.toString(i));
			uiDriver.click_dynamic(invoices);
			SleepUtils.sleep(TimeSlab.MEDIUM);
			
//			String PaidInvoices = uiDriver.getValue_Text("InvPaid");
//			String PaidInvoicesopen = uiDriver.getValue_Text("InvPaidopen");
			if(i==0)
			{
				String PaidInvoicesopen = uiDriver.getValue_Text("InvPaidopen");
				SleepUtils.sleep(TimeSlab.LOW);
				if (PaidInvoicesopen.equalsIgnoreCase("Open"))
					
				{
					passed("Verify Paid In Full Invoice",
							"Paid In Full should be displayed as" + PaidInvoicesopen
									+ "", "Paid In Full is displayed as"
									+ PaidInvoicesopen + "");
				} else {
					passed("Verify Paid In Full Invoice",
							"Paid In Full should be displayed as" + PaidInvoicesopen
									+ "", "Paid In Full is displayed as"
									+ PaidInvoicesopen + "");
				}
			}
			else if(i==1)
			{
				String PaidInvoices = uiDriver.getValue_Text("InvPaid");
				SleepUtils.sleep(TimeSlab.LOW);
				if (PaidInvoices.equalsIgnoreCase("Paid In Full"))
					
				{
					passed("Verify Paid In Full Invoice",
							"Paid In Full should be displayed as" + PaidInvoices
									+ "", "Paid In Full is displayed as"
									+ PaidInvoices + "");
				} else {
					passed("Verify Paid In Full Invoice",
							"Paid In Full should be displayed as" + PaidInvoices
									+ "", "Paid In Full is displayed as"
									+ PaidInvoices + "");
				}
			}

						
			uiDriver.back();
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.executeJavaScript("scroll(0,500)");
		}

	}
	
	/****************************************
	 * Name: VerifyPrjandRecalculate 
	 * Description: VerifyPrjandRecalculate
	 * Date: 16-November-2018
	 ****************************************/
	public void VerifyPrjandRecalculate(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billing");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billingschedules");
		SleepUtils.sleep(TimeSlab.HIGH);
		//uiDriver.click("RecalculateAll");
		//SleepUtils.sleep(TimeSlab.LOW);
		//SleepUtils.sleep(TimeSlab.HIGH);

		List<WebElement> Billing = uiDriver.webDr.findElements(By.xpath("//*[@id='contract-billing-schedules-grid']/div[3]/table//tr"));
		int size = Billing.size();
		for(i=2;i<=size;i++)
		{   SleepUtils.sleep(TimeSlab.HIGH);
			String Edit = uiDriver.getDyanmicData("Edit");
			String EditField = Edit.replace("#", Integer.toString(i));
			uiDriver.click_dynamic(EditField);
			SleepUtils.sleep(TimeSlab.HIGH);
			 SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.executeJavaScript("scroll(900,0)");
			uiDriver.click("Next");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Next");
			SleepUtils.sleep(TimeSlab.HIGH);
//			uiDriver.executeJavaScript("scroll(-2200,0)");
//			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.executeJavaScript("scroll(2200,0)");
			uiDriver.executeJavaScript("scroll(0,1000)");
			String PrjTitles = uiDriver.getDyanmicData("PrjTitles");
	        String PrjActualtitle = PrjTitles.replace("#", input.get("ProjectName"));
	      /*  SleepUtils.sleep(TimeSlab.MEDIUM);
	        uiDriver.executeJavaScript("scroll(2500,0)");
	        uiDriver.click("Page");
	        SleepUtils.sleep(TimeSlab.MEDIUM);
	        uiDriver.click_dynamic("pagevalues");
	        SleepUtils.sleep(TimeSlab.HIGH);*/
	       // uiDriver.executeJavaScript("scroll(2500,0)");
	        if(uiDriver.checkElementPresent_dynamic(PrjActualtitle))
	        {
	        SleepUtils.sleep(TimeSlab.MEDIUM);
 			passed("Verify the PITCH PERFECT Project Name",
			"PITCH PERFECT Project Name should be displayed Successfully",
			"PITCH PERFECT Project Name is displayed Successfully");
			}
			else {
			failed("Verify the PITCH PERFECT Project Name",
			"PITCH PERFECT Project Name is not displayed Successfully",
			"PITCH PERFECT Project Name is not displayed Successfully");
			}
	        uiDriver.executeJavaScript("scroll(0,document.body.scrollHeight)");
			uiDriver.click("Next");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			String Territory=uiDriver.getValue("TerritoryGBR");// change
			if (Territory.contains(input.get("Weight"))) 
			{
				passed("Verify the Weight of Territory GBR",
						"Weight of Territory GBR is displayed Successfully as expected",
						"Weight of Territory GBR is displayed Successfully");

			}
			else {
				failed("Verify the Weight of Territory GBR",
						"Weight of Territory GBR is not displayed Successfully as expected",
						"Weight of Territory GBR is not displayed Successfully");

			}
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Next");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			String TitleBasicCable=uiDriver.getValue("TitleBasicCable");
			String TitleFreeTV=uiDriver.getValue("TitleFreeTV");
			if (TitleBasicCable.contains(input.get("BasicCable"))&&TitleFreeTV.contains(input.get("FreeTV"))) 
			{
				passed("Verify the added title has been assigned",
						"Weight of Free TV and Basic Cable is displayed Successfully as expected",
						"Weight of Free TV and Basic Cable is displayed Successfully");

			}
			else {
				failed("Verify the added title has been assigned",
						"Weight of Free TV and Basic Cable is not displayed Successfully as expected",
						"Weight of Free TV and Basic Cable is not displayed Successfully");

			}
			
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Finish");
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.LOW);
		}
	}


	

	/****************************************
	 * Name: GenerateMultipleInvoices2
	 *  Description: GenerateMultipleInvoices2
	 * Date: 25OCT2018
	 ****************************************/
	public void GenerateMultipleInvoices2(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Invoices");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("BulkOperations");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("GenerateInvoices");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Filter");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("searchinput");
		String ContractId = input.get("ContractId");
		uiDriver.setValue("searchinput", input.get("ContractId"));
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		// uiDriver.setValue("searchinput", "123178");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Search");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		
		
		uiDriver.click("//*[@id='CriteriaDropdown']/button[1]");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("(//input[@data-data-type='Date'])[2]");
		//uiDriver.click("//*[@id='FilterSelector']/li[30]/label/input");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("//*[@id='CriteriaContainer']/div[4]/div/span[2]");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.setValue("//*[@id='CriteriaContainer']/div[4]/ul/li[4]/span[1]/span/input",input.get("StartDate"));
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.setValue("//*[@id='CriteriaContainer']/div[4]/ul/li[4]/span[2]/span/input",input.get("EndDate"));
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Search");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		if(input.get("Pagination").equals("Y")){
			uiDriver.executeJavaScript("scroll(0,2000)");
			String pages = uiDriver.getValue_Text("No.of.pages");
			String PageArr[] = pages.split(" ");
			String SetPage = PageArr[4];
			SleepUtils.sleep(TimeSlab.LOW);
			for(i=0;i<=53;i++){
				uiDriver.click("//*[@id='AdvancedSearchResultsGrid']/div[4]/span[1]/span/span/span[2]/span[1]/span");
				SleepUtils.sleep(3);	
			}
			/*List<String> invoicelist=new ArrayList();
			invoicelist.add(input.get("invoice1"));
			
			for(String s:invoicelist)
			{
				String Rights = uiDriver.getDyanmicData("Invoicenum");
				String rights1 = Rights.replace("#",s);
				uiDriver.click(rights1);
			}*/
	
			SleepUtils.sleep(TimeSlab.HIGH);	
			uiDriver.executeJavaScript("scroll(0,-2500)");
			uiDriver.click("Search");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("//td[text()='81.63']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='423.85']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='60.19']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='320.38']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='643.27']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='567.67']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='96.95']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			//uiDriver.executeJavaScript("scroll(0,2500)");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='108.84']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='414.99']/..//input");  
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='170.46']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='314.63']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='397.63']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			//uiDriver.executeJavaScript("scroll(0,2500)");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='235.50']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='122.33']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='367.50']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='459.12']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='259.68']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='602.85']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='1,199.49']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='1,219.02']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='1,724.89']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='1,980.86']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			
			uiDriver.click("//td[text()='1,727.61']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='641.26']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='854.32']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='175.71']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='126.11']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='309.20']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='231.82']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='146.61']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='84.96']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='2,500.92']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='277.33']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='535.13']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='813.73']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='1,849.24']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='176.84']/..//input");
			
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='242.24']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			
			uiDriver.click("//td[text()='44.22']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='40.32']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='30.41']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='85.40']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='553.71']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='373.73']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='86.15']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='149.03']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='300.11']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='257.77']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='136.06']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='43.78']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='74.84']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='359.71']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			
			
			
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.executeJavaScript("scroll(0,-2500)");
			//uiDriver.click("Createinvoice");
			SleepUtils.sleep(TimeSlab.LOW);
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("Createinvoice");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			String invoicenum = uiDriver.getValue("InvoiceID");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("InvoiceID");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			passed("Verify the Invoice",
					"Invoice should be displayed successfully",
					"Invoice is displayed successfully");
			output.put("Invoice", invoicenum);
			SleepUtils.sleep(TimeSlab.LOW);
			//uiDriver.click("Invoices");
			SleepUtils.sleep(TimeSlab.YIELD);
			output.put("Invoice", invoicenum);
							
		}
			
			
			
			
			SleepUtils.sleep(TimeSlab.HIGH);
			
		}

/****************************************
	 * Name: Verifycreditmemo
	 * Description:Method to Navigate To Invoice Screen
	 *  Date:30-Nov-2017 
	 * @throws IOException 
	 * @throws InvalidPasswordException 
	 ****************************************/
    public void Verifycreditmemo(DataRow input, DataRow output) throws InterruptedException, InvalidPasswordException, IOException 
    {
    	uiDriver.click("relatedrecord");
    	SleepUtils.sleep(TimeSlab.MEDIUM);
    	uiDriver.click("creditmemo");
    	SleepUtils.sleep(TimeSlab.MEDIUM);
    	String taxcode=uiDriver.getValue("taxcode");
    	String exptaxcode=input.get("taxcode");
    	if(taxcode.equals(exptaxcode)|taxcode.contains(exptaxcode)|taxcode.startsWith("Canada"))
    	{
    		passed("Verify tax code", " tax code should be"+taxcode+"",
    				" tax code should be"+exptaxcode+"");
    	}
    	else
    	{
    		failed("Verify tax code", " tax code should be"+taxcode+"",
    				" tax code should be"+exptaxcode+"");
    	}
    	
    	String creditmemo=uiDriver.getValue("creditmemovalue");
    	String mastercredit=uiDriver.getValue("mastercredit")+"A";
    	if(creditmemo.equalsIgnoreCase(mastercredit))
    	{
    		passed("Creditmemo", " native credit memo number should be master credit memo number with an 'A' appended on the end",
    				" native credit memo number is the master credit memo number with an 'A' appended on the end");
    	}
    	
    	else
    	{
    		failed("Creditmemo", " native credit memo number should be master credit memo number with an 'A' appended on the end",
    				" native credit memo number is not the master credit memo number with an 'A' appended on the end");
    	}
    	uiDriver.click("mastercredit");
    	passed("Verify master credit ", " master credit should be displayed",
				"master credit  is displayed");
    	
    	/*String contractkey=uiDriver.getValue_Text("contractkey");
    	String orderid=input.get("conf");
    	orderid=orderid.substring(0, orderid.length()-1);
    	if(contractkey.contains(orderid))
    	{
    		passed("Contract key validation", " Contract key should be displayed",
    				"  Contract key is displayed");
    	}
    	String presentwindow = uiDriver.webDr.getWindowHandle();
		// boolean flag = false;*/
    	/*String presentwindow = uiDriver.webDr.getWindowHandle();
		uiDriver.click("viewPDF");
		SleepUtils.sleep(TimeSlab.HIGH);


		Set<String> whandles = uiDriver.webDr.getWindowHandles();
		for (String w : whandles) {
			if (!w.equals(presentwindow)) {
				uiDriver.webDr.switchTo().window(w);
				String PDFWindowURL = uiDriver.webDr.getCurrentUrl();
				URL url = new URL(PDFWindowURL);
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.sendKey("save");
				SleepUtils.sleep(TimeSlab.LOW);

				Random random = new Random();
				int limit = random.nextInt(1000);
				String inv = Integer.toString(limit);
				String text = "credit" + inv;
				StringSelection stringSelection = new StringSelection(text);
				Clipboard clipboard = Toolkit.getDefaultToolkit()
						.getSystemClipboard();
				clipboard.setContents(stringSelection, stringSelection);
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.sendKey("paste");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.sendKey("enter");

				SleepUtils.sleep(TimeSlab.LOW);
				String path = System.getProperty("user.home");
				// try(PDDocument document = PDDocument.load(new
				// File(path+"/Downloads/"+FileName+".pdf"))){
				PDDocument document = PDDocument.load(new File(path
						+ "/Downloads/" + text + ".pdf"));

				document.getClass();

				if (!document.isEncrypted()) {

					PDFTextStripperByArea stripper = new PDFTextStripperByArea();
					stripper.setSortByPosition(true);

					PDFTextStripper tStripper = new PDFTextStripper();

					String pdfFileInText = tStripper.getText(document);
					// System.out.println("Text:" + st);

					// split by whitespace
					String lines[] = pdfFileInText.split("\\r?\\n");
					for (String line : lines) {
						System.out.println(line);
						if (input.get("BilledBy").contains(line)) {
							passed("Verifying the BilledBy info in pdf",
									"BilledBy info should be displayed as "
											+ input.get("BilledBy") + " ",
									"BilledBy info is displayed as "
											+ input.get("BilledBy") + " ");
						} else if ((input.get("Remit").contains(line))) {
							passed("Verifying the Remit info in pdf",
									"Remit info should be displayed as "
											+ input.get("Remit") + " ",
									"Remit info is displayed as "
											+ input.get("Remit") + " ");

						} else if (input.get("BillTo").contains(line)) {
							passed("Verifying the BillTo info in pdf",
									"BillTo info should be displayed as "
											+ input.get("BillTo") + " ",
									"BillTo info is displayed as "
											+ input.get("BillTo") + " ");
							;

						}

						else if (input.get("SendTo").contains(line)) {
							passed("Verifying the SendTo info in pdf",
									"SendTo info should be displayed as "
											+ input.get("SendTo") + " ",
									"SendTo info is displayed as "
											+ input.get("SendTo") + " ");
							;

						} else if (input.get("TotalAmount").contains(line)) {
							passed("Verifying the TotalAmount in pdf",
									"TotalAmount should be displayed as "
											+ input.get("TotalAmount") + " ",
									"TotalAmount is displayed as "
											+ input.get("TotalAmount") + " ");
							;

						} else if (input.get("RemitInformation").contains(line)) {
							passed("Verifying the RemitInformation in pdf",
									"RemitInformation should be displayed as "
											+ input.get("RemitInformation")
											+ " ",
									"RemitInformation is displayed as "
											+ input.get("RemitInformation")
											+ " ");
							;

						}

					}
				}

				uiDriver.webDr.close();

			}
			uiDriver.webDr.switchTo().window(presentwindow);
			uiDriver.executeJavaScript("scroll(0,-1000)");
			// uiDriver.switchToWindow("Invoice - NetSuite (NBCUniversal Media, LLC 10K QA)");

		}*/
		
			uiDriver.click("docnum");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("customercredit");
			String status=uiDriver.getValue("customercreditstatus");
			if(status.equalsIgnoreCase("refunded"))
			{
	    		passed("Verify customer credit status", " Customer credit status should be refunded",
	    				" Customer credit status should be refunded");
	    	}
	    	
	    	else
	    	{
	    		failed("Verify customer credit status", " Customer credit status should be refunded",
	    				" Customer credit status is not refunded");
	    	}
			
			
			uiDriver.back();
			SleepUtils.sleep(TimeSlab.HIGH);
		}
		
		 
    
	
	

	/****************************************
	 * Name: EditInvoicefile
	 * Description: EditInvoicefile
	 * Date: 11-July-2018
	 * @throws Exception 
	 ****************************************/
	public  void EditInvoicefile(DataRow input, DataRow output)
            throws Exception {
	
		String filePath = input.get("filePath");
		String OldInvoice = input.get("OldInvoice");
		String InvoiceSize = input.get("InvoiceSize");
		int invsize = Integer.parseInt(InvoiceSize);
		for (int r = 1; r < invsize; r++) {
		String invoice = input.get("invoice" + r);
		String newInvoice = invoice.substring(0, invoice.length()-1);
		uiDriver.modifyFile(filePath,OldInvoice,newInvoice);
		
		}
		passed("EditInvoicefile", "Edit Invoice file should be successful",
				"Edit Invoice file is successful");
	}

	/****************************************
	 * Name: EditSingleInvoicefile
	 * Description: EditSingleInvoicefile
	 * Date: 11-Dec-2018
	 * @throws Exception 
	 ****************************************/
	public  void EditSingleInvoicefile(DataRow input, DataRow output)
            throws Exception {
	
		String filePath = input.get("filePath");
		String OldInvoice = input.get("OldInvoice");
		String InvoiceSize = input.get("InvoiceSize");
		int invsize = Integer.parseInt(InvoiceSize);
		for (int r = 1; r <=invsize; r++) {
		String invoice = input.get("invioice" + r);
		String newInvoice = invoice.substring(0, invoice.length()-1);
		uiDriver.modifyFile(filePath,OldInvoice,newInvoice);
		
		}
	
	}

	/****************************************
	 * Name: ReadPaymentNumber
	 * Description: ReadPaymentNumber
	 * Date: 23-Nov-2018
	 ****************************************/
	public void ReadPaymentNumber(DataRow input, DataRow output)
			throws InterruptedException 
	{
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
    	String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("relatedRecord");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click_dynamic("InvoiceLinks");
		passed("InvoiceNo", "InvoiceNo Should be Clicked Successfully",
				"InvoiceNo is Clicked Successfully");
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("relatedRecord");
		uiDriver.click("//td[text()='Payment']/preceding-sibling::td/a");
		  passed("PaymentNumber", "Payment Number Should be displayed Successfully",
		            "PaymentNumber is displayed Successfully");
		      SleepUtils.sleep(5);
		      uiDriver.executeJavaScript("scroll(0,2500)");
		      String Payamnt=uiDriver.getValue("//a[text()='Applied']/../../span/../../span/../../div/span[2]");
		      if (Payamnt.contains(input.get("PaymentRecord"))) {

					passed("Verifying the PaymentRecord",
							"Amount should be displayed as " + Payamnt + " ",
							"Amount is displayed as " + input.get("PaymentRecord")
									+ " ");

				} else {
					failed("Verifying the PaymentRecord",
							"Amount should be displayed as " + Payamnt + " ",
							"Amount is displayed as " + input.get("PaymentRecord")
									+ " ");

				}     
		}
				
	
	/****************************************
	 * Name: ReadOpenPaymentNumber
	 * Description: ReadOpenPaymentNumber
	 * Date: 23-Nov-2018
	 ****************************************/
	public void ReadOpenPaymentNumber(DataRow input, DataRow output)
			throws InterruptedException 
	{
		SleepUtils.sleep(TimeSlab.MEDIUM);
    	String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");
		uiDriver.executeJavaScript("scroll(0,500)");	
		uiDriver.click("relatedRecord");
		String Invoices = uiDriver.getDyanmicData("InvoiceLinks");
		String InvoiceLink = Invoices.replace("#",input.get("Amount"));
		uiDriver.click_dynamic(InvoiceLink);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("relatedRecord");
		
		if(input.get("VerifyUnappliedAmount").equals("Y"))
		{
			SleepUtils.sleep(TimeSlab.HIGH);
			String unappliedamount=uiDriver.getValue("//span[@id='amountpaid_fs_lbl_uir_label']/following-sibling::span");
			passed("Unappliedamount", "Unappliedamount Should be displayed Successfully",
			            "Unappliedamount is displayed Successfully");
				SleepUtils.sleep(5);
				SleepUtils.sleep(TimeSlab.HIGH);
			     
				String Payamnt=uiDriver.getValue("//span[@id='amountremaining_fs_lbl_uir_label']/following-sibling::span");
			    System.out.println(Payamnt);
			    System.out.println(input.get("UnappliedAmount"));
				if (Payamnt.contains(input.get("UnappliedAmount"))) {

					passed("Verifying the PaymentRecord",
							"Amount should be displayed as " + Payamnt + " ",
							"Amount is displayed as " + input.get("PaymentRecord")
									+ " ");

				} else {
					failed("Verifying the PaymentRecord",
							"Amount should be displayed as " + Payamnt + " ",
							"Amount is displayed as " + input.get("PaymentRecord")
									+ " ");

					}      
		}
		if(input.get("VerifyAppliedAmount").equals("Y"))
		{
			uiDriver.executeJavaScript("scroll(0,500)");	
			uiDriver.click("//td[text()='Payment']/preceding-sibling::td/a");
			  passed("PaymentNumber", "Payment Number Should be displayed Successfully",
			            "PaymentNumber is displayed Successfully");
			      SleepUtils.sleep(5);
			      uiDriver.executeJavaScript("scroll(0,2500)");
			      String Payamnt=uiDriver.getValue("//a[text()='Applied']/../../span/../../span/../../div/span[2]");
			      if (Payamnt.contains(input.get("PaymentRecord"))) {

						passed("Verifying the PaymentRecord",
								"Amount should be displayed as " + Payamnt + " ",
								"Amount is displayed as " + input.get("PaymentRecord")
										+ " ");

					} else {
						failed("Verifying the PaymentRecord",
								"Amount should be displayed as " + Payamnt + " ",
								"Amount is displayed as " + input.get("PaymentRecord")
										+ " ");

					}      
		}
		    }	
	
	/****************************************
	 * Name: VerifyContractDetails
	 * Description: VerifyEstimateReason 
	 * Date: 26-Sept-2018
    ****************************************/	
	public void VerifyContractDetails(DataRow input, DataRow output)
	{
		SleepUtils.sleep(TimeSlab.LOW);
		String ActualdealType = uiDriver.getValue("dealType");
		if (input.get("ContractType").equalsIgnoreCase(ActualdealType)) {

			passed("Verifying the Contract Type",
					"Contract Type  "+ input.get("ContractType")+ "  should be displayed successfully",
					"Contract Type is displayed successfully"+  ActualdealType + "");
		} else {
			failed("Verifying the Contract Type",
					"Contract Type  "+ input.get("ContractType")+ "  should be displayed successfully",
					"Contract Type is not displayed successfully"+  ActualdealType + "");
		}
		
		String ActualcontractName = uiDriver.getValue("contractName");
		if (input.get("ExpcontractName").equalsIgnoreCase(ActualcontractName)) {

			passed("Verifying the Contract Name",
					"Contract Name  "+ input.get("ExpcontractName")+ "  should be displayed successfully",
					"Contract Name is displayed successfully"+  ActualcontractName + "");
		} else {
			failed("Verifying the Contract Name",
					"Contract Name  "+ input.get("ExpcontractName")+ "  should be displayed successfully",
					"Contract Name is not displayed successfully"+  ActualcontractName + "");
		}
		
		String ActualLicensor = uiDriver.getValue("Licensor");
		if (input.get("ExpLicensor").equalsIgnoreCase(ActualLicensor)) {

			passed("Verifying the Licensor",
					"Licensor  "+ input.get("ExpLicensor")+ "  should be displayed successfully",
					"Licensor is displayed successfully"+  ActualLicensor + "");
		} else {
			failed("Verifying the Licensor",
					"Licensor  "+ input.get("ExpLicensor")+ "  should be displayed successfully",
					"Licensor is not displayed successfully"+  ActualLicensor + "");
		}
		
		String ActualLicensee = uiDriver.getValue("Licensee");
		if (input.get("ExpLicensee").equalsIgnoreCase(ActualLicensee)) {

			passed("Verifying the Licensee",
					"Licensee  "+ input.get("ExpLicensee")+ "  should be displayed successfully",
					"Licensee is displayed successfully"+  ActualLicensee + "");
		} else {
			failed("Verifying the Licensee",
					"Licensee  "+ input.get("ExpLicensee")+ "  should be displayed successfully",
					"Licensee is not displayed successfully"+  ActualLicensee + "");
		}
		
		String ActualAmount = uiDriver.getValue("Amount");
		System.out.println(ActualAmount);
		String x=input.get("ExpAmount");
		System.out.println(x);
		if (input.get("ExpAmount").equalsIgnoreCase(ActualAmount)) {

			passed("Verifying the Amount",
					"Amount  "+ input.get("ExpAmount")+ "  should be displayed successfully",
					"Amount is displayed successfully"+  ActualAmount + "");
		} else {
			failed("Verifying the Amount",
					"Amount  "+ input.get("ExpAmount")+ "  should be displayed successfully",
					"Amount is not displayed successfully"+  ActualAmount + "");
		}
		
		String ActualcurrencyType = uiDriver.getValue("currencyType");
		if (input.get("ExpcurrencyType").equalsIgnoreCase(ActualcurrencyType)) {

			passed("Verifying the currency Type",
					"currency Type  "+ input.get("ExpcurrencyType")+ "  should be displayed successfully",
					" currency Type is displayed successfully "+  ActualcurrencyType + "");
		} else {
			failed("Verifying the currency Type",
					"currency Type  "+ input.get("ExpcurrencyType")+ "  should be displayed successfully",
					" currency Type is not displayed successfully "+  ActualcurrencyType + "");
		}
		
	/*	String Actualrights = uiDriver.getValueByText("Rights");
		if(input.get("ExpRights").equalsIgnoreCase(Actualrights)){
			passed("Verifying the Rights",
					"Rights "+ input.get("ExpRights")+ "  should be displayed successfully",
					"Rights is displayed successfully"+  Actualrights + "");
			
		}
		else{
			failed("Verifying the Rights",
					"Rights "+ input.get("ExpRights")+ "  should be displayed successfully",
					"Rights is not displayed successfully"+  Actualrights + "");
			
		}*/
		
		
		
	}
	/****************************************
	 * Name: 	
	 * Description: AddMultipleTerritoriess
	 * Date: 11-July-2018
	 ****************************************/
	public  void AddMultipleTerritoriesMexico(DataRow input, DataRow output)
            throws InterruptedException {
		uiDriver.click("Editicon");
		SleepUtils.sleep(5);
      SleepUtils.sleep(TimeSlab.HIGH);
      uiDriver.setValue("Name", input.get("Name"));
      SleepUtils.sleep(TimeSlab.LOW);
      //uiDriver.setValue("Note", input.get("Note"));
      //SleepUtils.sleep(TimeSlab.LOW);
      uiDriver.click("InvoiceItemCategory");
      SleepUtils.sleep(TimeSlab.LOW);
      uiDriver.click("InvoiceItemCategoryInput");
      SleepUtils.sleep(TimeSlab.LOW);
      Boolean Result = uiDriver.webDr.findElement(By.id("TerritoriesCheckbox")).isSelected();
      if(Result.equals(false)){
            
            uiDriver.click("Territories");
            SleepUtils.sleep(TimeSlab.LOW);
      }
      else{
            //do nothing 
      }
      
      Boolean RightResult = uiDriver.webDr.findElement(By.id("RightsCheckbox")).isSelected();
      if(RightResult.equals(false)){
            
            uiDriver.click("Rights");
            SleepUtils.sleep(TimeSlab.LOW);
      }
      else{
            //do nothing 
      }
      
      uiDriver.click("Next");
      SleepUtils.sleep(TimeSlab.HIGH);
      SleepUtils.sleep(TimeSlab.HIGH);
      uiDriver.executeJavaScript("document.getElementsByClassName('amount-value weight')[10].value='';");
      SleepUtils.sleep(TimeSlab.LOW);
      Actions action=new Actions(uiDriver.webDr);
		WebElement ele = uiDriver.webDr.findElement(By
				.xpath("//*[@id='allocationWidget']/div/span/span/input[1]"));
		SleepUtils.sleep(TimeSlab.LOW);
		action.sendKeys("ele", "00.00").build().perform();
		SleepUtils.sleep(TimeSlab.LOW);
		action.sendKeys(ele, "100.00").build().perform();
		uiDriver.click("NameChkBoxMEX");
		 SleepUtils.sleep(TimeSlab.LOW);
		 uiDriver.executeJavaScript("(scroll(0,-1500));");
		uiDriver.click("NameChkBoxBZ");
      SleepUtils.sleep(TimeSlab.HIGH);
     // uiDriver.executeJavaScript("(scroll(0,1000));");
		uiDriver.click("Spread");
      uiDriver.click("Next");
      SleepUtils.sleep(TimeSlab.HIGH);
      SleepUtils.sleep(TimeSlab.HIGH);
      SleepUtils.sleep(TimeSlab.HIGH);
        uiDriver.executeJavaScript("document.getElementsByClassName('amount-value weight')[48].value='';");
       Actions action2 = new Actions(uiDriver.webDr);
		WebElement ele2 = uiDriver.webDr.findElement(By.xpath("//*[@id='rightsGrid']/div[2]/table/tbody/tr[1]/td[4]/div[1]/div/input"));
		SleepUtils.sleep(TimeSlab.LOW);
		action2.sendKeys("ele2", "").build().perform();
		SleepUtils.sleep(TimeSlab.LOW);//cn
		action.sendKeys(ele2, "100.00").build().perform();
		SleepUtils.sleep(TimeSlab.HIGH);
		 uiDriver.executeJavaScript("document.getElementsByClassName('amount-value weight')[49].value='';");
		//uiDriver.click("NameChkBox");
		 Actions action4 = new Actions(uiDriver.webDr);
			WebElement ele4 = uiDriver.webDr.findElement(By.xpath("//*[@id='rightsGrid']/div[2]/table/tbody/tr[2]/td[4]/div[1]/div/input"));
			action4.sendKeys("ele4", "").build().perform();
			action4.sendKeys(ele4, "00.00").build().perform();
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Spread");
      SleepUtils.sleep(TimeSlab.MEDIUM);
      uiDriver.click("Finish");
      SleepUtils.sleep(TimeSlab.HIGH);
      SleepUtils.sleep(TimeSlab.HIGH);
      output.put("Name", input.get("Name"));
}      
	/****************************************
	 * Name: AddMultipleTerritoriesPTV
	 * Description: AddMultipleTerritoriess
	 * Date: 11-July-2018
	 ****************************************/
	public  void AddMultipleTerritoriesPTV(DataRow input, DataRow output)
            throws InterruptedException {
		uiDriver.click("Editicon");
		SleepUtils.sleep(5);
      SleepUtils.sleep(TimeSlab.LOW);
      uiDriver.setValue("Name", input.get("Name"));
      SleepUtils.sleep(TimeSlab.LOW);
      uiDriver.click("InvoiceItemCategory");
      SleepUtils.sleep(TimeSlab.LOW);
      uiDriver.click("InvoiceItemCategoryInput");
      SleepUtils.sleep(TimeSlab.LOW);
      Boolean Result = uiDriver.webDr.findElement(By.id("TerritoriesCheckbox")).isSelected();
      if(Result.equals(false)){
            
            uiDriver.click("Territories");
            SleepUtils.sleep(TimeSlab.LOW);
      }
      else{
            //do nothing 
      }
      
      Boolean RightResult = uiDriver.webDr.findElement(By.id("RightsCheckbox")).isSelected();
      if(RightResult.equals(false)){
            
            uiDriver.click("Rights");
            SleepUtils.sleep(TimeSlab.LOW);
      }
      else{
            //do nothing 
      }
      
      uiDriver.click("Next");
      SleepUtils.sleep(TimeSlab.HIGH);
      SleepUtils.sleep(TimeSlab.HIGH);
     //uiDriver.executeJavaScript("document.getElementsByClassName('amount-value weight')[10].value='';");
      SleepUtils.sleep(TimeSlab.LOW);
      //uiDriver.executeJavaScript("(scroll(0,1000));");
      Actions action = new Actions(uiDriver.webDr);
		WebElement ele = uiDriver.webDr.findElement(By
				.xpath("//*[@id='allocationWidget']/div/span/span/input[1]"));
		action.sendKeys("ele", "").build().perform();
		action.sendKeys(ele, "100.00").build().perform();
		uiDriver.click("NameChkBoxMEX");
		 SleepUtils.sleep(TimeSlab.LOW);
		 uiDriver.executeJavaScript("(scroll(0,-1000));");
		uiDriver.click("NameChkBoxBZ");
      SleepUtils.sleep(TimeSlab.HIGH);
      uiDriver.executeJavaScript("(scroll(0,-2000));");
		uiDriver.click("Spread");
      uiDriver.click("Next");
      SleepUtils.sleep(TimeSlab.HIGH);
      uiDriver.executeJavaScript("document.getElementsByClassName('amount-value weight')[50].value='';");
      Actions action2 = new Actions(uiDriver.webDr);
		WebElement ele2 = uiDriver.webDr.findElement(By.xpath("//*[@id='rightsGrid']/div[2]/table/tbody/tr[3]/td[4]/div[1]/div/input"));
		action2.sendKeys("ele2", "").build().perform();
		action2.sendKeys(ele2, "100.00").build().perform();
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("document.getElementsByClassName('amount-value weight')[51].value='';");
		Actions action3 = new Actions(uiDriver.webDr);
	//	WebElement ele3 = uiDriver.webDr.findElement(By.xpath("//*[@id='rightsGrid']/div[2]/table/tbody/tr[4]/td[4]/div[1]/div/input"));
		WebElement ele3 = uiDriver.webDr.findElement(By.xpath("//span[normalize-space()='Basic Cable']/../following-sibling::td//div/input"));
		action3.sendKeys("ele3", "").build().perform();
		action3.sendKeys(ele3, "00.00").build().perform();
	      SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Spread");
      SleepUtils.sleep(TimeSlab.MEDIUM);
      uiDriver.click("Finish");
      SleepUtils.sleep(TimeSlab.HIGH);
      SleepUtils.sleep(TimeSlab.HIGH);
      output.put("Name", input.get("Name"));
}   
	public void EditProjectDetailsBZ(DataRow input, DataRow output) throws InterruptedException 
	{ 

		SleepUtils.sleep(TimeSlab.YIELD);
		for(int k=4;k<6;k++){
		String Page= uiDriver.getDyanmicData("page");
		String NextPage=Page.replace("#",Integer.toString(k));
		uiDriver.click_dynamic(NextPage);
		SleepUtils.sleep(TimeSlab.MEDIUM);	
		List<WebElement> ele = uiDriver.webDr.findElements(By.xpath("//*[@id='contract-billing-project-centric-grid']/div[3]/table/tbody/tr"));
		int  count = ele.size();					
		String ExcelData = input.get("dataTitles");
		String ExcelDataarr []= ExcelData.split(";");
		SleepUtils.sleep(TimeSlab.MEDIUM);		
		for (int i = 1; i <count; i++) {
			uiDriver.executeJavaScript("scroll(0,-2000)");
			String title= uiDriver.getDyanmicData("title");
			String a =title.replace("#", Integer.toString(i));
			String titleactual= uiDriver.getValue_Text(a);
			String titlesize = input.get("titlesize");
			int Actualsize = Integer.parseInt(titlesize);
			for(int m=0;m<Actualsize;m++)
			{
				String tit = ExcelDataarr[m];
				if(titleactual.contains(tit))
						{
					SleepUtils.sleep(TimeSlab.MEDIUM);
					String defaultAL= uiDriver.getDyanmicData("EnableDefault");
					String defaultAlocation=defaultAL.replace("#",Integer.toString(i));
					uiDriver.click_dynamic(defaultAlocation);
					//uiDriver.click("EnableDefault");
					uiDriver.click("ClickDefault");
					SleepUtils.sleep(TimeSlab.YIELD);
					String ActualAllocationRule = uiDriver.getDyanmicData("defaultAllocation");
					SleepUtils.sleep(TimeSlab.YIELD);	
					String AllocationRule =ActualAllocationRule.replace("#", input.get("Data"));
					SleepUtils.sleep(TimeSlab.YIELD);	
					uiDriver.click_dynamic(AllocationRule);
					
					String titlenxt= uiDriver.getDyanmicData("title");
					String anxt =titlenxt.replace("#", Integer.toString(i+1));
					String titleactualnxt= uiDriver.getValue_Text(anxt);
					if(titleactualnxt.contains(titleactual))
					{
						SleepUtils.sleep(TimeSlab.MEDIUM);
						String defaultAL1= uiDriver.getDyanmicData("EnableDefault");
						String defaultAlocation1=defaultAL1.replace("#",Integer.toString(i+1));
						uiDriver.click_dynamic(defaultAlocation1);
						uiDriver.click("ClickDefault");
						SleepUtils.sleep(TimeSlab.YIELD);
						String ActualAllocationRule1 = uiDriver.getDyanmicData("defaultAllocation");
						SleepUtils.sleep(TimeSlab.YIELD);	
						String AllocationRule1 =ActualAllocationRule1.replace("#", input.get("Data1"));
						SleepUtils.sleep(TimeSlab.YIELD);	
						uiDriver.click_dynamic(AllocationRule1);
						i=i+1;
						SleepUtils.sleep(TimeSlab.YIELD);	
						//uiDriver.executeJavaScript("scroll(0,-100)");
					}
					
					else{
						//do nothing
					}
					
					
						}else
						{
							//do nothing
						}
			}
		
		}
		uiDriver.executeJavaScript("scroll(0,-2000)");
		uiDriver.click("save");
		SleepUtils.sleep(TimeSlab.HIGH);	
		SleepUtils.sleep(TimeSlab.HIGH);	
		}	
		/*uiDriver.click("AllocationRule");
		uiDriver.click("AllocationRule");
		uiDriver.click("CAFE-PTV");
		//
		uiDriver.click("SaveChanges");
		uiDriver.click("Regenreate");*/
		
	}
	public void VerifyTimelineItems(DataRow input, DataRow output) throws InterruptedException 
	{ 
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Dates");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimeLineItems");	
		SleepUtils.sleep(TimeSlab.YIELD);
		for(int k=1;k<6;k++){
		String Page= uiDriver.getDyanmicData("page");
		String NextPage=Page.replace("#",Integer.toString(k));
		uiDriver.click_dynamic(NextPage);
		List<WebElement> ele = uiDriver.webDr.findElements(By.xpath("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_TimelineItemsGrid_ctl00']/tbody/tr"));
		int  count = ele.size();
		String ExcelData = input.get("dataTitles");
		String ExcelDataarr []= ExcelData.split(";");
		SleepUtils.sleep(TimeSlab.MEDIUM);		
		for (int i = 0; i <count; i++) {
			String title= uiDriver.getDyanmicData("title");
			String a =title.replace("#", Integer.toString(i));
			String titleactual= uiDriver.getValue_Text(a);
				int m=0;
				String tit = ExcelDataarr[m];
				if(titleactual.contains(tit))
						{
							passed("Verify the OnNetwork Flag",
								"OnNetwork Flag should be unchecked Successfully",
								"OnNetwork Flag is unchecked Successfully");

					} else {
						passed("Verify the OnNetwork Flag",
								"OnNetwork Flag should be unchecked Successfully",
								"OnNetwork Flag is not unchecked Successfully");

					}

					m++;
		}
		}
		}

	public void Clickprojectdetails(DataRow input, DataRow output) throws InterruptedException 
	{ 
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("projectdetails");
		SleepUtils.sleep(TimeSlab.YIELD);
	}
					
		
	/**
	 * Overriding toString() method of object class to print SJMDriver format
	 * string
	 */
	public String toString() {
		return "NBCUDriver()";
	}
	
	

	public static int i = 4, j = 2;
	int nextRow = 2, firstRow = 2, ItemCol = 4;
	String orderId, FMVDimention, SONum;
	List<WebElement> fmvValue = new ArrayList<WebElement>();
	List<String> fmvVal = new ArrayList<String>();
	private static final int BUFFER_SIZE = 4096;
	/****************************************
	 * Name: VerifyBillingGroupXPG
	 * Description: Checks the default billing group
	 * Date: 05-mar-2019
	 ****************************************/
	public void VerifyBillingGroupXPG(DataRow input, DataRow output) {
	//	String test = input.get("numbill");
		uiDriver.click("Finance");
		//SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billing");
		
		uiDriver.click("Billinggroups");
		String Title= uiDriver.getDyanmicData("Default");
		String Actualtitle=Title.replace("#",input.get("Name"));
		//uiDriver.checkElementPresent_dynamic("//td[contains(text(),'Default-XPG')]");
		uiDriver.checkElementPresent_dynamic(Actualtitle);
		passed("VerifyBillingGroupXPG",
				"Default billing group  should be displayed as '" + Actualtitle + "' Successfully", 
				"Default billing group  should be displayed as '"+ Actualtitle + " is displayed Successfully");
	}
	/****************************************
	 * Name: GenerateBillingShedule
	 * Description: Generates a billing shedule 
	 * Date: 05-mar-2019
	 ****************************************/
	
	public void GenerateBillingShedule(DataRow input, DataRow output){
		
		Actions action1 = new Actions(uiDriver.webDr);
		
//		uiDriver.click("//p[contains(text(),'JERRY SPRINGER')]//..//..//a[contains(text(),'Edit')]");
//		SleepUtils.sleep(TimeSlab.HIGH);
		
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billing");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billingschedules");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("GenerateSchedule");
		SleepUtils.sleep(TimeSlab.HIGH);
		/*if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Enter Schedule Item Information']")) {
			passed("Generate Billing Schedule",
					"Enter Schedule Item Information window should be displayed",
					"Enter Schedule Item Information window is displayed");
		} else {
			failed("Generate Billing Schedule",
					"Enter Schedule Item Information window should be displayed",
					"Enter Schedule Item Information window is not displayed");
		}*/
		
		uiDriver.click("Scheduleitem");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//li[contains(text(),'"+input.get("Generate Schedule Item")+"')]");
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.LOW);
		/*if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Manually Add Schedule Items']")) {
			passed("Generate Billing Schedule",
					"Manually Add Schedule Items window should be displayed",
					"Manually Add Schedule Items window is displayed");
		} else {
			failed("Generate Billing Schedule",
					"Manually Add Schedule Items window should be displayed",
					"Manually Add Schedule Items window is not displayed");
		}*/
		
		uiDriver.click("Add");
		
				
			if(input.get("CalcMethod").equalsIgnoreCase("NA")) {
		// DO NOTHING	
		} else {
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.sendKey("tab");
			String CalcMethod=input.get("CalcMethod");
        uiDriver.setText(CalcMethod);
			uiDriver.sendKey("enter");
		}
		
		if(input.get("amount").equalsIgnoreCase("NA")) {
		// DO NOTHING	
		} else {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.sendKey("tab");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.sendKey("tab");
		String Amount=input.get("amount");
		uiDriver.setText(Amount);
		uiDriver.sendKey("enter");
		}
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Duedate");
		uiDriver.setValue("Duedate1",input.get("date"));
		uiDriver.sendKey("enter");
		
		if(input.get("amount1").trim().toLowerCase() == null || input.get("amount1").trim().toLowerCase() == "") {
			// Do nothing
		} else {
			uiDriver.click("Add");
	
			
			if(input.get("CalcMethod1").equalsIgnoreCase("NA")) {
			// DO NOTHING	
			} else {
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.sendKey("tab");
				String CalcMethod1=input.get("CalcMethod1");
				uiDriver.setText(CalcMethod1);
				uiDriver.sendKey("enter");
			}
			
			if(input.get("amount1").equalsIgnoreCase("NA")) {
			// DO NOTHING	
			} else {
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.sendKey("tab");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.sendKey("tab");
			String Amount=input.get("amount1");
			uiDriver.setText(Amount);
			uiDriver.sendKey("enter");
			}
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Duedate");
			uiDriver.setValue("Duedate1",input.get("date1"));

			uiDriver.sendKey("enter");
		}
		
		uiDriver.click("Savechanges");
		if(uiDriver.checkElementPresent("//*[contains(text(),'Save Successful')]")) {
			passed("Generate Billing Schedule",
					"Add Schedule Item should be successful",
					"Add Schedule Item is successful");
		} else {
			failed("Generate Billing Schedule",
					"Add Schedule Item should be successful",
					"Add Schedule Item is not successful");
		}		
		uiDriver.click("Next");
		while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
			SleepUtils.sleep(TimeSlab.YIELD);
		}
		/*if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Enter Projects Allocations']")) {
			passed("Generate Billing Schedule",
					"Enter Projects Allocations window should be displayed",
					"Enter Projects Allocations window is displayed");
		} else {
			failed("Generate Billing Schedule",
					"Enter Projects Allocations window should be displayed",
					"Enter Projects Allocations window is not displayed");
		}*/
		
		if(input.get("Name").equalsIgnoreCase("NA")) {			
		// DO NOTHING
		} else {
		uiDriver.click("Filter");
		uiDriver.setValue("Textfield",input.get("subtitle"));
		uiDriver.click("Filterbar");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.LOW);
		String titles = uiDriver.getDyanmicData("Title");
		String Actualtitle = titles.replace("#", input.get("Name"));
		uiDriver.click(Actualtitle);
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,0)");
		
		
		//action1.s
		WebElement ele = uiDriver.webDr.findElement(By
				.xpath("//*[@id='stepProjects']//input[1]"));
		action1.click(ele);
		SleepUtils.sleep(TimeSlab.YIELD);
		action1.sendKeys(ele, "").build().perform();
		String TotalAmount = input.get("Total Amount");
		action1.sendKeys(ele,TotalAmount).build().perform();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Spread");
		}
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Next");
		while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
			SleepUtils.sleep(TimeSlab.YIELD);
		}
		/*if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Enter Territories Allocations']")) {
			passed("Generate Billing Schedule",
					"Enter Territories Allocations window should be displayed",
					"Enter Territories Allocations window is displayed");
		} else {
			failed("Generate Billing Schedule",
					"Enter Territories Allocations window should be displayed",
					"Enter Territories Allocations window is not displayed");
		}*/
		
		WebElement ele = uiDriver.webDr.findElement(By
				.xpath("//*[@id='stepTerritories']//input[1]"));
		
		uiDriver.click("//div[@id='territoriesGrid']//input[@class='check-all']");
		SleepUtils.sleep(TimeSlab.LOW);
		action1.click(ele);
		SleepUtils.sleep(TimeSlab.YIELD);
		action1.sendKeys(ele, "").build().perform();
		action1.sendKeys(ele, "0.00").build().perform();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//div[@class='territory allocation-toolbar']//button[text()='Spread']");
		SleepUtils.sleep(TimeSlab.LOW);
		
		uiDriver.click("//*[@title='"+input.get("Territories")+"']/preceding::input[1]");
		action1.click(ele);
		SleepUtils.sleep(TimeSlab.YIELD);
		action1.sendKeys(ele, "").build().perform();
		action1.sendKeys(ele, input.get("TerrPercent")).build().perform();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//div[@class='territory allocation-toolbar']//button[text()='Spread']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Next");
		while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
			SleepUtils.sleep(TimeSlab.YIELD);
		}
		/*if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Enter Rights Allocations']")) {
			passed("Generate Billing Schedule",
					"Enter Rights Allocations window should be displayed",
					"Enter Rights Allocations window is displayed");
		} else {
			failed("Generate Billing Schedule",
					"Enter Rights Allocations window should be displayed",
					"Enter Rights Allocations window is not displayed");
		}*/
		
		ele = uiDriver.webDr.findElement(By
				.xpath("//*[@id='stepRights']//input[1]"));
		
		uiDriver.click("//div[@id='rightsGrid']//input[@class='check-all']");
		SleepUtils.sleep(TimeSlab.LOW);
		action1.click(ele);
		SleepUtils.sleep(TimeSlab.YIELD);
		action1.sendKeys(ele, "").build().perform();
		action1.sendKeys(ele, "0.00").build().perform();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//*[@id='stepRights']/div[2]/div/div[1]/div/button[2]");
		SleepUtils.sleep(TimeSlab.LOW);
		
		uiDriver.click("//*[@title='"+input.get("Rights")+"']/preceding::input[1]");
		SleepUtils.sleep(TimeSlab.LOW);
		action1.click(ele);
		SleepUtils.sleep(TimeSlab.YIELD);
		action1.sendKeys(ele, "").build().perform();
		action1.sendKeys(ele, input.get("RightPercent")).build().perform();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//*[@id='stepRights']/div[2]/div/div[1]/div/button[2]");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Finish");
		while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
			SleepUtils.sleep(TimeSlab.YIELD);
		}
		if(uiDriver.checkElementPresent("//a[contains(text(),'Recalculate All')]")) {
			passed("Generate Billing Schedule",
					"Billing schedule should generate",
					"Billing schedule is generated suscessfully");
		} else {
			passed("Generate Billing Schedule",
					"Billing schedule should generate",
					"Billing schedule is not generated suscessfully");
		}
		
	}
	
	/****************************************
	 * Name: GenerateBillingShedule1
	 * Description: Generates a billing shedule using "Using Fee Calculations"
	 * Date: 24-April-2019 
	 ****************************************/
	
	public void GenerateBillingShedule1(DataRow input, DataRow output){
		
		Actions action1 = new Actions(uiDriver.webDr);
		
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billing");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billingschedules");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("GenerateSchedule");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
//		if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Enter Schedule Item Information']")) {
//			passed("Generate Billing Schedule",
//					"Enter Schedule Item Information window should be displayed",
//					"Enter Schedule Item Information window is displayed");
//		} else {
//			failed("Generate Billing Schedule",
//					"Enter Schedule Item Information window should be displayed",
//					"Enter Schedule Item Information window is not displayed");
//		}
		
		uiDriver.click("Scheduleitem");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//li[contains(text(),'"+input.get("Generate Schedule Item")+"')]");
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.LOW);
//		if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Enter Schedule Item Information']")) {
//			passed("Generate Billing Schedule",
//					"Enter Schedule Item Information window should be displayed",
//					"Enter Schedule Item Information window is displayed");
//		} else {
//			failed("Generate Billing Schedule",
//					"Enter Schedule Item Information window should be displayed",
//					"Enter Schedule Item Information window is not displayed");
//		}
		
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//strong[text()='Aggregate Function:']//..//..//following-sibling::div//span");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//li[text()='"+input.get("Aggregate Function")+"']");
		
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//strong[text()='Evaluation Order:']//..//..//following-sibling::div//span");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//li[text()='"+input.get("Evaluation Order")+"']");
		
		SleepUtils.sleep(TimeSlab.YIELD);
		if(input.get("Force last statement").equalsIgnoreCase("Yes")) {
			uiDriver.click("//strong[text()='Force last statement to use end date?:']//..//..//following-sibling::div//input");
		} else {
			// DO NOTHING
		}
		
		SleepUtils.sleep(TimeSlab.YIELD);
		if(input.get("Prorate first and last").equalsIgnoreCase("Yes")) {
			uiDriver.click("//strong[text()='Prorate first and last?:']//..//..//following-sibling::div//input");
		} else {
			// DO NOTHING
		}
		
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//strong[text()='Reallocation Method:']//..//..//following-sibling::div//span");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//li[text()='"+input.get("Reallocation Method")+"']");
		
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//strong[text()='Days Threshold:']//..//..//following-sibling::div//span");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//ul[@id='feeCalcsThreshold_listbox']//li[text()='"+input.get("Days Threshold")+"']");
		
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.ScrollPageDown();
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Add");
		
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("(((//tbody[@role='rowgroup']//tr)[1]//td)[1]//span)[1]");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//li[text()='"+input.get("Calculation Trigger1")+"']");
		
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("((//tbody[@role='rowgroup']//tr)[1]//td)[2]");
		uiDriver.click("(((//tbody[@role='rowgroup']//tr)[1]//td)[2]//span)[1]");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//li[text()='"+input.get("Date Value1")+"']");
		
		if(input.get("Offset1").equalsIgnoreCase("NA")) {
		// DO NOTHING	
		} else {
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("((//tbody[@role='rowgroup']//tr)[1]//td)[3]");
		String Offset1=input.get("Offset1");
		uiDriver.sendKey("backspace");
		uiDriver.setText(Offset1);
		uiDriver.sendKey("enter");
		uiDriver.sendKey("tab");
		}
		
		if(input.get("Modifier1").equalsIgnoreCase("NA")) {
		// DO NOTHING	
		} else {
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("((//tbody[@role='rowgroup']//tr)[1]//td)[4]");
		String Modifier1=input.get("Modifier1");
		uiDriver.sendKey("backspace");
		uiDriver.setText(Modifier1);
		uiDriver.sendKey("enter");
		uiDriver.sendKey("tab");
		}
		
		if(input.get("Prorated As Of Date1").equalsIgnoreCase("NA")) {
		// DO NOTHING	
		} else {
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("(((//tbody[@role='rowgroup']//tr)[1]//td)[1]//span)[1]");
		uiDriver.click("(((//tbody[@role='rowgroup']//tr)[1]//td)[2]//span)[1]");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//li[text()='"+input.get("Prorated As Of Date1")+"']");
		}
		
		if(input.get("Calculation Trigger2").equalsIgnoreCase("NA")) {
			// Do nothing
		} else {
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("Add");
			
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("(((//tbody[@role='rowgroup']//tr)[1]//td)[1]//span)[1]");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//li[text()='"+input.get("Calculation Trigger2")+"']");
			
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("((//tbody[@role='rowgroup']//tr)[1]//td)[2]");
			uiDriver.click("(((//tbody[@role='rowgroup']//tr)[1]//td)[2]//span)[1]");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//li[text()='"+input.get("Date Value2")+"']");
			
			if(input.get("Offset2").equalsIgnoreCase("NA")) {
			// DO NOTHING	
			} else {
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("((//tbody[@role='rowgroup']//tr)[1]//td)[3]");
			String Offset1=input.get("Offset2");
			uiDriver.sendKey("backspace");
			uiDriver.setText(Offset1);
			uiDriver.sendKey("enter");
			uiDriver.sendKey("tab");
			}
			
			if(input.get("Modifier2").equalsIgnoreCase("NA")) {
			// DO NOTHING	
			} else {
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("((//tbody[@role='rowgroup']//tr)[1]//td)[4]");
			String Modifier1=input.get("Modifier2");
			uiDriver.sendKey("backspace");
			uiDriver.setText(Modifier1);
			uiDriver.sendKey("enter");
			uiDriver.sendKey("tab");
			}
			
			if(input.get("Prorated As Of Date2").equalsIgnoreCase("NA")) {
			// DO NOTHING	
			} else {
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("((//tbody[@role='rowgroup']//tr)[1]//td)[5]");
			String ProratedDate2=input.get("Prorated As Of Date2");
			uiDriver.sendKey("backspace");
			uiDriver.setText(ProratedDate2);
			uiDriver.sendKey("enter");
			uiDriver.sendKey("tab");
			}
			
		}
		
		uiDriver.click("Savechanges");
		if(uiDriver.checkElementPresent("//*[contains(text(),'Save Successful')]")) {
			passed("Generate Billing Schedule",
					"Enter Schedule Item Information should be successful",
					"Enter Schedule Item Information is successful");
		} else {
			failed("Generate Billing Schedule",
					"Enter Schedule Item Information should be successful",
					"Enter Schedule Item Information is not successful");
		}	
		
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
			SleepUtils.sleep(TimeSlab.YIELD);
		}
//		if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Manually Add Schedule Items']")) {
//			passed("Generate Billing Schedule",
//					"Manually Add Schedule Items window should be displayed",
//					"Manually Add Schedule Items window is displayed");
//		} else {
//			failed("Generate Billing Schedule",
//					"Manually Add Schedule Items window should be displayed",
//					"Manually Add Schedule Items window is not displayed");
//		}
		uiDriver.executeJavaScript("scroll(0,0)");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//div[@id='manualGrid']//a[text()='Add']");
		
		if(input.get("CalcMethod").equalsIgnoreCase("NA")) {
		// DO NOTHING	
		} else {
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.sendKey("tab");
			String CalcMethod=input.get("CalcMethod");
			uiDriver.setText(CalcMethod);
			uiDriver.sendKey("enter");
		}
		
		if(input.get("amount").equalsIgnoreCase("NA")) {
		// DO NOTHING	
		} else {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.sendKey("tab");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.sendKey("tab");
		String Amount=input.get("amount");
		uiDriver.setText(Amount);
		uiDriver.sendKey("enter");
		}
		
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Duedate");
		uiDriver.setValue("Duedate1",input.get("date"));
		uiDriver.sendKey("enter");
		
		if(input.get("Category").equalsIgnoreCase("NA")) {
		// DO NOTHING	
		} else {
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("((//tbody[@role='rowgroup']//tr)[3]//td)[12]");
			uiDriver.click("(((//tbody[@role='rowgroup']//tr)[3]//td)[12]//span)[1]");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//ul[@aria-hidden='false']//li[text()='"+input.get("Category")+"']");
		}
		
		uiDriver.click("//div[@id='stepManual']//*[text()='Save changes']");
		if(uiDriver.checkElementPresent("//*[contains(text(),'Save Successful')]")) {
			passed("Generate Billing Schedule",
					"Add Schedule Item should be successful",
					"Add Schedule Item is successful");
		} else {
			failed("Generate Billing Schedule",
					"Add Schedule Item should be successful",
					"Add Schedule Item is not successful");
		}	
		
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
			SleepUtils.sleep(TimeSlab.YIELD);
		}
		if(uiDriver.checkElementPresent("//*[@id='stepProjects']//*[contains(text(),'Enter Project Allocations')]")) {
			passed("Generate Billing Schedule",
					"Enter Projects Allocations window should be displayed",
					"Enter Projects Allocations window is displayed");
		} else {
			failed("Generate Billing Schedule",
					"Enter Projects Allocations window should be displayed",
					"Enter Projects Allocations window is not displayed");
		}
		
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//span[@class='k-pager-sizes k-label']//span[@class='k-input']");
		SleepUtils.sleep(TimeSlab.YIELD);
		try {
			List<WebElement> list1 = uiDriver.webDr.findElements(By.xpath("//div[@class='k-list-scroller']//ul[@aria-hidden='false']//li"));
			SleepUtils.sleep(TimeSlab.YIELD);
			int size = list1.size();
			SleepUtils.sleep(TimeSlab.YIELD);
			if(size > 0) {
				list1.get(size-1).click();
				SleepUtils.sleep(TimeSlab.HIGH);
			}
		} catch(Exception e) {			
		}
		
		for(int i=0; i<10; i++) {	
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.ScrollPageUp();
			SleepUtils.sleep(TimeSlab.YIELD);
		}
		
		uiDriver.click("//input[@class='include-check-all']");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
			SleepUtils.sleep(TimeSlab.YIELD);
		}
		if(input.get("Name").equalsIgnoreCase("NA")) {			
		// DO NOTHING
		} else {
			while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
				SleepUtils.sleep(TimeSlab.YIELD);
			}
		uiDriver.click("Filter");
		uiDriver.setValue("Textfield",input.get("subtitle"));
		uiDriver.click("Filterbar");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.YIELD);
		String titles = uiDriver.getDyanmicData("Title");
		String Actualtitle = titles.replace("#", input.get("Name"));
		uiDriver.click(Actualtitle);
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,0)");
		while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
			SleepUtils.sleep(TimeSlab.YIELD);
		}
		uiDriver.click("Filter");
		SleepUtils.sleep(TimeSlab.LOW);
		try{
		uiDriver.click("//button[text()='Clear']");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.YIELD);
		}
		catch(Exception e){
			uiDriver.click("(//*[text()='Clear'])[2]");
			SleepUtils.sleep(TimeSlab.YIELD);
			SleepUtils.sleep(TimeSlab.YIELD);
		}
		while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
			SleepUtils.sleep(TimeSlab.YIELD);
		}
		}
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
			SleepUtils.sleep(TimeSlab.YIELD);
		}	
//		if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Enter Territories Allocations']")) {
//			passed("Generate Billing Schedule",
//					"Enter Territories Allocations window should be displayed",
//					"Enter Territories Allocations window is displayed");
//		} else {
//			failed("Generate Billing Schedule",
//					"Enter Territories Allocations window should be displayed",
//					"Enter Territories Allocations window is not displayed");
//		}
		
		WebElement ele = uiDriver.webDr.findElement(By
				.xpath("//*[@id='stepTerritories']//input[1]"));
		
		uiDriver.click("//div[@id='territoriesGrid']//input[@class='check-all']");
		SleepUtils.sleep(TimeSlab.LOW);
		action1.click(ele);
		SleepUtils.sleep(TimeSlab.YIELD);
		action1.sendKeys(ele, "").build().perform();
		action1.sendKeys(ele, "0.00").build().perform();
		SleepUtils.sleep(TimeSlab.YIELD);
		try{
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//div[@class='territory allocation-toolbar']//button[text()='Spread']");
			}
			catch(Exception e){
				uiDriver.click("//div[@class='rights allocation-toolbar']//button[text()='Spread']");
			}
		SleepUtils.sleep(TimeSlab.LOW);
		
		uiDriver.click("//*[@title='"+input.get("Territories")+"']/preceding::input[1]");
		action1.click(ele);
		SleepUtils.sleep(TimeSlab.YIELD);
		action1.sendKeys(ele, "").build().perform();
		action1.sendKeys(ele, input.get("TerrPercent")).build().perform();
		SleepUtils.sleep(TimeSlab.YIELD);
		try{
		uiDriver.click("//div[@class='territory allocation-toolbar']//button[text()='Spread']");
		}
		catch(Exception e){
			uiDriver.click("//div[@class='rights allocation-toolbar']//button[text()='Spread']");
		}
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
			SleepUtils.sleep(TimeSlab.YIELD);
		}
//		if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Enter Rights Allocations']")) {
//			passed("Generate Billing Schedule",
//					"Enter Rights Allocations window should be displayed",
//					"Enter Rights Allocations window is displayed");
//		} else {
//			failed("Generate Billing Schedule",
//					"Enter Rights Allocations window should be displayed",
//					"Enter Rights Allocations window is not displayed");
//		}
		
		
		ele = uiDriver.webDr.findElement(By
				.xpath("//*[@id='stepRights']//input[1]"));
		
		uiDriver.click("//div[@id='rightsGrid']//input[@class='check-all']");
		SleepUtils.sleep(TimeSlab.LOW);
		action1.click(ele);
		SleepUtils.sleep(TimeSlab.YIELD);
		action1.sendKeys(ele, "").build().perform();
		action1.sendKeys(ele, "0.00").build().perform();
		SleepUtils.sleep(TimeSlab.YIELD);
		try{
			uiDriver.click("//div[@class='territory allocation-toolbar']//button[text()='Spread']");
			}
			catch(Exception e){
				uiDriver.click("//div[@class='rights allocation-toolbar']//button[text()='Spread']");
			}
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//div[@id='rightsGrid']//input[@class='check-all']");
		SleepUtils.sleep(TimeSlab.LOW);
		action1.click(ele);
		SleepUtils.sleep(TimeSlab.YIELD);
		action1.sendKeys(ele, "").build().perform();
		action1.sendKeys(ele, input.get("RightPercent")).build().perform();
		SleepUtils.sleep(TimeSlab.YIELD);
		try{
			uiDriver.click("//div[@class='territory allocation-toolbar']//button[text()='Spread']");
			}
			catch(Exception e){
				uiDriver.click("//div[@class='rights allocation-toolbar']//button[text()='Spread']");
			}
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Finish");
		SleepUtils.sleep(TimeSlab.HIGH);
		while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
			SleepUtils.sleep(TimeSlab.YIELD);
		}
		
		if(uiDriver.checkElementPresent("//a[contains(text(),'Recalculate All')]")) {
			passed("Generate Billing Schedule",
					"Billing schedule should generate",
					"Billing schedule is generated suscessfully");
		} else {
			passed("Generate Billing Schedule",
					"Billing schedule should generate",
					"Billing schedule is not generated suscessfully");
		}
		
	}
	
	public void ClickRecalculateAll(DataRow input, DataRow output) {
		uiDriver.click("//a[contains(text(),'Recalculate All')]");
//		SleepUtils.sleep(TimeSlab.HIGH);
		if(uiDriver.checkElementPresent("//*[contains(text(),'Recalculation Successful')]")) {
			passed("Recalculate All",
					"Recalculate All should be successful",
					"Recalculate All is successful");
		} else {
			
			if(uiDriver.checkElementPresent("//*[contains(text(),'Recalculation Successful')]")) {
				passed("Recalculate All",
						"Recalculate All should be successful",
						"Recalculate All is successful");
			} else {
				if(uiDriver.checkElementPresent("//*[contains(text(),'Recalculation Successful')]")) {
					passed("Recalculate All",
							"Recalculate All should be successful",
							"Recalculate All is successful");
				} else {
					failed("Recalculate All",
							"Recalculate All should be successful",
							"Recalculate All is not successful");
				}
			}
		}
	}
	
	
	
	
	/****************************************
	 * Name: Validatefinancesummary
	 * Description:Navigate to financial summary and validate
	 * Date: 24-Sept-2019
	 ****************************************/
	
	public void Validatefinancesummary(DataRow input, DataRow output)
	{
		// MANDATORY::PRESS F8 AND OPEN APPLICATION TILL NEXT DEBUG POINT
		uiDriver.click("finance");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("financesummary");
		SleepUtils.sleep(TimeSlab.YIELD);
		Actions action = new Actions(uiDriver.webDr);
		WebElement ele = uiDriver.webDr
				.findElement(By.xpath("(//*[@class='k-numeric-wrap k-state-default k-expand-padding']//input)[1]"));
		// action.sendKeys("ele", "").build().perform();
		action.click(ele).build().perform();
		action.sendKeys(Keys.CONTROL, "a", Keys.BACK_SPACE).build().perform();
		SleepUtils.sleep(TimeSlab.LOW);
		// uiDriver.click("(//*[@class='k-numeric-wrap k-state-default
		// k-expand-padding']//input)[1]");
		uiDriver.setText("516");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("search");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);

		String title = input.get("ExpTitles");
		String ExpTitles[] = title.split(";");

		String amount = input.get("ExpAmt");
		String expamount[] = amount.split(";");

		String category = input.get("ExpCategory");
		String expCategory[] = category.split(";");

		String dealno = input.get("ExpDealno");
		String expDealno[] = dealno.split(";");

		List<WebElement> titles = uiDriver.webDr
				.findElements(By.xpath("//*[@id='financial-summary-tree']/div[2]/table/tbody/tr"));
		int titlesize = titles.size();
		for (int i = 0; i <= titlesize; i++) {
			if(i==100){
				break;
			}
			String actualTitle = uiDriver
					.getValue("//*[@id='financial-summary-tree']/div[2]/table/tbody/tr[" + (i + 1) + "]/td[2]/span[2]"); // *[@id='financial-summary-tree']/div[2]/table/tbody/tr[1]/td[2]/span[2]
			String expectedTitle = ExpTitles[i].trim();

			if (expectedTitle.contains(actualTitle)) {

				passed("Validatefinancesummary", "Title should be dispalyed as" + expectedTitle,

						"Title is displayed successfully" + actualTitle.trim());

			} else {
				failed("Validatefinancesummary", "Title should be dispalyed as" + expectedTitle,
						"Title is not displayed successfully " + actualTitle.trim());
			}

			String actualAmt = uiDriver.getValue(
					"//*[@id='financial-summary-tree']/div[2]/table/tbody/tr[" + (i + 1) + "]/td[5]/div[1]/div/input");
			String aAmt = actualAmt.replace(",", "");
			String actAmt = aAmt.replace(".00", "");
			String expectedAmount = expamount[i].trim();

			if (expectedAmount.contains(actAmt)) {

				passed("Validatefinancesummary", "Amount should be dispalyed as" + expectedAmount,

						"Amount is displayed successfully" + actualAmt.trim());

			} else {
				failed("Validatefinancesummary", "Amount should be dispalyed as" + expectedAmount,
						"Amount is not displayed successfully " + actualAmt.trim());
			}

			String actualCategory = uiDriver.getValue("//*[@id='financial-summary-tree']/div[2]/table/tbody/tr["
					+ (i + 1) + "]/td[3]/div/span/span/span");
			String expectedCategory = expCategory[i].trim();

			if (expectedCategory.contains(actualCategory)) {

				passed("Validatefinancesummary", "Category should be dispalyed as" + expectedCategory,

						"Category is displayed successfully" + actualCategory);

			} else {
				failed("Validatefinancesummary", "Category should be dispalyed as" + expectedCategory,
						"Category is not displayed successfully " + actualCategory);
			}

			String actualDealno = uiDriver.getValue(
					"//*[@id='financial-summary-tree']/div[2]/table/tbody/tr[" + (i + 1) + "]/td[8]/div/input");
			String expectedDealno = expDealno[i].trim();

			if (actualDealno.contains(expectedDealno)) {

				passed("Validatefinancesummary", "Deal no should be dispalyed as" + expectedDealno,

						"Deal no is displayed successfully" + actualDealno);

			} else {
				failed("Validatefinancesummary", "Deal no should be dispalyed as" + expectedDealno,
						"Deal no is not displayed successfully " + actualDealno);
			}

		}

	}
	
	
	public void Validatefinancesummary28(DataRow input, DataRow output)
	{
		// MANDATORY::PRESS F8 AND OPEN APPLICATION TILL NEXT DEBUG POINT
		uiDriver.click("finance");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("financesummary");
		SleepUtils.sleep(TimeSlab.YIELD);
		Actions action = new Actions(uiDriver.webDr);
		WebElement ele = uiDriver.webDr
				.findElement(By.xpath("(//*[@class='k-numeric-wrap k-state-default k-expand-padding']//input)[1]"));
		// action.sendKeys("ele", "").build().perform();
		action.click(ele).build().perform();
		action.sendKeys(Keys.CONTROL, "a", Keys.BACK_SPACE).build().perform();
		SleepUtils.sleep(TimeSlab.LOW);
		// uiDriver.click("(//*[@class='k-numeric-wrap k-state-default
		// k-expand-padding']//input)[1]");
		uiDriver.setText("118");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("search");
		SleepUtils.sleep(TimeSlab.HIGH);
		

		String title = input.get("ExpTitles");
		String ExpTitles[] = title.split(";");

		String amount = input.get("ExpAmt");
		String expamount[] = amount.split(";");

		String category = input.get("ExpCategory");
		String expCategory[] = category.split(";");

		

		List<WebElement> titles = uiDriver.webDr
				.findElements(By.xpath("//*[@id='financial-summary-tree']/div[2]/table/tbody/tr"));
		int titlesize = titles.size();
		for (int i = 0; i <= titlesize; i++) {
			if(i==100){
				break;
			}
			String actualTitle = uiDriver
					.getValue("//*[@id='financial-summary-tree']/div[2]/table/tbody/tr[" + (i + 1) + "]/td[2]/span[2]"); // *[@id='financial-summary-tree']/div[2]/table/tbody/tr[1]/td[2]/span[2]
			String expectedTitle = ExpTitles[i].trim();

			if (expectedTitle.contains(actualTitle)) {

				passed("Validatefinancesummary", "Title should be dispalyed as" + expectedTitle,

						"Title is displayed successfully" + actualTitle.trim());

			} else {
				failed("Validatefinancesummary", "Title should be dispalyed as" + expectedTitle,
						"Title is not displayed successfully " + actualTitle.trim());
			}

			String actualAmt = uiDriver.getValue(
					"//*[@id='financial-summary-tree']/div[2]/table/tbody/tr[" + (i + 1) + "]/td[5]/div[1]/div/input");
			String aAmt = actualAmt.replace(",", "");
			String actAmt = aAmt.replace(".00", "");
			String expectedAmount = expamount[i].trim();

			if (expectedAmount.contains(actAmt)) {

				passed("Validatefinancesummary", "Amount should be dispalyed as" + expectedAmount,

						"Amount is displayed successfully" + actualAmt.trim());

			} else {
				failed("Validatefinancesummary", "Amount should be dispalyed as" + expectedAmount,
						"Amount is not displayed successfully " + actualAmt.trim());
			}

			String actualCategory = uiDriver.getValue("//*[@id='financial-summary-tree']/div[2]/table/tbody/tr["
					+ (i + 1) + "]/td[3]/div/span/span/span");
			String expectedCategory = expCategory[i].trim();

			if (expectedCategory.contains(actualCategory)) {

				passed("Validatefinancesummary", "Category should be dispalyed as" + expectedCategory,

						"Category is displayed successfully" + actualCategory);

			} else {
				failed("Validatefinancesummary", "Category should be dispalyed as" + expectedCategory,
						"Category is not displayed successfully " + actualCategory);
			}

			
		}

	}
	
	
	 public void ValidateFinancialSummary(DataRow input, DataRow output)

     {

            SleepUtils.sleep(TimeSlab.MEDIUM);

            uiDriver.click("Finance");

            SleepUtils.sleep(TimeSlab.YIELD);

            uiDriver.click("FinancialSummary");

            SleepUtils.sleep(TimeSlab.HIGH);
            SleepUtils.sleep(TimeSlab.HIGH);

           /*           */

            if(input.get("Title").equals("Y")){

            String JAKandAME="BNI-05|I3501|BIG HOUSE PT. 1, THE";

            String NoOfRecords=uiDriver.getValue_Text("TotalRecords");

            NoOfRecords.substring(0, NoOfRecords.length()-9);

            System.out.println(NoOfRecords);

            int m = Integer.parseInt(NoOfRecords);

            for(int i=0; i<m+1;i++)

            {

                   if(m==22)

                   {

                         passed("Verify the Record is not displayed",

                                       "The  Record is not displayed",

                                       "The record Record has been removed");

                   }

                   String inv = uiDriver.getDyanmicData("records");

                   String Records = inv.replace("#", Integer.toString(i));

                   SleepUtils.sleep(TimeSlab.MEDIUM);

                   if(Records.contains(JAKandAME))

                   {

                        

                         failed("Verify the Record is displayed",

                                       "The  " + Records + "is displayed",

                                       "The record " + Records + "should have been removed");



                   }

                   else

                   {

                         continue;

                   }

                  

            }

            }     
            
            		if(input.get("Sync").equals("Y")){
            			 uiDriver.click("//*[text()='Sync From Schedule Items']");
            			 SleepUtils.sleep(TimeSlab.LOW);
            			 uiDriver.click("//*[text()='Are you sure you want to update Amounts from schedule items?']//following::button[2]");
            			  SleepUtils.sleep(TimeSlab.LOW);
            			  SleepUtils.sleep(TimeSlab.LOW);

                         uiDriver.click("//button[text()='Update Contract Total']");
                         SleepUtils.sleep(TimeSlab.LOW);
                         SleepUtils.sleep(TimeSlab.LOW);
                         uiDriver.click("//*[text()='Are you sure you want to update the contract total?']//following::button[2]");
                         String ContractTotal=uiDriver.getValue_Text("ContractTotal");
                         

                         SleepUtils.sleep(TimeSlab.LOW);

                         String AllocTotal=uiDriver.getValue_Text("AllocTotal");

                         SleepUtils.sleep(TimeSlab.LOW);

                         String difference=uiDriver.getValue_Text("difference");

                         if(input.get("ContractTotal").contains(ContractTotal)&&input.get("AllocTotal").contains(AllocTotal)&&input.get("difference").contains(difference))

                         {

                               

                                passed("Verify the Record is displayed",

                                             "The  " + ContractTotal + AllocTotal+difference+"is displayed",

                                             "The records are matching");

                        

                         }

                         else

                         {

                                failed("Verify the Record is displayed",

                                             "The  " + ContractTotal + AllocTotal+difference+"is displayed",

                                             "The record are not matching");

                         }



                  

                  

            }

           

           



     }
	
	 /****************************************
		 * Name: verifyRevenueNotPresent
		 * Description: Check if no revenues are present 
		 * Date: 08-mar-2019
		 ****************************************/
		
	 
	 public void verifyRevenueNotPresent(DataRow input, DataRow output) {
		 SleepUtils.sleep(TimeSlab.LOW);
		 uiDriver.click("relatedRecord");
		 SleepUtils.sleep(TimeSlab.LOW);
		 if(uiDriver.checkElementPresent_dynamic("(//td[text()=\"Revenue Arrangement\"])[1]")) {
			 failed("Revenue  present",
						"Revenue should not be present'" , 
						"Revenue is  present '");
			
			 
		 }
		 else {
			passed("Revenue not present",
					"Revenue should not be present'" , 
					"Revenue not present is checked '");
		 }
		
			
		 
		 
	 }
	 
	 public void TransactionAllocationNotPresent(DataRow input, DataRow output) {
		 
		 uiDriver.refresh();
		    SleepUtils.sleep(10);
			uiDriver.click("Custom");
			SleepUtils.sleep(TimeSlab.LOW);
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.executeJavaScript("scroll(0,800)");
//			uiDriver.executeJavaScript("document.getElementById('recmachcustrecord_nbcu_titleallocpa_contracttxt').click();");
			//uiDriver.click("TitleAllocationParent");
			SleepUtils.sleep(TimeSlab.LOW);
			SleepUtils.sleep(TimeSlab.LOW);
			
			
			uiDriver.executeJavaScript("scroll(0,1200)");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//*[@id='recmachcustrecord_nbcu_titleallocpa_paymenttxt']");
			SleepUtils.sleep(TimeSlab.LOW);
			//int accRows = uiDriver.webDr.findElements(By.xpath("//table[@id='recmachcustrecord_nbcu_titleallocpa_contract__tab']/tbody/tr")).size();
			if(uiDriver.checkElementPresent_dynamic("//*[@id='recmachcustrecord_nbcu_titleallocpa_paymentrow0']/td[1]/a")) {
				 failed("TransactionAllocation  present",
							"TransactionAllocation should not be present'" , 
							"TransactionAllocation is  present '");
				
				 
			 }
			 else {
				passed("TransactionAllocation not present",
						"TransactionAllocation should not be present'" , 
						"TransactionAllocation not present is checked '");
			 }
			SleepUtils.sleep(TimeSlab.HIGH);

		 
	 }
	 
	 
	 /****************************************
		 * Name: CalculateWhtAmount
		 * Description: Check for Whtamount and masterinvoice 
		 * Date: 12-mar-2019
		 ****************************************/

	 
	 
	 public void CalculateWhtAmount(DataRow input, DataRow output) {
		 
		 SleepUtils.sleep(TimeSlab.MEDIUM);
	    	String Num = input.get("conf");
			uiDriver.setValue("SearchSO", Num);
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("SalesOrder");
			passed("SalesOrder", "SalesOrder Should be displayed Successfully",
					"SalesOrder is displayed Successfully");
			uiDriver.executeJavaScript("scroll(0,500)");	
			uiDriver.click("relatedRecord");
			String Invoices = uiDriver.getDyanmicData("InvoiceLinks");
			String InvoiceLink = Invoices.replace("#",input.get("Amount"));
			uiDriver.click_dynamic(InvoiceLink);
			
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.executeJavaScript("scroll(0,500)");
			String Actualmasterinvoice=uiDriver.getValue_Text("actualmasterinvoice");
			
			
			
			
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.executeJavaScript("scroll(0,500)");
			uiDriver.click("relatedRecord");
			uiDriver.click("payment");
			SleepUtils.sleep(TimeSlab.MEDIUM);
	        SleepUtils.sleep(TimeSlab.MEDIUM);
	        uiDriver.executeJavaScript("scroll(0,500)");	
	        uiDriver.click("Cashadj");
	        uiDriver.executeJavaScript("scroll(0,500)");
	        uiDriver.click("//a[text()='HT Information']");
	        SleepUtils.sleep(TimeSlab.LOW);
	        String Whtamount = uiDriver.getValue_Text("Whtamount");
	        if(input.get("whtamount").contains(Whtamount)) {
	        	passed("Wht amount ",
						"Wht amount  should  be " +input.get("whtamount") , 
						"Wht amount  is  "+Whtamount);
			
	        	
	        }
	        else {
	        	failed("Wht amount ",
						"Wht amount  should  be " +input.get("whtamount") , 
						"Wht amount  is  "+Whtamount);
			
				
	        }
	        
	        if(uiDriver.getValue_Text("Masterinvoice").contains(Actualmasterinvoice)) {
	        	passed("Masterinvoice",
						"Masterinvoice  should  be " +uiDriver.getValue_Text("Masterinvoice") , 
						"Masterinvoice  is  "+Actualmasterinvoice);
			
	        	
	        }
	        else {
	        	passed("Masterinvoice",
						"Masterinvoice  should  be " +input.get("Masterinvoice") , 
						"Masterinvoice  is  "+Actualmasterinvoice);
			
	        }
	        
	    	uiDriver.executeJavaScript("scroll(0,0)");	
			
		 
	 }
	 
	 
	 /****************************************
	  * Name: ReadSingleInvoiceArmr
	  * Description: Check for Invoice flown from Armr  
	  * Date: 14-mar-2019
	  ****************************************/

	 
	 public void ReadSingleInvoiceArmr(DataRow input, DataRow output) {
		 //SleepUtils.sleep(600);
		 
		 uiDriver.click("Finance");
		 SleepUtils.sleep(TimeSlab.MEDIUM); 
		 uiDriver.click("Billing");
		 uiDriver.click("Invoices");
		 SleepUtils.sleep(TimeSlab.HIGH);
		 //uiDriver.click("//*[text()='3,027.19']/preceding::input[1]");
		 String Invoice = uiDriver.getDyanmicData("ArmInvoice1");
		 String Amount=input.get("Amount");
		 System.out.println(Amount);
			String ActualInvoice= Invoice.replace("#", Amount);
			String Invnum=uiDriver.getDyanmicData("Invnum1");
			for(int i=0;i<=50;i++) {
			if(uiDriver.checkElementPresent_dynamic(ActualInvoice)) {
				passed("ReadSingleInvoiceArmr  ",
						"Invoice generated through armr should be present" , 
						"Invoice generated through armr should is present in Filmtrack");
				
				break;
			}
			else {
				uiDriver.refresh();
				SleepUtils.sleep(50);
				uiDriver.refresh();
			}
			output.put("ArInvoice", ActualInvoice);
			}
		 
	 }

	 /****************************************
	  * Name: NavigateToTimelineItems
	  * Description: NavigateToTimelineItems
	  * Date: 22-April-2019
	  ****************************************/
	 public void NavigateToTimelineItems(DataRow input, DataRow output) {
		 SleepUtils.sleep(TimeSlab.YIELD);
		 uiDriver.click("//li//a[text()='Dates']");
		 SleepUtils.sleep(TimeSlab.YIELD);
		 uiDriver.click("//li//a[text()='Timeline Items']");
		 SleepUtils.sleep(TimeSlab.HIGH);
	 }

	 
	 
	 public void SingleSubscribercatexists(DataRow input, DataRow output) 
	 {
	 SleepUtils.sleep(TimeSlab.MEDIUM);
	 uiDriver.click("//a[text()='Maintenance']");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.click("//a[text()='Finance/Accounting']");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.click("(//a[text()='Fee Calculation'])[1]");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.click("//a[text()='Statement Input Categories']");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 String subscribers=uiDriver.getValueByText("//td[text()='Subscribers']");
	 if(subscribers.equalsIgnoreCase("Subscribers")) {		 
		 passed("Single Subscriber category info", "Single Subscriber Should be exists",
				 "Single Subscriber is displayed");
	 } else {
		 failed("Single Subscriber category info", "Single Subscriber Should be exists",
				 "Single Subscriber is not displayed");
	 }
	 SleepUtils.sleep(TimeSlab.YIELD);
	 }

	 
	 
	 /****************************************
	  * Name: SingleSubscribersexists
	  * Description: SingleSubscribersexists
	  * Date: 02-May-2019
	  ****************************************/
	 public void SingleSubscribersexists(DataRow input, DataRow output) 
	 {
		 SleepUtils.sleep(TimeSlab.MEDIUM);
		 uiDriver.click("//a[text()='Maintenance']");
		 SleepUtils.sleep(TimeSlab.YIELD);
		 uiDriver.click("//a[text()='Finance/Accounting']");
		 SleepUtils.sleep(TimeSlab.YIELD);
		 uiDriver.click("(//a[text()='Fee Calculation'])[1]");
		 SleepUtils.sleep(TimeSlab.YIELD);
		 uiDriver.click("//*[text()='Statement Templates']");
		 SleepUtils.sleep(TimeSlab.YIELD);
		
		 String subscribers=uiDriver.getValueByText("//td[contains(text(),'Single Subscriber')]");
		 //String subscribers=uiDriver.getValueByText("//td[text()='Single Subscribers']");
		 if((subscribers.equalsIgnoreCase("Single Subscribers"))||(subscribers.equalsIgnoreCase("Single Subscriber"))) {		 
			 passed("Single Subscriber info", "Single Subscriber Should be exists",
					 "Single Subscriber is displayed");
		 } else {
			 failed("Single Subscriber info", "Single Subscriber Should be exists",
					 "Single Subscriber is not displayed");
		 }
		 SleepUtils.sleep(TimeSlab.YIELD);
	 }
	 
	 
	 
	 /****************************************
	  * Name: SingleSubscribersexists
	  * Description: SingleSubscribersexists
	  * Date: 02-May-2019
	  ****************************************/
	 /****************************************
	  * Name: SingleSubscribersexists
	  * Description: SingleSubscribersexists
	  * Date: 02-May-2019
	  ****************************************/
	


	 /****************************************
	  * Name: SingleSubscribermapping
	  * Description: SingleSubscribermapping
	  * Date: 02-May-2019
	  ****************************************/
	 public void SingleSubscribermapping(DataRow input, DataRow output) 
	 {
	 SleepUtils.sleep(TimeSlab.MEDIUM);
	 uiDriver.click("Finance");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.click("FeeCalculation");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.click("Statements");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.click("dropdown");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.click("SingleSubscriber");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.click("Save");
	
	 SleepUtils.sleep(TimeSlab.YIELD);
	 }

	 /****************************************
	  * Name: AddFeeCalculationInput
	  * Description: AddFeeCalculationInput
	  * Date: 02-May-2019
	  ****************************************/
	 public void AddFeeCalculationInput(DataRow input, DataRow output) 
	 {
	 SleepUtils.sleep(TimeSlab.MEDIUM);
	 uiDriver.click("Finance");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.click("FeeCalculation");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.click("Input");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 for(int i=1;i<=9;i++)
	 {
	 uiDriver.click("Addinput");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.click("Projectcatagory");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.click("Select");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 String xpath="//li[text()='#']";
	 String project=input.get("Project"+i);
	 String newxpath=xpath.replace("#", project);
	 uiDriver.click(newxpath);
	 //uiDriver.click("//ul[@class='k-list k-reset']/li["+i+"])[2]");
	 //uiDriver.click("CurrentMegahit");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.click("Inputtype");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.click("Select");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.click("Inputtypevalue");
	 SleepUtils.sleep(TimeSlab.HIGH);
	 uiDriver.click("Amount");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.webDr.findElement(By.xpath("//input[@name='Amount']")).clear();
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.webDr.findElement(By.xpath("(//input[@type='text'])[1]")).click();
	 SleepUtils.sleep(TimeSlab.YIELD);
	 String amount=input.get("amount"+i);
	 uiDriver.setText(amount);
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.click("Savechanges");
	 SleepUtils.sleep(TimeSlab.HIGH);
	 }
	 uiDriver.click("Addinput");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.click("Inputtype");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.click("Select");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.click("InputGuaranteedSubs");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.click("Amount");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.webDr.findElement(By.xpath("//input[@name='Amount']")).clear();
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.webDr.findElement(By.xpath("(//input[@type='text'])[1]")).click();
	 SleepUtils.sleep(TimeSlab.YIELD);
	 String Guaranteedamount=input.get("GuaranteedSubsamount");
	 uiDriver.setText(Guaranteedamount);
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.click("Savechanges");
	 }
	 
	 
	 /****************************************
	  * Name: AddFeeCalculationInput1
	  * Description: AddFeeCalculationInput1
	  * Date: 02-May-2019
	  ****************************************/
	 public void AddFeeCalculationInput1(DataRow input, DataRow output) 
	 {
	 SleepUtils.sleep(TimeSlab.MEDIUM);
	 uiDriver.click("Finance");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.click("FeeCalculation");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 uiDriver.click("Input");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 
	 String Projects = input.get("Projects");
	 String InputTypes = input.get("Input Types");
	 String Amounts = input.get("Amounts");
	 String Posts = input.get("Posts");
	 String Statements = input.get("Statements");
	 
	 String[] Project = Projects.split(";");
	 String[] InputType = InputTypes.split(";");
	 String[] Amount = Amounts.split(";");
	 String[] Post = Posts.split(";");
	 String[] Statement = Statements.split(";");
	 System.out.println(Statement.length);
	 for(int i=0;i<Integer.parseInt(input.get("Rows"));i++)
	 {
	 SleepUtils.sleep(TimeSlab.LOW);
	 uiDriver.click("Addinput");
	 SleepUtils.sleep(TimeSlab.YIELD);
	 
	 String project=Project[i].trim();
	 if(project.equalsIgnoreCase("NA")) {
	 } else {
		 uiDriver.click("Projectcatagory");
		 SleepUtils.sleep(TimeSlab.YIELD);
		 uiDriver.click("Select");
		 SleepUtils.sleep(TimeSlab.YIELD);
		 String xpath="//li[text()='#']";	 
		 String newxpath=xpath.replace("#", project);
		 uiDriver.click(newxpath);
		 SleepUtils.sleep(TimeSlab.YIELD);
	 }
	 //uiDriver.click("//ul[@class='k-list k-reset']/li["+i+"])[2]");
	 //uiDriver.click("CurrentMegahit");
//	 SleepUtils.sleep(TimeSlab.YIELD);
	 
	 String inputtype=InputType[i].trim();
	 if(inputtype.equalsIgnoreCase("NA")) {
	 } else {
		 
		 
		/*WebElement inputtyped = uiDriver.webDr.findElement(By.xpath("//*[text()='CPS']"));
		((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView(true);", inputtyped);
		((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();",inputtyped);*/
		 uiDriver.click("//*[text()='CPS']");
		 uiDriver.click("//*[text()='CPS']");
		 SleepUtils.sleep(TimeSlab.YIELD);
		/* WebElement element = uiDriver.webDr.findElement(By.xpath("//span[text()='"+input.get("ProjectName")+"']//..//..//a[text()='Edit']"));
			((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView(true);", element);
			((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();",element);
		 uiDriver.click("Select");*/
		 SleepUtils.sleep(TimeSlab.YIELD);
		 String xpath="//li[text()='#']";	 
		 String newxpath=xpath.replace("#", inputtype);
		 uiDriver.click(newxpath);
		 
		 WebElement inputtypedvalue = uiDriver.webDr.findElement(By.xpath(newxpath));
			((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView(true);", inputtypedvalue);
			((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();",inputtypedvalue);
		 SleepUtils.sleep(TimeSlab.YIELD);
	 }
	 
	 String amount=Amount[i].trim();
	 System.out.println(amount);
	 if(inputtype.equalsIgnoreCase("NA")) {
	 } else {
		 uiDriver.click("Amount");
		 SleepUtils.sleep(TimeSlab.HIGH);
		 uiDriver.webDr.findElement(By.xpath("//input[@name='Amount']")).sendKeys(Keys.BACK_SPACE);
		 SleepUtils.sleep(TimeSlab.LOW);
		 //uiDriver.webDr.findElement(By.xpath("//input[@name='Amount']")).click();
		 SleepUtils.sleep(TimeSlab.YIELD);
		 System.out.println("entering amount");
		// uiDriver.webDr.findElement(By.xpath("//input[@name='Amount']")).sendKeys(amount);
         uiDriver.setText(amount);
         System.out.println("entered amount");
		 SleepUtils.sleep(TimeSlab.YIELD);
	 }
	 String statement=Statement[i].trim();
	 if(statement.equalsIgnoreCase("Yes")) {
	 } else {
		 uiDriver.click("(//a[text()='Project Category']/../../../../../../following-sibling::div[1]/table/tbody/tr/td[6])[1]/input");
		 SleepUtils.sleep(TimeSlab.YIELD);
	 }	 
	 String post=Post[i].trim();
	 if(post.equalsIgnoreCase("Yes")) {
	 } else {
		 uiDriver.click("(//a[text()='Project Category']/../../../../../../following-sibling::div[1]/table/tbody/tr/td[5])[1]/input");
		 SleepUtils.sleep(TimeSlab.YIELD);
	 }
	 
	
	 }
	 uiDriver.click("Savechanges");
	if(uiDriver.checkElementPresent("//*[contains(text(),'Save Successful')]")) {
		passed("AddFeeCalculationInput1",
			"Add Fee Calculation Input should be successful",
			"Add Fee Calculation Input is successful");
	} else {
		if(uiDriver.checkElementPresent("//*[contains(text(),'Save Successful')]")) {
			passed("AddFeeCalculationInput1",
				"Add Fee Calculation Input should be successful",
				"Add Fee Calculation Input is successful");
		} else {
			failed("AddFeeCalculationInput1",
				"Add Fee Calculation Input should be successful",
				"Add Fee Calculation Input is not successful");
		}
	}
	 }
	 
	 
	 /****************************************
		 * Name: FeeCalculationStatements
		 * Description: Fee Calculation Statements
		 * Date: 30-April-2019
		 ****************************************/
	 int Approveeachstatement_LENGTH;
		public void FeeCalculationStatements(DataRow input, DataRow output) 
		{
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("Finance");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("FeeCalculation");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("Statements");
			SleepUtils.sleep(TimeSlab.HIGH);
			
			String StatementTypes = input.get("StatementTypes");
			String Months = input.get("Months");
			String Years = input.get("Years");
			String Amounts = input.get("Amounts");
			 
			String[] StatementType = StatementTypes.split(";");
			String[] Month = Months.split(";");
			String[] Year = Years.split(";");
			String[] Amount = Amounts.split(";");
			Approveeachstatement_LENGTH = StatementType.length;
			
		for(int i=0;i<Month.length;i++)
		{
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("Statementtype");
			SleepUtils.sleep(TimeSlab.YIELD);
			String statementtypexpath="//li[text()='#']";
			statementtypexpath=statementtypexpath.replaceAll("#", StatementType[i].trim());
			uiDriver.click(statementtypexpath);
			SleepUtils.sleep(TimeSlab.YIELD);
			
			uiDriver.click("Monthdropdown");
			SleepUtils.sleep(TimeSlab.YIELD);
			String monthxpath="//li[text()='#']";
			monthxpath=monthxpath.replaceAll("#", Month[i].trim());
			uiDriver.click(monthxpath);
			SleepUtils.sleep(TimeSlab.YIELD);
			
			uiDriver.click("yeardropdown");
			SleepUtils.sleep(TimeSlab.YIELD);
			String year="//li[text()='#']";
			year=year.replaceAll("#", Year[i].trim());
			uiDriver.click(year);
			SleepUtils.sleep(TimeSlab.YIELD);
			
			uiDriver.click("subsamountfield");
			SleepUtils.sleep(TimeSlab.YIELD);			
			String amount=Amount[i].trim();			
			uiDriver.setValue("subsamountfieldvalue", amount);
			SleepUtils.sleep(TimeSlab.YIELD);
			
//			if(i==1)
//			{
//			uiDriver.click("Save");
//			SleepUtils.sleep(TimeSlab.HIGH);
//			}
			uiDriver.click("submit");
			SleepUtils.sleep(TimeSlab.HIGH);
			}
			
			
		}
		
		
		/****************************************
		* Name:  
		* Description: Approve each statement
		* Date: 29-April-2019
		****************************************//*
		public void Approveeachstatement(DataRow input, DataRow output) 
		{
			SleepUtils.sleep(TimeSlab.YIELD);
			List<WebElement> lst = uiDriver.webDr.findElements(By.xpath("//a[text()='Calculate']"));
			for(int i=1;i<=lst.size();i++)
			{
			SleepUtils.sleep(TimeSlab.MEDIUM);
			String calculatebutton="(//a[text()='Calculate'])[1]";
			uiDriver.click(calculatebutton);
			SleepUtils.sleep(TimeSlab.HIGH);
			passed("Approve each statement", "Should click button Calculate"+i,
					"Clicked button Calculate"+i);
			uiDriver.click("(//a[text()='Calculate'])[1]/following::button[@title='Transition to workflow state ...'][1]");
			uiDriver.handleAlert("", "OK");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.refresh();
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.refresh();
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.refresh();
			
			if(uiDriver.checkElementPresent("//span[text()='Processing: Waiting for NS ']")||uiDriver.checkElementPresent("//span[text()='Processing ']")){
			while(uiDriver.checkElementPresent("//span[text()='Processing: Waiting for NS ']")||uiDriver.checkElementPresent("//span[text()='Processing ']")){
				
				
				SleepUtils.sleep(TimeSlab.HIGH);
				uiDriver.refresh();
				SleepUtils.sleep(TimeSlab.HIGH);
				uiDriver.refresh();
				
				
			}
			}
			else if(uiDriver.checkElementPresent("//*[text()='Error ']")){
				failed("Approve each statement", "Statement should reach NS ",
						"Statement went to error");
				break;
				
				
			}
			
			
			}
			
			}*/
		
		
		
		/****************************************
	      * Name: Approveeachstatement
	      * Description: Approve each statement
	      * Date: 29-April-2019
	      ****************************************/
	      public void Approveeachstatement(DataRow input, DataRow output) 
	      {
	    	  SleepUtils.sleep(TimeSlab.YIELD);
	  		List<WebElement> lst = uiDriver.webDr.findElements(By.xpath("//a[text()='Calculate']"));
	  		for (int i = 1; i <= lst.size(); i++) {
	  			SleepUtils.sleep(TimeSlab.MEDIUM);
	  			String calculatebutton = "(//a[text()='Calculate'])[1]";
	  			uiDriver.click(calculatebutton);
	  			SleepUtils.sleep(TimeSlab.HIGH);
	  			passed("Approve each statement", "Should click button Calculate" + i, "Clicked button Calculate" + i);
	  			uiDriver.click(
	  					"(//a[text()='Calculate'])[1]/following::button[@title='Transition to workflow state ...'][1]");
	  			uiDriver.handleAlert("", "OK");
	  			SleepUtils.sleep(TimeSlab.HIGH);
	  			uiDriver.refresh();
	  			SleepUtils.sleep(TimeSlab.HIGH);
	  			uiDriver.refresh();
	  			SleepUtils.sleep(TimeSlab.HIGH);
	  			uiDriver.refresh();

	  			if (uiDriver.checkElementPresent("//span[text()='Processing: Waiting for NS ']")
	  					|| uiDriver.checkElementPresent("//span[text()='Processing ']") || uiDriver.checkElementPresent("//span[contains(text(), 'Send to NS')]" )|| uiDriver.checkElementPresent("//span[contains(text(), 'Processing')]") ){
	  				while (uiDriver.checkElementPresent("//span[text()='Processing: Waiting for NS ']")
	  						|| uiDriver.checkElementPresent("//span[text()='Processing ']") || uiDriver.checkElementPresent("//span[contains(text(), 'Send to NS')]" )|| uiDriver.checkElementPresent("//span[contains(text(), 'Processing')]")) {

	  					SleepUtils.sleep(TimeSlab.HIGH);
	  					uiDriver.refresh();
	  					SleepUtils.sleep(TimeSlab.HIGH);
	  					uiDriver.refresh();

	  				}
	  			} else if (uiDriver.checkElementPresent("//*[contains(text(),'Error')]")) {
	  				failed("Approve each statement", "Statement should reach NS ", "Statement went to error");
	  				break;

	  			}

	  		}			                  
	  	}

		

		
		
		
		/****************************************
		 * Name: NavigateToBillingSchedule_PULAK 
		 * Description: NavigateToBillingSchedule_PULAK
		 * Date: 19-June-2019
		 ****************************************/
		public void NavigateToBillingSchedule_PULAK(DataRow input, DataRow output) {
			
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//*[@id='ft-context-menu']//a[text()='Finance']");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//*[@id='ft-context-menu']/li[4]/ul/li[5]/a[text()='Billing']");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//a[contains(text(),'Billing Schedules')]");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			
			if(uiDriver.checkElementPresent("//span[contains(text(),'Billing Schedules')]")) {
				passed("Navigation to Billing Schedule Screen",
						"Billing Schedule Screen Should be displayed",
						"Billing Schedule Screen is displayed");
			} else {
				failed("Display of Billing Schedule Screen",
						"Billing Schedule Screen Should be displayed",
						"Billing Schedule Screen is not displayed");
			}
		}
		
		/****************************************
		 * Name: NavigateToAllocations_PULAK 
		 * Description: NavigateToAllocations_PULAK
		 * Date: 19-June-2019
		 ****************************************/
		public void NavigateToAllocations_PULAK(DataRow input, DataRow output) {
			
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//*[@id='ft-context-menu']//a[text()='Finance']");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//*[@id='ft-context-menu']/li[4]/ul/li[5]/a[text()='Billing']");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//a[contains(text(),'Allocations')]");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			
			if(uiDriver.checkElementPresent("//span[contains(text(),'Allocations')]")) {
				passed("Navigation to Allocations Screen",
						"Allocations Screen Should be displayed",
						"Allocations Screen is displayed");
			} else {
				failed("Display of Allocations Screen",
						"Allocations Screen Should be displayed",
						"Allocations Screen is not displayed");
			}
		}
		
		/****************************************
		 * Name: NavigateToBillingGroups_PULAK 
		 * Description: NavigateToBillingGroups_PULAK
		 * Date: 19-June-2019
		 ****************************************/
		public void NavigateToBillingGroups_PULAK(DataRow input, DataRow output) {
			
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//*[@id='ft-context-menu']//a[text()='Finance']");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//*[@id='ft-context-menu']/li[4]/ul/li[5]/a[text()='Billing']");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//a[contains(text(),'Billing Groups')]");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			
			if(uiDriver.checkElementPresent("//span[contains(text(),'Billing Groups')]")) {
				passed("Navigation to Billing Groups Screen",
						"Billing Groups Screen Should be displayed",
						"Billing Groups Screen is displayed");
			} else {
				failed("Display of Billing Groups Screen",
						"Billing Groups Screen Should be displayed",
						"Billing Groups Screen is not displayed");
			}
		}
		
		/****************************************
		 * Name: NavigateToInvoices_PULAK 
		 * Description: NavigateToInvoices_PULAK
		 * Date: 19-June-2019
		 ****************************************/
		public void NavigateToInvoices_PULAK(DataRow input, DataRow output) {
			
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//*[@id='ft-context-menu']//a[text()='Finance']");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//*[@id='ft-context-menu']/li[4]/ul/li[5]/a[text()='Billing']");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//*[@id='ft-context-menu']//a[text()='Finance']//..//a[contains(text(),'Invoices')]");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			
			if(uiDriver.checkElementPresent("//span[contains(text(),'Invoices')]")) {
				passed("Navigation to Invoices Screen",
						"Invoices Screen Should be displayed",
						"Invoices Screen is displayed");
			} else {
				failed("Display of Invoices Screen",
						"Invoices Screen Should be displayed",
						"Invoices Screen is not displayed");
			}
		}
		
		/****************************************
		 * Name: NavigateToByProjectDetails_PULAK 
		 * Description: NavigateToByProjectDetails_PULAK
		 * Date: 19-June-2019
		 ****************************************/
		public void NavigateToByProjectDetails(DataRow input, DataRow output) {
			
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//*[@id='ft-context-menu']//a[text()='Finance']");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//*[@id='ft-context-menu']/li[4]/ul/li[5]/a[text()='Billing']");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//a[contains(text(),'By Project Details')]");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			
			if(uiDriver.checkElementPresent("//span[contains(text(),'By Project Details')]")) {
				passed("Navigation to By Project Details Screen",
						"By Project Details Screen Should be displayed",
						"By Project Details Screen is displayed");
			} else {
				failed("Display of By Project Details Screen",
						"By Project Details Screen Should be displayed",
						"By Project Details Screen is not displayed");
			}
		}

		
		/****************************************
		 * Name: Makebillschedtentative 
		 * Description: Makebillschedtentative
		 * Date: 19-June-2019
		 ****************************************/
		public void Makebillschedtentative(DataRow input, DataRow output) {
			
			uiDriver.click("//button[text()='Next']");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("//button[text()='Next']");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("//button[text()='Next']");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			int j=50;
			int loc=1;
			List<WebElement> lst = uiDriver.webDr.findElements(By.xpath("//input[@name='IsUnbillable']"));
			for(int i=0;i<lst.size();i++)
			{
				lst.get(i).click();
				SleepUtils.sleep(3);
				loc=j*i;
				
				uiDriver.executeJavaScript("scroll(0,"+loc+")");
				
				passed("Make billing schedule tentative",
						"should  click on"+i+"th index",
						"clicked on"+i+"th index");
			}
			uiDriver.executeJavaScript("scroll(0,-1000)");
			SleepUtils.sleep(3);
			uiDriver.click("//a[@class='k-button k-button-icontext k-grid-save-changes']");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			passed("Make billing schedule tentative",
					" billing schedule should be tentative",
					"billing schedule should be tentativen");
		}
		
		
		/****************************************
		 * Name: ValidateBillingSchedule_PULAK 
		 * Description: ValidateBillingSchedule_PULAK
		 * Date: 20-June-2019
		 ****************************************/
		public void ValidateBillingSchedule_PULAK(DataRow input, DataRow output) {
			
			String Projects = input.get("Projects");
			String Project[] = Projects.split(";");
			
			for(int i=0; i<Project.length; i++) {				
				String xpath_Project = "//p[contains(text(),'"+Project[i].trim()+"')]";
				if(uiDriver.checkElementPresent(xpath_Project)) {
					passed("ValidateBillingSchedule_PULAK",
							Project[i].trim()+" project should be displayed in Billing Schedule screen",
							Project[i].trim()+"project is displayed in Billing Schedule screen");
				} else {
					failed("ValidateBillingSchedule_PULAK",
							Project[i].trim()+" project should be displayed in Billing Schedule screen",
							Project[i].trim()+"project is not displayed in Billing Schedule screen");
				}
			}
			
			String Amounts = input.get("Amounts");
			String Amount[] = Amounts.split(";");
			
			for(int i=0; i<Amount.length; i++) {				
				String xpath_Amount = "//div[text()='"+Amount[i].trim()+"']";
				if(uiDriver.checkElementPresent(xpath_Amount)) {
					passed("ValidateBillingSchedule_PULAK",
							Amount[i].trim()+" amount should be displayed in Billing Schedule screen",
							Amount[i].trim()+"amount is displayed in Billing Schedule screen");
				} else {
					failed("ValidateBillingSchedule_PULAK",
							Amount[i].trim()+" amount should be displayed in Billing Schedule screen",
							Amount[i].trim()+"amount is not displayed in Billing Schedule screen");
				}
			}
		}
		
		/****************************************
		 * Name: ValidateAllocations_PULAK 
		 * Description: ValidateAllocations_PULAK
		 * Date: 20-June-2019
		 ****************************************/
		public void ValidateAllocations_PULAK(DataRow input, DataRow output) {
			
			if(uiDriver.checkElementPresent("//button[@id='recalculate']")) {				
				uiDriver.click("//button[@id='recalculate']");
				SleepUtils.sleep(TimeSlab.HIGH);
			}
			
			String Projects = input.get("Projects");
			String Project[] = Projects.split(";");
			
			for(int i=0; i<Project.length; i++) {				
				String xpath_Project = "//td[contains(text(),'"+Project[i].trim()+"')]";
				if(uiDriver.checkElementPresent(xpath_Project)) {
					passed("ValidateAllocations_PULAK",
							Project[i].trim()+" project should be displayed in Allocations screen",
							Project[i].trim()+"project is displayed in Allocations screen");
				} else {
					failed("ValidateAllocations_PULAK",
							Project[i].trim()+" project should be displayed in Allocations screen",
							Project[i].trim()+"project is not displayed in Allocations screen");
				}
			}
			
			String Rights = input.get("Rights");
			String Right[] = Rights.split(";");
			
			for(int i=0; i<Right.length; i++) {				
				String xpath_Right = "//td[contains(text(),'"+Right[i].trim()+"')]";
				if(uiDriver.checkElementPresent(xpath_Right)) {
					passed("ValidateAllocations_PULAK",
							Right[i].trim()+" right should be displayed in Allocations screen",
							Right[i].trim()+"right is displayed in Allocations screen");
				} else {
					failed("ValidateAllocations_PULAK",
							Right[i].trim()+" right should be displayed in Allocations screen",
							Right[i].trim()+"right is not displayed in Allocations screen");
				}
			}
			
			String Amounts = input.get("Amounts");
			String Amount[] = Amounts.split(";");
			
			for(int i=0; i<Amount.length; i++) {				
				String xpath_Amount = "//div[text()='"+Amount[i].trim()+"']";
				if(uiDriver.checkElementPresent(xpath_Amount)) {
					passed("ValidateAllocations_PULAK",
							Amount[i].trim()+" amount should be displayed in Allocations screen",
							Amount[i].trim()+"amount is displayed in Allocations screen");
				} else {
					failed("ValidateAllocations_PULAK",
							Amount[i].trim()+" amount should be displayed in Allocations screen",
							Amount[i].trim()+"amount is not displayed in Allocations screen");
				}
			}
		}
		
		/****************************************
		 * Name: ValidateByProjectDetails_PULAK 
		 * Description: ValidateByProjectDetails_PULAK
		 * Date: 20-June-2019
		 ****************************************/
		public void ValidateByProjectDetails_PULAK(DataRow input, DataRow output) {
			
			if(uiDriver.checkElementPresent("//button[@id='recalculate']")) {				
				uiDriver.click("//button[@id='recalculate']");
				SleepUtils.sleep(TimeSlab.HIGH);
			}
			
			String Projects = input.get("Projects");
			String Project[] = Projects.split(";");
			
			String StartDates = input.get("StartDates");
			String StartDate[] = StartDates.split(";");
			
			String EndDates = input.get("EndDates");
			String EndDate[] = EndDates.split(";");
			
			String Amounts = input.get("Amounts");
			String Amount[] = Amounts.split(";");
			
			String InstallmentAmounts = input.get("InstallmentAmounts");
			String InstallmentAmount[] = InstallmentAmounts.split(";");
			
			for(int i=0; i<Project.length; i++) {				
				String xpath_Project = "//td[contains(text(),'"+Project[i].trim()+"')]";
				if(uiDriver.checkElementPresent(xpath_Project)) {
					passed("ValidateByProjectDetails_PULAK",
							Project[i].trim()+" project should be displayed in By Project Details screen",
							Project[i].trim()+"project is displayed in By Project Details screen");
					
					String actual_StartDate = uiDriver.getValue("//td[contains(text(),'"+Project[i].trim()+"')]//..//td[8]");
					String expected_StartDate = StartDate[i].trim();
					if(expected_StartDate.equalsIgnoreCase(actual_StartDate)) {
						passed("ValidateByProjectDetails_PULAK",
								StartDate[i].trim()+" start date should be displayed in By Project Details screen for project "+Project[i].trim(),
								StartDate[i].trim()+" start date is displayed in By Project Details screen for project "+Project[i].trim());
					} else {
						failed("ValidateByProjectDetails_PULAK",
								StartDate[i].trim()+" start date should be displayed in By Project Details screen for project "+Project[i].trim(),
								StartDate[i].trim()+" start date is not displayed in By Project Details screen for project "+Project[i].trim());
					}
					
					String actual_EndDate = uiDriver.getValue("//td[contains(text(),'"+Project[i].trim()+"')]//..//td[9]");
					String expected_EndDate = EndDate[i].trim();
					if(expected_EndDate.equalsIgnoreCase(actual_EndDate)) {
						passed("ValidateByProjectDetails_PULAK",
								EndDate[i].trim()+" end date should be displayed in By Project Details screen for project "+Project[i].trim(),
								EndDate[i].trim()+" end date is displayed in By Project Details screen for project "+Project[i].trim());
					} else {
						failed("ValidateByProjectDetails_PULAK",
								EndDate[i].trim()+" end date should be displayed in By Project Details screen for project "+Project[i].trim(),
								EndDate[i].trim()+" end date is not displayed in By Project Details screen for project "+Project[i].trim());
					}
					
					String actual_Amount = uiDriver.getValue("//td[contains(text(),'"+Project[i].trim()+"')]//..//td[11]");
					String expected_Amount = Amount[i].trim();
					if(expected_Amount.equalsIgnoreCase(actual_Amount)) {
						passed("ValidateByProjectDetails_PULAK",
								Amount[i].trim()+" amount should be displayed in By Project Details screen for project "+Project[i].trim(),
								Amount[i].trim()+" amount is displayed in By Project Details screen for project "+Project[i].trim());
					} else {
						failed("ValidateByProjectDetails_PULAK",
								Amount[i].trim()+" amount should be displayed in By Project Details screen for project "+Project[i].trim(),
								Amount[i].trim()+" amount is not displayed in By Project Details screen for project "+Project[i].trim());
					}
					
					uiDriver.click(xpath_Project);
					SleepUtils.sleep(TimeSlab.HIGH);
					if(uiDriver.checkElementPresent("//div[contains(text(),'Installments')]")) {
						if(uiDriver.checkElementPresent("//div[text()='"+InstallmentAmount[i].trim()+"']")) {
							passed("ValidateByProjectDetails_PULAK",
									InstallmentAmount[i].trim()+" installment amount should be displayed in By Project Details screen for project "+Project[i].trim(),
									InstallmentAmount[i].trim()+" installment amount is displayed in By Project Details screen for project "+Project[i].trim());
						} else {
							failed("ValidateByProjectDetails_PULAK",
									InstallmentAmount[i].trim()+" installment amount should be displayed in By Project Details screen for project "+Project[i].trim(),
									InstallmentAmount[i].trim()+" installment amount is not displayed in By Project Details screen for project "+Project[i].trim());
						}
					}
					
				} else {
					failed("ValidateByProjectDetails_PULAK",
							Project[i].trim()+" project should be displayed in ByProjectDetails screen",
							Project[i].trim()+"project is not displayed in ByProjectDetails screen");
				}
			}
		}
		
		/****************************************
		 * Name: EditBillingSchedule_PULAK
		 * Description: EditBillingSchedule_PULAK
		 * Date: 20-June-2019
		 ****************************************/		
		public void EditBillingSchedule_PULAK(DataRow input, DataRow output){
			
			Actions action1 = new Actions(uiDriver.webDr);
			
			uiDriver.click("//p[contains(text(),'"+input.get("BillingSchedule")+"')]//..//..//a[contains(text(),'Edit')]");
			SleepUtils.sleep(TimeSlab.HIGH);			
			if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Enter Schedule Item Information']")) {
				passed("Generate Billing Schedule",
						"Enter Schedule Item Information window should be displayed",
						"Enter Schedule Item Information window is displayed");
			} else {
				failed("Generate Billing Schedule",
						"Enter Schedule Item Information window should be displayed",
						"Enter Schedule Item Information window is not displayed");
			}
			
			if(input.get("Territories").trim().toLowerCase().equals("yes")) {			
				uiDriver.click("//*[@id='TerritoriesCheckbox']");
				SleepUtils.sleep(TimeSlab.YIELD);
			}	
			if(input.get("Languages").trim().toLowerCase().equals("yes")) {			
				uiDriver.click("//*[@id='LanguagesCheckbox']");
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			if(input.get("Rights").trim().toLowerCase().equals("yes")) {			
				uiDriver.click("//*[@id='RightsCheckbox']");
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			if(input.get("Channels").trim().toLowerCase().equals("yes")) {			
				uiDriver.click("//*[@id='ChannelsCheckbox']");
				SleepUtils.sleep(TimeSlab.YIELD);
			}			
			uiDriver.click("//*[@id='next']");
			SleepUtils.sleep(TimeSlab.LOW);
			if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Manually Add Schedule Items']")) {
				passed("Generate Billing Schedule",
						"Manually Add Schedule Items window should be displayed",
						"Manually Add Schedule Items window is displayed");
			} else {
				failed("Generate Billing Schedule",
						"Manually Add Schedule Items window should be displayed",
						"Manually Add Schedule Items window is not displayed");
			}
			
			uiDriver.click("//*[@id='next']");
			SleepUtils.sleep(TimeSlab.HIGH);
			while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Enter Projects Allocations']")) {
				passed("EditBillingSchedule_PULAK",
						"Enter Projects Allocations window should be displayed",
						"Enter Projects Allocations window is displayed");
			} else {
				failed("EditBillingSchedule_PULAK",
						"Enter Projects Allocations window should be displayed",
						"Enter Projects Allocations window is not displayed");
			}
			
			if(input.get("TitleName").equalsIgnoreCase("NA")) {			
			// DO NOTHING
			} else {
			uiDriver.click("//th[2]/a[@href='#']/span[@class='k-icon k-i-filter']");
			uiDriver.setValue("//*[@title='Value']",input.get("SubTitle"));
			uiDriver.click("//*[text()='Filter']");
			SleepUtils.sleep(TimeSlab.YIELD);
			SleepUtils.sleep(TimeSlab.YIELD);
			String titles = uiDriver.getDyanmicData("//*[@title='#']//preceding::input[@type='checkbox'][1]");
			String Actualtitle = titles.replace("#", input.get("TitleName"));
			uiDriver.click(Actualtitle);
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.executeJavaScript("scroll(0,0)");			
			WebElement ele = uiDriver.webDr.findElement(By
					.xpath("//*[@id='allocationWidget']/div/span/span/input[1]"));
			action1.click(ele);
			SleepUtils.sleep(TimeSlab.YIELD);
			action1.sendKeys(ele, "").build().perform();
			String TotalAmount = input.get("TotalAmount");
			action1.sendKeys(ele,TotalAmount).build().perform();
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//button[text()='Spread']");
			}
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//*[@id='next']");
			SleepUtils.sleep(TimeSlab.HIGH);
			while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Enter Territories Allocations']")) {
				passed("EditBillingSchedule_PULAK",
						"Enter Territories Allocations window should be displayed",
						"Enter Territories Allocations window is displayed");
			} else {
				failed("EditBillingSchedule_PULAK",
						"Enter Territories Allocations window should be displayed",
						"Enter Territories Allocations window is not displayed");
			}
			
			WebElement ele = uiDriver.webDr.findElement(By
					.xpath("//*[@id='allocationWidget']/div/span/span/input[1]"));			
			uiDriver.click("//div[@id='territoriesGrid']//input[@class='check-all']");
			SleepUtils.sleep(TimeSlab.LOW);
			action1.click(ele);
			SleepUtils.sleep(TimeSlab.YIELD);
			action1.sendKeys(ele, "").build().perform();
			action1.sendKeys(ele, "0.00").build().perform();
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//button[text()='Spread']");
			SleepUtils.sleep(TimeSlab.LOW);	
			String territory = input.get("TerritoryName");
			if(territory.equalsIgnoreCase("all")) {
				uiDriver.click("//div[@id='territoriesGrid']//input[@class='check-all']");
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.click("//div[@id='territoriesGrid']//input[@class='check-all']");
				SleepUtils.sleep(TimeSlab.YIELD);
			} else {				
				uiDriver.click("//*[@title='"+input.get("TerritoryName")+"']/preceding::input[1]");
			}
			action1.click(ele);
			SleepUtils.sleep(TimeSlab.YIELD);
			action1.sendKeys(ele, "").build().perform();
			action1.sendKeys(ele, input.get("TerrPercent")).build().perform();
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//button[text()='Spread']");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//*[@id='next']");
			SleepUtils.sleep(TimeSlab.HIGH);
			while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Enter Rights Allocations']")) {
				passed("EditBillingSchedule_PULAK",
						"Enter Rights Allocations window should be displayed",
						"Enter Rights Allocations window is displayed");
			} else {
				failed("EditBillingSchedule_PULAK",
						"Enter Rights Allocations window should be displayed",
						"Enter Rights Allocations window is not displayed");
			}
			
			uiDriver.click("//div[@id='rightsGrid']//input[@class='check-all']");
			SleepUtils.sleep(TimeSlab.LOW);
			action1.click(ele);
			SleepUtils.sleep(TimeSlab.YIELD);
			action1.sendKeys(ele, "").build().perform();
			action1.sendKeys(ele, "0.00").build().perform();
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//button[text()='Spread']");
			SleepUtils.sleep(TimeSlab.LOW);		
			String right = input.get("RightName");
			if(right.equalsIgnoreCase("all")) {
				uiDriver.click("//div[@id='rightsGrid']//input[@class='check-all']");
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.click("//div[@id='rightsGrid']//input[@class='check-all']");
				SleepUtils.sleep(TimeSlab.YIELD);
			} else {				
				uiDriver.click("//*[@title='"+input.get("RightName")+"']/preceding::input[1]");
			}
			SleepUtils.sleep(TimeSlab.LOW);
			action1.click(ele);
			SleepUtils.sleep(TimeSlab.YIELD);
			action1.sendKeys(ele, "").build().perform();
			action1.sendKeys(ele, input.get("RightPercent")).build().perform();
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//button[text()='Spread']");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//*[@id='finish']");
			if(uiDriver.checkElementPresent("//button[@id='overrideSave']")) {
				uiDriver.click("//button[@id='overrideSave']");
			}
			SleepUtils.sleep(TimeSlab.HIGH);
			while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			if(uiDriver.checkElementPresent("//a[contains(text(),'Recalculate All')]")) {
				passed("EditBillingSchedule_PULAK",
						"Billing schedule should generate",
						"Billing schedule is generated suscessfully");
			} else {
				passed("EditBillingSchedule_PULAK",
						"Billing schedule should generate",
						"Billing schedule is not generated suscessfully");
			}
			
		}
		
		/****************************************
		 * Name: EditAllocationRulesTerritory 
		 * Description: EditAllocationRulesTerritory Date:
		 * Date: 17-July-2019
		 ****************************************/
		public void EditAllocationRulesTerritory(DataRow input, DataRow output) {
			
		if(uiDriver.checkElementPresent("//td[contains(text(),'"+input.get("AllocationName")+"')]")) {
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("(//td[contains(text(),'"+input.get("AllocationName")+"')]//..//td//input[@type='image'])[1]");
			SleepUtils.sleep(TimeSlab.YIELD);
			
			if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Enter Allocation Rule Information']")) {
				passed("Edit Allocation Rules Territory",
						"Enter Allocation Rule Information window should be displayed",
						"Enter Allocation Rule Information window is displayed");
			} else {
				failed("Edit Allocation Rules Territory",
						"Enter Allocation Rule Information window should be displayed",
						"Enter Allocation Rule Information window is not displayed");
			}
			String Name = input.get("Name");
			uiDriver.setValue("//*[@id='AllocationRuleName']", Name);
			SleepUtils.sleep(TimeSlab.YIELD);
			//uiDriver.setValue("Note", input.get("Note"));
			uiDriver.click("//*[@id='AllocationRuleNote']");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//*[@id='step1Form']/div[3]/div[2]/span[1]/span/span[2]");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//li[contains(text(),'"+input.get("Invoice Item Category")+"')]");
			SleepUtils.sleep(TimeSlab.YIELD);
			//uiDriver.click("InvoiceItemCategoryInput");
			//SleepUtils.sleep(TimeSlab.YIELD);
			if(input.get("Territories").trim().toLowerCase().equals("yes")) {			
				uiDriver.click("//*[@id='TerritoriesCheckbox']");
				SleepUtils.sleep(TimeSlab.YIELD);
			}	
			if(input.get("Languages").trim().toLowerCase().equals("yes")) {			
				uiDriver.click("//*[@id='LanguagesCheckbox']");
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			if(input.get("Rights").trim().toLowerCase().equals("yes")) {			
				uiDriver.click("//*[@id='RightsCheckbox']");
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			if(input.get("Channels").trim().toLowerCase().equals("yes")) {			
				uiDriver.click("//*[@id='ChannelsCheckbox']");
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			uiDriver.click("//*[@id='next']");
			SleepUtils.sleep(TimeSlab.HIGH);
			while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Enter Territories Allocations']")) {
				passed("Edit Allocation Rules Territory",
						"Enter Territories Allocations window should be displayed",
						"Enter Territories Allocations window is displayed");
			} else {
				failed("Edit Allocation Rules Territory",
						"Enter Territories Allocations window should be displayed",
						"Enter Territories Allocations window is not displayed");
			}
			// uiDriver.executeJavaScript("document.getElementsByClassName('k-formatted-value k-input')[0].value=100;");
			Actions action1 = new Actions(uiDriver.webDr);
			WebElement ele = uiDriver.webDr.findElement(By
					.xpath("//*[@id='allocationWidget']/div/span/span/input[1]"));			
			uiDriver.click("//div[@id='territoriesGrid']//input[@class='check-all']");
			SleepUtils.sleep(TimeSlab.LOW);
			action1.click(ele);
			SleepUtils.sleep(TimeSlab.YIELD);
			action1.sendKeys(ele, "").build().perform();
			action1.sendKeys(ele, "0.00").build().perform();
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//button[text()='Spread']");
			SleepUtils.sleep(TimeSlab.LOW);	
			String territory = input.get("TerritoryName");
			if(territory.equalsIgnoreCase("all")) {
				uiDriver.click("//div[@id='territoriesGrid']//input[@class='check-all']");
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.click("//div[@id='territoriesGrid']//input[@class='check-all']");
				SleepUtils.sleep(TimeSlab.YIELD);
			} else {				
				uiDriver.click("//*[@title='"+input.get("TerritoryName")+"']/preceding::input[1]");
			}
			action1.click(ele);
			SleepUtils.sleep(TimeSlab.YIELD);
			action1.sendKeys(ele, "").build().perform();
			action1.sendKeys(ele, input.get("TerrPercent")).build().perform();
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//button[text()='Spread']");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//*[@id='next']");
			SleepUtils.sleep(TimeSlab.HIGH);
			while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			if(uiDriver.checkElementPresent("//div[@id='wizardHeaderText' and text()='Enter Rights Allocations']")) {
				passed("Edit Allocation Rules Territory",
						"Enter Rights Allocations window should be displayed",
						"Enter Rights Allocations window is displayed");
			} else {
				failed("Edit Allocation Rules Territory",
						"Enter Rights Allocations window should be displayed",
						"Enter Rights Allocations window is not displayed");
			}
			uiDriver.click("//div[@id='rightsGrid']//input[@class='check-all']");
			SleepUtils.sleep(TimeSlab.LOW);
			action1.click(ele);
			SleepUtils.sleep(TimeSlab.YIELD);
			action1.sendKeys(ele, "").build().perform();
			action1.sendKeys(ele, "0.00").build().perform();
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//button[text()='Spread']");
			SleepUtils.sleep(TimeSlab.LOW);		
			String right = input.get("RightName");
			if(right.equalsIgnoreCase("all")) {
				uiDriver.click("//div[@id='rightsGrid']//input[@class='check-all']");
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.click("//div[@id='rightsGrid']//input[@class='check-all']");
				SleepUtils.sleep(TimeSlab.YIELD);
			} else {				
				uiDriver.click("//*[@title='"+input.get("RightsName")+"']/preceding::input[1]");
			}
			SleepUtils.sleep(TimeSlab.LOW);
			action1.click(ele);
			SleepUtils.sleep(TimeSlab.YIELD);
			action1.sendKeys(ele, "").build().perform();
			action1.sendKeys(ele, input.get("RightPercent")).build().perform();
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//button[text()='Spread']");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//*[@id='finish']");
			SleepUtils.sleep(TimeSlab.HIGH);
			while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			if(uiDriver.checkElementPresent("//table[contains(@id,'AllocationRulesGrid')]//td[contains(text(),'"+input.get("Name")+"')]")) {
				passed("Edit Allocation Rules Territory",
						"Allocation should be edited successfully",
						"Allocation is edited successfully");
			} else {
				failed("Edit Allocation Rules Territory",
						"Allocation should be edited successfully",
						"Allocation is not edited successfully");
			}
			output.put("Name", Name);

		} else {
			failed("Edit Allocation Rules Territory",
					input.get("AllocationName")+"Allocation should be edited successfully",
					input.get("AllocationName")+"Allocation is not edited successfully");
		}
		}
		
		/****************************************
		 * Name: AddFMVFilmTrack 
		 * Description: AddFMVFilmTrack Date:
		 * Date: 01-August-2019
		 ****************************************/
		public void AddFMVFilmTrack(DataRow input, DataRow output) {
			
			
			for(int i=1; i<=5; i++) {				
				if(uiDriver.checkElementPresent("//span[text()='"+input.get("ProjectName")+"']")) {
					
					WebElement element = uiDriver.webDr.findElement(By.xpath("//span[text()='"+input.get("ProjectName")+"']//..//..//a[text()='Edit']"));
					((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView(true);", element);
					((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();",element);
//					uiDriver.click("//span[text()='"+input.get("ProjectName")+"']//..//..//a[text()='View']");
					SleepUtils.sleep(TimeSlab.LOW);
					
					uiDriver.click("//a[text()='Card-Info']");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("//a[text()='Card Other Data']");
					SleepUtils.sleep(TimeSlab.YIELD);
					
					uiDriver.click("//span[text()='License Card']");
					while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
						SleepUtils.sleep(TimeSlab.YIELD);
					}
					uiDriver.click("//a[text()=' Add']");
					while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
						SleepUtils.sleep(TimeSlab.YIELD);
					}
					
					uiDriver.setValue("//td[contains(text(),'Attribute')]//..//input", input.get("AttributeName"));
					while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
						SleepUtils.sleep(TimeSlab.YIELD);
					}
					uiDriver.setValue("//td[contains(text(),'Value')]//..//textarea", input.get("AttributeValue"));
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("//input[contains(@name,'SaveButton')]");
					SleepUtils.sleep(TimeSlab.HIGH);
					
					if(uiDriver.checkElementPresent("//span[contains(text(),'"+input.get("AttributeName")+"')]//..//..//span[contains(text(),'"+input.get("AttributeValue")+"')]")) {
						passed("AddFMVFilmTrack", "FMV Value should be updated", "FMV Value is updated successfully");
					} else {
						failed("AddFMVFilmTrack", "FMV Value should be updated", "FMV Value is not updated successfully");
					}
					
					break;
				} else {
					uiDriver.click("//input[@title='Next Page']");
					while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
						SleepUtils.sleep(TimeSlab.YIELD);
					}
				}
			}
		}
		
		public void ValidatethefieldsinFT(DataRow input, DataRow output) {

			String contractid = uiDriver
					.getValue("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_ContractCodeEdit']");

			String dealtype = uiDriver.getValue(
					"//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_ContractDealTypeEdit_Input']");

			String licensor = uiDriver
					.getValue("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_LicensorEdit_Input']");	
			
			String licensee = uiDriver
					.getValue("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_LicenseeEdit_Input']");

			String amount = uiDriver
					.getValue("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_GrossEdit']");

			String currency = uiDriver.getValue(
					"//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_CurrencyEdit_CurrencyEdit_Input']");

			String Rights = uiDriver.getValue(
					"//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentHeader_ContractSummaryHeader1_ContractGrantRightsValue']");

			String Titlestatus = uiDriver.getValue(
					"//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_ContractCardSummary1_ContractCardSummaryGrid_ctl00']//tr[1]/td[7]");

			if (contractid.toLowerCase().trim().contains(input.get("contract").toLowerCase().trim()) 
					|| input.get("contract").toLowerCase().trim().contains(contractid.toLowerCase().trim())) {
				passed("Verifying the  Contractid",
						"Contract id Status should be displayed as " + input.get("contract") + "'",
						"Contract id Status is displayed as " + contractid + "'");
			} else {
				failed("Verifying the  Contractid",
						"Contract id Status should be displayed as " + input.get("contract") + "'",
						"Contract id Status is not displayed as " + contractid + "'");
			}

			if (dealtype.toLowerCase().trim().contains(input.get("dealtype").toLowerCase().trim()) 
					|| input.get("dealtype").toLowerCase().trim().contains(dealtype.toLowerCase().trim())) {
				passed("Verifying the  dealtype",
						"dealtype should be displayed as " + input.get("dealtype") + "'",
						"dealtype is displayed as " + dealtype + "'");
			} else {
				failed("Verifying the  dealtype",
						"dealtype should be displayed as " + input.get("dealtype") + "'",
						"dealtype is displayed as " + dealtype + "'");
			}
			
			if (licensor.toLowerCase().trim().contains(input.get("licensor").toLowerCase().trim()) 
					|| input.get("licensor").toLowerCase().trim().contains(licensor.toLowerCase().trim())) {
				passed("Verifying the  licensee",
						"licensor should be displayed as " + input.get("licensor") + "'",
						"licensor is displayed as " + licensor + "'");
			} else {
				failed("Verifying the  licensee",
						"licensor should be displayed as " + input.get("licensor") + "'",
						"licensor is displayed as " + licensor + "'");
			}

			if (licensee.toLowerCase().trim().contains(input.get("licensee").toLowerCase().trim()) 
					|| input.get("licensee").toLowerCase().trim().contains(licensee.toLowerCase().trim())) {
				passed("Verifying the  licensee",
						"licensee should be displayed as " + input.get("licensee") + "'",
						"licensee is displayed as " + licensee + "'");
			} else {
				failed("Verifying the  licensee",
						"licensee should be displayed as " + input.get("licensee") + "'",
						"licensee is displayed as " + licensee + "'");
			}

			if (amount.toLowerCase().trim().contains(input.get("amount").toLowerCase().trim()) 
					|| input.get("amount").toLowerCase().trim().contains(amount.toLowerCase().trim())) {
				passed("Verifying the  amount",
						"amount should be displayed as " + input.get("amount") + "'",
						"amount is displayed as " + amount + "'");
			} else {
				failed("Verifying the  amount",
						"amount Status should be displayed as " + input.get("amount") + "'",
						"amount Status is displayed as " + amount + "'");
			}

			if (currency.toLowerCase().trim().contains(input.get("currency").toLowerCase().trim()) 
					|| input.get("currency").toLowerCase().trim().contains(currency.toLowerCase().trim())) {
				passed("Verifying the  currency",
						"currency should be displayed as " + input.get("currency") + "'",
						"currency is displayed as " + currency + "'");
			} else {
				failed("Verifying the  currency",
						"currency should be displayed as " + input.get("currency") + "'",
						"currency is displayed as " + currency + "'");
			}

			if (Rights.toLowerCase().trim().contains(input.get("Rights").toLowerCase().trim()) 
					|| input.get("Rights").toLowerCase().trim().contains(Rights.toLowerCase().trim())) {
				passed("Verifying the  Rights",
						"Rights should be displayed as " + input.get("Rights") + "'"
						,
						"Rights is displayed as " + Rights + "'");
			} else {
				failed("Verifying the  Rights",
						"Rights should be displayed as " + input.get("Rights") + "'",
						"Rights is displayed as " + Rights + "'");
			}

			/*if (Titlestatus.toLowerCase().trim().contains(input.get("Titlestatus").toLowerCase().trim()) 
					|| input.get("Titlestatus").toLowerCase().trim().contains(Titlestatus.toLowerCase().trim())) {
				passed("Verifying the  Titlestatus",
						"Titlestatus should be displayed as " + input.get("Titlestatus") + "'",
						"Titlestatus is displayed as " + Titlestatus + "'");
			} else {
				failed("Verifying the  Titlestatus",
						"Titlestatus should be displayed as " + input.get("Titlestatus") + "'",
						"Titlestatus is displayed as " + Titlestatus + "'");
			}*/
		}
		
		/****************************************
		 * Name: NavigateToInvoiceScreen Description:Method to Navigate To Invoice
		 * Screen Date:30-Nov-2017
		 ****************************************/
		public void NavigateToinvoiceDueDate(DataRow input, DataRow output) throws InterruptedException {

			SleepUtils.sleep(TimeSlab.MEDIUM);
			String Num = input.get("conf");
			uiDriver.setValue("SearchSO", Num);
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("SalesOrder");
			passed("SalesOrder", "SalesOrder Should be displayed Successfully", "SalesOrder is displayed Successfully");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			// uiDriver.refresh();
			// uiDriver.executeJavaScript("scroll(0,500)");
			uiDriver.click("relatedRecord");
			SleepUtils.sleep(TimeSlab.LOW);
			String amount = input.get("amount");
			List<WebElement> lst = uiDriver.webDr
					.findElements(By.xpath("//td[contains(text(),'" + amount + "')]//..//td[text()='Invoice']/..//td[3]"));
			for(int i=1;i<=lst.size();i++){
			uiDriver.click("(//td[contains(text(),'" + amount + "')]//..//td[text()='Invoice']/..//td[1]/a)["+i+"]");
			SleepUtils.sleep(TimeSlab.LOW);
			String date=uiDriver.getValue_Text("//*[text()='Due Date']/following::span[1]");
			if(date.equals(input.get("date"))){
				break;
			}else{
				uiDriver.back();
				SleepUtils.sleep(TimeSlab.MEDIUM);
				uiDriver.click("relatedRecord");
				SleepUtils.sleep(TimeSlab.LOW);
			}
			}
			String invoicenumber = uiDriver.getValue("Invoicenum");
			output.put("invoice1", invoicenumber);
					
		}


		
}
