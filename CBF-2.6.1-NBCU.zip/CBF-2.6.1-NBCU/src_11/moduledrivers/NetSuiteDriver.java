package moduledrivers;

import cbfx.basedrivers.BaseWebModuleDriver;
import static cbf.engine.TestResultLogger.*;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;

import org.apache.james.mime4j.field.datetime.DateTime;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.python.antlr.PythonParser.continue_stmt_return;

import cbf.engine.TestResult.ResultType;
import cbf.utils.DataRow;
import cbf.utils.SleepUtils;
import cbf.utils.SleepUtils.TimeSlab;
import cbfx.basedrivers.BaseWebModuleDriver;
import cbfx.objectmaps.ObjectMap;

public class NetSuiteDriver extends BaseWebModuleDriver  {
	
	/****************************************
	 * Name: createInvoiceAndAcceptPayment
	 * Description:Method to create Invoice and accept Payment and to navigate CashAdjacentcode
	 * Date:30-Nov-2017 
	 ****************************************/

	public void createInvoiceAndAcceptPayment(DataRow input, DataRow output) throws InterruptedException 
    {
			SleepUtils.sleep(3);
			String Num = input.get("conf");
			uiDriver.setValue("SearchSO",Num);
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("SalesOrder");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("Bill");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.executeJavaScript("scroll(0,400)");
					
			uiDriver.executeJavaScript("scroll(0,400)");
			SleepUtils.sleep(TimeSlab.LOW);
			SleepUtils.sleep(TimeSlab.LOW);
			
			if(input.get("ReduceAmount").equalsIgnoreCase("Y"))	{
				uiDriver.click("reduceqty");	
			SleepUtils.sleep(TimeSlab.LOW);		
			uiDriver.sendKey("backspace");
				SleepUtils.sleep(TimeSlab.LOW);
				 uiDriver.executeJavaScript("document.getElementById('quantity_formattedValue').value = ''");
				uiDriver.setValue("reduceqtyvalue", input.get("PartialTotalAmt"));
				SleepUtils.sleep(TimeSlab.MEDIUM);
				//uiDriver.executeJavaScript("document.getElementById('item_addedit').click();");
				uiDriver.click("OK");
				SleepUtils.sleep(TimeSlab.MEDIUM);
				uiDriver.handleAlert("", "OK");
				SleepUtils.sleep(TimeSlab.MEDIUM);
				uiDriver.handleAlert("", "OK");
			}
			
			if(input.get("ReduceAmountMultiple").equalsIgnoreCase("Y"))	{
				
			
				for(int i=1;i<=4;i++)
				{
				String QuantityLink = uiDriver.getDyanmicData("QuantityLink");
				String QuantLink = QuantityLink.replace("#", Integer.toString(i));
				uiDriver.click_dynamic(QuantLink);
						
			SleepUtils.sleep(TimeSlab.LOW);				
			uiDriver.sendKey("backspace");
				SleepUtils.sleep(TimeSlab.LOW);
				 uiDriver.executeJavaScript("document.getElementById('quantity_formattedValue').value = ''");
				 SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.setValue("reduceqtyvalue", input.get("invoiceamount"));
				SleepUtils.sleep(TimeSlab.MEDIUM);
				uiDriver.executeJavaScript("scroll(0,1000)");
				//uiDriver.executeJavaScript("document.getElementById('item_addedit').click();");
				uiDriver.click("OK");
				uiDriver.handleAlert("", "OK");
				SleepUtils.sleep(TimeSlab.MEDIUM);
				
				//SleepUtils.sleep(TimeSlab.MEDIUM);
				//uiDriver.handleAlert("", "OK");
			}
			}
			
			if(input.get("ChangeCurrencyType").equalsIgnoreCase("Y"))
			{
				if(uiDriver.checkElementPresent("Accounting")){
					uiDriver.executeJavaScript("scroll(0,500)");
					uiDriver.click("Accounting");
				}
				passed("Click On Accounting button",
						"Should click  on Accounting button",
						"Successfully clicked on Accounting button");				
				SleepUtils.sleep(TimeSlab.LOW);							
				uiDriver.handleAlert("", "OK");
				uiDriver.click("exchangeRate");
				SleepUtils.sleep(TimeSlab.MEDIUM);
				uiDriver.executeJavaScript("document.getElementById('exchangerate_formattedValue').value='"+input.get("exchangeRate")+"';");
				SleepUtils.sleep(TimeSlab.MEDIUM);
				passed("Select Exchange Rate",
						"Exchange Rate should be set successfully", 
						"Exchange Rate "+ input.get("exchangeRat") + " is set successfully");
				String exchangeRate = uiDriver.getValue("exchangeRate");
				uiDriver.handleAlert("", "OK");
 		 		SleepUtils.sleep(TimeSlab.LOW);
	                        output.put("exchangeRate", exchangeRate);
	           		}			
				uiDriver.click("saveBill");
				if(uiDriver.checkElementPresent("DuplicateInvoice")){
					uiDriver.click("SaveDuplicateInvoice");
				}
				
				//uiDriver.executeJavaScript("document.getElementById('btn_secondarymultibutton_submitter').click();");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.handleAlert("", "OK");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.handleAlert("", "OK");
				String invoicenum = uiDriver.getValue("invoicenum");
				output.put("invoicenumber", invoicenum);
				}	
			
   
        public void NavigateTopaidfullinvoice(DataRow input, DataRow output) throws InterruptedException 
    {
    	SleepUtils.sleep(TimeSlab.MEDIUM);
    	String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");
		SleepUtils.sleep(5);
		uiDriver.refresh();
		uiDriver.executeJavaScript("scroll(0,200)");
		uiDriver.click("relatedRecord");
		SleepUtils.sleep(5);
		uiDriver.click("paidinfullinvoice");
		passed("InvoiceNo", "InvoiceNo Should be Clicked Successfully",
				"InvoiceNo is Clicked Successfully");
		String invoicenumber=uiDriver.getValue("Invoicenum");
		output.put("InvoiceNum", invoicenumber);
		String Masterinvoice = invoicenumber.substring(0, invoicenumber.length()-1);
		output.put("MasterInvoice", Masterinvoice);
    }
        
        /****************************************
    	 * Name:NavigateToJE 
    	 * Description: NavigateToJE
    	 * Date: 14-aug-2019
    	 
    	 ****************************************/
        
        public void NavigateToJE(DataRow input, DataRow output){
        	SleepUtils.sleep(TimeSlab.LOW);
        	// To click on Specific journal pass jeName in data sheet
             uiDriver.click("//a[contains(text(),'lated Transactions') or (text()='lated Transactions')] ");  
             String JeXpath = uiDriver.getDyanmicData("JeXpath");
             String ActualJe = JeXpath.replace("#",input.get("JeName"));
             SleepUtils.sleep(TimeSlab.LOW);
             uiDriver.click_dynamic(ActualJe);
             SleepUtils.sleep(TimeSlab.LOW);
             uiDriver.executeJavaScript("scroll(0,500)");
        
        }
        
        /****************************************
    	 * Name: ValidateAllInvoiceData Description: ValidateAllInvoiceData Date:
    	 * 14-Aug-2019
    	 ****************************************/
    	public void ValidateAllInvoiceData(DataRow input, DataRow output) throws InterruptedException {
    	 try {
    	  SleepUtils.sleep(TimeSlab.LOW);
    	  uiDriver.setValue("//input[@id='_searchstring']", input.get("conf"));
    	  SleepUtils.sleep(TimeSlab.LOW);
    	  uiDriver.click("//a[contains(text(),'Sales Order:')]");
    	  SleepUtils.sleep(TimeSlab.LOW);
    	  if (uiDriver.checkElementPresent("//h1[text()='Sales Order']")) {
    	   passed("ValidateAllInvoiceData", "Sales Order Should be displayed", "Sales Order is displayed");
    	  } else {
    	   failed("ValidateAllInvoiceData", "Sales Order Should be displayed", "Sales Order is not displayed");
    	  }
    	  uiDriver.click("//a[@id='rlrcdstabtxt']");
    	  SleepUtils.sleep(TimeSlab.LOW);

    	  String TotalAmounts = input.get("TotalAmount");
    	  String TotalAmount[] = TotalAmounts.split(";");

    	  String Items = input.get("Item");
    	  String Item[] = Items.split(";");

    	  String Quantities = input.get("Quantity");
    	  String Quantity[] = Quantities.split(";");

    	  String Rates = input.get("Rate");
    	  String Rate[] = Rates.split(";");

    	  String Amounts = input.get("Amount");
    	  String Amount[] = Amounts.split(";");

    	  String TaxCodes = input.get("Tax Code");
    	  String TaxCode[] = TaxCodes.split(";");

    	  String MarketCodes = input.get("Market Code");
    	  String MarketCode[] = MarketCodes.split(";");

    	  String Territories = input.get("Territory");
    	  String Territory[] = Territories.split(";");

    	  String TitleIDs = input.get("Title ID");
    	  String TitleID[] = TitleIDs.split(";");

    	  String GLPNs = input.get("GLPN");
    	  String GLPN[] = GLPNs.split(";");

    	  String ProductOwners = input.get("Product Owner");
    	  String ProductOwner[] = ProductOwners.split(";");

    	  //String Rights = input.get("Right");
    	  //String Right[] = Rights.split(";");

    	//  String UnbilledRevenueAccounts = input.get("Unbilled Revenue Account");
    	//  String UnbilledRevenueAccount[] = UnbilledRevenueAccounts.split(";");

    	  String BilledRevenueAccounts = input.get("Billed Revenue Account");
    	  String BilledRevenueAccount[] = BilledRevenueAccounts.split(";");

    	  String BilledARAccounts = input.get("Billed AR Account");
    	  String BilledARAccount[] = BilledARAccounts.split(";");

    	  String UnbilledARAccounts = input.get("Unbilled AR Account");
    	  String UnbilledARAccount[] = UnbilledARAccounts.split(";");

    	  String PaidDeferredRevenueAccounts = input.get("Paid Deferred Revenue Account");
    	  String PaidDeferredRevenueAccount[] = PaidDeferredRevenueAccounts.split(";");

    	  String UnpaidDeferredRevenueAccounts = input.get("Unpaid Deferred Revenue Account");
    	  String UnpaidDeferredRevenueAccount[] = UnpaidDeferredRevenueAccounts.split(";");

    	  String BadDebtRevenueAccounts = input.get("Bad Debt Revenue Account");
    	  String BadDebtRevenueAccount[] = BadDebtRevenueAccounts.split(";");

    	  List<WebElement> Invoices = uiDriver.webDr.findElements(By.xpath("//td[text()='Invoice']//..//a"));
    	  int total_Invoices = Invoices.size();

    	  int k = 0, flag = 0;
    	  for (int i = 0; i < total_Invoices; i++) {
    		  
    		  uiDriver.executeJavaScript("scroll(0,500)");
    		  SleepUtils.sleep(TimeSlab.LOW);
    	   uiDriver.click("//a[@id='rlrcdstabtxt']");
    	   SleepUtils.sleep(TimeSlab.LOW);

    	   String xpath_Invoice = "//td[text()='Invoice']//..//td[text()='" + TotalAmount[i].trim() + "']//..//a";
    	   // uiDriver.click(xpath_Invoice);
    	   List<WebElement> element = uiDriver.webDr.findElements(By.xpath(xpath_Invoice));
    	   if (element.size() > 1) {
    	    ((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView(true);",
    	      element.get(flag));
    	    ((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();", element.get(flag));
    	    flag++;
    	   } else {
    	    ((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView(true);",
    	      element.get(0));
    	    ((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();", element.get(0));
    	   }
    	   SleepUtils.sleep(TimeSlab.LOW);
    	   if (uiDriver.checkElementPresent("//h1[text()='Invoice']")) {
    	    passed("ValidateAllInvoiceData", "Invoice Should be displayed", "Invoice is displayed");
    	   } else {
    	    failed("ValidateAllInvoiceData", "Invoice Should be displayed", "Invoice is not displayed");
    	   }

    	   String actual_Customer = uiDriver
    	     .getValue("//span[@id='entity_fs_lbl_uir_label']//following-sibling::span//a");
    	   String actual_DueDate = uiDriver
    	     .getValue("//span[@id='duedate_fs_lbl_uir_label']//following-sibling::span");
    	   String actual_ApprovalStatus = uiDriver
    	     .getValue("//span[@id='approvalstatus_fs_lbl_uir_label']//following-sibling::span//span");
    	   String actual_Status = uiDriver.getValue("//div[@class='uir-record-status']");
    	   String actual_Subsidiary = uiDriver
    	     .getValue("//span[@id='subsidiary_lbl_uir_label']//following-sibling::span//span");
    	   String actual_RevisionNumber = uiDriver.getValue(
    	     "//span[@id='custbody_nbcu_revision_number_fs_lbl_uir_label']//following-sibling::span");
    	   String actual_InvoiceType = uiDriver.getValue(
    	     "//span[@id='custbody_nbcu_inv_type_fs_lbl_uir_label']//following-sibling::span//span");

    	   /*String Customer = input.get("Customer");
    	   String[] expected_Customer = Customer.split(";");
    	   String DueDate = input.get("DueDate");
    	   String[] expected_DueDate = DueDate.split(";");
    	   String ApprovalStatus = input.get("ApprovalStatus");
    	   String[] expected_ApprovalStatus = ApprovalStatus.split(";");
    	   String Status = input.get("Status");
    	   String[] expected_Status = Status.split(";");
    	   String Subsidiary = input.get("Subsidiary");
    	   String[] expected_Subsidiary = Subsidiary.split(";");
    	   String RevisionNumber = input.get("RevisionNumber");
    	   String[] expected_RevisionNumber = RevisionNumber.split(";");
    	   String InvoiceType = input.get("InvoiceType");
    	   String[] expected_InvoiceType = InvoiceType.split(";");*/

    /*	   if (actual_Customer.toLowerCase().trim().contains(expected_Customer[i].toLowerCase().trim())
    	     || expected_Customer[i].toLowerCase().trim().contains(actual_Customer.toLowerCase().trim())) {
    	    passed("Verify Invoice Details", "Customer should be displayed as : " + expected_Customer[i].trim(),
    	      "Customer is displayed as : " + actual_Customer.trim());
    	   } else {
    	    failed("Verify Invoice Details", "Customer should be displayed as : " + expected_Customer[i].trim(),
    	      "Customer is displayed as : " + actual_Customer.trim());
    	   }

    	   if (actual_DueDate.toLowerCase().trim().contains(expected_DueDate[i].toLowerCase().trim())
    	     || expected_DueDate[i].toLowerCase().trim().contains(actual_DueDate.toLowerCase().trim())) {
    	    passed("Verify Invoice Details", "DueDate should be displayed as : " + expected_DueDate[i].trim(),
    	      "DueDate is displayed as : " + actual_DueDate.trim());
    	   } else {
    	    failed("Verify Invoice Details", "DueDate should be displayed as : " + expected_DueDate[i].trim(),
    	      "DueDate is displayed as : " + actual_DueDate.trim());
    	   }

    	   if (actual_ApprovalStatus.toLowerCase().trim().contains(expected_ApprovalStatus[i].toLowerCase().trim())
    	     || expected_ApprovalStatus[i].toLowerCase().trim()
    	       .contains(actual_ApprovalStatus.toLowerCase().trim())) {
    	    passed("Verify Invoice Details",
    	      "ApprovalStatus should be displayed as : " + expected_ApprovalStatus[i].trim(),
    	      "ApprovalStatus is displayed as : " + actual_ApprovalStatus.trim());
    	   } else {
    	    failed("Verify Invoice Details",
    	      "ApprovalStatus should be displayed as : " + expected_ApprovalStatus[i].trim(),
    	      "ApprovalStatus is displayed as : " + actual_ApprovalStatus.trim());
    	   }

    	   if (actual_Status.toLowerCase().trim().contains(expected_Status[i].toLowerCase().trim())
    	     || expected_Status[i].toLowerCase().trim().contains(actual_Status.toLowerCase().trim())) {
    	    passed("Verify Invoice Details", "Status should be displayed as : " + expected_Status[i].trim(),
    	      "Status is displayed as : " + actual_Status.trim());
    	   } else {
    	    failed("Verify Invoice Details", "Status should be displayed as : " + expected_Status[i].trim(),
    	      "Status is displayed as : " + actual_Status.trim());
    	   }

    	   if (actual_Subsidiary.toLowerCase().trim().contains(expected_Subsidiary[i].toLowerCase().trim())
    	     || expected_Subsidiary[i].toLowerCase().trim()
    	       .contains(actual_Subsidiary.toLowerCase().trim())) {
    	    passed("Verify Invoice Details",
    	      "Subsidiary should be displayed as : " + expected_Subsidiary[i].trim(),
    	      "Subsidiary is displayed as : " + actual_Subsidiary.trim());
    	   } else {
    	    failed("Verify Invoice Details",
    	      "Subsidiary should be displayed as : " + expected_Subsidiary[i].trim(),
    	      "Subsidiary is displayed as : " + actual_Subsidiary.trim());
    	   }

    	   if (actual_RevisionNumber.toLowerCase().trim().contains(expected_RevisionNumber[i].toLowerCase().trim())
    	     || expected_RevisionNumber[i].toLowerCase().trim()
    	       .contains(actual_RevisionNumber.toLowerCase().trim())) {
    	    passed("Verify Invoice Details",
    	      "RevisionNumber should be displayed as : " + expected_RevisionNumber[i].trim(),
    	      "RevisionNumber is displayed as : " + actual_RevisionNumber.trim());
    	   } else {
    	    failed("Verify Invoice Details",
    	      "RevisionNumber should be displayed as : " + expected_RevisionNumber[i].trim(),
    	      "RevisionNumber is displayed as : " + actual_RevisionNumber.trim());
    	   }

    	   if (actual_InvoiceType.toLowerCase().trim().contains(expected_InvoiceType[i].toLowerCase().trim())
    	     || expected_InvoiceType[i].toLowerCase().trim()
    	       .contains(actual_InvoiceType.toLowerCase().trim())) {
    	    passed("Verify Invoice Details",
    	      "InvoiceType should be displayed as : " + expected_InvoiceType[i].trim(),
    	      "InvoiceType is displayed as : " + actual_InvoiceType.trim());
    	   } else {
    	    failed("Verify Invoice Details",
    	      "InvoiceType should be displayed as : " + expected_InvoiceType[i].trim(),
    	      "InvoiceType is displayed as : " + actual_InvoiceType.trim());
    	   }
    */
    	   uiDriver.executeJavaScript("scroll(0,500)");

    	   List<WebElement> LineItems = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tr"));
    	   int total_LineItems = LineItems.size();
    			   int temp = 0;

    	   for (int j = 2; j <= total_LineItems; j++) {
    	    List<WebElement> el;
    	    String xpath = "//table[@id='item_splits']//td[contains(text(),'" + GLPN[k].trim() + "')]";

    	    if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
    	      + GLPN[k].trim()
    	      + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title']//..//preceding-sibling::*)+1]")) {
    	     String actual_Item;
    	     el = uiDriver.webDr.findElements(
    	       By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
    	         + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title']//..//preceding-sibling::*)+1]"));
    	     try {
    	      actual_Item = el.get(temp).getText();
    	     } catch (Exception e) {
    	      temp = 0;
    	      actual_Item = el.get(0).getText();
    	     }

    	     String expected_Item = Item[k].trim();
    	     expected_Item = expected_Item.replace("Null", " ");

    	     if (expected_Item.contains(actual_Item) || actual_Item.contains(expected_Item)) {
    	      passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "Item Should be displayed as " + expected_Item,
    	        "Item is displayed as " + actual_Item);
    	     } else {
    	      failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "Item Should be displayed as " + expected_Item,
    	        "Item is not displayed as " + actual_Item);
    	     }
    	    }

    	    if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
    	      + GLPN[k].trim()
    	      + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Quantity']//..//preceding-sibling::*)+1]")) {
    	     String actual_Quantity;
    	     float actual_Quantity_temp;
    	     el = uiDriver.webDr.findElements(
    	       By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
    	         + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Quantity']//..//preceding-sibling::*)+1]"));
    	     try {
    	      actual_Quantity = el.get(temp).getText();
    	      actual_Quantity = actual_Quantity.replace(",", "");
    	      actual_Quantity_temp = Float.parseFloat(actual_Quantity);
    	     } catch (Exception e) {
    	      temp = 0;
    	      actual_Quantity = el.get(0).getText();
    	      actual_Quantity = actual_Quantity.replace(",", "");
    	      actual_Quantity_temp = Float.parseFloat(actual_Quantity);
    	     }

    	     String expected_Quantity = Quantity[k].trim();
    	     expected_Quantity = expected_Quantity.replace("Null", " ");
    	     expected_Quantity = expected_Quantity.replace(",", "");
    	     Float expected_Quantity_temp = Float.parseFloat(actual_Quantity);

    	     if (expected_Quantity_temp == actual_Quantity_temp) {
    	      passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "Quantity Should be displayed as " + expected_Quantity,
    	        "Quantity is displayed as " + actual_Quantity);
    	     } else {
    	      failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "Quantity Should be displayed as " + expected_Quantity,
    	        "Quantity is not displayed as " + actual_Quantity);
    	     }
    	    }

    	    if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
    	      + GLPN[k].trim()
    	      + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Rate']//..//preceding-sibling::*)+1]")) {
    	     String actual_Rate;
    	     float actual_Rate_temp;
    	     el = uiDriver.webDr.findElements(
    	       By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
    	         + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Rate']//..//preceding-sibling::*)+1]"));
    	     try {
    	      actual_Rate = el.get(temp).getText();
    	      actual_Rate = actual_Rate.replace(",", "");
    	      actual_Rate_temp = Float.parseFloat(actual_Rate);
    	     } catch (Exception e) {
    	      temp = 0;
    	      actual_Rate = el.get(0).getText();
    	      actual_Rate = actual_Rate.replace(",", "");
    	      actual_Rate_temp = Float.parseFloat(actual_Rate);
    	     }

    	     String expected_Rate = Rate[k].trim();
    	     expected_Rate = expected_Rate.replace("Null", " ");
    	     expected_Rate = expected_Rate.replace(",", "");
    	     Float expected_Rate_temp = Float.parseFloat(actual_Rate);

    	     if (expected_Rate_temp == actual_Rate_temp) {
    	      passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "Rate Should be displayed as " + expected_Rate,
    	        "Rate is displayed as " + actual_Rate);
    	     } else {
    	      failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "Rate Should be displayed as " + expected_Rate,
    	        "Rate is not displayed as " + actual_Rate);
    	     }
    	    }

    	    if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
    	      + GLPN[k].trim()
    	      + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Amount']//..//preceding-sibling::*)+1]")) {
    	     String actual_Amount;
    	     float actual_Amount_temp;
    	     el = uiDriver.webDr.findElements(
    	       By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
    	         + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Amount']//..//preceding-sibling::*)+1]"));
    	     try {
    	      actual_Amount = el.get(temp).getText();
    	      actual_Amount = actual_Amount.replace(",", "");
    	      actual_Amount_temp = Float.parseFloat(actual_Amount);
    	     } catch (Exception e) {
    	      temp = 0;
    	      actual_Amount = el.get(0).getText();
    	      actual_Amount = actual_Amount.replace(",", "");
    	      actual_Amount_temp = Float.parseFloat(actual_Amount);
    	     }

    	     String expected_Amount = Amount[k].trim();
    	     expected_Amount = expected_Amount.replace("Null", " ");
    	     expected_Amount = expected_Amount.replace(",", "");
    	     Float expected_Amount_temp = Float.parseFloat(actual_Amount);

    	     if (expected_Amount_temp == actual_Amount_temp) {
    	      passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "Amount Should be displayed as " + expected_Amount,
    	        "Amount is displayed as " + actual_Amount);
    	     } else {
    	      failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "Amount Should be displayed as " + expected_Amount,
    	        "Amount is not displayed as " + actual_Amount);
    	     }
    	    }

    	    if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
    	      + GLPN[k].trim()
    	      + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Tax Code']//..//preceding-sibling::*)+1]")) {
    	     String actual_TaxCode;
    	     el = uiDriver.webDr.findElements(
    	       By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
    	         + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Tax Code']//..//preceding-sibling::*)+1]"));
    	     try {
    	      actual_TaxCode = el.get(temp).getText();
    	     } catch (Exception e) {
    	      temp = 0;
    	      actual_TaxCode = el.get(0).getText();
    	     }

    	     String expected_TaxCode = TaxCode[k].trim();
    	     expected_TaxCode = expected_TaxCode.replace("Null", " ");

    	     if (expected_TaxCode.contains(actual_TaxCode) || actual_TaxCode.contains(expected_TaxCode)) {
    	      passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "TaxCode Should be displayed as " + expected_TaxCode,
    	        "TaxCode is displayed as " + actual_TaxCode);
    	     } else {
    	      failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "TaxCode Should be displayed as " + expected_TaxCode,
    	        "TaxCode is not displayed as " + actual_TaxCode);
    	     }
    	    }

    	    if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
    	      + GLPN[k].trim()
    	      + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Market Code']//..//preceding-sibling::*)+1]")) {
    	     String actual_MarketCode;
    	     el = uiDriver.webDr.findElements(
    	       By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
    	         + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Market Code']//..//preceding-sibling::*)+1]"));
    	     try {
    	      actual_MarketCode = el.get(temp).getText();
    	     } catch (Exception e) {
    	      temp = 0;
    	      actual_MarketCode = el.get(0).getText();
    	     }

    	     String expected_MarketCode = MarketCode[k].trim();
    	     expected_MarketCode = expected_MarketCode.replace("Null", " ");

    	     if (expected_MarketCode.contains(actual_MarketCode)
    	       || actual_MarketCode.contains(expected_MarketCode)) {
    	      passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "MarketCode Should be displayed as " + expected_MarketCode,
    	        "MarketCode is displayed as " + actual_MarketCode);
    	     } else {
    	      failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "MarketCode Should be displayed as " + expected_MarketCode,
    	        "MarketCode is not displayed as " + actual_MarketCode);
    	     }
    	    }

    	    if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
    	      + GLPN[k].trim()
    	      + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title ID']//..//preceding-sibling::*)+1]")) {
    	     String actual_TitleID;
    	     el = uiDriver.webDr.findElements(
    	       By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
    	         + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title ID']//..//preceding-sibling::*)+1]"));
    	     try {
    	      actual_TitleID = el.get(temp).getText();
    	     } catch (Exception e) {
    	      temp = 0;
    	      actual_TitleID = el.get(0).getText();
    	     }

    	     String expected_TitleID = TitleID[k].trim();
    	     expected_TitleID = expected_TitleID.replace("Null", " ");

    	     if (expected_TitleID.contains(actual_TitleID) || actual_TitleID.contains(expected_TitleID)) {
    	      passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "TitleID Should be displayed as " + expected_TitleID,
    	        "TitleID is displayed as " + actual_TitleID);
    	     } else {
    	      failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "TitleID Should be displayed as " + expected_TitleID,
    	        "TitleID is not displayed as " + actual_TitleID);
    	     }
    	    }

    	    if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
    	      + GLPN[k].trim()
    	      + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]")) {
    	     String actual_GLPN;
    	     el = uiDriver.webDr.findElements(
    	       By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
    	         + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]"));
    	     try {
    	      actual_GLPN = el.get(temp).getText();
    	     } catch (Exception e) {
    	      temp = 0;
    	      actual_GLPN = el.get(0).getText();
    	     }

    	     String expected_GLPN = GLPN[k].trim();
    	     expected_GLPN = expected_GLPN.replace("Null", " ");

    	     if (expected_GLPN.contains(actual_GLPN) || actual_GLPN.contains(expected_GLPN)) {
    	      passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "GLPN Should be displayed as " + expected_GLPN,
    	        "GLPN is displayed as " + actual_GLPN);
    	     } else {
    	      failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "GLPN Should be displayed as " + expected_GLPN,
    	        "GLPN is not displayed as " + actual_GLPN);
    	     }
    	    }

    	    if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
    	      + GLPN[k].trim()
    	      + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Owner']//..//preceding-sibling::*)+1]")) {
    	     String actual_ProductOwner;
    	     el = uiDriver.webDr.findElements(
    	       By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
    	         + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Owner']//..//preceding-sibling::*)+1]"));
    	     try {
    	      actual_ProductOwner = el.get(temp).getText();
    	     } catch (Exception e) {
    	      temp = 0;
    	      actual_ProductOwner = el.get(0).getText();
    	     }

    	     String expected_ProductOwner = ProductOwner[k].trim();
    	     expected_ProductOwner = expected_ProductOwner.replace("Null", " ");

    	     if (expected_ProductOwner.contains(actual_ProductOwner)
    	       || actual_ProductOwner.contains(expected_ProductOwner)) {
    	      passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "ProductOwner Should be displayed as " + expected_ProductOwner,
    	        "ProductOwner is displayed as " + actual_ProductOwner);
    	     } else {
    	      failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "ProductOwner Should be displayed as " + expected_ProductOwner,
    	        "ProductOwner is not displayed as " + actual_ProductOwner);
    	     }
    	    }

    	   /* if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
    	      + GLPN[k].trim()
    	      + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Right']//..//preceding-sibling::*)+1]")) {
    	     String actual_Right;
    	     el = uiDriver.webDr.findElements(
    	       By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
    	         + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Right']//..//preceding-sibling::*)+1]"));
    	     try {
    	      actual_Right = el.get(temp).getText();
    	     } catch (Exception e) {
    	      temp = 0;
    	      actual_Right = el.get(0).getText();
    	     }

    	     String expected_Right = Right[k].trim();
    	     expected_Right = expected_Right.replace("Null", " ");

    	     if (expected_Right.contains(actual_Right) || actual_Right.contains(expected_Right)) {
    	      passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "Right Should be displayed as " + expected_Right,
    	        "Right is displayed as " + actual_Right);
    	     } else {
    	      failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "Right Should be displayed as " + expected_Right,
    	        "Right is displayed as " + actual_Right);
    	     }
    	    }*/

    	  /*  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
    	      + GLPN[k].trim()
    	      + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled Revenue Account']//..//preceding-sibling::*)+1]")) {
    	     String actual_UnbilledRevenueAccount;
    	     el = uiDriver.webDr.findElements(
    	       By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
    	         + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled Revenue Account']//..//preceding-sibling::*)+1]"));
    	     try {
    	      actual_UnbilledRevenueAccount = el.get(temp).getText();
    	     } catch (Exception e) {
    	      temp = 0;
    	      actual_UnbilledRevenueAccount = el.get(0).getText();
    	     }

    	     String expected_UnbilledRevenueAccount = UnbilledRevenueAccount[k].trim();
    	     expected_UnbilledRevenueAccount = expected_UnbilledRevenueAccount.replace("Null", " ");

    	     if (expected_UnbilledRevenueAccount.contains(actual_UnbilledRevenueAccount)
    	       || actual_UnbilledRevenueAccount.contains(expected_UnbilledRevenueAccount)) {
    	      passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "UnbilledRevenueAccount Should be displayed as " + expected_UnbilledRevenueAccount,
    	        "UnbilledRevenueAccount is displayed as " + actual_UnbilledRevenueAccount);
    	     } else {
    	      failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "UnbilledRevenueAccount Should be displayed as " + expected_UnbilledRevenueAccount,
    	        "UnbilledRevenueAccount is displayed as " + actual_UnbilledRevenueAccount);
    	     }
    	    }*/

    	    if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
    	      + GLPN[k].trim()
    	      + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed Revenue Account']//..//preceding-sibling::*)+1]")) {
    	     String actual_BilledRevenueAccount;
    	     el = uiDriver.webDr.findElements(
    	       By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
    	         + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed Revenue Account']//..//preceding-sibling::*)+1]"));
    	     try {
    	      actual_BilledRevenueAccount = el.get(temp).getText();
    	     } catch (Exception e) {
    	      temp = 0;
    	      actual_BilledRevenueAccount = el.get(0).getText();
    	     }

    	     String expected_BilledRevenueAccount = BilledRevenueAccount[k].trim();
    	     expected_BilledRevenueAccount = expected_BilledRevenueAccount.replace("Null", " ");

    	     if (expected_BilledRevenueAccount.contains(actual_BilledRevenueAccount)
    	       || actual_BilledRevenueAccount.contains(expected_BilledRevenueAccount)) {
    	      passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "BilledRevenueAccount Should be displayed as " + expected_BilledRevenueAccount,
    	        "BilledRevenueAccount is displayed as " + actual_BilledRevenueAccount);
    	     } else {
    	      failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "BilledRevenueAccount Should be displayed as " + expected_BilledRevenueAccount,
    	        "BilledRevenueAccount is not displayed as " + actual_BilledRevenueAccount);
    	     }
    	    }

    	    if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
    	      + GLPN[k].trim()
    	      + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed AR Account']//..//preceding-sibling::*)+1]")) {
    	     String actual_BilledARAccount;
    	     el = uiDriver.webDr.findElements(
    	       By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
    	         + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed AR Account']//..//preceding-sibling::*)+1]"));
    	     try {
    	      actual_BilledARAccount = el.get(temp).getText();
    	     } catch (Exception e) {
    	      temp = 0;
    	      actual_BilledARAccount = el.get(0).getText();
    	     }

    	     String expected_BilledARAccount = BilledARAccount[k].trim();
    	     expected_BilledARAccount = expected_BilledARAccount.replace("Null", " ");

    	     if (expected_BilledARAccount.contains(actual_BilledARAccount)
    	       || actual_BilledARAccount.contains(expected_BilledARAccount)) {
    	      passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "BilledARAccount Should be displayed as " + expected_BilledARAccount,
    	        "BilledARAccount is displayed as " + actual_BilledARAccount);
    	     } else {
    	      failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "BilledARAccount Should be displayed as " + expected_BilledARAccount,
    	        "BilledARAccount is not displayed as " + actual_BilledARAccount);
    	     }
    	    }

    	    if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
    	      + GLPN[k].trim()
    	      + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled AR Account']//..//preceding-sibling::*)+1]")) {
    	     String actual_UnbilledARAccount;
    	     el = uiDriver.webDr.findElements(
    	       By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
    	         + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled AR Account']//..//preceding-sibling::*)+1]"));
    	     try {
    	      actual_UnbilledARAccount = el.get(temp).getText();
    	     } catch (Exception e) {
    	      temp = 0;
    	      actual_UnbilledARAccount = el.get(0).getText();
    	     }

    	     String expected_UnbilledARAccount = UnbilledARAccount[k].trim();
    	     expected_UnbilledARAccount = expected_UnbilledARAccount.replace("Null", " ");

    	     if (expected_UnbilledARAccount.contains(actual_UnbilledARAccount)
    	       || actual_UnbilledARAccount.contains(expected_UnbilledARAccount)) {
    	      passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "UnbilledARAccount Should be displayed as " + expected_UnbilledARAccount,
    	        "UnbilledARAccount is displayed as " + actual_UnbilledARAccount);
    	     } else {
    	      failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "UnbilledARAccount Should be displayed as " + expected_UnbilledARAccount,
    	        "UnbilledARAccount is not displayed as " + actual_UnbilledARAccount);
    	     }
    	    }

    	    if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
    	      + GLPN[k].trim()
    	      + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Paid Deferred Account']//..//preceding-sibling::*)+1]")) {
    	     String actual_PaidDeferredRevenueAccount;
    	     el = uiDriver.webDr.findElements(
    	       By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
    	         + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Paid Deferred Account']//..//preceding-sibling::*)+1]"));
    	     try {
    	      actual_PaidDeferredRevenueAccount = el.get(temp).getText();
    	     } catch (Exception e) {
    	      temp = 0;
    	      actual_PaidDeferredRevenueAccount = el.get(0).getText();
    	     }

    	     String expected_PaidDeferredRevenueAccount = PaidDeferredRevenueAccount[k].trim();
    	     expected_PaidDeferredRevenueAccount = expected_PaidDeferredRevenueAccount.replace("Null", " ");

    	     if (expected_PaidDeferredRevenueAccount.contains(actual_PaidDeferredRevenueAccount)
    	       || actual_PaidDeferredRevenueAccount.contains(expected_PaidDeferredRevenueAccount)) {
    	      passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "PaidDeferredRevenueAccount Should be displayed as "
    	          + expected_PaidDeferredRevenueAccount,
    	        "PaidDeferredRevenueAccount is displayed as " + actual_PaidDeferredRevenueAccount);
    	     } else {
    	      failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "PaidDeferredRevenueAccount Should be displayed as "
    	          + expected_PaidDeferredRevenueAccount,
    	        "PaidDeferredRevenueAccount is not displayed as " + actual_PaidDeferredRevenueAccount);
    	     }
    	    }

    	    if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
    	      + GLPN[k].trim()
    	      + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unpaid Deferred Account']//..//preceding-sibling::*)+1]")) {
    	     String actual_UnpaidDeferredRevenueAccount;
    	     el = uiDriver.webDr.findElements(
    	       By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
    	         + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unpaid Deferred Account']//..//preceding-sibling::*)+1]"));
    	     try {
    	      actual_UnpaidDeferredRevenueAccount = el.get(temp).getText();
    	     } catch (Exception e) {
    	      temp = 0;
    	      actual_UnpaidDeferredRevenueAccount = el.get(0).getText();
    	     }

    	     String expected_UnpaidDeferredRevenueAccount = UnpaidDeferredRevenueAccount[k].trim();
    	     expected_UnpaidDeferredRevenueAccount = expected_UnpaidDeferredRevenueAccount.replace("Null",
    	       " ");

    	     if (expected_UnpaidDeferredRevenueAccount.contains(actual_UnpaidDeferredRevenueAccount)
    	       || actual_UnpaidDeferredRevenueAccount
    	         .contains(expected_UnpaidDeferredRevenueAccount)) {
    	      passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "UnpaidDeferredRevenueAccount Should be displayed as "
    	          + expected_UnpaidDeferredRevenueAccount,
    	        "UnpaidDeferredRevenueAccount is displayed as "
    	          + actual_UnpaidDeferredRevenueAccount);
    	     } else {
    	      failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "UnpaidDeferredRevenueAccount Should be displayed as "
    	          + expected_UnpaidDeferredRevenueAccount,
    	        "UnpaidDeferredRevenueAccount is not displayed as "
    	          + actual_UnpaidDeferredRevenueAccount);
    	     }
    	    }

    	    if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
    	      + GLPN[k].trim()
    	      + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Bad Debt Revenue Account']//..//preceding-sibling::*)+1]")) {
    	     String actual_BadDebtRevenueAccount;
    	     el = uiDriver.webDr.findElements(
    	       By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
    	         + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Bad Debt Revenue Account']//..//preceding-sibling::*)+1]"));
    	     try {
    	      actual_BadDebtRevenueAccount = el.get(temp).getText();
    	     } catch (Exception e) {
    	      temp = 0;
    	      actual_BadDebtRevenueAccount = el.get(0).getText();
    	     }

    	     String expected_BadDebtRevenueAccount = BadDebtRevenueAccount[k].trim();
    	     expected_BadDebtRevenueAccount = expected_BadDebtRevenueAccount.replace("Null", " ");

    	     if (expected_BadDebtRevenueAccount.contains(actual_BadDebtRevenueAccount)
    	       || actual_BadDebtRevenueAccount.contains(expected_BadDebtRevenueAccount)) {
    	      passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "BadDebtRevenueAccount Should be displayed as " + expected_BadDebtRevenueAccount,
    	        "BadDebtRevenueAccount is displayed as " + actual_BadDebtRevenueAccount);
    	     } else {
    	      failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
    	        "BadDebtRevenueAccount Should be displayed as " + expected_BadDebtRevenueAccount,
    	        "BadDebtRevenueAccount is not displayed as " + actual_BadDebtRevenueAccount);
    	     }
    	    }

    	    el = uiDriver.webDr.findElements(By.xpath(xpath));
    	    if (el.size() > 1) {
    	     temp++;
    	    } else {
    	     temp = 0;
    	    }

    	    k++;
    	    if(k==5)
    	    	break;
    	   }

    	   if (uiDriver.checkElementPresent("//input[@id='_back']")) {
    	    uiDriver.executeJavaScript("scroll(0,-1000)");
    	    uiDriver.click("//input[@id='_back']");
    	   } else {
    	    uiDriver.back();
    	   }
    	  }
    	 } catch (Exception e) {
    	  failed("ValidateAllInvoiceData", "Error in ValidateAllInvoiceData method", "Error : " + e.toString());
    	 }
    	}

        
        
        
        /****************************************

         * Name: VeryfyJeGeneric

         * Description: To verify details of Invoice GLImpact

         *  Date: 08/06/2019

         ****************************************/



	public void VeryfyJeGeneric1(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.HIGH);

		String ACCOUNT = input.get("ACCOUNT");

		String ACCOUNTS[] = ACCOUNT.split(";");

		String DEBIT = input.get("DEBIT");

		String DEBITS[] = DEBIT.split(";");

		String CREDIT = input.get("CREDIT");

		String CREDITS[] = CREDIT.split(";");

		String Name = input.get("Name");

		String Names[] = Name.split(";");

		String Subsidiary = input.get("Subsidiary");

		String Subsidiarys[] = Subsidiary.split(";");

		String MarketCode = input.get("MarketCode");

		String MarketCodes[] = MarketCode.split(";");

		String Territory = input.get("Territory");

		String Territorys[] = Territory.split(";");

		String GLPN = input.get("GLPN");

		String GLPNS[] = GLPN.split(";");

		System.out.println(ACCOUNTS.length);

		List<WebElement> NoRows = uiDriver.webDr.findElements(By.xpath("//*[@id='line_splits']/tbody/tr"));
		int temp = 0, k = 0;
		for (int i = 0; i < NoRows.size() - 1; i++) {

			String xpath = "//table[@id='line_splits']//td[contains(text(),'" + GLPNS[k].trim() + "')]";

			String xpath_Project = "//*[contains(text(),'Generic') or contains(text(),'Deferred Rev -Unpaid - Intl')]";

			if (uiDriver.checkElementPresent(xpath_Project)) {

				passed("Validate Journal",

						ACCOUNTS[i].trim() + "Account Details should be displayed in GLImpact screen",

						ACCOUNTS[i].trim() + "Account Details is displayed in GLImpact screen");

				// Account

				List<WebElement> el = uiDriver.webDr.findElements(
						By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'" + GLPNS[k].trim()
								+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Account']//..//preceding-sibling::*)+1]"));

				String Account;
				try {
					Account = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					Account = el.get(temp).getText();
				}

				String actual_ACCOUNTS = Account;

				if (actual_ACCOUNTS != null && !actual_ACCOUNTS.equals(" ")) {

					String expected_ACCOUNTS = ACCOUNTS[k].trim();

					if (expected_ACCOUNTS.equalsIgnoreCase(actual_ACCOUNTS)) {

						passed("Validate Journal",

								ACCOUNTS[k].trim() + " Account should be displayed as " + ACCOUNTS[k].trim(),

								ACCOUNTS[k].trim() + " Account is displayed as " + ACCOUNTS[k].trim());

					} else {

						failed("Validate Journal",

								ACCOUNTS[k].trim() + " Account should be displayed as " + ACCOUNTS[k].trim(),

								ACCOUNTS[k].trim() + " Account is not displayed as " + ACCOUNTS[k].trim());

					}

				} else {

				}

				// Debit
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'"
						+ GLPNS[k].trim()
						+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Debit']//..//preceding-sibling::*)+1]"));

				String Debit;
				try {
					Debit = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					Debit = el.get(temp).getText();
				}

				String actual_Debit = Debit;

				if (actual_Debit != null && !actual_Debit.equals(" ")) {

					String expected_DEBITS = DEBITS[k].trim();

					if (expected_DEBITS.equalsIgnoreCase(actual_Debit)) {

						passed("Validate Journal",

								DEBITS[k].trim() + " DEBITS should be displayed as " + DEBITS[k].trim(),

								DEBITS[k].trim() + " DEBITS is displayed as " + DEBITS[k].trim());

					} else {

						failed("Validate Journal",

								DEBITS[k].trim() + " DEBITS should be displayed as " + DEBITS[k].trim(),

								DEBITS[k].trim() + " DEBITS is not displayed as " + DEBITS[k].trim());

					}

				} else {

				}

				// Credit
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'"
						+ GLPNS[k].trim()
						+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Credit']//..//preceding-sibling::*)+1]"));

				String Credit;
				try {
					Credit = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					Credit = el.get(temp).getText();
				}

				String actual_Credit = Credit;

				if (actual_Credit != null && !actual_Credit.equals(" ")) {

					String expected_DEBITS = CREDITS[k].trim();

					if (expected_DEBITS.equalsIgnoreCase(actual_Credit)) {

						passed("Validate Journal",

								CREDITS[k].trim() + " CREDITS should be displayed as " + CREDITS[k].trim(),

								CREDITS[k].trim() + " CREDITS is displayed as " + CREDITS[k].trim());

					} else {

						failed("Validate Journal",

								CREDITS[k].trim() + " CREDITS should be displayed as " + CREDITS[k].trim(),

								CREDITS[k].trim() + " CREDITS is not displayed as " + CREDITS[k].trim());

					}

				} else {

				}

				el = uiDriver.webDr.findElements(By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'"
						+ GLPNS[k].trim()
						+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Name']//..//preceding-sibling::*)+1]"));

				String name;
				try {
					name = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					name = el.get(temp).getText();
				}

				String actual_name = name;

				if (actual_name != null && !actual_name.equals(" ")) {

					String expected_name = Names[k].trim();

					if (actual_name.contains(expected_name)) {

						passed("Validate Journal",

								Names[k].trim() + " Names should be displayed as " + Names[k].trim(),

								Names[k].trim() + " Names is displayed as " + Names[k].trim());

					} else {

						failed("Validate Journal",

								Names[k].trim() + " Names should be displayed as " + Names[k].trim(),

								Names[k].trim() + " Names is not displayed as " + Names[k].trim());

					}

				} else {

				}

				// Market code

				el = uiDriver.webDr.findElements(By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'"
						+ GLPNS[k].trim()
						+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Market Code']//..//preceding-sibling::*)+1]"));

				String Marketcode;
				try {
					Marketcode = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					Marketcode = el.get(temp).getText();
				}

				String actual_Marketcode = Marketcode;

				if (actual_Marketcode != null && !actual_Marketcode.equals(" ")) {

					String expected_name = MarketCodes[k].trim();

					if (expected_name.equalsIgnoreCase(actual_Marketcode)) {

						passed("Validate Journal",

								MarketCodes[k].trim() + " MarketCode should be displayed as " + MarketCodes[k].trim(),

								MarketCodes[k].trim() + " MarketCode is displayed as " + MarketCodes[k].trim());

					} else {

						failed("Validate Journal",

								MarketCodes[k].trim() + " MarketCode should be displayed as " + MarketCodes[k].trim(),

								MarketCodes[k].trim() + " MarketCode is not displayed as " + MarketCodes[k].trim());

					}

				} else {

				}

				// Territory

				el = uiDriver.webDr.findElements(By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'"
						+ GLPNS[k].trim()
						+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Territory']//..//preceding-sibling::*)+1]"));

				String territory;
				try {
					territory = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					territory = el.get(temp).getText();
				}

				String actual_territory = territory;

				if (actual_territory != null && !actual_territory.equals(" ")) {

					String expected_name = Territorys[k].trim();

					if (expected_name.equalsIgnoreCase(actual_territory)) {

						passed("Validate Journal",

								Territorys[k].trim() + " Territorys should be displayed as " + Territorys[k].trim(),

								Territorys[k].trim() + " Territorys is displayed as " + Territorys[k].trim());

					} else {

						failed("Validate Journal",

								Territorys[k].trim() + " Territorys should be displayed as " + Territorys[k].trim(),

								Territorys[k].trim() + " Territorys is not displayed as " + Territorys[k].trim());

					}

				} else {

				}

				// GLPN

				el = uiDriver.webDr.findElements(By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'"
						+ GLPNS[k].trim()
						+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]"));

				String GLPn;
				try {
					GLPn = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					GLPn = el.get(temp).getText();
				}

				String actual_GLPN = GLPn;

				if (actual_GLPN != null && !actual_GLPN.equals(" ")) {

					String expected_name = GLPNS[k].trim();

					if (expected_name.equalsIgnoreCase(actual_GLPN)) {

						passed("Validate Journal",

								GLPNS[k].trim() + " GLPNS should be displayed as " + GLPNS[k].trim(),

								GLPNS[k].trim() + " GLPNS is displayed as " + GLPNS[k].trim());

					} else {

						failed("Validate Journal",

								GLPNS[k].trim() + " GLPNS should be displayed as " + GLPNS[k].trim(),

								GLPNS[k].trim() + " GLPNS is not displayed as " + GLPNS[k].trim());

					}

				} else {

				}

				String actual_Subsidiary = uiDriver

						.getValue("//*[text()='Subsidiary']/following::span[1]");

				if (actual_Subsidiary != null && !actual_Subsidiary.equals(" ")) {

					String expected_Subsidiary = Subsidiarys[i].trim();

					if (expected_Subsidiary.equalsIgnoreCase(actual_Subsidiary)) {

						passed("Validate Journal",

								Subsidiarys[i].trim() + " Subsidiary should be displayed as " + Subsidiarys[i].trim(),

								Subsidiarys[i].trim() + " Subsidiary is displayed as " + Subsidiarys[i].trim());

					} else {

						failed("Validate Journal",

								Subsidiarys[i].trim() + " Subsidiary should be displayed as " + Subsidiarys[i].trim(),

								Subsidiarys[i].trim() + " Subsidiary is not displayed as " + Subsidiarys[i].trim());

					}

				} else {

				}

				if (el.size() > 1) {
					temp++;
					if (temp == 1) {
						break;
					}
				} else {
					temp = 0;
				}
				k++;
			}

		}

		uiDriver.back();

	}
         
         
         /****************************************

          * Name: VeryfyJeGenericUnbilledtoBilled

          * Description: To verify details of Invoice GLImpact

          *  Date: 28/08/2019

          ****************************************/



          public void VeryfyJeGenericUnbilledtoBilled(DataRow input, DataRow output){

         
                SleepUtils.sleep(TimeSlab.LOW);

               

                 String ACCOUNT = input.get("ACCOUNT");

                String ACCOUNTS[] = ACCOUNT.split(";");

               

                 String DEBIT = input.get("DEBIT");

                String DEBITS[] = DEBIT.split(";");

               

                 String CREDIT = input.get("CREDIT");

                String CREDITS[] = CREDIT.split(";");

                String DEBIT1= input.get("DEBIT1");

                String DEBITS1[] = DEBIT.split(";");

               

                 String CREDIT1 = input.get("CREDIT");

                String CREDITS1[] = CREDIT.split(";");


                 String Name = input.get("Name");

                String Names[] = Name.split(";");

               

                 String Subsidiary = input.get("Subsidiary");

                String Subsidiarys[] = Subsidiary.split(";");

               

                 String MarketCode = input.get("MarketCode");

                String MarketCodes[] = MarketCode.split(";");

               

                 String Territory = input.get("Territory");

                String Territorys[] = Territory.split(";");

               

                 String GLPN = input.get("GLPN");

                String GLPNS[] = GLPN.split(";");

                System.out.println(ACCOUNTS.length);
             
                            
                            
                  //Account          
                            
                                                         if (uiDriver.checkElementPresent("//*[contains(text(),'"+input.get("DEBIT")+"')]"))
                                                        		 {

                                               passed("Validate Journal",

                                            		   input.get("DEBIT") + " DEBITS should be displayed as " + input.get("DEBIT"),

                                            		   input.get("DEBIT") + " DEBITS is displayed as " + input.get("DEBIT"));

                                         } else {
                                        	 failed("Validate Journal",

                                          		   input.get("DEBIT") + " DEBITS should be displayed as " + input.get("DEBIT"),

                                          		   input.get("DEBIT") + " DEBITS is displayed as " + input.get("DEBIT"));


                                         }

                                  

                                                         if (uiDriver.checkElementPresent("//*[contains(text(),'"+input.get("DEBIT1")+"')]"))
                                                        		 {

                                               passed("Validate Journal",

                                            		   input.get("DEBIT1") + " DEBITS should be displayed as " + input.get("DEBIT1"),

                                            		   input.get("DEBIT") + " DEBITS is displayed as " + input.get("DEBIT"));

                                         } else {
                                        	 failed("Validate Journal",

                                          		   input.get("DEBIT1") + " DEBITS should be displayed as " + input.get("DEBIT1"),

                                          		   input.get("DEBIT1") + " DEBITS is displayed as " + input.get("DEBIT1"));


                                         }
                
                                                         if (uiDriver.checkElementPresent("//*[contains(text(),'"+input.get("CREDIT")+"')]"))
                                                		 {

                                       passed("Validate Journal",

                                    		   input.get("CREDIT") + " CREDIT should be displayed as " + input.get("CREDIT"),

                                    		   input.get("CREDIT") + " CREDIT is displayed as " + input.get("CREDIT"));

                                 } else {
                                	 failed("Validate Journal",

                                  		   input.get("CREDIT") + " CREDIT should be displayed as " + input.get("CREDIT"),

                                  		   input.get("CREDIT") + " CREDIT is displayed as " + input.get("CREDIT"));


                                 }
        
                                                         if (uiDriver.checkElementPresent("//*[contains(text(),'"+input.get("CREDIT1")+"')]"))
                                                		 {

                                       passed("Validate Journal",

                                    		   input.get("CREDIT1") + " CREDIT should be displayed as " + input.get("CREDIT1"),

                                    		   input.get("CREDIT1") + " CREDIT is displayed as " + input.get("CREDIT1"));

                                 } else {
                                	 failed("Validate Journal",

                                  		   input.get("CREDIT1") + " CREDIT should be displayed as " + input.get("CREDIT1"),

                                  		   input.get("CREDIT1") + " CREDIT is displayed as " + input.get("CREDIT1"));


                                 }
                                                         
                                                         
                                                         
                                                         if (uiDriver.checkElementPresent("//*[contains(text(),'"+input.get("ACCOUNT")+"')]"))
                                                		 {

                                       passed("Validate Journal",

                                    		   input.get("ACCOUNT") + " ACCOUNT should be displayed as " + input.get("ACCOUNT"),

                                    		   input.get("ACCOUNT") + " ACCOUNT is displayed as " + input.get("ACCOUNT"));

                                 } else {
                                	 failed("Validate Journal",

                                  		   input.get("ACCOUNT") + " ACCOUNT should be displayed as " + input.get("ACCOUNT"),

                                  		   input.get("ACCOUNT") + " ACCOUNT is displayed as " + input.get("ACCOUNT"));


                                 }
                                                         
                                                         
                                                         if (uiDriver.checkElementPresent("//*[contains(text(),'"+input.get("ACCOUNT1")+"')]"))
                                                		 {

                                       passed("Validate Journal",

                                    		   input.get("ACCOUNT1") + " ACCOUNT should be displayed as " + input.get("ACCOUNT1"),

                                    		   input.get("ACCOUNT1") + " ACCOUNT is displayed as " + input.get("ACCOUNT1"));

                                 } else {
                                	 failed("Validate Journal",

                                  		   input.get("ACCOUNT1") + " ACCOUNT should be displayed as " + input.get("ACCOUNT1"),

                                  		   input.get("ACCOUNT1") + " ACCOUNT is displayed as " + input.get("ACCOUNT1"));


                                 }
                                                         
                                                         
                                                         
                                                         if (uiDriver.checkElementPresent("//*[contains(text(),'"+input.get("Subsidiary")+"')]"))
                                                		 {

                                       passed("Validate Journal",

                                    		   input.get("Subsidiary") + " Subsidiary should be displayed as " + input.get("Subsidiary"),

                                    		   input.get("Subsidiary") + " Subsidiary is displayed as " + input.get("Subsidiary"));

                                 } else {
                                	 failed("Validate Journal",

                                  		   input.get("Subsidiary") + " Subsidiary should be displayed as " + input.get("Subsidiary"),

                                  		   input.get("Subsidiary") + " Subsidiary is displayed as " + input.get("Subsidiary"));


                                 }
                                                         
                                                         
                                                         
                                                         if (uiDriver.checkElementPresent("//*[contains(text(),'"+input.get("Subsidiary")+"')]"))
                                                		 {

                                       passed("Validate Journal",

                                    		   input.get("Subsidiary") + " Subsidiary should be displayed as " + input.get("Subsidiary"),

                                    		   input.get("Subsidiary") + " Subsidiary is displayed as " + input.get("Subsidiary"));

                                 } else {
                                	 failed("Validate Journal",

                                  		   input.get("Subsidiary") + " Subsidiary should be displayed as " + input.get("Subsidiary"),

                                  		   input.get("Subsidiary") + " Subsidiary is displayed as " + input.get("Subsidiary"));


                                 }
                                                         
                                                         
                                                         
                                                         if (uiDriver.checkElementPresent("//*[contains(text(),'"+input.get("MarketCode")+"')]"))
                                                		 {

                                       passed("Validate Journal",

                                    		   input.get("MarketCode") + " MarketCode should be displayed as " + input.get("MarketCode"),

                                    		   input.get("MarketCode") + " MarketCode is displayed as " + input.get("MarketCode"));

                                 } else {
                                	 failed("Validate Journal",

                                  		   input.get("MarketCode") + " MarketCode should be displayed as " + input.get("MarketCode"),

                                  		   input.get("MarketCode") + " MarketCode is displayed as " + input.get("MarketCode"));


                                 }   
                                                         
                                                         
                                                         
                                                         
                                                         if (uiDriver.checkElementPresent("//*[contains(text(),'"+input.get("Territory")+"')]"))
                                                		 {

                                       passed("Validate Journal",

                                    		   input.get("Territory") + " Territory should be displayed as " + input.get("Territory"),

                                    		   input.get("Territory") + " Territory is displayed as " + input.get("Territory"));

                                 } else {
                                	 failed("Validate Journal",

                                  		   input.get("Territory") + " Territory should be displayed as " + input.get("Territory"),

                                  		   input.get("Territory") + " Territory is displayed as " + input.get("Territory"));


                                 } 
                                                         
                                                         
                                                         if (uiDriver.checkElementPresent("//*[contains(text(),'"+input.get("GLPN")+"')]"))
                                                		 {

                                       passed("Validate Journal",

                                    		   input.get("GLPN") + " GLPN should be displayed as " + input.get("GLPN"),

                                    		   input.get("GLPN") + " GLPN is displayed as " + input.get("GLPN"));

                                 }                            
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         




                                                         

          }
         /****************************************
 		 * Name: ValidateLineitemsinNS
 		 * Description:ValidateLineitemsinNS
 		 *  Date:19-Aug-2019 
 		 ****************************************/
         
         
         
         public void ValidateLineitemsinNS(DataRow input, DataRow output) {

        	 String Item = input.get("Item");

        	 String item[] = Item.split(";");

        	 String revrecmethod = input.get("Rev Rec Method");

        	 String Revrecmethod[] = revrecmethod.split(";");

        	 String subtype = input.get("Sub Type");

        	 String Subtype[] = subtype.split(";");

        	 String Onnetwork = input.get("On Network");

        	 String onnetwork[] = Onnetwork.split(";");

        	 String Continuousproduction = input.get("Continuous Production");

        	 String continuousproduction[] = Continuousproduction.split(";");

        	 String MarketCode = input.get("Market Code");

        	 String marketCode[] = MarketCode.split(";");

        	 String Right = input.get("Right");

        	 String right[] = Right.split(";");

        	 String Territory = input.get("Territory");

        	 String territory[] = Territory.split(";");

        	 String TitleID = input.get("Title ID");

        	 String titleID[] = TitleID.split(";");

        	 String Quantity = input.get("Quantity");

        	 String quantity[] = Quantity.split(";");

        	 String Rate = input.get("Rate");

        	 String rate[] = Rate.split(";");

        	 String Amount = input.get("Amount");

        	 String amount[] = Amount.split(";");

        	 String NetRevisedAmount = input.get("Net Revised Amount");

        	 String netRevisedAmount[] = NetRevisedAmount.split(";");

        	 String Productowner = input.get("Product Owner");

        	 String productowner[] = Productowner.split(";");

        	 String GLPN = input.get("GLPN");

        	 String gLPN[] = GLPN.split(";");

        	 String ProductType = input.get("Product Type");

        	 String productType[] = ProductType.split(";");

        	 String RevRecStartDate = input.get("Rev Rec Start Date");

        	 String revRecStartDate[] = RevRecStartDate.split(";");

        	 String RevRecEndDate = input.get("Rev Rec End Date");

        	 String revRecEndDate[] = RevRecEndDate.split(";");

        	 String TaxCode = input.get("Tax Code");

        	 String taxCode[] = TaxCode.split(";");

        	 String SplitWindowNumber = input.get("Split Window Number");

        	 String splitWindowNumber[] = SplitWindowNumber.split(";");

        	 String UnbilledRevenueAccount = input.get("Unbilled Revenue Account");

        	 String unbilledRevenueAccount[] = UnbilledRevenueAccount.split(";");

        	 String BilledRevenueAccount = input.get("Billed Revenue Account");

        	 String billedRevenueAccount[] = BilledRevenueAccount.split(";");

        	 String BilledARAccount = input.get("Billed AR Account");

        	 String billedARAccount[] = BilledARAccount.split(";");

        	 String UnbilledARAccount = input.get("Unbilled AR Account");

        	 String unbilledARAccount[] = UnbilledARAccount.split(";");

        	 String PaidDeferredRevenueAccount = input.get("Paid Deferred Revenue Account");

        	 String paidDeferredRevenueAccount[] = PaidDeferredRevenueAccount.split(";");

        	 String UnpaidDeferredRevenueAccount = input.get("Unpaid Deferred Revenue Account");

        	 String unpaidDeferredRevenueAccount[] = UnpaidDeferredRevenueAccount.split(";");

        	 String BadDebtRevenueAccount = input.get("Bad Debt Revenue Account");

        	 String badDebtRevenueAccount[] = BadDebtRevenueAccount.split(";");

        	 List<WebElement> LineItems = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tr"));
        	 int total_LineItems = LineItems.size();
        	 int k = 0, temp = 0;
        	 
        	 for (int i = 2; i <= 12;i++) {

        	  List<WebElement> el;
        	  List<WebElement> el2 =uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
             	     + gLPN[k].trim()
            	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Item']//..//preceding-sibling::*)+1]"));
        	  String xpath = "//table[@id='item_splits']//td[contains(text(),'" + gLPN[k].trim() + "')]";

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Item']//..//preceding-sibling::*)+1]")) {
        	   String actual_Item;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Item']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_Item = el.get(temp).getText();
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_Item = el.get(0).getText();
        	   }

        	   String expected_Item = item[k].trim();
        	   expected_Item = expected_Item.replace("Null", " ");

        	   if (expected_Item.contains(actual_Item) || actual_Item.contains(expected_Item)) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "Item Should be displayed as " + expected_Item, "Item is displayed as " + actual_Item);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "Item not displayed as " + expected_Item, "Item is displayed as " + actual_Item);
        	   }
        	  }

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Revenue Recognition Method']//..//preceding-sibling::*)+1]")) {
        	   String actual_Revrecmethod;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Revenue Recognition Method']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_Revrecmethod = el.get(temp).getText();
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_Revrecmethod = el.get(0).getText();
        	   }

        	   String expected_Revrecmethod = Revrecmethod[k].trim();
        	   expected_Revrecmethod = expected_Revrecmethod.replace("Null", " ");

        	   if (expected_Revrecmethod.contains(actual_Revrecmethod)
        	     || actual_Revrecmethod.contains(expected_Revrecmethod)) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "Revrecmethod Should be displayed as " + expected_Revrecmethod,
        	      "Revrecmethod is displayed as " + actual_Revrecmethod);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "Revrecmethod not displayed as " + expected_Revrecmethod,
        	      "Revrecmethod is not displayed as " + actual_Revrecmethod);
        	   }
        	  }

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='On Network']//..//preceding-sibling::*)+1]")) {
        	   String actual_onnetwork;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='On Network']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_onnetwork = el.get(temp).getText();
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_onnetwork = el.get(0).getText();
        	   }

        	   String expected_onnetwork = onnetwork[k].trim();
        	   expected_onnetwork = expected_onnetwork.replace("Null", " ");

        	   if (expected_onnetwork.contains(actual_onnetwork) || actual_onnetwork.contains(expected_onnetwork)) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "onnetwork Should be displayed as " + expected_onnetwork,
        	      "onnetwork is displayed as " + actual_onnetwork);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "onnetwork not displayed as " + expected_onnetwork,
        	      "onnetwork is displayed as " + actual_onnetwork);
        	   }
        	  }

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Continuous Production']//..//preceding-sibling::*)+1]")) {
        	   String actual_continuousproduction;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Continuous Production']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_continuousproduction = el.get(temp).getText();
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_continuousproduction = el.get(0).getText();
        	   }

        	   String expected_continuousproduction = continuousproduction[k].trim();
        	   expected_continuousproduction = expected_continuousproduction.replace("Null", " ");

        	   if (expected_continuousproduction.contains(actual_continuousproduction)
        	     || actual_continuousproduction.contains(expected_continuousproduction)) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "continuousproduction Should be displayed as " + expected_continuousproduction,
        	      "continuousproduction is displayed as " + actual_continuousproduction);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "continuousproduction not displayed as " + expected_continuousproduction,
        	      "continuousproduction is displayed as " + actual_continuousproduction);
        	   }
        	  }

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Quantity']//..//preceding-sibling::*)+1]")) {
        	   String actual_Quantity;
        	   float actual_Quantity_temp;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Quantity']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_Quantity = el.get(temp).getText();
        	    actual_Quantity = actual_Quantity.replace(",", "");
        	    actual_Quantity_temp = Float.parseFloat(actual_Quantity);
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_Quantity = el.get(0).getText();
        	    actual_Quantity = actual_Quantity.replace(",", "");
        	    actual_Quantity_temp = Float.parseFloat(actual_Quantity);
        	   }

        	   String expected_Quantity = quantity[k].trim();
        	   expected_Quantity = expected_Quantity.replace("Null", " ");
        	   expected_Quantity = expected_Quantity.replace(",", "");
        	   Float expected_Quantity_temp = Float.parseFloat(actual_Quantity);

        	   if (expected_Quantity_temp == actual_Quantity_temp) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "Quantity Should be displayed as " + expected_Quantity,
        	      "Quantity is displayed as " + actual_Quantity);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "Quantity not displayed as " + expected_Quantity,
        	      "Quantity is displayed as " + actual_Quantity);
        	   }
        	  }

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Rate']//..//preceding-sibling::*)+1]")) {
        	   String actual_Rate;
        	   float actual_Rate_temp;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Rate']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_Rate = el.get(temp).getText();
        	    actual_Rate = actual_Rate.replace(",", "");
        	    actual_Rate_temp = Float.parseFloat(actual_Rate);
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_Rate = el.get(0).getText();
        	    actual_Rate = actual_Rate.replace(",", "");
        	    actual_Rate_temp = Float.parseFloat(actual_Rate);
        	   }

        	   String expected_Rate = rate[k].trim();
        	   expected_Rate = expected_Rate.replace("Null", " ");
        	   expected_Rate = expected_Rate.replace(",", "");
        	   Float expected_Rate_temp = Float.parseFloat(actual_Rate);

        	   if (expected_Rate_temp == actual_Rate_temp) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "Rate Should be displayed as " + expected_Rate, "Rate is displayed as " + actual_Rate);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "Rate not displayed as " + expected_Rate, "Rate is displayed as " + actual_Rate);
        	   }
        	  }

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Amount']//..//preceding-sibling::*)+1]")) {
        	   String actual_Amount;
        	   float actual_Amount_temp;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Amount']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_Amount = el.get(temp).getText();
        	    actual_Amount = actual_Amount.replace(",", "");
        	    actual_Amount_temp = Float.parseFloat(actual_Amount);
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_Amount = el.get(0).getText();
        	    actual_Amount = actual_Amount.replace(",", "");
        	    actual_Amount_temp = Float.parseFloat(actual_Amount);
        	   }

        	   String expected_Amount = amount[k].trim();
        	   expected_Amount = expected_Amount.replace("Null", " ");
        	   expected_Amount = expected_Amount.replace(",", "");
        	   Float expected_Amount_temp = Float.parseFloat(actual_Amount);

        	   if (expected_Amount_temp == actual_Amount_temp) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "Amount Should be displayed as " + expected_Amount,
        	      "Amount is displayed as " + actual_Amount);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "Amount not displayed as " + expected_Amount,
        	      "Amount is displayed as " + actual_Amount);
        	   }
        	  }

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Net Revised Amount']//..//preceding-sibling::*)+1]")) {
        	   String actual_NetRevisedAmount;
        	   float actual_NetRevisedAmount_temp;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Net Revised Amount']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_NetRevisedAmount = el.get(temp).getText();
        	    actual_NetRevisedAmount = actual_NetRevisedAmount.replace(",", "");
        	    actual_NetRevisedAmount_temp = Float.parseFloat(actual_NetRevisedAmount);
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_NetRevisedAmount = el.get(0).getText();
        	    actual_NetRevisedAmount = actual_NetRevisedAmount.replace(",", "");
        	    actual_NetRevisedAmount_temp = Float.parseFloat(actual_NetRevisedAmount);
        	   }

        	   String expected_NetRevisedAmount = netRevisedAmount[k].trim();
        	   expected_NetRevisedAmount = expected_NetRevisedAmount.replace("Null", " ");
        	   expected_NetRevisedAmount = expected_NetRevisedAmount.replace(",", "");
        	   Float expected_NetRevisedAmount_temp = Float.parseFloat(actual_NetRevisedAmount);

        	   if (expected_NetRevisedAmount_temp == actual_NetRevisedAmount_temp) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "NetRevisedAmount Should be displayed as " + expected_NetRevisedAmount,
        	      "NetRevisedAmount is displayed as " + actual_NetRevisedAmount);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "NetRevisedAmount not displayed as " + expected_NetRevisedAmount,
        	      "NetRevisedAmount is displayed as " + actual_NetRevisedAmount);
        	   }
        	  }

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Owner']//..//preceding-sibling::*)+1]")) {
        	   String actual_ProductOwner;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Owner']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_ProductOwner = el.get(temp).getText();
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_ProductOwner = el.get(0).getText();
        	   }

        	   String expected_ProductOwner = productowner[k].trim();
        	   expected_ProductOwner = expected_ProductOwner.replace("Null", " ");

        	   if (expected_ProductOwner.contains(actual_ProductOwner)
        	     || actual_ProductOwner.contains(expected_ProductOwner)) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "ProductOwner Should be displayed as " + expected_ProductOwner,
        	      "ProductOwner is displayed as " + actual_ProductOwner);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "ProductOwner not displayed as " + expected_ProductOwner,
        	      "ProductOwner is displayed as " + actual_ProductOwner);
        	   }
        	  }

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]")) {
        	   String actual_GLPN;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_GLPN = el.get(temp).getText();
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_GLPN = el.get(0).getText();
        	   }

        	   String expected_GLPN = gLPN[k].trim();
        	   expected_GLPN = expected_GLPN.replace("Null", " ");

        	   if (expected_GLPN.contains(actual_GLPN) || actual_GLPN.contains(expected_GLPN)) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "GLPN Should be displayed as " + expected_GLPN, "GLPN is displayed as " + actual_GLPN);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "GLPN not displayed as " + expected_GLPN, "GLPN is displayed as " + actual_GLPN);
        	   }
        	  }

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Type']//..//preceding-sibling::*)+1]")) {
        	   String actual_ProductType;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Type']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_ProductType = el.get(temp).getText();
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_ProductType = el.get(0).getText();
        	   }

        	   String expected_ProductType = productType[k].trim();
        	   expected_ProductType = expected_ProductType.replace("Null", " ");

        	   if (expected_ProductType.contains(actual_ProductType)
        	     || actual_ProductType.contains(expected_ProductType)) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "ProductType Should be displayed as " + expected_ProductType,
        	      "ProductType is displayed as " + actual_ProductType);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "ProductType not displayed as " + expected_ProductType,
        	      "ProductType is displayed as " + actual_ProductType);
        	   }
        	  }

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Revenue Recognition Start Date']//..//preceding-sibling::*)+1]")) {
        	   String actual_RevenueRecognitionStartDate;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Revenue Recognition Start Date']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_RevenueRecognitionStartDate = el.get(temp).getText();
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_RevenueRecognitionStartDate = el.get(0).getText();
        	   }

        	   String expected_RevenueRecognitionStartDate = revRecStartDate[k].trim();
        	   expected_RevenueRecognitionStartDate = expected_RevenueRecognitionStartDate.replace("Null", " ");

        	   if (expected_RevenueRecognitionStartDate.contains(actual_RevenueRecognitionStartDate)
        	     || actual_RevenueRecognitionStartDate.contains(expected_RevenueRecognitionStartDate)) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "RevenueRecognitionStartDate Should be displayed as "
        	        + expected_RevenueRecognitionStartDate,
        	      "RevenueRecognitionStartDate is displayed as " + actual_RevenueRecognitionStartDate);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "RevenueRecognitionStartDate not displayed as "
        	        + expected_RevenueRecognitionStartDate,
        	      "RevenueRecognitionStartDate is displayed as " + actual_RevenueRecognitionStartDate);
        	   }
        	  }

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Revenue Recognition End Date']//..//preceding-sibling::*)+1]")) {
        	   String actual_RevenueRecognitionEndDate;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Revenue Recognition End Date']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_RevenueRecognitionEndDate = el.get(temp).getText();
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_RevenueRecognitionEndDate = el.get(0).getText();
        	   }

        	   String expected_RevenueRecognitionEndDate = revRecEndDate[k].trim();
        	   expected_RevenueRecognitionEndDate = expected_RevenueRecognitionEndDate.replace("Null", " ");

        	   if (expected_RevenueRecognitionEndDate.contains(actual_RevenueRecognitionEndDate)
        	     || actual_RevenueRecognitionEndDate.contains(expected_RevenueRecognitionEndDate)) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "RevenueRecognitionEndDate Should be displayed as " + expected_RevenueRecognitionEndDate,
        	      "RevenueRecognitionEndDate is displayed as " + actual_RevenueRecognitionEndDate);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "RevenueRecognitionEndDate not displayed as " + expected_RevenueRecognitionEndDate,
        	      "RevenueRecognitionEndDate is displayed as " + actual_RevenueRecognitionEndDate);
        	   }
        	  }

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Tax Code']//..//preceding-sibling::*)+1]")) {
        	   String actual_TaxCode;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Tax Code']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_TaxCode = el.get(temp).getText();
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_TaxCode = el.get(0).getText();
        	   }

        	   String expected_TaxCode = taxCode[k].trim();
        	   expected_TaxCode = expected_TaxCode.replace("Null", " ");

        	   if (expected_TaxCode.contains(actual_TaxCode) || actual_TaxCode.contains(expected_TaxCode)) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "TaxCode Should be displayed as " + expected_TaxCode,
        	      "TaxCode is displayed as " + actual_TaxCode);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "TaxCode not displayed as " + expected_TaxCode,
        	      "TaxCode is displayed as " + actual_TaxCode);
        	   }
        	  }

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Split Window Number']//..//preceding-sibling::*)+1]")) {
        	   String actual_splitWindowNumber;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Split Window Number']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_splitWindowNumber = el.get(temp).getText();
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_splitWindowNumber = el.get(0).getText();
        	   }

        	   String expected_splitWindowNumber = splitWindowNumber[k].trim();
        	   expected_splitWindowNumber = expected_splitWindowNumber.replace("Null", " ");

        	   if (expected_splitWindowNumber.contains(actual_splitWindowNumber)
        	     || actual_splitWindowNumber.contains(expected_splitWindowNumber)) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "splitWindowNumber Should be displayed as " + expected_splitWindowNumber,
        	      "splitWindowNumber is displayed as " + actual_splitWindowNumber);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "splitWindowNumber not displayed as " + expected_splitWindowNumber,
        	      "splitWindowNumber is displayed as " + actual_splitWindowNumber);
        	   }
        	  }

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled Revenue Account']//..//preceding-sibling::*)+1]")) {
        	   String actual_unbilledRevenueAccount;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled Revenue Account']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_unbilledRevenueAccount = el.get(temp).getText();
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_unbilledRevenueAccount = el.get(0).getText();
        	   }

        	   String expected_unbilledRevenueAccount = unbilledRevenueAccount[k].trim();
        	   expected_unbilledRevenueAccount = expected_unbilledRevenueAccount.replace("Null", " ");

        	   if (expected_unbilledRevenueAccount.contains(actual_unbilledRevenueAccount)
        	     || actual_unbilledRevenueAccount.contains(expected_unbilledRevenueAccount)) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "unbilledRevenueAccount Should be displayed as " + expected_unbilledRevenueAccount,
        	      "unbilledRevenueAccount is displayed as " + actual_unbilledRevenueAccount);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "unbilledRevenueAccount not displayed as " + expected_unbilledRevenueAccount,
        	      "unbilledRevenueAccount is displayed as " + actual_unbilledRevenueAccount);
        	   }
        	  }

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed Revenue Account']//..//preceding-sibling::*)+1]")) {
        	   String actual_BilledRevenueAccount;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed Revenue Account']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_BilledRevenueAccount = el.get(temp).getText();
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_BilledRevenueAccount = el.get(0).getText();
        	   }

        	   String expected_BilledRevenueAccount = billedRevenueAccount[k].trim();
        	   expected_BilledRevenueAccount = expected_BilledRevenueAccount.replace("Null", " ");

        	   if (expected_BilledRevenueAccount.contains(actual_BilledRevenueAccount)
        	     || actual_BilledRevenueAccount.contains(expected_BilledRevenueAccount)) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "BilledRevenueAccount Should be displayed as " + expected_BilledRevenueAccount,
        	      "BilledRevenueAccount is displayed as " + actual_BilledRevenueAccount);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "BilledRevenueAccount not displayed as " + expected_BilledRevenueAccount,
        	      "BilledRevenueAccount is displayed as " + actual_BilledRevenueAccount);
        	   }
        	  }

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled AR']//..//preceding-sibling::*)+1]")) {
        	   String actual_unbilledARAccount;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled AR']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_unbilledARAccount = el.get(temp).getText();
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_unbilledARAccount = el.get(0).getText();
        	   }

        	   String expected_unbilledARAccount = unbilledARAccount[k].trim();
        	   expected_unbilledARAccount = expected_unbilledARAccount.replace("Null", " ");

        	   if (expected_unbilledARAccount.contains(actual_unbilledARAccount)
        	     || actual_unbilledARAccount.contains(expected_unbilledARAccount)) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "unbilledARAccount Should be displayed as " + expected_unbilledARAccount,
        	      "unbilledARAccount is displayed as " + actual_unbilledARAccount);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "unbilledARAccount not displayed as " + expected_unbilledARAccount,
        	      "unbilledARAccount is displayed as " + actual_unbilledARAccount);
        	   }
        	  }

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed AR Account']//..//preceding-sibling::*)+1]")) {
        	   String actual_BilledARAccount;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed AR Account']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_BilledARAccount = el.get(temp).getText();
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_BilledARAccount = el.get(0).getText();
        	   }

        	   String expected_BilledARAccount = billedARAccount[k].trim();
        	   expected_BilledARAccount = expected_BilledARAccount.replace("Null", " ");

        	   if (expected_BilledARAccount.contains(actual_BilledARAccount)
        	     || actual_BilledARAccount.contains(expected_BilledARAccount)) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "BilledARAccount Should be displayed as " + expected_BilledARAccount,
        	      "BilledARAccount is displayed as " + actual_BilledARAccount);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "BilledARAccount not displayed as " + expected_BilledARAccount,
        	      "BilledARAccount is displayed as " + actual_BilledARAccount);
        	   }
        	  }

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Paid Deferred']//..//preceding-sibling::*)+1]")) {
        	   String actual_PaidDeferred;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Paid Deferred']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_PaidDeferred = el.get(temp).getText();
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_PaidDeferred = el.get(0).getText();
        	   }

        	   String expected_PaidDeferred = paidDeferredRevenueAccount[k].trim();
        	   expected_PaidDeferred = expected_PaidDeferred.replace("Null", " ");

        	   if (expected_PaidDeferred.contains(actual_PaidDeferred)
        	     || actual_PaidDeferred.contains(expected_PaidDeferred)) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "PaidDeferred Should be displayed as " + expected_PaidDeferred,
        	      "PaidDeferred is displayed as " + actual_PaidDeferred);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "PaidDeferred not displayed as " + expected_PaidDeferred,
        	      "PaidDeferred is displayed as " + actual_PaidDeferred);
        	   }
        	  }

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Bad Debt Revenue']//..//preceding-sibling::*)+1]")) {
        	   String actual_BadDebtRevenue;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Bad Debt Revenue']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_BadDebtRevenue = el.get(temp).getText();
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_BadDebtRevenue = el.get(0).getText();
        	   }

        	   String expected_BadDebtRevenue = badDebtRevenueAccount[k].trim();
        	   expected_BadDebtRevenue = expected_BadDebtRevenue.replace("Null", " ");

        	   if (expected_BadDebtRevenue.contains(actual_BadDebtRevenue)
        	     || actual_BadDebtRevenue.contains(expected_BadDebtRevenue)) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "BadDebtRevenue Should be displayed as " + expected_BadDebtRevenue,
        	      "BadDebtRevenue is displayed as " + actual_BadDebtRevenue);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "BadDebtRevenue not displayed as " + expected_BadDebtRevenue,
        	      "BadDebtRevenue is displayed as " + actual_BadDebtRevenue);
        	   }
        	  }

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Market Code']//..//preceding-sibling::*)+1]")) {
        	   String actual_MarketCode;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Market Code']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_MarketCode = el.get(temp).getText();
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_MarketCode = el.get(0).getText();
        	   }

        	   String expected_MarketCode = marketCode[k].trim();
        	   expected_MarketCode = expected_MarketCode.replace("Null", " ");

        	   if (expected_MarketCode.contains(actual_MarketCode)
        	     || actual_MarketCode.contains(expected_MarketCode)) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "MarketCode Should be displayed as " + expected_MarketCode,
        	      "MarketCode is displayed as " + actual_MarketCode);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "MarketCode not displayed as " + expected_MarketCode,
        	      "MarketCode is displayed as " + actual_MarketCode);
        	   }
        	  }

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Territory']//..//preceding-sibling::*)+1]")) {
        	   String actual_Territory;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Territory']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_Territory = el.get(temp).getText();
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_Territory = el.get(0).getText();
        	   }

        	   String expected_Territory = territory[k].trim();
        	   expected_Territory = expected_Territory.replace("Null", " ");

        	   if (expected_Territory.contains(actual_Territory) || actual_Territory.contains(expected_Territory)) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "Territory Should be displayed as " + expected_Territory,
        	      "Territory is displayed as " + actual_Territory);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "Territory not displayed as " + expected_Territory,
        	      "Territory is displayed as " + actual_Territory);
        	   }
        	  }

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title']//..//preceding-sibling::*)+1]")) {
        	   String actual_Title;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_Title = el.get(temp).getText();
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_Title = el.get(0).getText();
        	   }

        	   String expected_Title = titleID[k].trim();
        	   expected_Title = expected_Title.replace("Null", " ");

        	   if (expected_Title.contains(actual_Title) || actual_Title.contains(expected_Title)) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "Title Should be displayed as " + expected_Title, "Title is displayed as " + actual_Title);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "Title not displayed as " + expected_Title, "Title is displayed as " + actual_Title);
        	   }
        	  }

        	  if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
        	    + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Right']//..//preceding-sibling::*)+1]")) {
        	   String actual_Right;
        	   el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
        	     + gLPN[k].trim()
        	     + "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Right']//..//preceding-sibling::*)+1]"));
        	   try {
        	    actual_Right = el.get(temp).getText();
        	   } catch (Exception e) {
        	    temp = 0;
        	    actual_Right = el.get(0).getText();
        	   }

        	   String expected_Right = right[k].trim();
        	   expected_Right = expected_Right.replace("Null", " ");

        	   if (expected_Right.contains(actual_Right) || actual_Right.contains(expected_Right)) {
        	    passed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "Right Should be displayed as " + expected_Right, "Right is displayed as " + actual_Right);
        	   } else {
        	    failed("ValidateLineitemsinNS-" + "-Line Item" + (i - 1),
        	      "Right not displayed as " + expected_Right, "Right is displayed as " + actual_Right);
        	   }
        	  }
        	  
        	  if(el2.size()>1){
        		  temp++;
        		  
        	  }
        	  else{
        		  temp=0;
        	  }
        	  k++;
        	  if(k==5)
        		  break;
        	 }

        	}
         
         
       
     
        /****************************************
		 * Name: NavigateToInvoiceScreen
		 * Description:Method to Navigate To Invoice Screen
		 *  Date:30-Nov-2017 
		 ****************************************/
	    public void NavigateToRevisedInvoice(DataRow input, DataRow output) throws InterruptedException 
	    {
	    	SleepUtils.sleep(TimeSlab.HIGH);
	    	String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("SalesOrder");
			passed("SalesOrder", "SalesOrder Should be displayed Successfully",
					"SalesOrder is displayed Successfully");
			SleepUtils.sleep(5);
			uiDriver.refresh();
			uiDriver.executeJavaScript("scroll(0,500)");
			SleepUtils.sleep(5);
			uiDriver.click("relatedRecord");
			String invoice=uiDriver.getDyanmicData("invoice");
			String invoice1 = invoice.replace("#", input.get("amount"));
			uiDriver.click_dynamic(invoice1);
			SleepUtils.sleep(5);
			
//			uiDriver.click("invoiceNo");
//			passed("InvoiceNo", "InvoiceNo Should be Clicked Successfully",
//					"InvoiceNo is Clicked Successfully");
//			String invoicenumber=uiDriver.getValue("Invoicenum");
//			output.put("InvoiceNum", invoicenumber);
//			String Masterinvoice = invoicenumber.substring(0, invoicenumber.length()-1);
//			output.put("MasterInvoice", Masterinvoice);
	    }
	    /****************************************
		 * Name: NavigateeToSalesOrder
		 * Description:
		 *  Date:30-Nov-2017 
		 ****************************************/
	    public void NavigateeToSalesOrder(DataRow input, DataRow output) throws InterruptedException 
	    {
	    	SleepUtils.sleep(TimeSlab.MEDIUM);
	    	String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("SalesOrder");
			passed("SalesOrder", "SalesOrder Should be displayed Successfully",
					"SalesOrder is displayed Successfully");
			SleepUtils.sleep(5);
			uiDriver.refresh();
	    }
	    
	    /****************************************
		 * Name: ValidateeRevenueArrangement
		 * Description:Navigate and validate Revenue Arrangement
		 *  Date:14-Aug-2017 
		 ****************************************/
	    
	    
	    public void VRAScen11(DataRow input, DataRow output) throws InterruptedException {

            String contractId = input.get("conf"); // conf should pass

            uiDriver.setValue("SearchSo", contractId);

            uiDriver.click("Salesorder");

            uiDriver.click("relatedRecord");

            SleepUtils.sleep(TimeSlab.MEDIUM);

            String SalesorderId = uiDriver.getValue("SalesorderId");

            if (contractId.equals(SalesorderId)) {

 

                  passed("ValidateRevenueArrangement", "SalesOrderId should be displayed successfully" + contractId,

                              "SalesOrderId is displayed successfully" + SalesorderId);

            } else {

                  failed("ValidateRevenueArrangement ", "SalesOrderId should be validated successfully" + contractId,

                              "SalesOrderId is not  displayed" + SalesorderId);

            }

 

            uiDriver.click("relatedRecord");

            SleepUtils.sleep(TimeSlab.LOW);

            uiDriver.click("revenueArrangement");

            // uiDriver.click("relatedRecord");

            SleepUtils.sleep(TimeSlab.LOW);

            List<WebElement> title = uiDriver.webDr.findElements(By.xpath("//*[@id='revenueelement_splits']/tbody/tr"));

            int titlesize = title.size();

            // int data = 0;

            for (int j = 0; j < titlesize - 1; j++) {
            	//*[@id="revenueelement_splits"]/tbody/tr[28]/td[25]
                  String title1 = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)

                              + "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Title')]/../preceding-sibling::*)+1]");

           
                  	if(title1.contains("05692|SEARCH PARTY"))
                  	{
                  String AcutalTitles = input.get("AcutalTitle");

                  String AcutalTitle[] = AcutalTitles.split(";");

                  for (int i = 0; i < 1; i++) {
                	if(AcutalTitle[i]!=null)
                	{
                        if (title1.contains(input.get("AcutalTitle" + i))) {

 

                              String DeferralAccount = input.get("DeferralAccount");

                              String deferralAccount[] = DeferralAccount.split(";");

 

                              // for(int i=0;i<=deferralAccount.length;i++){

 

                              String actual_item = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)

                                          + "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Deferral Account')]/../preceding-sibling::*)+1]");

 

                              String expected_item = deferralAccount[i].trim();

 

                              if (actual_item.contains(expected_item)) {

 

                                    passed("ValidateRevenueArrangement",

                                                "Deferral account should be dispalyed " + expected_item.trim(),

 

                                                "Deferral account is displayed" + actual_item.trim());

 

                              } else {

                                    failed("ValidateRevenueArrangement ",

                                                "Deferral account should be dispalyed" + expected_item.trim(),

                                                "Deferral account is not dispalyed " + actual_item.trim());

                              }

                              String RevenuePlanStatus = input.get("RevenuePlanStatus");

                              String revenuePlanStatus[] = RevenuePlanStatus.split(";");

 

                              String actual_status = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)

                                          + "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Revenue Plan Status')]/../preceding-sibling::*)+1]");

                              String expected_status = revenuePlanStatus[i].trim();

 

                              if (actual_status.contains(expected_status)) {

 

                                    passed("ValidateRevenueArrangement",

                                                "Revenue plan Status should be displayed " + expected_status.trim(),

 

                                                "Revenue plan Status is displayed" + actual_status.trim());

 

                              } else {

                                    failed("ValidateRevenueArrangement ",

                                                "Revenue plan Status should be displayed" + expected_status.trim(),

                                                "Revenue plan Status is not displayed" + actual_status.trim());

                              }

 

                              String RevenueStartDate = input.get("RevenueStartDate");

                              String revenueStartDate[] = RevenueStartDate.split(";");

                              String actual_StartDate = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr["

                                          + (j + 2)

                                          + "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Start Date')]/../preceding-sibling::*)+1]");

                              String expected_StartDate = revenueStartDate[i].trim();

 

                              if (actual_StartDate.contains(expected_StartDate)) {

 

                                    passed("ValidateRevenueArrangement",

                                                "Revenue start date should be displayed " + expected_StartDate.trim(),

 

                                                "Revenue start date is displayed" + actual_StartDate.trim());

 

                              } else {

                                    failed("ValidateRevenueArrangement ",

                                                "Revenue start date should be displayed" + expected_StartDate.trim(),

                                                "Revenue start date is not displayed" + actual_StartDate.trim());

                              }

 

                              String RevenueEndDate = input.get("RevenueEndDate");

                              String revenueEndDate[] = RevenueEndDate.split(";");

                              String actual_EndDate = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)

                                          + "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'End Date')]/../preceding-sibling::*)+1]");

                              String expected_EndDate = revenueEndDate[i].trim();

 

                              if (actual_EndDate.contains(expected_EndDate)) {

 

                                    passed("ValidateRevenueArrangement",

                                                "Revenue End date should be displayed " + expected_EndDate.trim(),

 

                                                "Revenue End date is displayed" + actual_EndDate.trim());

 

                              } else {

                                    failed("ValidateRevenueArrangement ",

                                                "Revenue End date should be displayed" + expected_EndDate.trim(),

                                                "Revenue End date is not displayed" + actual_EndDate.trim());

                              }

 

                              String RevenueAmount = input.get("RevenueAmount");

                              String revenueAmount[] = RevenueAmount.split(";");

                              String actAmount = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)

                                          + "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Revenue Amount')]/../preceding-sibling::*)+1]");
                              String actAmountt=actAmount.replace(",", "").replace(".00","");
                             // int actual_Amount1= Integer.parseInt(actAmountt);
                              
                             // String actamt=uiDriver.getValue("//*[@id='revenueelement_splits']/tbody/tr[34]/td[9]");
                             // String actAmoun=actamt.replace(",", "").replace(".00","");
                             // int actual_Amount2= Integer.parseInt(actAmoun);
                            //int actual_Amount=actual_Amount1+actual_Amount2;
                           
                              String expAmount = revenueAmount[i].trim();
                              String expAmountt=expAmount.replace(",", "");
                             // int expected_Amount= Integer.parseInt(expAmountt);
 

                              if (actAmountt.equals(expAmountt)) {

 

                                    passed("ValidateRevenueArrangement",

                                                "Revenue Amount should be displayed " + expAmountt,

 

                                                "Revenue Amount is displayed" + actAmountt);

 

                              } else {

                                    failed("ValidateRevenueArrangement ",

                                                "Revenue Amount should be displayed" + expAmountt,

                                                "Revenue Amount is not displayed" + actAmountt);

                              }
                              uiDriver.executeJavaScript("scroll(0,-1000)");
                              SleepUtils.sleep(TimeSlab.LOW);

                             /* WebElement element = uiDriver.webDr

                                          .findElement(By.xpath("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)

                                                      + "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Revenue Recognition Plan')]/../preceding-sibling::*)+1]"));

                              ((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView();", element);
                              ((JavascriptExecutor) uiDriver.webDr).executeScript("element.click()");
                              // element.click();*/

                             // SleepUtils.sleep(TimeSlab.HIGH);

                              // uiDriver.ScrollPageUp();

                              //SleepUtils.sleep(TimeSlab.LOW);

                              //uiDriver.click("//*[@id='revenueelement_splits']/tbody/tr[" + (j + 2) + "]/td[15]/a/img");

                             //// SleepUtils.sleep(TimeSlab.HIGH);

                              //uiDriver.setFrame("//iframe[@name='updaterevenuerecognitionplans_frame']");

                             /* SleepUtils.sleep(TimeSlab.LOW);

                              uiDriver.click("//*[text()='Actual']/..//td[3]//a");

                              SleepUtils.sleep(TimeSlab.HIGH);

 

                              String PlannedPeriod = input.get("PlannedPeriod");

                              String plannedPeriod[] = PlannedPeriod.split(";");

                              String actual_PlannedPeriod = uiDriver

                                          .getValue("//*[@id='plannedrevenue_splits']/tbody/tr[2]/td[1]");

                              String expected_PlannedPeriod = plannedPeriod[i].trim();

 

                              if (actual_PlannedPeriod.contains(expected_PlannedPeriod)) {

 

                                    passed("ValidateRevenueArrangement",

                                                "Planing Period should be displayed " + expected_PlannedPeriod.trim(),

 

                                                "Planing Period is displayed" + actual_PlannedPeriod.trim());

 

                              } else {

                                    failed("ValidateRevenueArrangement ",

                                                "PlannedPeriod should be displayed" + expected_PlannedPeriod.trim(),

                                                "PlannedPeriod is not displayed" + actual_PlannedPeriod.trim());

                              }

 

                              /*

                              * Actions act3=new Actions(uiDriver.webDr); WebElement ele

                              * = uiDriver.webDr.findElement(By .xpath(

                              * "//*[text()='Update Revenue Recognition Plans']//..//div"

                              * )); act3.click(ele).build().perform();

                              * //uiDriver.click(""); WebElement

                              * close=uiDriver.webDr.findElement(By.cssSelector(

                              * "#ext-gen21")); close.click(); uiDriver.resetFrame();

                              */

 

                             /* uiDriver.click("//td[@id='tdbody_secondary_back']//input");

                              SleepUtils.sleep(TimeSlab.MEDIUM);

                              uiDriver.click("//td[@id='tdbody_secondary_cancel']//input");*/

                              SleepUtils.sleep(TimeSlab.LOW);

                              //uiDriver.resetFrame();
                        }
                        }

 

                        // data++;

                  }

            break;
            }
            }

      }
	    /****************************************

	     * Name: VeryfyGlAccountData1

	     * Description: To verify details of Invoice GLImpact

	     *  Date: 16/08/2019

	     ****************************************/

	 

	      public void VerifyGlAccountData1(DataRow input, DataRow output) {

	 

	            SleepUtils.sleep(TimeSlab.HIGH);

	 

	            String ACCOUNT = input.get("ACCOUNT");

	            String ACCOUNTS[] = ACCOUNT.split(";");

	 

	            String DEBIT = input.get("DEBIT");

	            String DEBITS[] = DEBIT.split(";");

	 

	            String CREDIT = input.get("CREDIT");

	            String CREDITS[] = CREDIT.split(";");

	 

	            String Name = input.get("Name");

	            String Names[] = Name.split(";");

	 

	            String Subsidiary = input.get("Subsidiary");

	            String Subsidiarys[] = Subsidiary.split(";");

	 

	            String MarketCode = input.get("MarketCode");

	            String MarketCodes[] = MarketCode.split(";");

	 

	            String Territory = input.get("Territory");

	            String Territorys[] = Territory.split(";");

	 

	            String GLPN = input.get("GLPN");

	            String GLPNS[] = GLPN.split(";");

	 

	            System.out.println(ACCOUNTS.length);

	            int temp = 0;

	            for (int k = 0; k < GLPNS.length; k++) {

	 

	                  String xpath = "//table[@id='div__bodytab']//td[contains(text(),'" + GLPNS[k].trim() + "')]";

	 

	                  List<WebElement> el = uiDriver.webDr

	                              .findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'" + GLPNS[k].trim().replace("NULL"," ")

	                                          + "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Account']//..//preceding-sibling::*)+1]"));

	                  String actual_Account;

	                  try {

	                        actual_Account = el.get(temp).getText();

	                  } catch (Exception e) {

	                        temp = 0;

	                        actual_Account = el.get(temp).getText();

	                  }

	                  String expected_Account = ACCOUNTS[k].trim();

	                  if (actual_Account != null && !actual_Account.equals(" ")) {

	                        if (expected_Account.toLowerCase().contains(actual_Account.toLowerCase())

	                                    || actual_Account.toLowerCase().contains(expected_Account.toLowerCase())) {

	                              passed("VerifyGLImpactData", "Account Should be displayed as " + expected_Account,

	                                          "Account is displayed as " + actual_Account);

	                        } else {

	                              failed("VerifyGLImpactData", "Account Should be displayed as " + expected_Account,

	                                          "Account is not displayed as " + actual_Account);

	                        }

	                  } else {

	                        // nothing

	                  }

	                 

	                  String actual_Debit =uiDriver.getValue("//table[@id='div__bodytab']/tbody/tr["+(k+2)+"]//td[count(//table[@id='div__bodytab']//td/div[contains(text(),'Amount (Debit)')]/../preceding-sibling::*)]");

	           

	                  String expected_Debit = DEBITS[k].trim();

	                 

	                  if (actual_Debit != null && !actual_Debit.equals(" ")) {

	                        if (expected_Debit.toLowerCase().equals(actual_Debit.toLowerCase())

	                                    || actual_Debit.toLowerCase().contains(expected_Debit.toLowerCase())) {

	                              passed("VerifyGLImpactData", "debit Amount Should be displayed as " + expected_Debit,

	                                          "debit Amount is displayed as " + actual_Debit);

	                        } else {

	                              failed("VerifyGLImpactData", "debit Amount Should be displayed as " + expected_Debit,

	                                          "dedit Amount should not be displayed as " + actual_Debit);

	                        }}

	                  else{

	                        //Null

	                  }

	                 

	                 

	 

	                  el = uiDriver.webDr.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"

	                              + GLPNS[k].trim().replace("NULL"," ")

	                              + "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Amount (Credit)']//..//preceding-sibling::*)-1]"));

	                  String actual_Credit;

	 

	                  try {

	                        actual_Credit = el.get(temp).getText();

	                  } catch (Exception e) {

	                        temp = 0;

	                        actual_Credit = el.get(temp).getText();

	                  }

	                  String expected_Credit = CREDITS[k].trim();

	                  if (actual_Credit != null && !actual_Credit.equals(" ")) {

	                        if (expected_Credit.toLowerCase().contains(actual_Credit.toLowerCase())

	                                    || actual_Credit.toLowerCase().contains(expected_Credit.toLowerCase())) {

	                              passed("VerifyGLImpactData", "Credit Amount Should be displayed as " + expected_Credit,

	                                          "Credit Amount is displayed as " + actual_Credit);

	                        } else {

	                              failed("VerifyGLImpactData", "Credit Amount Should be displayed as " + expected_Credit,

	                                          "Credit Amount should not be displayed as " + actual_Credit);

	                        }

	                  } else {

	                        // nothing

	                  }

	 

	                  el = uiDriver.webDr.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"

	                              + GLPNS[k].trim().replace("NULL"," ")

	                              + "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Name']//..//preceding-sibling::*)-6]"));

	                  String actual_Name;

	                  try {

	                        actual_Name = el.get(temp).getText();

	                  } catch (Exception e) {

	                        temp = 0;

	                        actual_Name = el.get(temp).getText();

	                  }

	                  String expected_Name = Names[k].trim();

	                  if (actual_Name != null && !actual_Name.equals(" ")) {

	                	   if (actual_Name.toLowerCase().contains(expected_Name.toLowerCase())

	                                    || actual_Name.toLowerCase().contains(expected_Name.toLowerCase())) {

	                              passed("VerifyGLImpactData", "Name Should be displayed as " + expected_Name,

	                                          "Name is displayed as " + actual_Name);

	                        } else {

	                              failed("VerifyGLImpactData", "Name Should be displayed as " + expected_Name,

	                                          "Name should not be displayed as " + actual_Name);

	                        }

	                  } else {

	                        // nothing

	                  }

	 

	                  el = uiDriver.webDr.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"

	                              + GLPNS[k].trim().replace("NULL"," ")

	                              + "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Subsidiary']//..//preceding-sibling::*)-5]"));

	                  String actual_Subsidiary;

	                  try {

	                        actual_Subsidiary = el.get(temp).getText();

	                  } catch (Exception e) {

	                        temp = 0;

	                        actual_Subsidiary = el.get(temp).getText();

	                  }

	                  String expected_Subsidiary = Subsidiarys[k].trim();

	                  if (actual_Subsidiary != null && !actual_Subsidiary.equals(" ")) {

	                        if (expected_Subsidiary.toLowerCase().contains(actual_Subsidiary.toLowerCase())

	                                    || actual_Subsidiary.toLowerCase().contains(expected_Subsidiary.toLowerCase())) {

	                              passed("VerifyGLImpactData", "Subsidiary Should be displayed as " + expected_Subsidiary,

	                                          "Subsidiary is displayed as " + actual_Subsidiary);

	                        } else {

	                              failed("VerifyGLImpactData", "Subsidiary Should be displayed as " + expected_Subsidiary,

	                                          "Subsidiary should not be displayed as " + actual_Subsidiary);

	                        }

	                  } else {

	                        // nothing

	                  }

	 

	                  el = uiDriver.webDr.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"

	                              + GLPNS[k].trim().replace("NULL"," ")

	                              + "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Market Code']//..//preceding-sibling::*)-6]"));

	                  String actual_MarketCode;

	                  try {

	                        actual_MarketCode = el.get(temp).getText();

	                  } catch (Exception e) {

	                        temp = 0;

	                        actual_MarketCode = el.get(temp).getText();

	                  }

	                  String expected_MarketCode = MarketCodes[k].trim();

	                  if (actual_MarketCode != null && !actual_MarketCode.equals(" ")) {

	                        if (expected_MarketCode.toLowerCase().contains(actual_MarketCode.toLowerCase())

	                                    || actual_MarketCode.toLowerCase().contains(expected_MarketCode.toLowerCase())) {

	                              passed("VerifyGLImpactData", "MarketCode Should be displayed as " + expected_MarketCode,

	                                          "MarketCode is displayed as " + actual_MarketCode);

	                        } else {

	                              failed("VerifyGLImpactData", "MarketCode Should be displayed as " + expected_MarketCode,

	                                          "MarketCode should not be displayed as " + actual_MarketCode);

	                        }

	                  } else {

	                        // nothing

	                  }

	                  el = uiDriver.webDr.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"

	                              + GLPNS[k].trim().replace("NULL"," ")

	                              + "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Territory']//..//preceding-sibling::*)-7]"));

	                  String actual_Territory;

	                  try {

	                        actual_Territory = el.get(temp).getText();

	                  } catch (Exception e) {

	                        temp = 0;

	                        actual_Territory = el.get(temp).getText();

	                  }

	                  String expected_Territory = Territorys[k].trim();

	                  if (actual_Territory != null && !actual_Territory.equals(" ")) {

	                        if (expected_Territory.toLowerCase().contains(actual_Territory.toLowerCase())

	                                    || actual_Territory.toLowerCase().contains(expected_Territory.toLowerCase())) {

	                              passed("VerifyGLImpactData", "Territory Should be displayed as " + expected_Territory,

	                                          "Territory is displayed as " + actual_Territory);

	                        } else {

	                              failed("VerifyGLImpactData", "Territory Should be displayed as " + expected_Territory,

	                                          "Territory should not be displayed as " + actual_Territory);

	                        }

	                  } else {

	                        // nothing

	                  }

	 

	                  el = uiDriver.webDr.findElements(By.xpath(xpath));

	                  if (el.size() > 1) {

	                        temp++;

	                  } else {

	                        temp = 0;

	                  }

	            }

	 

	      }

	     
         
         
         /****************************************
     	 * Name: NavigateToGLImpact Description: NavigateToGLImpact Date:
     	 * 30-Nov-2017
     	 ****************************************/

     	public void NavigateToGLImpact(DataRow input, DataRow output)
     			throws InterruptedException {
     		
     		SleepUtils.sleep(TimeSlab.LOW);
     		uiDriver.executeJavaScript("scroll(0,-1000)");
     		SleepUtils.sleep(TimeSlab.MEDIUM);
     		uiDriver.mouseOver("action");
     		SleepUtils.sleep(TimeSlab.LOW);
     		uiDriver.click("Glimpact");
     	}
     	
     	public void NavigateToGLImpact1(DataRow input, DataRow output)
     			throws InterruptedException {
     		uiDriver.click("relatedRecord");
     		SleepUtils.sleep(TimeSlab.LOW);
     		uiDriver.click("//table[@id='links_splits']//div[contains(text(),'Number')]");
     		
     		SleepUtils.sleep(TimeSlab.LOW);
     		if(uiDriver.checkElementPresent("//table[@id='links_splits']//div[contains(text(),'Number')]/span[@class='listheadersortup']"))
     		{
     			passed("Invoice in ascending order in NS", "Invoice should be in ascending order in NS",
        				"Invoice in ascending order in NS");
     		}
     		else
     		{
     			uiDriver.click("//table[@id='links_splits']//div[contains(text(),'Number')]");
     			if(uiDriver.checkElementPresent("//table[@id='links_splits']//div[contains(text(),'Number')]/span[@class='listheadersortup']"))
         		{
         			passed("Invoice in ascending order in NS", "Invoice should be in ascending order in NS",
            				"Invoice in ascending order in NS");
         		}
     		}
     		
     		uiDriver.click("//table[@id='links_splits']//tr[2]//a[1]");
     		//uiDriver.executeJavaScript("scroll(0,-1000)");
     		SleepUtils.sleep(TimeSlab.MEDIUM);
     		uiDriver.mouseOver("action");
     		SleepUtils.sleep(TimeSlab.LOW);
     		uiDriver.click("Glimpact");
     	}
        /****************************************
    	 * Name: ValidateWhtJournal
    	 * Description: Validate cash adj journal in payment 
    	 * Date: 13-mar-2019
    	 * @throws InterruptedException 
    	 ****************************************/
    	
    	
    	public void ValidatePaymentJournal(DataRow input, DataRow output) throws InterruptedException {
    		SleepUtils.sleep(TimeSlab.MEDIUM);
        	String Num = input.get("conf");
    		uiDriver.setValue("SearchSO", Num);
    		SleepUtils.sleep(TimeSlab.MEDIUM);
    		uiDriver.click("SalesOrder");
    		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
    				"SalesOrder is displayed Successfully");
    		uiDriver.executeJavaScript("scroll(0,500)");	
    		uiDriver.click("relatedRecord");
    		String Invoices = uiDriver.getDyanmicData("InvoiceLinks");
    		String InvoiceLink = Invoices.replace("#",input.get("Amount"));
    		uiDriver.click_dynamic(InvoiceLink);
    		
    		SleepUtils.sleep(TimeSlab.MEDIUM);
    		uiDriver.executeJavaScript("scroll(0,500)");
    		
    		
    		
    		
    		SleepUtils.sleep(TimeSlab.MEDIUM);
    		uiDriver.executeJavaScript("scroll(0,500)");
    		uiDriver.click("relatedRecord");
    		uiDriver.click("payment");
    		SleepUtils.sleep(TimeSlab.MEDIUM);
            SleepUtils.sleep(TimeSlab.MEDIUM);
            uiDriver.executeJavaScript("scroll(0,500)");
            WebElement w = uiDriver.webDr.findElement(By.xpath("//*[contains(text(),'lated Transactions')]"));
    		String id = w.getAttribute("id");
    	SleepUtils.sleep(TimeSlab.HIGH);
    	uiDriver.executeJavaScript("scroll(0,-1000)");
    	//if(uiDriver.checkElementPresent_dynamic("reclassJEntry")){
    	uiDriver.executeJavaScript("document.getElementById('"+id+"').click();");
            SleepUtils.sleep(TimeSlab.LOW);
            List<WebElement> reclasslink = uiDriver.webDr.findElements(By.xpath("//*[text()='saction']/following::td[text()='Journal']"));
    	    int RowSize = reclasslink.size();
    	    Thread.sleep(5);
    	    for(int r=1;r<=RowSize;r++)
    		{
           
            SleepUtils.sleep(TimeSlab.LOW);
            uiDriver.executeJavaScript("scroll(0,500)");
            uiDriver.executeJavaScript("document.getElementById('"+id+"').click();");
            // Validating journal
            String s1= uiDriver.getDyanmicData("DocNum");
        	String s2=s1.replace("#", Integer.toString(r));
        	if(uiDriver.checkElementPresent_dynamic(s2)){
        	uiDriver.click(s2);
        	passed("Click On the Revenue Paln Number "+s2+"",
        	    "Should be SuccessFully Clicked on Revenue Paln Number "+s2+"",
        	    "SuccessFully Clicked on Revenue Paln Number "+s2+"");
            int invoiceRow = 2;
    		int accRows = uiDriver.webDr.findElements(By.xpath("//table[contains(@id,'line_splits')]//tbody/tr")).size();
    		for (int i = 0; i < accRows - 1; i++) {
    			if (uiDriver.getValue("//table[contains(@id,'line_splits')]//tbody/tr["+ invoiceRow + "]/td[1]").contains("11015051 USL Cash Clearing"))

    			{
    				if (uiDriver.getValue("//table[contains(@id,'line_splits')]//tbody/tr["+ invoiceRow + "]/td[3]").equals("")) {
    					failed("Validating Credit Amount",
    							"Validating Credit Amount should be successfull",
    							"Credit amount is not USL Cash Clearing");
    				} else {
    					passed("Credit is USL Cash Clearing",
    							"Credit is USL Cash Clearing",
    							"Credit amount is "+uiDriver.getValue_Text("//table[contains(@id,'line_splits')]//tbody/tr["+ invoiceRow + "]/td[3]"));
    				}
    			}
    			
    			if (uiDriver.getValue("//table[contains(@id,'line_splits')]//tbody/tr["+ invoiceRow + "]/td[1]").contains("74300391 WHT Expense"))

    			{
    				if (uiDriver.getValue("//table[contains(@id,'line_splits')]//tbody/tr["+ invoiceRow + "]/td[3]").equals("")) {
    					passed("DEBIT is  WHT Expense",
    							"DEBIT is  WHT Expense",
    							"DEBIT amount is  WHT Expense" +uiDriver.getValue_Text("//table[contains(@id,'line_splits')]//tbody/tr["+ invoiceRow + "]/td[2]"));
    				} else {
    					passed("DEBIT is  WHT Expense",
    							"DEBIT is  WHT Expense",
    							"DEBIT amount is  WHT Expense" +uiDriver.getValue_Text("//table[contains(@id,'line_splits')]//tbody/tr["+ invoiceRow + "]/td[2]"));
    				}
    				
    			}
    			
    						invoiceRow++;

    			
    			
    		}
    		uiDriver.executeJavaScript("scroll(0,-15000)");
    		WebElement w1=uiDriver.webDr.findElement(By.xpath("//*[@value='Back' and @name='_back']"));
    		String s=w1.getAttribute("id");
    		uiDriver.executeJavaScript("document.getElementById('"+s+"').click();");
        	}
    		
    		
        	}
            
        
    	}
    	
      
	/****************************************
	 * Name:  VerifyingPartialAndRestPayment
	 * Description:Method to Verifying Partial And RestPayment
	 * Date:30-Nov-2017 
	 ****************************************/
	public void VerifyingPartialAndRestPayment(DataRow input, DataRow output) throws InterruptedException 
    {
          	String invoicenum = uiDriver.getValue("invoicenum");
            SleepUtils.sleep(TimeSlab.LOW);
            uiDriver.executeJavaScript("scroll(0,-500)");
        	 uiDriver.click("AcceptPayment");
             passed("AcceptPayment", "Should be clicked successfully",
                     "AcceptPayment button is clicked successfully");
             SleepUtils.sleep(TimeSlab.MEDIUM);

             if(input.get("UK_Currency").equals("Y")){
            	 uiDriver.click("exchangeRate");
            	 
            	 uiDriver.handleAlert("", "OK");
            	 //uiDriver.setValue("exchangeRate", input.get("exchangeRate"));
            	 //SleepUtils.sleep(TimeSlab.LOW);
            	 uiDriver.executeJavaScript("document.getElementById('exchangerate_formattedValue').value='"+input.get("exchangeRate")+"';");
            	 //SleepUtils.sleep(TimeSlab.LOW);
            	 uiDriver.handleAlert("", "OK");
            	 String exchangeRate = uiDriver.getValue("exchangeRate");
                 output.put("exchangeRate", exchangeRate);
             }
             
	 		SleepUtils.sleep(TimeSlab.YIELD);
            String partialpayment = uiDriver.getDyanmicData("partialpaymentfield");
            SleepUtils.sleep(TimeSlab.YIELD);
            String ReferenceVal1 = partialpayment.replace("#", invoicenum);
            SleepUtils.sleep(TimeSlab.YIELD);
            uiDriver.executeJavaScript("scroll(0,500)");
            uiDriver.click("PaymentAmt");
            uiDriver.executeJavaScript("document.getElementById('payment_formattedValue').value = ''");
            SleepUtils.sleep(2);
            
            uiDriver.setValue("PaymentAmt", input.get("PartialTotalAmt"));
            SleepUtils.sleep(TimeSlab.LOW);
            
           // uiDriver.executeJavaScript("document.getElementById('payment_formattedValue').value = '"+ input.get("PartialTotalAmt") + "'");
            if(uiDriver.checkElementPresent_dynamic(ReferenceVal1)){
           	 
         	   SleepUtils.sleep(10);
         	   uiDriver.click_dynamic(ReferenceVal1);
                uiDriver.click_dynamic(ReferenceVal1);  
           }
            else{
          	   
          	   SleepUtils.sleep(TimeSlab.LOW);
          	   uiDriver.click("FilterNumber");
          	   uiDriver.click("FirstFilteringNumber");
          	   uiDriver.executeJavaScript("scroll(0,800)");
          	   SleepUtils.sleep(TimeSlab.LOW);
          	  if(uiDriver.checkElementPresent_dynamic(ReferenceVal1)){
                
          		uiDriver.click_dynamic(ReferenceVal1);
                 uiDriver.click_dynamic(ReferenceVal1); 
          	    SleepUtils.sleep(TimeSlab.MEDIUM);
          	  }
          	  else{
          		  
          	   SleepUtils.sleep(TimeSlab.LOW);
          	  uiDriver.executeJavaScript("scroll(0,-800)");
            	   uiDriver.click("FilterNumber");
            	   uiDriver.click("SecondFilteringNumber");
            	   uiDriver.executeJavaScript("scroll(0,800)");
            	   SleepUtils.sleep(TimeSlab.LOW);
            	  if(uiDriver.checkElementPresent_dynamic(ReferenceVal1)){
                  
            		uiDriver.click_dynamic(ReferenceVal1);
                   uiDriver.click_dynamic(ReferenceVal1); 
            	    SleepUtils.sleep(TimeSlab.MEDIUM);
            	    
            	  }
            	  else{
            		  
            		 SleepUtils.sleep(TimeSlab.LOW);
            		 uiDriver.executeJavaScript("scroll(0,-800)");
              	   uiDriver.click("FilterNumber");
              	   uiDriver.click("ThirdFilteringNumber");
              	   uiDriver.executeJavaScript("scroll(0,800)");
              	   SleepUtils.sleep(TimeSlab.LOW);
              	  if(uiDriver.checkElementPresent_dynamic(ReferenceVal1)){
                    
              		uiDriver.click_dynamic(ReferenceVal1);
                     uiDriver.click_dynamic(ReferenceVal1); 
              	    SleepUtils.sleep(TimeSlab.MEDIUM);
              	    
              	  }
            	  }
          		  
          	  }
          	   
             } 
          		  
          	  if(input.get("cashAdjCode").equals("Y")){
             
            	 SleepUtils.sleep(TimeSlab.LOW);
            	 uiDriver.executeJavaScript("scroll(0,-200)");
            	 uiDriver.click("CashAdjCode");
                SleepUtils.sleep(2);
                uiDriver.click("CashAdjCode1");
                uiDriver.setValue("CashAdjCode1",input.get("CashAdjCode1"));
                SleepUtils.sleep(2);
                uiDriver.click("dropdown");
                SleepUtils.sleep(2);
                uiDriver.click("List");
                SleepUtils.sleep(2);
                uiDriver.click("searchbox");
                String invoicenumber="Invoice #"+invoicenum;
                uiDriver.setValue("searchbox",invoicenumber);
                uiDriver.click("searchbutton");
                SleepUtils.sleep(2);
                uiDriver.click("searchedinvoicecode");
                SleepUtils.sleep(2);
                uiDriver.click("WHTCode");
                uiDriver.setValue("EditWHTCode",input.get("WHTCode"));
                SleepUtils.sleep(TimeSlab.LOW);
                uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[3].click();");
                SleepUtils.sleep(TimeSlab.MEDIUM);
                uiDriver.setValue("EditWHTRate",input.get("WHTRate"));
                SleepUtils.sleep(2);
                uiDriver.click("Add");
                SleepUtils.sleep(2);
                uiDriver.click("CAshAdjCodeAmount");
                SleepUtils.sleep(3);
                String WHTAmount = uiDriver.getValue("WHTAmount");   
                uiDriver.setValue("CAshAdjCodeAmount",WHTAmount);
                String WHTpercent=uiDriver.getValue("WHTpercent"); 
                SleepUtils.sleep(2);
                uiDriver.executeJavaScript("scroll(0,-800)");
                output.put("WHTAmount", WHTAmount);
   
     }

           uiDriver.executeJavaScript("scroll(0,-1000)");
           uiDriver.click("acctradiobutton");
   	    	SleepUtils.sleep(TimeSlab.YIELD);
   	    	uiDriver.setValue("Account", "11015051 USL Cash Clearing");
   			 SleepUtils.sleep(TimeSlab.YIELD);
   			uiDriver.setValue("ContractorName", "");
  			 SleepUtils.sleep(TimeSlab.LOW);
            uiDriver.click("SaveInvoice");
            SleepUtils.sleep(TimeSlab.YIELD);
       //     uiDriver.executeJavaScript("document.getElementById('btn_multibutton_submitter').click();");
        //    uiDriver.handleAlert("", "Leave");
            passed("SaveInvoice", "Invoice Should be Saved successfully",
                    "Invoice is Saved successfully");
            String PaymentNumber = uiDriver.getValue("PaymentNumber");
            SleepUtils.sleep(TimeSlab.LOW);
            output.put("PaymentNumber", PaymentNumber);
           
        }
	
	
	/****************************************
	 * Name:  NavigatetoTitleallocationParentmultiple
	 * Description:Method to NavigatetoTitleallocationParentmultiple
	 * Date:30-Nov-2017 
	 ****************************************/
	public void NavigatetoTitleallocationParentmultiple(DataRow input, DataRow output) throws InterruptedException 
    {
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Custom");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,1600)");
		uiDriver.click("TitleAllocationParent");
		/*SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);*/
		uiDriver.executeJavaScript("scroll(0,1200)");
		SleepUtils.sleep(TimeSlab.LOW);
		int accRows = uiDriver.webDr.findElements(By.xpath("//table[@id='recmachcustrecord_nbcu_titleallocpa_contract__tab']/tbody/tr")).size();
		SleepUtils.sleep(TimeSlab.LOW);
		for (int r = 0; r < accRows; r++) {
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.executeJavaScript("scroll(0,900)");
			String s1 = uiDriver.getDyanmicData("DynamicTapid");
			String s2 = s1.replace("#", Integer.toString(r));
			if (uiDriver.checkElementPresent_dynamic(s2)) 
				SleepUtils.sleep(TimeSlab.HIGH);
				uiDriver.click_dynamic(s2);
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.executeJavaScript("scroll(0,500)");
			SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.click("AllocationDetail");
				SleepUtils.sleep(TimeSlab.LOW);
	            int accRows1 = uiDriver.webDr.findElements(By.xpath("//table[@id='recmachcustrecord_nbcu_titleallocch_parent__tab']/tbody/tr")).size();
	            for(int i=0;i<accRows1;i++)
	            {
	                String s3= uiDriver.getDyanmicData("ARAmount");
	                String s4=s1.replace("#", Integer.toString(i));
	                if(uiDriver.checkElementPresent_dynamic(s4)){
	                	
	                    String ARAmount=uiDriver.getValue(s4);
	                    passed("Verify AR Amount "+ARAmount+"",
	                           "SuccessFully Verified AR Amount "+ARAmount+"",
	                            "SuccessFully Verified AR Amount "+ARAmount+"");
	           }

	           String s5= uiDriver.getDyanmicData("WHTAmount");
	           String s6=s3.replace("#", Integer.toString(i));
	           if(uiDriver.checkElementPresent_dynamic(s6)){
	              String WHTAmount=uiDriver.getValue(s6);
	              passed("Verify WHT Amount "+WHTAmount+"",
	                     "SuccessFully Verified WHT Amount "+WHTAmount+"",
	                      "SuccessFully Verified WHT Amount "+WHTAmount+"");
	          }

	          String s7= uiDriver.getDyanmicData("VATAmount");
	          String s8=s5.replace("#", Integer.toString(i));
	          if(uiDriver.checkElementPresent_dynamic(s8)){
	            String VATAmount=uiDriver.getValue(s8);
	            passed("Verify VAT Amount "+VATAmount+"",
	                   "SuccessFully Verified WHT Amount "+VATAmount+"",
	                   "SuccessFully Verified WHT Amount "+VATAmount+"");
	          }
	          String s9= uiDriver.getDyanmicData("CACAmount");
	          String s10=s7.replace("#", Integer.toString(i));
	          if(uiDriver.checkElementPresent_dynamic(s10)){
	               String CACAmount=uiDriver.getValue(s10);
	               passed("Verify CAC Amount "+CACAmount+"",
	                      "SuccessFully Verified WHT Amount "+CACAmount+"",
	                      "SuccessFully Verified WHT Amount "+CACAmount+"");
	            }
	       }
	            uiDriver.executeJavaScript("scroll(0,800)");
	    		SleepUtils.sleep(TimeSlab.LOW);
	    		uiDriver.click("Back1");
	    		SleepUtils.sleep(TimeSlab.HIGH);
	    		uiDriver.click("Custom");
	    		SleepUtils.sleep(TimeSlab.LOW);
	    		uiDriver.executeJavaScript("scroll(0,2500)");
	    		uiDriver.click("TitleAllocationParent");
	    		SleepUtils.sleep(TimeSlab.HIGH);
		
		}
		
		
		
    }
	
		
	/****************************************
	 * Name:  NavigateToMultiplePaymentScreen
	 * Description:Method to NavigateToMultiplePaymentScreen
	 * Date:30-Nov-2017 
	 ****************************************/
	public void NavigateToMultiplePaymentScreen(DataRow input, DataRow output) throws InterruptedException 
    {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String InvoiceNum=input.get("InvoiceNum");
    	String PaymentNumber = input.get("PaymentNumber");
    	String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");
		SleepUtils.sleep(5);
		uiDriver.refresh();
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("relatedRecord");
		SleepUtils.sleep(TimeSlab.LOW);
		String InvoiceLink = uiDriver.getDyanmicData("InvoiceLink");
		String InvLink = InvoiceLink.replace("#",InvoiceNum);
		uiDriver.click_dynamic(InvLink);
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("relatedRecord");
		String PaymentLink = uiDriver.getDyanmicData("PaymentLink");
		String PayLink = PaymentLink.replace("#",PaymentNumber);
		uiDriver.click_dynamic(PayLink);
		 
   }	
	
	/****************************************
	 * Name: AllocateCashtoTitleMap
	 * Description:Method to Allocate Cash to TitleMap
	 *  Date:30-Nov-2017 
	 ****************************************/
    public void AllocateCashtoTitleMap(DataRow input, DataRow output) throws InterruptedException 
    { 
    	   SleepUtils.sleep(TimeSlab.YIELD);
           uiDriver.mouseOver("Customization");
           SleepUtils.sleep(TimeSlab.YIELD);
           uiDriver.mouseOver("Scripting");
           SleepUtils.sleep(TimeSlab.YIELD);
           uiDriver.mouseOver("Scripts");
           SleepUtils.sleep(TimeSlab.YIELD); 
           uiDriver.click("Scripts");
           SleepUtils.sleep(TimeSlab.YIELD);
           uiDriver.click("EditBtnAllocateCashtoTitleMap");
           SleepUtils.sleep(TimeSlab.YIELD);
           uiDriver.mouseOver("SaveBtndropdown");
           SleepUtils.sleep(TimeSlab.YIELD);
           uiDriver.click("SaveAndExecute"); 
           uiDriver.handleAlert("", "OK");
           uiDriver.click("refresh");
           SleepUtils.sleep(TimeSlab.MEDIUM);
           uiDriver.click("refresh");
           SleepUtils.sleep(TimeSlab.HIGH);
          
 }	
	
    
    /****************************************
	 * Name: NavigateToPaymentScreen
	 * Description:Method to Navigate To PaymentScreen
	 *  Date:30-Nov-2017 
	 ****************************************/
    public void NavigateToPaymentScreen(DataRow input, DataRow output) throws InterruptedException 
    {
    	SleepUtils.sleep(TimeSlab.MEDIUM);
    	String PaymentNumber = input.get("PaymentNumber");
    	String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");
		SleepUtils.sleep(5);
		uiDriver.refresh();
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("relatedRecord");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("invoiceNo");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("relatedRecord");
		String PaymentLink = uiDriver.getDyanmicData("PaymentLink");
		String PayLink = PaymentLink.replace("#",PaymentNumber);
		uiDriver.click_dynamic(PayLink);
		 
   }	
	
    /****************************************
	 * Name: NavigateToInvoiceScreen
	 * Description:Method to Navigate To Invoice Screen
	 *  Date:30-Nov-2017 
	 ****************************************/
    public void NavigateToInvoiceScreen(DataRow input, DataRow output) throws InterruptedException 
    {
    	SleepUtils.sleep(1);
    	uiDriver.refresh();
    	SleepUtils.sleep(1);
    	uiDriver.refresh();
    	SleepUtils.sleep(1);
    	uiDriver.refresh();
    	SleepUtils.sleep(TimeSlab.MEDIUM);
    	String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.HIGH);
		//SleepUtils.sleep(TimeSlab.HIGH);
//		SleepUtils.sleep(TimeSlab.HIGH);
		//SleepUtils.sleep(TimeSlab.HIGH);
		//SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");
		SleepUtils.sleep(5);
		uiDriver.refresh();
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("//*[text()='elated Records']");
		if(input.get("multipleinvoice").equals("Y"))
		{
			String InvoiceLink = uiDriver.getDyanmicData("InvoiceLink");
			String InvoiceNum=input.get("InvoiceNum");
			String InvLink = InvoiceLink.replace("#",InvoiceNum);
			uiDriver.click_dynamic(InvLink);
		}
		else if(input.get("multipleopeninvoice").equals("Y"))
		{
			
			List<WebElement> fil = uiDriver.webDr.findElements(By.xpath("//*[@id='links_splits']//tbody/tr/td[text()='Open']"));
            int filter = fil.size();
            for(int h=1;h<=filter;h++)
            {
            String InvoiceLink = uiDriver.getDyanmicData("InvoiceLinks");		
			String InvLink = InvoiceLink.replace("#",Integer.toString(h));
			uiDriver.click_dynamic(InvLink);
			passed("InvoiceNo", "InvoiceNo Should be Clicked Successfully",
					"InvoiceNo is Clicked Successfully");
			uiDriver.executeJavaScript("scroll(0,400)");
			String invoiceType=uiDriver.getValue_Text("invoiceType");
			if (invoiceType.contains(input.get("InvoiceType"))) 
			{
				passed("Verify the InvoiceType ",
						"InvoiceType is displayed Successfully as Title Invoice",
						"InvoiceType is displayed Successfully");
			}
			else 
			{
				failed("Verify the InvoiceType ",
						"InvoiceType is not displayed Successfully as Title Invoice",
						"InvoiceType is not displayed Successfully");
			}	
			uiDriver.executeJavaScript("scroll(0,-400)");
			if(h==1)
			{
			uiDriver.click("back");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("relatedRecord");
			SleepUtils.sleep(TimeSlab.HIGH);
			}
			uiDriver.executeJavaScript("scroll(0,400)");
            }
		}
		else 
		{
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("invoiceNo");
		passed("InvoiceNo", "InvoiceNo Should be Clicked Successfully",
				"InvoiceNo is Clicked Successfully");
		String invoicenumber=uiDriver.getValue("Invoicenum");
		output.put("InvoiceNum", invoicenumber);
		String Masterinvoice = invoicenumber.substring(0, invoicenumber.length()-1);
		output.put("MasterInvoice", Masterinvoice);
    }
		 }	
    /****************************************
	 * Name:Naviagte to customsubtab
	 * Description:Naviagte to customsubtab
	 *  Date:31-Oct-2018 
	 ****************************************/
    public void Naviagtetocustomsubtab(DataRow input, DataRow output) throws InterruptedException 
    {
    	
    	SleepUtils.sleep(TimeSlab.HIGH);
    	uiDriver.click("RelatedRecord");
    	SleepUtils.sleep(TimeSlab.LOW);
    	uiDriver.executeJavaScript("scroll(0,500)");
    	uiDriver.click("Billamount");
    	SleepUtils.sleep(TimeSlab.HIGH);
    	uiDriver.executeJavaScript("scroll(0,500)");
    	uiDriver.click("RelatedRecord");
    	SleepUtils.sleep(TimeSlab.HIGH);
    	SleepUtils.sleep(TimeSlab.LOW);
    	uiDriver.refresh();
    	SleepUtils.sleep(TimeSlab.LOW);
    	uiDriver.refresh();
    	SleepUtils.sleep(TimeSlab.HIGH);
    	uiDriver.click("RelatedRecord");
    	SleepUtils.sleep(TimeSlab.HIGH);
    	uiDriver.click("Dateclick");
    	SleepUtils.sleep(TimeSlab.HIGH);
    	Actions action = new Actions(uiDriver.webDr);
        WebElement ele = uiDriver.webDr.findElement(By.xpath("//*[@id='spn_cRR_d1']/a"));
        action.moveToElement(ele).perform();
    	
    	
    	//uiDriver.click("//*[@id='spn_cRR_d1']/a");
    	SleepUtils.sleep(TimeSlab.LOW);
    	uiDriver.click("//span[text()='NBCUniversal Media, LLC 10K QA  -  NBCU: Manager 1']");
    	SleepUtils.sleep(TimeSlab.HIGH);
    	SleepUtils.sleep(TimeSlab.HIGH);
    	SleepUtils.sleep(TimeSlab.HIGH);
    	SleepUtils.sleep(TimeSlab.HIGH);
    	SleepUtils.sleep(TimeSlab.HIGH);
    	SleepUtils.sleep(TimeSlab.HIGH);
    	uiDriver.click("Cbtbutton");
    	SleepUtils.sleep(TimeSlab.LOW);
    	uiDriver.click("Nextbutton");
    	SleepUtils.sleep(TimeSlab.LOW);
    	uiDriver.click("Nextbutton");
    	SleepUtils.sleep(TimeSlab.LOW);
    	uiDriver.click("Territory");
    	SleepUtils.sleep(TimeSlab.LOW);
    	uiDriver.click("Greece");
    	SleepUtils.sleep(TimeSlab.LOW);
    	uiDriver.click("Right");
    	SleepUtils.sleep(TimeSlab.LOW);
    	uiDriver.click("FTV");
    	SleepUtils.sleep(TimeSlab.LOW);
    	
    	SleepUtils.sleep(TimeSlab.LOW);
    	String totalValue = input.get("totalValue");
    	int totalcolumn = Integer.parseInt(totalValue);
    	for(int i=1;i<=totalcolumn;i++)
    	{
    		
    		uiDriver.click("Title");
    		uiDriver.setValue("Title",input.get("title"+i));
    		SleepUtils.sleep(TimeSlab.LOW);
    		uiDriver.click("ApplyFilters");
    		SleepUtils.sleep(TimeSlab.LOW);
    		if(i>=8)
    		{
    		uiDriver.executeJavaScript("scroll(0,-2500)");
    		}
    		String displayedamount=uiDriver.getValue_Text("Getamountvalue");
    		SleepUtils.sleep(TimeSlab.LOW);
    		uiDriver.click("Textamountvalue");
    		SleepUtils.sleep(TimeSlab.LOW);
    		uiDriver.setValue("Editamountvalue",displayedamount);
    		SleepUtils.sleep(TimeSlab.LOW);
    		uiDriver.click("Okbutton");
    		
    		if(i>=8)
    		{
    			uiDriver.executeJavaScript("scroll(0,-2500)");
    		}
    	}
    	 uiDriver.click("savebutton");
    }



    	 /* if(uiDriver.checkElementPresent("//input[@name='inpt_custpage_line_item']/../span"))
    	  {
              uiDriver.click("//input[@name='inpt_custpage_line_item']/../span");
              List<WebElement> fil = uiDriver.webDr.findElements(By.xpath("/html/body/div[6]/div/div/div"));
              int filter = fil.size();
              if(filter==2)
              {
              for(int i=1;i<=filter;i++)
              {
            	 // uiDriver.click("//input[@name='inpt_custpage_line_item']/../span");
            	  SleepUtils.sleep(TimeSlab.LOW);
            	  uiDriver.click("/html/body/div[6]/div/div/div["+i+"]");
            	  SleepUtils.sleep(TimeSlab.LOW);
            	  uiDriver.click("savebutton");
            	  
            	  
              }
            	  
            	  
              
              }
              else
              {
            	  uiDriver.click("savebutton");
              }
            	  
              }
            	  
              }*/
              
              


/*List<WebElement> rows = uiDriver.webDr.findElements(By.xpath("//table[@id='custpage_cbt_details_splits']/tbody/tr"));
int rowsize = rows.size();
uiDriver.executeJavaScript("scroll(0,-2500)");
    	for(int i=2;i<=rowsize+1;i++)
    	{
    		String amount=uiDriver.getDyanmicData("Amount");
    		String amount1=amount.replace("#", Integer.toString(i));
    		String Amount1=uiDriver.getValue_Text(amount1);
    		
    		String newamount=uiDriver.getDyanmicData("NewAmount");
    		String newamount1=newamount.replace("#", Integer.toString(i));
    		uiDriver.click_dynamic(newamount1);
    		uiDriver.setValue("Newamountedit", Amount1);
    		SleepUtils.sleep(TimeSlab.LOW);
    		uiDriver.click("Okbutton");
    		SleepUtils.sleep(TimeSlab.LOW);
    		
    		
    		
    	}*/
    	
    
    
    
    
    
    
    
    
    
    
    
    
    /****************************************
	 * Name: VerifyCreditMemo
	 * Description:Method to verify credit memo
	 *  Date:30-Nov-2017 
	 ****************************************/
    public void VerifyCreditMemo(DataRow input, DataRow output) throws InterruptedException 
    {
    	
    	String reviseamount=input.get("reviseamount");
    	String payment1=input.get("payment1");
    	String payment2=input.get("payment2");
    	 double reviseamountd = Double.parseDouble(reviseamount);
    	double pay1=Double.parseDouble(payment1);
    	double pay2=Double.parseDouble(payment2);
    	double Payments = pay1+pay2;
    	 double creditamount = Payments-reviseamountd;
    	 String expectedcreditamount = Double.toString(creditamount);
    	String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");
		SleepUtils.sleep(5);
		uiDriver.refresh();
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("relatedRecord");
		SleepUtils.sleep(5);
		uiDriver.click("CreditMemo");
		String actualcreditamount=uiDriver.getValue("CreditMemoamount");
		if(expectedcreditamount.equalsIgnoreCase(actualcreditamount))
		{
		passed("Verifying the credit amount",
				"Credit memo amount  displayed as '" + actualcreditamount+ "' Successfully",
				"Credit memo amount "	+ actualcreditamount + " is displayed Successfully");
    }
    }		
		 
	
		
    /****************************************
	 * Name: Revise Sales order
	 * Description:Method to Revise Sales Order
	 *  Date:30-Nov-2017 
	 ****************************************/
    public void ReviseSalesOrder(DataRow input, DataRow output) throws InterruptedException 
    {
    	String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");
		SleepUtils.sleep(5);
		uiDriver.click("ReviseOrder");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("EditforRevise");
		SleepUtils.sleep(TimeSlab.HIGH);
		for(int i=1;i<=4;i++)
		{
			String updateline = uiDriver.getDyanmicData("updateLineItem");
			String updateLineItem = updateline.replace("#", Integer.toString(i));
			uiDriver.click_dynamic(updateLineItem);
			uiDriver.click("action");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("updateSOLine");			
			
			
		String QuantityLink = uiDriver.getDyanmicData("changeQuantity");
		String QuantLink = QuantityLink.replace("#", Integer.toString(i));
		uiDriver.click_dynamic(QuantLink);
				
	SleepUtils.sleep(TimeSlab.LOW);		
	uiDriver.sendKey("backspace");
		SleepUtils.sleep(TimeSlab.LOW);
		 uiDriver.executeJavaScript("document.getElementById('quantity_formattedValue').value = ''");

		 SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("Updateqty", input.get("invoiceamount"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,1000)");
		
		
		//uiDriver.executeJavaScript("document.getElementById('item_addedit').click();");
		uiDriver.click("OKbutton");		
		uiDriver.handleAlert("", "OK");			
		SleepUtils.sleep(TimeSlab.MEDIUM);
		
		//SleepUtils.sleep(TimeSlab.MEDIUM);
		//uiDriver.handleAlert("", "OK");
	}
	
	//else{}
	uiDriver.click("SaveRevise");
	String RevisedAmount=uiDriver.getValue("ReviseAmount");
	SleepUtils.sleep(TimeSlab.MEDIUM);
	uiDriver.click("CommitRevision");
	SleepUtils.sleep(TimeSlab.MEDIUM);
	uiDriver.setFrame("frame");
	//uiDriver.switchToWindow("Estimate - NetSuite (NBCUniversal Media, LLC - QA)");
	uiDriver.click("OK");
	uiDriver.handleAlert("", "OK");
	passed("Revise Order", "Revise order is successful",
				"Revise order is successful");
	output.put("RevisedAmount", RevisedAmount);
    
		 }	
	
       
    
    /****************************************
   	 * Name: NavigateToTitleAllocationParent
   	 * Description:Method to Navigate To TitleAllocationParent
   	 *  Date:30-Nov-2017 
   	 ****************************************/
	public void NavigateToTitleAllocationParent(DataRow input, DataRow output) throws InterruptedException {
		
		SleepUtils.sleep(5);
		uiDriver.click("Custom");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,1600)");
		uiDriver.click("TitleAllocationParent");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("scroll(0,600)");		       	
			uiDriver.click("TAPId");
            passed("Should click on TAPId",
                   "Should click on TAPId",
                    "Should click on TAPId");
   
		   	   		
		if (input.get("FullPayment").equals("Y")) {
		
			if(input.get("WHT").equals("Y")){
				
				String WHTAmount = input.get("WHTAmt");
		   	    double WHTAmt = Double.parseDouble(WHTAmount);	
		   	    String CashlessTax = input.get("CashlessTax");
				double FullCashlessTaxVal = Double.parseDouble(CashlessTax);
		    	double FullCashlessTaxWithWHT = FullCashlessTaxVal - WHTAmt;
		    	String FullCashlessTaxWithWHTCode = Double.toString(FullCashlessTaxWithWHT) ;
		    	String CashlessTaxAmt = uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE");
		    	String TotalTax = input.get("TotalTax");
				String TotalAmount = input.get("TotalAmount");
	          	String VAT = input.get("VAT");
				// fetching the value from title allocation parent page
				String TotalTaxAmt=uiDriver.getValue("TaxTotal");
				String TotalAmt = uiDriver.getValue("TotalAmount");
				String VATRate=uiDriver.getValue("VAT");
				String VATArr[] = VATRate.split("\\.");
				String VATActualRate = VATArr[0];
				
		    	
		    	if (CashlessTaxAmt.contains(FullCashlessTaxWithWHTCode)) {
					passed("Verifying the CashlessTax",
							"CashlessTax should be displayed as '" + CashlessTax + "' Successfully",
							"CashlessTax " + CashlessTaxAmt + " is displayed Successfully");
				} else {
					failed("Verifying the CashlessTax",
							"CashlessTaxAmt should be displayed as '" + CashlessTax + "' Successfully",
							"CashlessTax " + CashlessTaxAmt + " is not displayed Successfully");
				}
		    	
				if (input.get("TotalTax").equalsIgnoreCase(TotalTaxAmt)||input.get("TotalTax").contains(TotalTaxAmt)) {
					passed("Verifying the TotalTax", "TotalTax should be displayed as '" + TotalTax + "' Successfully",
							"TotalTax " + TotalTaxAmt + " is displayed Successfully");
				} else {
					failed("Verifying the TotalTax", "TotalTax should be displayed as '" + TotalTax + "' Successfully",
							"TotalTax " + TotalTaxAmt + " is not displayed Successfully");
				}
				if (input.get("TotalAmount").contains(TotalAmt)||input.get("TotalAmount").equalsIgnoreCase((TotalAmt))) {
					passed("Verifying the TotalAmount",
							"TotalAmount should be displayed as '" + TotalAmount + "' Successfully",
							"TotalAmount " + TotalAmt + " is displayed Successfully");
				} else {
					failed("Verifying the TotalAmount",
							"TotalAmount should be displayed as '" + TotalAmount + "' Successfully",
							"TotalAmount " + TotalAmt + " is not displayed Successfully");
				}
				if (input.get("VAT").contains(VATRate) || (input.get("VAT").contains(VATActualRate)) || input.get("VAT").equalsIgnoreCase(VATRate)) {
					passed("Verifying the VAT", "VAT should be displayed as '" + VAT + "' Successfully",
							"VAT " + VATRate + " is displayed Successfully");
				} else {
					failed("Verifying the VAT", "VAT should be displayed as '" + VAT + "' Successfully",
							"VAT " + VATRate + " is not displayed Successfully");
				} 	
				
			}
		
			else{
			String CashlessTax = input.get("CashlessTax");
			if(CashlessTax.contains(","))
			{
				CashlessTax=CashlessTax.replace(",", "");
			}
			double FullCashlessTaxVal = Double.parseDouble(CashlessTax);
	    	String TotalTax = input.get("TotalTax");
			String TotalAmount = input.get("TotalAmount");
	    	if(TotalAmount.contains(","))
			{
				TotalAmount=TotalAmount.replace(",", "");
			}
            double TotalAmount1=Double.parseDouble(TotalAmount);
			String VAT = input.get("VAT");
			// fetching the value from title allocation parent page
			
			String CashlessTaxAmt = uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE");
			if(CashlessTaxAmt.contains(","))
			{
				CashlessTaxAmt=CashlessTaxAmt.replace(",", "");
			}
			String TotalTaxAmt=uiDriver.getValue("TaxTotal");
			String TotalAmt = uiDriver.getValue("TotalAmount");
			if(TotalAmt.contains(","))
			{
				TotalAmt=TotalAmt.replace(",", "");
			}
			String VATRate=uiDriver.getValue("VAT");
			String VATArr[] = VATRate.split("\\.");
			String VATActualRate = VATArr[0];
			
			String ExpectedWHTRate = uiDriver.getValue("ExpectedWHTRate");
	 		String ExpectedWHTAmount = uiDriver.getValue("ExpectedWHTAmount");
	 		
	 		String InvoiceExchangeRate = uiDriver.getValue("InvoiceExchangeRate");			
		    double actualInvoiceExchangeRate = Double.parseDouble(InvoiceExchangeRate);
			String paymentExchangeRate = uiDriver.getValue("paymentExchangeRate");	
			double actualpaymentExchangeRate = Double.parseDouble(paymentExchangeRate);
			String gainLossAmount = uiDriver.getValue("gainLossAmount");		
			double actualgainLossAmount1=(actualInvoiceExchangeRate-actualpaymentExchangeRate)*TotalAmount1;
			String actualgainLossAmount2 = Double.toString(actualgainLossAmount1);
			

		if(input.get("GainLoss").equals("Y")) {
		   if (input.get("PaymentRate").contains(paymentExchangeRate)) {
		        passed("Verifying the  PartialCashlessTax",
				"PartialCashlessTax should be displayed as '" + paymentExchangeRate+ "' Successfully",
				"PartialCashlessTax "	+ paymentExchangeRate + " is displayed Successfully");
	          } else {
		        failed("Verifying the  PartialCashlessTax","PartialCashlessTax should be displayed as '" + paymentExchangeRate+ "' Successfully",
				"PartialCashlessTax "+ paymentExchangeRate	+ " is not displayed Successfully");
	}
		
		
		if (input.get("InvoiceRate").contains(InvoiceExchangeRate)) {
		passed("Verifying the  PartialCashlessTax",
				"PartialCashlessTax should be displayed as '" + InvoiceExchangeRate+ "' Successfully",
				"PartialCashlessTax "	+ InvoiceExchangeRate + " is displayed Successfully");
		} else {
				failed("Verifying the  PartialCashlessTax","PartialCashlessTax should be displayed as '" + InvoiceExchangeRate+ "' Successfully",
				"PartialCashlessTax "+ InvoiceExchangeRate	+ " is not displayed Successfully");
		}
			 		 			 		
		if (gainLossAmount.contains(actualgainLossAmount2)) {
		passed("Verifying the  PartialCashlessTax",
				"PartialCashlessTax should be displayed as '" + gainLossAmount+ "' Successfully",
				"PartialCashlessTax "	+ gainLossAmount + " is displayed Successfully");
		} else {
		failed("Verifying the  PartialCashlessTax","PartialCashlessTax should be displayed as '" + gainLossAmount+ "' Successfully",
				"PartialCashlessTax "+ gainLossAmount	+ " is not displayed Successfully");
		}
					
	}

			if (input.get("CashlessTax").contains(CashlessTaxAmt) || CashlessTax.contains(CashlessTaxAmt)) {
				passed("Verifying the CashlessTax",
						"CashlessTax should be displayed as '" + CashlessTax + "' Successfully",
						"CashlessTax " + CashlessTaxAmt + " is displayed Successfully");
			} else {
				failed("Verifying the CashlessTax",
						"CashlessTaxAmt should be displayed as '" + CashlessTax + "' Successfully",
						"CashlessTax " + CashlessTaxAmt + " is not displayed Successfully");
			}
			if (input.get("TotalTax").equalsIgnoreCase(TotalTaxAmt)||input.get("TotalTax").contains(TotalTaxAmt) || TotalAmt.contains(TotalTaxAmt)) {
				passed("Verifying the TotalTax", "TotalTax should be displayed as '" + TotalTax + "' Successfully",
						"TotalTax " + TotalTaxAmt + " is displayed Successfully");
			} else {
				failed("Verifying the TotalTax", "TotalTax should be displayed as '" + TotalTax + "' Successfully",
						"TotalTax " + TotalTaxAmt + " is not displayed Successfully");
			}
			if (input.get("TotalAmount").contains(TotalAmt)||input.get("TotalAmount").equalsIgnoreCase((TotalAmt))) {
				passed("Verifying the TotalAmount",
						"TotalAmount should be displayed as '" + TotalAmount + "' Successfully",
						"TotalAmount " + TotalAmt + " is displayed Successfully");
			} else {
				failed("Verifying the TotalAmount",
						"TotalAmount should be displayed as '" + TotalAmount + "' Successfully",
						"TotalAmount " + TotalAmt + " is not displayed Successfully");
			}
			if (input.get("VAT").contains(VATRate) || (input.get("VAT").contains(VATActualRate)) || input.get("VAT").equalsIgnoreCase(VATRate)) {
				passed("Verifying the VAT", "VAT should be displayed as '" + VAT + "' Successfully",
						"VAT " + VATRate + " is displayed Successfully");
			} else {
				failed("Verifying the VAT", "VAT should be displayed as '" + VAT + "' Successfully",
						"VAT " + VATRate + " is not displayed Successfully");
			}
		}
		}		
			
		if (input.get("PartialPayment").equals("Y")) {
			
			String PartialCashlessTax = input.get("PartialCashlessTax");
			String PartialTaxAmt = input.get("PartialTaxAmt");
			String PartialTotalAmt = input.get("PartialTotalAmt");
			double actualPartialTotalAmt = Double.parseDouble(PartialTotalAmt);	
			String VAT = input.get("VAT");
			// fetching the value from title allocation parent page
			String CashlessTaxAmt = uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE").substring(0,uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE").length() - 1);
			if(CashlessTaxAmt.contains(","))
			{
				CashlessTaxAmt=CashlessTaxAmt.replace(",", "");
			}
			String PartialTaxAmount = uiDriver.getValue("TaxTotal").substring(0,uiDriver.getValue("TaxTotal").length() - 1);
			if(PartialTaxAmount.contains(","))
			{
				PartialTaxAmount=PartialTaxAmount.replace(",", "");
			}
			String PartialTaxTotalAmt = uiDriver.getValue("PartialTotalAmount").substring(0,uiDriver.getValue("TaxTotal").length() - 1);
			if(PartialTaxTotalAmt.contains(","))
			{
				PartialTaxTotalAmt=PartialTaxTotalAmt.replace(",", "");
			}
			String VATArr[] = uiDriver.getValue("VAT").split("\\.");
			String VATRate = VATArr[0];
			String InvoiceExchangeRate = uiDriver.getValue("InvoiceExchangeRate");
	 		double actualInvoiceExchangeRate = Double.parseDouble(InvoiceExchangeRate);
	 		String paymentExchangeRate = uiDriver.getValue("paymentExchangeRate");
	 		double actualpaymentExchangeRate = Double.parseDouble(paymentExchangeRate);
	 		String gainLossAmount = uiDriver.getValue("gainLossAmount");
	 		double actualgainLossAmount1=(actualInvoiceExchangeRate-actualpaymentExchangeRate)*actualPartialTotalAmt;
	 		String actualgainLossAmount2 = Double.toString(actualgainLossAmount1);
	 		
	 		if(input.get("PartialGainLoss").equals("Y")){
	 		if (input.get("PaymentRate").contains(paymentExchangeRate)) {
				passed("Verifying the  PartialCashlessTax",
						"PartialCashlessTax should be displayed as '" + paymentExchangeRate+ "' Successfully",
						"PartialCashlessTax "	+ paymentExchangeRate + " is displayed Successfully");
			} else {
				failed("Verifying the  PartialCashlessTax","PartialCashlessTax should be displayed as '" + paymentExchangeRate+ "' Successfully",
						"PartialCashlessTax "+ paymentExchangeRate	+ " is not displayed Successfully");
			}
	 		
	 		
	 		if (input.get("InvoiceRate").contains(InvoiceExchangeRate)) {
				passed("Verifying the  PartialCashlessTax",
						"PartialCashlessTax should be displayed as '" + InvoiceExchangeRate+ "' Successfully",
						"PartialCashlessTax "	+ InvoiceExchangeRate + " is displayed Successfully");
			} else {
				failed("Verifying the  PartialCashlessTax","PartialCashlessTax should be displayed as '" + InvoiceExchangeRate+ "' Successfully",
						"PartialCashlessTax "+ InvoiceExchangeRate	+ " is not displayed Successfully");
			}
	 			 		 			 		
	 		if (gainLossAmount.contains(actualgainLossAmount2)) {
				passed("Verifying the  PartialCashlessTax",
						"PartialCashlessTax should be displayed as '" + gainLossAmount+ "' Successfully",
						"PartialCashlessTax "	+ gainLossAmount + " is displayed Successfully");
			} else {
				failed("Verifying the  PartialCashlessTax","PartialCashlessTax should be displayed as '" + gainLossAmount+ "' Successfully",
						"PartialCashlessTax "+ gainLossAmount	+ " is not displayed Successfully");
			}
	 }		

			// put it in array using split
			if (input.get("PartialCashlessTax").contains(CashlessTaxAmt)||CashlessTaxAmt.contains(input.get("PartialCashlessTax"))) {
				passed("Verifying the PartialCashlessTax",
						"PartialCashlessTax should be displayed as '" + PartialCashlessTax + "' Successfully",
						"PartialCashlessTax " + CashlessTaxAmt + " is displayed Successfully");
			} else {
				failed("Verifying the PartialCashlessTax",
						"PartialCashlessTax should be displayed as '" + PartialCashlessTax + "' Successfully",
						"PartialCashlessTax " + CashlessTaxAmt + " is not displayed Successfully");
			}
			if (input.get("PartialTaxAmt").contains(PartialTaxAmount)||PartialTaxAmount.contains(input.get("PartialTaxAmt"))) {
				passed("Verifying the PartialTaxAmt",
						"PartialTaxAmt should be displayed as '" + PartialTaxAmt + "' Successfully",
						"PartialTaxAmt " + PartialTaxAmount + " is displayed Successfully");
			} else {
				failed("Verifying the PartialTaxAmt",
						"TotalTax should be displayed as '" + PartialTaxAmt + "' Successfully",
						"PartialTaxAmt " + PartialTaxAmount + " is not displayed Successfully");
			}
			if (input.get("PartialTotalAmt").contains(PartialTaxTotalAmt)||PartialTaxTotalAmt.contains(input.get("PartialTotalAmt"))) {
				passed("Verifying the PartialTotalAmt",
						"PartialTotalAmt should be displayed as '" + PartialTaxTotalAmt + "' Successfully",
						"PartialTotalAmt " + PartialTaxTotalAmt + " is displayed Successfully");
			} else {
				failed("Verifying the PartialTotalAmt",
						"PartialTotalAmt should be displayed as '" + PartialTaxTotalAmt + "' Successfully",
						"PartialTotalAmt " + PartialTaxTotalAmt + " is not displayed Successfully");
			}
			if (input.get("VAT").contains(VATRate)) {
				passed("Verifying the VAT", "VAT should be displayed as '" + VATRate + "' Successfully",
						"VAT " + VATRate + " is displayed Successfully");
			} else {
				failed("Verifying the VAT", "VAT should be displayed as '" + VATRate + "' Successfully",
						"VAT " + VATRate + " is not displayed Successfully");
			}
		}
		if (input.get("EditPayment").equals("Y")) {
			String PayPartialCashlessTax = input.get("PayPartialCashlessTax");
			String payPartialTaxAmt = input.get("payPartialTaxAmt");
			String payPartialTotalAmt = input.get("payPartialTotalAmt");
			
			// fetching the value from title allocation parent page
			String CashlessTaxAmt = uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE").substring(0,uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE").length()-1);
			String PartialTaxAmount = uiDriver.getValue("TaxTotal");
			String PartialTaxTotalAmt = uiDriver.getValue("PartialTotalAmount");
			String VAT = uiDriver.getValue("VAT").substring(0,uiDriver.getValue("VAT").length() - 1);
			// put it in array using split
			if (PartialTaxTotalAmt.contains(input.get("PayPartialCashlessTax"))|input.get("PayPartialCashlessTax").equalsIgnoreCase(PartialTaxTotalAmt)) {
				passed("Verifying the PartialpayCashlessTax",
						"PartialpayCashlessTax should be displayed as '" + PayPartialCashlessTax + "' Successfully",
						"PartialCashlessTax " + PartialTaxTotalAmt + " is displayed Successfully");
			} else {
				failed("Verifying the PartialpayCashlessTax",
						"PartialpayCashlessTax should be displayed as '" + PayPartialCashlessTax + "' Successfully",
						"PartialCashlessTax " + PartialTaxTotalAmt + " is not displayed Successfully");
			}
			if (input.get("payPartialTaxAmt").contains(PartialTaxAmount)|input.get("payPartialTaxAmt").equalsIgnoreCase(PartialTaxAmount)) {
				passed("Verifying the PartialpayTaxAmt",
						"PartialpayTaxAmt should be displayed as '" + payPartialTaxAmt + "' Successfully",
						"PartialTaxAmt " + PartialTaxAmount + " is displayed Successfully");
			} else {
				failed("Verifying the PartialTaxAmt",
						"TotalTax should be displayed as '" + payPartialTaxAmt + "' Successfully",
						"PartialTaxAmt " + PartialTaxAmount + " is not displayed Successfully");
			}
			if (input.get("payPartialTotalAmt").contains(CashlessTaxAmt)|input.get("payPartialTotalAmt").equalsIgnoreCase(CashlessTaxAmt)) {
				passed("Verifying the PartialTotalAmt",
						"PartialTotalAmt should be displayed as '" + payPartialTotalAmt + "' Successfully",
						"PartialTotalAmt " + CashlessTaxAmt + " is displayed Successfully");
			} else {
				failed("Verifying the PartialTotalAmt",
						"PartialTotalAmt should be displayed as '" + payPartialTotalAmt + "' Successfully",
						"PartialTotalAmt " + CashlessTaxAmt + " is not displayed Successfully");
			}
			
		}
		
		if (input.get("RestPartialPayment").equals("Y")) {
			
			
			if(input.get("WHT").equals("Y")){
				
			 String WHTAmount = input.get("WHTAmt");
	   	     double WHTAmt = Double.parseDouble(WHTAmount);
	   	     String RestPartialCashlessTax = input.get("RestPartialCashlessTax");
			double RestPartialCashlessTaxVal = Double.parseDouble(RestPartialCashlessTax);
	    	double RestPartialCashlessTaxWithWHT = RestPartialCashlessTaxVal - WHTAmt;
	    	String RestPartialCashlessTaxWithWHTCode = Double.toString(RestPartialCashlessTaxWithWHT) ;
	    	String CashlessTaxAmt = uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE").substring(0,uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE").length() - 1);
	    	String TotalTax = input.get("TotalTax");
			String TotalAmount = input.get("TotalAmount");
         	String VAT = input.get("VAT");
			// fetching the value from title allocation parent page
			String RestPartialTaxAmt = input.get("RestPartialTaxAmt");
			String RestPartialTotalAmt = input.get("RestPartialTotalAmt");
			 double actualRestPartialTotalAmt=Double.parseDouble(RestPartialTotalAmt);
		// fetching the value from title allocation parent page
			String PartialTaxAmount = uiDriver.getValue("TaxTotal").substring(0,uiDriver.getValue("TaxTotal").length() - 1);
			String PartialTotalAmount = uiDriver.getValue("TotalAmount").substring(0,uiDriver.getValue("TotalAmount").length() - 1);
			String VATArr[] = uiDriver.getValue("VAT").split("\\.");
			String VATRate = VATArr[0];   	
	    	
	    	if (RestPartialCashlessTaxWithWHTCode .contains(CashlessTaxAmt)) {
				passed("Verifying the RestPartialCashlessTax",
						"RestPartialCashlessTax should be displayed as '" + RestPartialCashlessTax + "' Successfully",
						"RestPartialCashlessTax " + CashlessTaxAmt + " is displayed Successfully");
			} else {
				failed("Verifying the RestPartialCashlessTax",
						"RestPartialCashlessTax should be displayed as '" + RestPartialCashlessTax + "' Successfully",
						"RestPartialCashlessTax " + CashlessTaxAmt + " is not displayed Successfully");
			}
	    	
	    	if (input.get("RestPartialTaxAmt").contains(PartialTaxAmount)|input.get("RestPartialTaxAmt").equalsIgnoreCase(PartialTaxAmount)) {
				passed("Verifying the RestPartialTaxAmt",
						"RestPartialTaxAmt should be displayed as '" + RestPartialTaxAmt + "' Successfully",
						"RestPartialTaxAmt " + PartialTaxAmount + " is displayed Successfully");
			} else {
				failed("Verifying the RestPartialTaxAmt",
						"TotalTax should be displayed as '" + RestPartialTaxAmt + "' Successfully",
						"RestPartialTaxAmt " + PartialTaxAmount + " is not displayed Successfully");
			}
			if (input.get("RestPartialTotalAmt").contains(RestPartialTotalAmt)) {
				passed("Verifying the RestPartialTotalAmt",
						"RestPartialTotalAmt should be displayed as '" + PartialTotalAmount + "' Successfully",
						"RestPartialTotalAmt " + PartialTotalAmount + " is displayed Successfully");
			} else {
				failed("Verifying the RestPartialTotalAmt",
						"RestPartialTotalAmt should be displayed as '" + PartialTotalAmount + "' Successfully",
						"RestPartialTotalAmt " + PartialTotalAmount + " is not displayed Successfully");
			}
			if (input.get("VAT").contains(VATRate)) {
				passed("Verifying the VAT", "VAT should be displayed as '" + VAT + "' Successfully",
						"VAT " + VATRate + " is displayed Successfully");
			} else {
				failed("Verifying the VAT", "VAT should be displayed as '" + VAT + "' Successfully",
						"VAT " + VATRate + " is not displayed Successfully");
			}
			}	
	    	
		else{
			
			String RestPartialCashlessTax = input.get("RestPartialCashlessTax");
			double RestPartialCashlessTaxVal = Double.parseDouble(RestPartialCashlessTax);
	    	String RestPartialTaxAmt = input.get("RestPartialTaxAmt");
			String RestPartialTotalAmt = input.get("RestPartialTotalAmt");
			 double actualRestPartialTotalAmt=Double.parseDouble(RestPartialTotalAmt);
			String VAT = input.get("VAT");
			// fetching the value from title allocation parent page
			String CashlessTaxAmt = uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE").substring(0,uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE").length() - 1);
			if(CashlessTaxAmt.contains(","))
			{
				CashlessTaxAmt=CashlessTaxAmt.replace(",", "");
			}
			String PartialTaxAmount = uiDriver.getValue("TaxTotal").substring(0,uiDriver.getValue("TaxTotal").length() - 1);
			if(PartialTaxAmount.contains(","))
			{
				PartialTaxAmount=PartialTaxAmount.replace(",", "");
			}
			String PartialTotalAmount = uiDriver.getValue("TotalAmount").substring(0,uiDriver.getValue("TotalAmount").length() - 1);
			if(PartialTotalAmount.contains(","))
			{
				PartialTotalAmount=PartialTotalAmount.replace(",", "");
			}
			
			String VATArr[] = uiDriver.getValue("VAT").split("\\.");
			String VATRate = VATArr[0];
			//Gain/loss Validation
	 		String InvoiceExchangeRate = uiDriver.getValue("InvoiceExchangeRate");
	 		//.substring(0, uiDriver.getValue("InvoiceExchangeRate").length()-1);
	 		double actualInvoiceExchangeRate = Double.parseDouble(InvoiceExchangeRate);
	 		String paymentExchangeRate = uiDriver.getValue("paymentExchangeRate");
	 		//.substring(0, uiDriver.getValue("paymentExchangeRate").length()-1);
	 		double actualpaymentExchangeRate = Double.parseDouble(paymentExchangeRate);
	 		String gainLossAmount = uiDriver.getValue("gainLossAmount");
	 		//.substring(0, uiDriver.getValue("gainLossAmount").length()-1);
	 		//double actualgainLossAmount = Double.parseDouble(gainLossAmount);
	 		double actualgainLossAmount1=(actualInvoiceExchangeRate-actualpaymentExchangeRate)*actualRestPartialTotalAmt;
	 		String actualgainLossAmount2 = Double.toString(actualgainLossAmount1);
	 		
	 		if(input.get("RestGainLoss").equals("Y")){
	 		
	 		if (input.get("PaymentRate").contains(paymentExchangeRate)) {
				passed("Verifying the  PartialCashlessTax",
						"PartialCashlessTax should be displayed as '" + paymentExchangeRate+ "' Successfully",
						"PartialCashlessTax "	+ paymentExchangeRate + " is displayed Successfully");
			} else {
				failed("Verifying the  PartialCashlessTax","PartialCashlessTax should be displayed as '" + paymentExchangeRate+ "' Successfully",
						"PartialCashlessTax "+ paymentExchangeRate	+ " is not displayed Successfully");
			}
	 		
	 		
	 		if (input.get("InvoiceRate").contains(InvoiceExchangeRate)) {
				passed("Verifying the  PartialCashlessTax",
						"PartialCashlessTax should be displayed as '" + InvoiceExchangeRate+ "' Successfully",
						"PartialCashlessTax "	+ InvoiceExchangeRate + " is displayed Successfully");
			} else {
				failed("Verifying the  PartialCashlessTax","PartialCashlessTax should be displayed as '" + InvoiceExchangeRate+ "' Successfully",
						"PartialCashlessTax "+ InvoiceExchangeRate	+ " is not displayed Successfully");
			}
	 			 		 			 		
	 		if (gainLossAmount.contains(actualgainLossAmount2)) {
				passed("Verifying the  PartialCashlessTax",
						"PartialCashlessTax should be displayed as '" + gainLossAmount+ "' Successfully",
						"PartialCashlessTax "	+ gainLossAmount + " is displayed Successfully");
			} else {
				failed("Verifying the  PartialCashlessTax","PartialCashlessTax should be displayed as '" + gainLossAmount+ "' Successfully",
						"PartialCashlessTax "+ gainLossAmount	+ " is not displayed Successfully");
			}
	 		
	 }
	 		
	 		
	 		
	 		
	 		
	 		
	 		
	 		
			if (input.get("RestPartialCashlessTax").contains(CashlessTaxAmt)) {
				passed("Verifying the RestPartialCashlessTax",
						"RestPartialCashlessTax should be displayed as '" + RestPartialCashlessTax + "' Successfully",
						"RestPartialCashlessTax " + CashlessTaxAmt + " is displayed Successfully");
			} else {
				failed("Verifying the RestPartialCashlessTax",
						"RestPartialCashlessTax should be displayed as '" + RestPartialCashlessTax + "' Successfully",
						"RestPartialCashlessTax " + CashlessTaxAmt + " is not displayed Successfully");
			}
			if (input.get("RestPartialTaxAmt").contains(PartialTaxAmount)|input.get("RestPartialTaxAmt").equalsIgnoreCase(PartialTaxAmount)) {
				passed("Verifying the RestPartialTaxAmt",
						"RestPartialTaxAmt should be displayed as '" + RestPartialTaxAmt + "' Successfully",
						"RestPartialTaxAmt " + PartialTaxAmount + " is displayed Successfully");
			} else {
				failed("Verifying the RestPartialTaxAmt",
						"TotalTax should be displayed as '" + RestPartialTaxAmt + "' Successfully",
						"RestPartialTaxAmt " + PartialTaxAmount + " is not displayed Successfully");
			}
			if (input.get("RestPartialTotalAmt").contains(RestPartialTotalAmt)) {
				passed("Verifying the RestPartialTotalAmt",
						"RestPartialTotalAmt should be displayed as '" + PartialTotalAmount + "' Successfully",
						"RestPartialTotalAmt " + PartialTotalAmount + " is displayed Successfully");
			} else {
				failed("Verifying the RestPartialTotalAmt",
						"RestPartialTotalAmt should be displayed as '" + PartialTotalAmount + "' Successfully",
						"RestPartialTotalAmt " + PartialTotalAmount + " is not displayed Successfully");
			}
			if (input.get("VAT").contains(VATRate)) {
				passed("Verifying the VAT", "VAT should be displayed as '" + VAT + "' Successfully",
						"VAT " + VATRate + " is displayed Successfully");
			} else {
				failed("Verifying the VAT", "VAT should be displayed as '" + VAT + "' Successfully",
						"VAT " + VATRate + " is not displayed Successfully");
			}
			}	

       if(input.get("CashAdjCode").equals("Y")){
    	   
    	  String WHtAmount = uiDriver.getValue("WHTAmountCashAdjCode");
    	  if(input.get("WHTAmt").contains(WHtAmount)){
    		  passed("Verifying the  WHtAmount",
						"WHtAmount should be displayed as '" + WHtAmount+ "' Successfully",
						"WHtAmount "	+ WHtAmount + " is displayed Successfully");
			} else {
				failed("Verifying the  WHtAmount",	"WHtAmount should be displayed as '" + WHtAmount+ "' Successfully",
						"WHtAmount "+ WHtAmount + " is not displayed Successfully");
			}  
    		  
    		  
    	  }
    	  		  
    	  
    	   
       }
   
	}
		
	
       
   /****************************************
 	 * Name: MRAdjustAllocatedCashbyTitle
     * Description:Method to MRAdjustAllocatedCashbyTitle
     * Date:30-Nov-2017 
  
   ****************************************/   
	public void MRAdjustAllocatedCashbyTitle(DataRow input, DataRow output)throws InterruptedException, ParseException
	{
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Customization");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Scripting");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Scripts");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Scripts");
		SleepUtils.sleep(TimeSlab.YIELD);
		if(uiDriver.checkElementPresent("EditBtnMRAdjustAllocatedCash"))
		{
			uiDriver.click("EditBtnMRAdjustAllocatedCash");
		}
		else
		{
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("EditBtnMRAdjustAllocatedCash");
		}
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("deployments");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("manualscript");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("edit");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.mouseOver("SaveBtndropdown");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("SaveAndExecute");
		uiDriver.handleAlert("", "OK");
		uiDriver.click("refresh");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("refresh");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refresh");
		uiDriver.click("refresh");
		uiDriver.click("refresh");
		uiDriver.click("refresh");
				
	}	
	/****************************************
 	 * Name: MRSORevisionCBT
     * Description:Method to run MRSORevisionCBT
     * Date:30-Nov-2017 
  
   ****************************************/   
	public void MRSORevisionCBT(DataRow input, DataRow output)throws InterruptedException, ParseException
	{
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Customization");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Scripting");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Scripts");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Scripts");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("EditBtnMRSORevision");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("SaveBtndropdown");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("SaveAndExecute");
		uiDriver.handleAlert("", "OK");
		uiDriver.click("refresh");	
		SleepUtils.sleep(30);
		uiDriver.click("refresh");		
		SleepUtils.sleep(TimeSlab.YIELD);
		
	}
	
	
	/****************************************
 	 * Name: RevisionInvoiceCreditMR
     * Description:Method to run RevisionInvoiceCreditMR
     * Date:30-Nov-2017 
  
   ****************************************/   
	public void RevisionInvoiceCreditMR(DataRow input, DataRow output)throws InterruptedException, ParseException
	{
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Customization");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Scripting");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Scripts");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Scripts");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("EditInvoiceCredit");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("SaveBtndropdown");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("SaveAndExecute");
		uiDriver.handleAlert("", "OK");
		uiDriver.click("refresh");	
		SleepUtils.sleep(30);
		uiDriver.click("refresh");			
		
	}
	
	
	
	
	/****************************************
   	 * Name: Edit Payment
   	 * Description:Method to edit payment
   	 *  Date:30-Nov-2017 
   	 ****************************************/
	public void EditPayment(DataRow input, DataRow output) throws InterruptedException {
		String invoicenum = input.get("invoicenumber");
		
		uiDriver.click("EditPayment");
        SleepUtils.sleep(TimeSlab.HIGH);
        uiDriver.executeJavaScript("scroll(0,-500)");
    	                      
        
        uiDriver.click("PaymentAmt");
        uiDriver.executeJavaScript("document.getElementById('payment_formattedValue').value = ''");
        SleepUtils.sleep(2);
        
        uiDriver.setValue("PaymentAmt", input.get("PartialTotalAmt"));
        if(input.get("Unappply").equals("N"))
        {
        String partialpayment = uiDriver.getDyanmicData("partialpaymentfield");
        SleepUtils.sleep(TimeSlab.YIELD);
        String ReferenceVal1 = partialpayment.replace("#", invoicenum);
        SleepUtils.sleep(TimeSlab.YIELD);
        uiDriver.executeJavaScript("scroll(0,500)");
       // uiDriver.executeJavaScript("document.getElementById('payment_formattedValue').value = '"+ input.get("PartialTotalAmt") + "'");
        uiDriver.click_dynamic(ReferenceVal1);
        uiDriver.click_dynamic(ReferenceVal1);
        }
        uiDriver.executeJavaScript("scroll(0,-1000)");
        uiDriver.click("acctradiobutton");
		SleepUtils.sleep(TimeSlab.YIELD);
		 uiDriver.setValue("Account", "30 Undeposited Funds");
		 SleepUtils.sleep(TimeSlab.HIGH);
        //uiDriver.click("Save");
        SleepUtils.sleep(TimeSlab.YIELD);
        uiDriver.executeJavaScript("document.getElementById('btn_multibutton_submitter').click();");
        passed("Edit Payment", "Payment should edited be successfully",
                "Payment is edited successfully");
        String PaymentNumber = uiDriver.getValue("PaymentNumber");
        SleepUtils.sleep(TimeSlab.LOW);
        output.put("PaymentNumber", PaymentNumber);
        SleepUtils.sleep(TimeSlab.LOW);
       
	}
	
	/****************************************
 	 * Name: VerifyJournalsafterMRAdjust
     * Description:Verify Journals after MRAdjust
     * Date:30-Nov-2017 
   ****************************************/   
	public void VerifyJournalsafterMRAdjust(DataRow input, DataRow output) throws InterruptedException
	{
		SleepUtils.sleep(2);
		uiDriver.click("Custom");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("scroll(0,900)");
		uiDriver.click("TitleAllocationParent");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("TAPId");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("checkjournals");
		SleepUtils.sleep(TimeSlab.LOW);
		int accRows = uiDriver.webDr.findElements(By.xpath("//table[@id='recmachcustbody_nbcu_titleallocation__tab']/tbody/tr")).size();
		int invoiceRow = 2;
		for (int r = 1; r < accRows + 1; r++) {
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.executeJavaScript("scroll(0,-200)");
			uiDriver.click("checkjournals");
			uiDriver.executeJavaScript("scroll(0,900)");
			String s1 = uiDriver.getDyanmicData("DocNum");
			String s2 = s1.replace("#", Integer.toString(r));
			if (uiDriver.checkElementPresent_dynamic(s2)) {

				uiDriver.click(s2);
				uiDriver.executeJavaScript("scroll(0,800)");
				int transRows = uiDriver.webDr.findElements(By.xpath("//*[@id='line_splits']//tbody/tr")).size();
				for (int i = 0; i < transRows - 1; i++) {
					uiDriver.executeJavaScript("scroll(0,100);");
					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Deferred Rev - Unpaid"))
					{

						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[2]").equals(""))

						{

							failed("Validating Debit Amount",
							"Validating Debit Amount should be successfull",
							"Debit amount is not Deferred Rev - Unpaid");

						}

						else
						{

							passed("Debit is Deferred Rev - Unpaid",
							"Debit is Deferred Rev - Unpaid",
							"Debit amount is Deferred Rev - Unpaid");

						}

					}

					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Generic Billed"))
					{

						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[2]").equals(""))

						{

							failed("Validating Debit Amount",
							"Validating Debit Amount should be successfull",
							"Debit amount is not Generic Billed");

						}

						else
						{

							passed("Debit is Generic Billed",
							"Debit is Deferred Rev - Unpaid",
							"Debit amount is Generic Billed");

						}

					}

					
					
					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Contract revenue - Dom"))
					{
						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals(""))
						{

							failed("Validating Credit Amount",
							"Validating Debit Amount should be successfull",
							"Credit amount is not Contract revenue - Dom");

						}

						else
						{
							passed("Credit is Deferred Rev - Generic",
							"Credit is Bad Debt",
							"Credit amount is Contract revenue - Dom");
						}
					}

					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Undeposited"))
					{
						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals(""))
						{

							failed("Validating Debit Amount",
							"Validating Debit Amount should be successfull",
						   "Debit amount is not Billed Dom AR");
						}

						else
						{
							passed("Debit is Billed Dom AR",
							"Debit is Billed Dom AR",
							"Debit amount is Billed Dom AR");
						}
					}

					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Billed Dom"))
					{
						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals(""))
						{

							failed("Validating Debit Amount",
							"Validating Credit Amount should be successfull",
							"Credit amount is not Billed Dom");

						}

						else
						{
							passed("Credit is Billed Dom",
							"Credit is Billed Dom",
							"Credit amount is Billed Dom");
						}

					}

					invoiceRow++;

				}

				uiDriver.executeJavaScript("scroll(0,800)");
				SleepUtils.sleep(5);
				uiDriver.click("Back1");
				invoiceRow = 2;
				SleepUtils.sleep(5);
				SleepUtils.sleep(5);
			} else

			{

			}

		}

	}

	
	/****************************************
 	 * Name: NavigateToTitleAllocationChild
     * Description:NavigateToTitleAllocationChild
     * Date:30-Nov-2017 
   ****************************************/   
	public void NavigateToTitleAllocationChild(DataRow input, DataRow output) throws InterruptedException 
    {
		SleepUtils.sleep(5);
		uiDriver.executeJavaScript("scroll(0,500)");
		SleepUtils.sleep(5);
			uiDriver.click("AllocationDetail");
			SleepUtils.sleep(5);
            int accRows = uiDriver.webDr.findElements(By.xpath("//table[@id='recmachcustrecord_nbcu_titleallocch_parent__tab']/tbody/tr")).size();
            for(int i=0;i<accRows;i++)
            {
                String s1= uiDriver.getDyanmicData("ARAmount");
                String s2=s1.replace("#", Integer.toString(i));
                if(uiDriver.checkElementPresent_dynamic(s2)){
                	
                    String ARAmount=uiDriver.getValue(s2);
                    passed("Verify AR Amount "+ARAmount+"",
                           "SuccessFully Verified AR Amount "+ARAmount+"",
                            "SuccessFully Verified AR Amount "+ARAmount+"");
           }

           String s3= uiDriver.getDyanmicData("WHTAmount");
           String s4=s3.replace("#", Integer.toString(i));
           if(uiDriver.checkElementPresent_dynamic(s4)){
              String WHTAmount=uiDriver.getValue(s4);
              passed("Verify WHT Amount "+WHTAmount+"",
                     "SuccessFully Verified WHT Amount "+WHTAmount+"",
                      "SuccessFully Verified WHT Amount "+WHTAmount+"");
          }

          String s5= uiDriver.getDyanmicData("VATAmount");
          String s6=s5.replace("#", Integer.toString(i));
          if(uiDriver.checkElementPresent_dynamic(s6)){
            String VATAmount=uiDriver.getValue(s6);
            passed("Verify VAT Amount "+VATAmount+"",
                   "SuccessFully Verified WHT Amount "+VATAmount+"",
                   "SuccessFully Verified WHT Amount "+VATAmount+"");
          }
          String s7= uiDriver.getDyanmicData("CACAmount");
          String s8=s7.replace("#", Integer.toString(i));
          if(uiDriver.checkElementPresent_dynamic(s8)){
               String CACAmount=uiDriver.getValue(s8);
               passed("Verify CAC Amount "+CACAmount+"",
                      "SuccessFully Verified WHT Amount "+CACAmount+"",
                      "SuccessFully Verified WHT Amount "+CACAmount+"");
               SleepUtils.sleep(10);
               
            }
       }
    } 



    /****************************************
 	 * Name: VerifyingFullPayment
     * VerifyingFullPayment
     * Date:28-Feb-2017 
     ****************************************/  
	public void VerifyingFullPayment(DataRow input, DataRow output) throws InterruptedException

	{
	     SleepUtils.sleep(TimeSlab.LOW);   
        String invoicenum = uiDriver.getValue("invoicenum");
        SleepUtils.sleep(TimeSlab.LOW);                        
        uiDriver.executeJavaScript("scroll(0,-500)");
        uiDriver.click("AcceptPayment");
        passed("AcceptPayment", "Should be clicked successfully",
                "AcceptPayment button is clicked successfully");
        
        if(input.get("UK_Currency").equals("Y")){
       	 uiDriver.click("exchangeRate");
       	 
       	 uiDriver.handleAlert("", "OK");
       	 //uiDriver.setValue("exchangeRate", input.get("exchangeRate"));
       	 uiDriver.executeJavaScript("document.getElementById('exchangerate_formattedValue').value='"+input.get("exchangeRate")+"';");
       	 uiDriver.handleAlert("", "OK");
       	 String exchangeRate = uiDriver.getValue("exchangeRate");
            output.put("exchangeRate", exchangeRate);
        }
        
        SleepUtils.sleep(TimeSlab.YIELD);
        String partialpayment = uiDriver.getDyanmicData("partialpaymentfield");
        SleepUtils.sleep(TimeSlab.YIELD);
        String ReferenceVal1 = partialpayment.replace("#", invoicenum);
        SleepUtils.sleep(TimeSlab.YIELD);
        uiDriver.executeJavaScript("scroll(0,500)");
        //uiDriver.click("PaymentAmt");
        //uiDriver.executeJavaScript("document.getElementById('payment_formattedValue').value = ''");
        //SleepUtils.sleep(2);
        
        //uiDriver.setValue("PaymentAmt", input.get("PartialTotalAmt"));
        SleepUtils.sleep(TimeSlab.LOW);
        
       // uiDriver.executeJavaScript("document.getElementById('payment_formattedValue').value = '"+ input.get("PartialTotalAmt") + "'");
        if(uiDriver.checkElementPresent_dynamic(ReferenceVal1)){
       	 
     	   SleepUtils.sleep(10);
     	   uiDriver.click_dynamic(ReferenceVal1);
            uiDriver.click_dynamic(ReferenceVal1);  
       }
        else{
      	   
      	   SleepUtils.sleep(TimeSlab.LOW);
      	   uiDriver.click("FilterNumber");
      	   uiDriver.click("FirstFilteringNumber");
      	   uiDriver.executeJavaScript("scroll(0,800)");
      	   SleepUtils.sleep(TimeSlab.LOW);
      	  if(uiDriver.checkElementPresent_dynamic(ReferenceVal1)){
            
      		uiDriver.click_dynamic(ReferenceVal1);
             uiDriver.click_dynamic(ReferenceVal1); 
      	    SleepUtils.sleep(TimeSlab.MEDIUM);
      	  }
      	  else{
      		  
      	   SleepUtils.sleep(TimeSlab.LOW);
      	  uiDriver.executeJavaScript("scroll(0,-800)");
        	   uiDriver.click("FilterNumber");
        	   uiDriver.click("SecondFilteringNumber");
        	   uiDriver.executeJavaScript("scroll(0,800)");
        	   SleepUtils.sleep(TimeSlab.LOW);
        	  if(uiDriver.checkElementPresent_dynamic(ReferenceVal1)){
              
        		uiDriver.click_dynamic(ReferenceVal1);
               uiDriver.click_dynamic(ReferenceVal1); 
        	    SleepUtils.sleep(TimeSlab.MEDIUM);
        	    
        	  }
        	  else{
        		  
        		 SleepUtils.sleep(TimeSlab.LOW);
        		 uiDriver.executeJavaScript("scroll(0,-800)");
          	   uiDriver.click("FilterNumber");
          	   uiDriver.click("ThirdFilteringNumber");
          	   uiDriver.executeJavaScript("scroll(0,800)");
          	   SleepUtils.sleep(TimeSlab.LOW);
          	  if(uiDriver.checkElementPresent_dynamic(ReferenceVal1)){
                
          		uiDriver.click_dynamic(ReferenceVal1);
                 uiDriver.click_dynamic(ReferenceVal1); 
          	    SleepUtils.sleep(TimeSlab.MEDIUM);
          	    
          	  }
        	  }
      		  
      	  }
      	   
         }
        
        if(input.get("cashAdjCode").equals("Y")){
            
       	 SleepUtils.sleep(TimeSlab.LOW);
       	 uiDriver.click("CashAdjCode");
           SleepUtils.sleep(2);
           uiDriver.click("CashAdjCode1");
           uiDriver.setValue("CashAdjCode1",input.get("CashAdjCode1"));
           SleepUtils.sleep(2);
           uiDriver.click("dropdown");
           SleepUtils.sleep(2);
           uiDriver.click("List");
           SleepUtils.sleep(2);
           uiDriver.click("searchbox");
           String invoicenumber="Invoice #"+invoicenum;
           uiDriver.setValue("searchbox",invoicenumber);
           uiDriver.click("searchbutton");
           SleepUtils.sleep(2);
           uiDriver.click("searchedinvoicecode");
           SleepUtils.sleep(2);
           uiDriver.click("WHTCode");
           uiDriver.setValue("EditWHTCode",input.get("WHTCode"));
           SleepUtils.sleep(TimeSlab.LOW);
           uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[3].click();");
           SleepUtils.sleep(TimeSlab.MEDIUM);
           uiDriver.setValue("EditWHTRate",input.get("WHTRate"));
           SleepUtils.sleep(2);
           uiDriver.click("Add");
           SleepUtils.sleep(2);
           uiDriver.click("CAshAdjCodeAmount");
           SleepUtils.sleep(3);
           String WHTAmount = uiDriver.getValue("WHTAmount");   
           uiDriver.setValue("CAshAdjCodeAmount",WHTAmount);
           String WHTpercent=uiDriver.getValue("WHTpercent"); 
           SleepUtils.sleep(2);
           uiDriver.executeJavaScript("scroll(0,-800)");
           output.put("WHTAmount", WHTAmount);
        }
        
       uiDriver.executeJavaScript("scroll(0,-500)");
       uiDriver.click("acctradiobutton");
	    SleepUtils.sleep(TimeSlab.YIELD);
			 uiDriver.setValue("Account", "11015051 USL Cash Clearing");
			 SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.setValue("ContractorName", "");
			 
			 SleepUtils.sleep(TimeSlab.YIELD);
       //uiDriver.click("SaveInvoice");
       SleepUtils.sleep(TimeSlab.YIELD);
       uiDriver.executeJavaScript("document.getElementById('btn_multibutton_submitter').click();");
       uiDriver.handleAlert("", "Leave");            
       passed("SaveInvoice", "Invoice Should be Saved successfully",
               "Invoice is Saved successfully");
       String PaymentNumber = uiDriver.getValue("PaymentNumber");
       SleepUtils.sleep(TimeSlab.LOW);
       output.put("PaymentNumber", PaymentNumber);          
        }
	
	/****************************************
	  * Name: Cash Adj Code
	  * Description:Verify Journals after MRAdjust
	  * Date:30-Nov-2017
	****************************************/

	     public void CashAdjCode(DataRow input, DataRow output)

	     {

	             uiDriver.click("Editbtn");
	            SleepUtils.sleep(2);
	            /*uiDriver.click("CashAdjCode");
	            SleepUtils.sleep(2);
	            uiDriver.click("CashAdjCode1");
	            uiDriver.setValue("CashAdjCode1",input.get("WHTCode"));
	            SleepUtils.sleep(2);
	            uiDriver.click("dropdown");
	            SleepUtils.sleep(2);
	            uiDriver.click("List");
	            SleepUtils.sleep(2);
	            uiDriver.click("searchbox");
	            String invoicenum=input.get("invoicenum");
	            String invoicenumber="Invoice #"+invoicenum;
	            //uiDriver.setValue("searchbox", invoicenumber);
	            uiDriver.setValue("searchbox", "Invoice #1C364");
	            uiDriver.click("searchbutton");
	            SleepUtils.sleep(2);
	            uiDriver.click("searchedinvoicecode");
	            SleepUtils.sleep(2);
	            uiDriver.click("WHTCode");
	            uiDriver.setValue("EditWHTCode",input.get("WHTCode"));
	            SleepUtils.sleep(TimeSlab.MEDIUM);
	           // uiDriver.click("WHTRate");
	            
	            uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[3].click();");
	            SleepUtils.sleep(TimeSlab.MEDIUM);
	            uiDriver.setValue("EditWHTRate",input.get("cashadjcode"));
	            //SleepUtils.sleep(TimeSlab.LOW);  
	           // uiDriver.executeJavaScript("document.getElementById('custrecord_nbcu_whti_wht_rate_formattedValue').value='"+input.get("cashadjcode")+"';");
	           // uiDriver.setValue("EditWHTRate",input.get("cashadjcode"));
	            SleepUtils.sleep(2);
	            uiDriver.click("Add");
	            SleepUtils.sleep(2);
	            uiDriver.click("CAshAdjCodeAmount");
	            SleepUtils.sleep(3);
	            String CACamount=uiDriver.getValue("WHTAmount");   
	            uiDriver.setValue("Amount",CACamount);
	            String WHTpercent=uiDriver.getValue("WHTpercent"); 
	            SleepUtils.sleep(2);
	            uiDriver.executeJavaScript("scroll(0,-800)");
	            output.put("WHTpercent", WHTpercent);
	            
	            uiDriver.click("Save");
	            SleepUtils.sleep(TimeSlab.LOW) ;*/
	            SleepUtils.sleep(TimeSlab.LOW);
	            uiDriver.click("CashAdjCode");
	             SleepUtils.sleep(2);
	             uiDriver.click("CashAdjCode1");
	             SleepUtils.sleep(2);
	             SleepUtils.sleep(2);
	             SleepUtils.sleep(2);
	             uiDriver.setValue("CashAdjCode1",input.get("CashAdjCode1"));
	             SleepUtils.sleep(2);
	             uiDriver.click("dropdown");
	             SleepUtils.sleep(2);
	             uiDriver.click("List");
	             SleepUtils.sleep(2);
	             uiDriver.click("searchbox");
	             String invoicenum=input.get("invoicenum");
	             String invoicenumber="Invoice #"+invoicenum;
	             uiDriver.setValue("searchbox",invoicenumber);
	             uiDriver.click("searchbutton");
	             SleepUtils.sleep(2);
	             uiDriver.click("searchedinvoicecode");
	             SleepUtils.sleep(2);
	             uiDriver.click("WHTCode");
	             uiDriver.setValue("EditWHTCode",input.get("WHTCode"));
	             SleepUtils.sleep(TimeSlab.LOW);
	             uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[3].click();");
	             SleepUtils.sleep(TimeSlab.MEDIUM);
	             uiDriver.setValue("EditWHTRate",input.get("WHTRate"));
	             SleepUtils.sleep(2);
	             uiDriver.click("Add");
	              SleepUtils.sleep(2);
	              uiDriver.click("CAshAdjCodeAmount");
	              SleepUtils.sleep(3);
	              String WHTAmount = uiDriver.getValue("WHTAmount");   
	              uiDriver.setValue("CAshAdjCodeAmount",WHTAmount);
	              String WHTpercent=uiDriver.getValue("WHTpercent"); 
	              SleepUtils.sleep(2);
	              uiDriver.executeJavaScript("scroll(0,-800)");
	              output.put("WHTAmount", WHTAmount);
	              uiDriver.executeJavaScript("scroll(0,-800)");
	              output.put("WHTpercent", WHTpercent);
	              
	              uiDriver.click("Save");
	              SleepUtils.sleep(TimeSlab.LOW);
	            
	     }
	/****************************************
 	 * Name: EditingARAmount
     * Description:EditingARAmount
     * Date:26-Feb-2017 
   ****************************************/ 
	public void EditingARAmount(DataRow input, DataRow output) throws InterruptedException 

    {	SleepUtils.sleep(TimeSlab.LOW);   
		
		
		if(input.get("editmultiple").equals("Y")){
			uiDriver.executeJavaScript("scroll(0,-1000)");
			
			uiDriver.click("EditBtn");
				for(int i=1;i<=4;i++)
				{

				String Aramountedit1 = uiDriver.getDyanmicData("Aramountedit");
				String updateArmount2 = Aramountedit1.replace("#", Integer.toString(i));
				uiDriver.click_dynamic(updateArmount2);
				                     

				uiDriver.executeJavaScript("document.getElementById('custrecord_nbcu_titleallocch_allocamount_formattedValue').value = ''");

				                    if(i==1)
				                     {
				                           uiDriver.setValue("EditedARAmount",input.get("amount1"));
				                     }
				                     if(i==2)
				                     {
				                    	 uiDriver.setValue("EditedARAmount",input.get("amount2"));    
				                    	 }
				                     if(i==3)
				                     {
				                    	 uiDriver.setValue("EditedARAmount",input.get("amount3")); 
				                    	 }
				                     if(i==4)
				                     {
				                    	 uiDriver.setValue("EditedARAmount",input.get("amount4")); 
				                     }
				}
				uiDriver.executeJavaScript("scroll(0,-300)");
			    uiDriver.click("SaveBtn");
			    if(uiDriver.isAlertPresent()){
				 String alerttext=uiDriver.getAlertText();   
				 System.out.println(alerttext);
				 uiDriver.handleAlert("", "OK");
				 //uiDriver.handleAlert("Payment amounts allocated to the lines do not match the total payment amount. Please allocate the remaining balance to the lines., button","OK");
				 if(alerttext.contains("Payment amounts allocated to the lines do not match the total payment amount. Please allocate the remaining balance to the lines."))
				 {
					 passed("Validation alert verified ", "amount should not be allocated more than the payment amount",
		                     "amount is not  allocated more than the payment amount"); 
				 }
				 
				 uiDriver.click("CancelBtn");
			    }
				 
				//}
				
				
				
				}
				                     else if(input.get("editmultiple").equals("N"))
				                     {


		
		Double ChangedARAmt = 10.00;
		uiDriver.executeJavaScript("scroll(0,-200)");
		uiDriver.click("EditBtn");
		 SleepUtils.sleep(5);
		uiDriver.executeJavaScript("scroll(0,-200)");
		String ARAmt = uiDriver.getValue("ARAmount");
 		Double ARAmnt = Double.parseDouble(ARAmt);
		Double ARAmount = ARAmnt + ChangedARAmt ;
		String NewARAmount = Double.toString(ARAmount);
		uiDriver.click("ARAmount");
		uiDriver.executeJavaScript("document.getElementById('custrecord_nbcu_titleallocch_allocamount_formattedValue').value = ''");
		uiDriver.setValue("EditedARAmount",NewARAmount );
		  passed("ARAmount", "ARAmount Should be entered successfully "+NewARAmount+" ",
                  "ARAmount is entered successfully as  "+NewARAmount+"");
		  String ARAmt1 = uiDriver.getValue("ARAmount1");
			Double ARAmnt1= Double.parseDouble(ARAmt1);
			Double ARAmount1 = ARAmnt1 - ChangedARAmt ;
			String NewARAmount1 = Double.toString(ARAmount1);
			uiDriver.click("EditARAmount1");
			uiDriver.executeJavaScript("document.getElementById('custrecord_nbcu_titleallocch_allocamount_formattedValue').value = ''");
			uiDriver.setValue("EditARAmountValue",NewARAmount1);
			uiDriver.executeJavaScript("scroll(0,-300)");
		    uiDriver.click("SaveBtn");
}
   }
	
	public void NavigateToCustomization(DataRow input, DataRow output) throws InterruptedException
		{
			
			uiDriver.mouseOver("Customization");
		    SleepUtils.sleep(TimeSlab.YIELD);
		    uiDriver.mouseOver("ListsandRecords");
		    SleepUtils.sleep(TimeSlab.YIELD);
		    uiDriver.mouseOver("RecordTypes");
		    SleepUtils.sleep(TimeSlab.YIELD);
		    uiDriver.click("RecordTypes");
		    SleepUtils.sleep(TimeSlab.YIELD); 
		} 
	
		    
	 public void ValidateTitleAllocationParent(DataRow input, DataRow output) throws InterruptedException
		    {
		 
		 uiDriver.executeJavaScript("scroll(0,1200)");
		 		uiDriver.click("TitleAllocationParent");
		 		SleepUtils.sleep(TimeSlab.YIELD);
		    
		    String customertype=uiDriver.getValue("Customer");
		      if(customertype.equals("List/Record"))
		    {
		    	
		    	passed("Validated customertype "+customertype+"",
                        "Customertype should be validated successfully"+customertype+"",
                         "SuccessFully Validated customertype"+customertype+"");
		    }
		      else
		      {
		    	  failed("Not Validated customertype "+customertype+"",
                        "customertype should be validated successfully"+customertype+"",
                         "customertype is not validated successfully "+customertype+"");
		      }
		      
		    String Invoicetype=uiDriver.getValue("Invoice");
		      if(Invoicetype.equals("List/Record"))
		    {
		    	passed("Validated Invoicetype "+Invoicetype+"",
                        "Invoicetype should be validated successfully"+Invoicetype+"",
                         "SuccessFully Validated Invoicetype"+Invoicetype+"");
		    }
		      else
		      {
		    	  failed("Not Validated Invoicetype "+Invoicetype+"",
                        "Invoicetype should be validated successfully"+Invoicetype+"",
                         "Invoicetype is not validated successfully "+Invoicetype+"");
		      }
		    
		    String Contracttype=uiDriver.getValue("Contract");
		      if(Contracttype.equals("List/Record"))
		    {
		    	passed("Validated Contracttype "+Contracttype+"",
                        "Contracttype should be validated successfully"+Contracttype+"",
                         "SuccessFully Validated customertype"+Contracttype+"");
		    }
		      else
		      {
		    	  failed("Not Validated Contracttype "+Contracttype+"",
                        "Contracttype should be validated successfully"+Contracttype+"",
                         "Contracttype is not validated successfully "+Contracttype+"");
		      }
		    
		    String Paymenttype=uiDriver.getValue("Payment");
		      if(Paymenttype.equals("List/Record"))
		    {
		    	passed("Validated Paymenttype "+Paymenttype+"",
                        "Paymenttype should be validated successfully"+Paymenttype+"",
                         "SuccessFully Validated Paymenttype"+Paymenttype+"");
		    }
		      else
		      {
		    	  failed("Not Validated Paymenttype "+Paymenttype+"",
                        "Paymenttype should be validated successfully"+Paymenttype+"",
                         "Paymenttype is not validated successfully "+Paymenttype+"");
		      }
		
		    String InvoiceTotaltype=uiDriver.getValue("InvoiceTotal");
		      if(InvoiceTotaltype.equals("Currency"))
		    {
		    	passed("Validated InvoiceTotaltype "+InvoiceTotaltype+"",
                        "InvoiceTotaltype should be validated successfully"+InvoiceTotaltype+"",
                         "SuccessFully Validated InvoiceTotaltype"+InvoiceTotaltype+"");
		    }
		      else
		      {
		    	  failed("Not Validated InvoiceTotaltype "+InvoiceTotaltype+"",
                        "InvoiceTotaltype should be validated successfully"+InvoiceTotaltype+"",
                         "InvoiceTotaltype is not validated successfully "+InvoiceTotaltype+"");
		      }
		      
		    String AppliedtoInvoicetype=uiDriver.getValue("AppliedtoInvoice");
		      if(AppliedtoInvoicetype.equals("Currency"))
		    {
		    	passed("Validated AppliedtoInvoicetype "+AppliedtoInvoicetype+"",
                        "AppliedtoInvoicetype should be validated successfully"+AppliedtoInvoicetype+"",
                         "SuccessFully Validated AppliedtoInvoicetype "+AppliedtoInvoicetype+"");
		    }
		      else
		      {
		    	  failed("Not Validated AppliedtoInvoicetype "+AppliedtoInvoicetype+"",
                        "AppliedtoInvoicetype should be validated successfully"+AppliedtoInvoicetype+"",
                         "AppliedtoInvoicetype is not validated successfully "+AppliedtoInvoicetype+"");
		      }
		      
		    String CashAccounttype=uiDriver.getValue("CashAccount");
		      if(CashAccounttype.equals("List/Record"))
		    {
		    	passed("Validated CashAccounttype "+CashAccounttype+"",
                        "CashAccounttype should be validated successfully"+CashAccounttype+"",
                         "SuccessFully Validated CashAccounttype "+CashAccounttype+"");
		    }
		      
		      else
		      {
		    	  failed("Not Validated CashAccounttype "+CashAccounttype+"",
                        "CashAccounttype should be validated successfully"+CashAccounttype+"",
                         "CashAccounttype is not validated successfully "+CashAccounttype+"");
		      }
		      
		    String CashBasistype=uiDriver.getValue("CashBasis");
		      if(CashBasistype.equalsIgnoreCase("Check Box"))
		    {
		    	passed("Validated CashBasistype "+CashBasistype+"",
                        "CashBasistype should be validated successfully"+CashBasistype+"",
                         "SuccessFully Validated CashBasistype "+CashBasistype+"");
		    }
		      else
		      {
		    	  failed("Not Validated CashBasistype "+CashBasistype+"",
                        "CashBasistype should be validated successfully"+CashBasistype+"",
                         "CashBasistype is not validated successfully "+CashBasistype+"");
		      }

		}


	 public void ValidateTitleAllocationChild(DataRow input, DataRow output) throws InterruptedException
	    {
		 
		 	uiDriver.click("TitleAllocationChild");
		    SleepUtils.sleep(TimeSlab.YIELD);
		    	    
			    String TitleAllocationParenttype=uiDriver.getValue("TitleAllocationParent");
				      if(TitleAllocationParenttype.equals("List/Record"))
				      	{
				    	
				    	passed("Validated TitleAllocationParenttype "+TitleAllocationParenttype+"",
			                 "TitleAllocationParenttype should be validated successfully"+TitleAllocationParenttype+"",
			                  "SuccessFully Validated TitleAllocationParenttype"+TitleAllocationParenttype+"");
				      	}
				      else
				      {
				    	  failed("Not Validated TitleAllocationParenttype "+TitleAllocationParenttype+"",
			                 "TitleAllocationParenttype should be validated successfully"+TitleAllocationParenttype+"",
			                  "TitleAllocationParenttype is not validated successfully "+TitleAllocationParenttype+"");
				      }
	 
				 String ContractLinetype = uiDriver.getValue("ContractLine");
			     if(ContractLinetype.equals("Integer Number"))
				     {
				   	
				   	passed("Validated ContractLinetype "+ContractLinetype+"",
				            "ContractLinetype should be validated successfully"+ContractLinetype+"",
				             "SuccessFully Validated ContractLinetype"+ContractLinetype+"");
				     }
				     else
				     {
				   	  failed("Not Validated ContractLinetype "+ContractLinetype+"",
				            "ContractLinetype should be validated successfully"+ContractLinetype+"",
				             "ContractLinetype is not validated successfully "+ContractLinetype+"");
				     }
			     
			     
			     
			     String InvoiceLinetype=uiDriver.getValue("InvoiceLine");
			      if(InvoiceLinetype.equals("Integer Number"))
			      	{
			    	
			    	passed("Validated InvoiceLinetype "+InvoiceLinetype+"",
		                 "InvoiceLinetype should be validated successfully"+InvoiceLinetype+"",
		                  "SuccessFully Validated InvoiceLinetype"+InvoiceLinetype+"");
			      	}
			      else
			      {
			    	  failed("Not Validated InvoiceLinetype "+InvoiceLinetype+"",
		                 "InvoiceLinetype should be validated successfully"+InvoiceLinetype+"",
		                  "InvoiceLinetype is not validated successfully "+InvoiceLinetype+"");
			      }
			      
			      
			      String Titletype=uiDriver.getValue("Title");
			      if(Titletype.equals("List/Record"))
			      	{
			    	
			    	passed("Validated Titletype "+Titletype+"",
		                 "Titletype should be validated successfully"+Titletype+"",
		                  "SuccessFully Validated Titletype"+Titletype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated Titletype "+Titletype+"",
		                 "Titletype should be validated successfully"+Titletype+"",
		                  "Titletype is not validated successfully "+Titletype+"");
			      	}
			      
			      String InvoiceLineAmounttype=uiDriver.getValue("InvoiceLineAmount");
			      if(InvoiceLineAmounttype.equals("Currency"))
			      	{
			    	
			    	passed("Validated InvoiceLineAmounttype "+InvoiceLineAmounttype+"",
		                 "InvoiceLineAmounttype should be validated successfully"+InvoiceLineAmounttype+"",
		                  "SuccessFully Validated InvoiceLineAmounttype"+InvoiceLineAmounttype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated InvoiceLineAmounttype "+InvoiceLineAmounttype+"",
		                 "InvoiceLineAmounttype should be validated successfully"+InvoiceLineAmounttype+"",
		                  "InvoiceLineAmounttype is not validated successfully "+InvoiceLineAmounttype+"");
			      	}
			      
			      String WHTPercentagetype=uiDriver.getValue("WHTPercentage");
			      if(WHTPercentagetype.equals("Percent"))
			      	{
			    	
			    	passed("Validated WHTPercentagetype "+WHTPercentagetype+"",
		                 "WHTPercentagetype should be validated successfully"+WHTPercentagetype+"",
		                  "SuccessFully Validated WHTPercentagetype"+WHTPercentagetype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated WHTPercentagetype "+WHTPercentagetype+"",
		                 "WHTPercentagetype should be validated successfully"+WHTPercentagetype+"",
		                  "WHTPercentagetype is not validated successfully "+WHTPercentagetype+"");
			      	}
			      			      
			      String RevisionNumbertype=uiDriver.getValue("RevisionNumber");
			      if(RevisionNumbertype.equals("Integer Number"))
			      	{
			    	
			    	passed("Validated RevisionNumbertype "+RevisionNumbertype+"",
		                 "RevisionNumbertype should be validated successfully"+RevisionNumbertype+"",
		                  "SuccessFully Validated RevisionNumbertype"+RevisionNumbertype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated RevisionNumbertype "+RevisionNumbertype+"",
		                 "RevisionNumbertype should be validated successfully"+RevisionNumbertype+"",
		                  "RevisionNumbertype is not validated successfully "+RevisionNumbertype+"");
			      	}
			      
			      String GLPNtype=uiDriver.getValue("GLPN");
			      if(GLPNtype.equals("List/Record"))
			      	{
			    	
			    	passed("Validated GLPNtype "+GLPNtype+"",
		                 "GLPNtype should be validated successfully"+GLPNtype+"",
		                  "SuccessFully Validated GLPNtype"+GLPNtype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated GLPNtype "+GLPNtype+"",
		                 "GLPNtype should be validated successfully"+GLPNtype+"",
		                  "GLPNtype is not validated successfully "+GLPNtype+"");
			      	}
			      
			      String MarketCodetype=uiDriver.getValue("MarketCode");
			      if(MarketCodetype.equals("List/Record"))
			      	{
			    	
			    	passed("Validated MarketCodetype "+MarketCodetype+"",
		                 "MarketCodetype should be validated successfully"+MarketCodetype+"",
		                  "SuccessFully Validated MarketCodetype"+MarketCodetype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated MarketCodetype "+MarketCodetype+"",
		                 "MarketCodetype should be validated successfully"+MarketCodetype+"",
		                  "MarketCodetype is not validated successfully "+MarketCodetype+"");
			      	}
			      String Righttype=uiDriver.getValue("Right");
			      if(Righttype.equals("List/Record"))
			      	{
			    	
			    	passed("Validated Righttype "+Righttype+"",
		                 "Righttype should be validated successfully"+Righttype+"",
		                  "SuccessFully Validated Righttype"+Righttype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated Righttype "+Righttype+"",
		                 "Righttype should be validated successfully"+Righttype+"",
		                  "Righttype is not validated successfully "+Righttype+"");
			      	}
			      String Territorytype=uiDriver.getValue("Territory");
			      if(Territorytype.equals("List/Record"))
			      	{
			    	
			    	passed("Validated Territorytype "+Territorytype+"",
		                 "Territorytype should be validated successfully"+Territorytype+"",
		                  "SuccessFully Validated Territorytype"+Territorytype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated Territorytype "+Territorytype+"",
		                 "Territorytype should be validated successfully"+Territorytype+"",
		                  "Territorytype is not validated successfully "+Territorytype+"");
			      	}
			      
			      String Closedtype=uiDriver.getValue("Closed");
			      if(Closedtype.equals("Check Box"))
			      	{
			    	
			    	passed("Validated Closedtype "+Closedtype+"",
		                 "Closedtype should be validated successfully"+Closedtype+"",
		                  "SuccessFully Validated Closedtype"+Closedtype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated Closedtype "+Closedtype+"",
		                 "Closedtype should be validated successfully"+Closedtype+"",
		                  "Closedtype is not validated successfully "+Closedtype+"");
			      	}
			      
			      String CBRecEdtype=uiDriver.getValue("CBRecEd");
			      if(CBRecEdtype.equals("Check Box"))
			      	{
			    	
			    	passed("Validated CBRecEdtype "+CBRecEdtype+"",
		                 "CBRecEdtype should be validated successfully"+CBRecEdtype+"",
		                  "SuccessFully Validated CBRecEdtype"+CBRecEdtype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated CBRecEdtype "+CBRecEdtype+"",
		                 "CBRecEdtype should be validated successfully"+CBRecEdtype+"",
		                  "CBRecEdtype is not validated successfully "+CBRecEdtype+"");
			      	}
			      
			      String RRSDtype=uiDriver.getValue("RRSD");
			      if(RRSDtype.equals("Date"))
			      	{
			    	
			    	passed("Validated RRSDtype "+RRSDtype+"",
		                 "RRSDtype should be validated successfully"+RRSDtype+"",
		                  "SuccessFully Validated RRSDtype"+RRSDtype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated RRSDtype "+RRSDtype+"",
		                 "RRSDtype should be validated successfully"+RRSDtype+"",
		                  "RRSDtype is not validated successfully "+RRSDtype+"");
			      	}
			    }

	 /****************************************
	 	 * Name: ValidateAllocationARAmount
	     *Description: ValidateAllocationARAmount
	     * Date:29-Mar-2018 
	     ****************************************/  	 
	 public void ValidateAllocationARAmount(DataRow input, DataRow output) throws InterruptedException
	    {
	 
	 		SleepUtils.sleep(TimeSlab.YIELD);
	    
	    String AllocatedAramount=uiDriver.getValue("ARAmountLine1");
	      if(AllocatedAramount.equals("0.00"))
	    {
	    	
	    	passed("Validated AllocatedAramount "+AllocatedAramount+"",
                 "AllocatedAramount should be validated successfully"+AllocatedAramount+"",
                  "SuccessFully Validated AllocatedAramount"+AllocatedAramount+"");
	    }
	      else
	      {
	    	  failed("Not Validated AllocatedAramount "+AllocatedAramount+"",
                 "AllocatedAramount should be validated successfully"+AllocatedAramount+"",
                  "AllocatedAramount is not validated successfully "+AllocatedAramount+"");
	      }
	    }
	 

	
	 /****************************************
		 * Name: EditContractWizard
		 * Description: EditContractWizard
		 *  Date: 11-July-2018
		 ****************************************/
	/*	public void EditMultipleContractWizard(DataRow input, DataRow output) {
			
			uiDriver.executeJavaScript("(scroll(0,-300));");
			uiDriver.click("Edit");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("Next");
			SleepUtils.sleep(TimeSlab.MEDIUM);
		//	uiDriver.click("MarketCode");
			String ContractLineFilter  = uiDriver.getDyanmicData("ContractLineFilters");
			String titleValues = ContractLineFilter.replace("#",input.get("title"));
			uiDriver.setValue(titleValues, input.get("titleVal"));
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("ApplyFilters");
 			SleepUtils.sleep(TimeSlab.YIELD);
			SleepUtils.sleep(TimeSlab.YIELD);
			List<WebElement> ContractLines = uiDriver.webDr.findElements(By.xpath("//*[@id='contract_lines_splits']//tr"));
			int MC = ContractLines.size();
		/*	for (int i = 0; i < MC - 1; i++) {
				
				String FMV = uiDriver.getDyanmicData("FMV");
				String FMVVal = FMV.replace("#", Integer.toString(i));
				uiDriver.setValue(FMVVal, input.get("ContractValues"));
				SleepUtils.sleep(TimeSlab.LOW);
			}

			uiDriver.executeJavaScript("(scroll(0,-300));");
			SleepUtils.sleep(TimeSlab.HIGH);
			for (int j = 0; j < MC - 1; j++) {
				String Chkbox = uiDriver.getDyanmicData("chkbox");
				String ChkboxChk = Chkbox.replace("#", Integer.toString(j));
				uiDriver.focus(ChkboxChk);
				// uiDriver.click_dynamic(ChkboxChk);
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.executeJavaScript("(scroll(0,300));");
				SleepUtils.sleep(TimeSlab.LOW);
			}
			for (int i = 0; i < MC - 1; i++) {
				
				String ProductOwner = uiDriver.getDyanmicData("ProductOwner");
				String ProductOwnerVal = ProductOwner.replace("#", Integer.toString(i));
				uiDriver.setValue(ProductOwnerVal, input.get("ProductOwnerValues"));
				SleepUtils.sleep(TimeSlab.LOW);
			}
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.executeJavaScript("(scroll(0,-1500));");
			uiDriver.click("MoveDown");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.executeJavaScript("(scroll(0,-1500));");
			uiDriver.executeJavaScript("(scroll(0,1500));");
			uiDriver.click("Save");
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
		}*/
		
		
	public void EditMultipleContractWizard(DataRow input, DataRow output) {
			
			uiDriver.executeJavaScript("(scroll(0,-300));");
			uiDriver.click("Edit");
			SleepUtils.sleep(TimeSlab.HIGH);
		//	uiDriver.setValue("//*[@id='inpt_tax_address_list1']", "SHIPTO");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("Next");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			String ContractLineFilter  = uiDriver.getDyanmicData("ContractLineFilters");
			String titleValues = ContractLineFilter.replace("#",input.get("title"));
			uiDriver.setValue(titleValues, input.get("titleVal"));
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("ApplyFilters");
 			SleepUtils.sleep(TimeSlab.YIELD);
			SleepUtils.sleep(TimeSlab.YIELD);
			if(uiDriver.checkElementPresent("//*[@id='pagination_selector_fs']/div[1]/input")){
				uiDriver.click("//*[@id='pagination_selector_fs']/div[1]/span");
				List<WebElement> fil = uiDriver.webDr.findElements(By.xpath("//div[@class='dropdownDiv']/div"));
				int filter = fil.size();
				for(int i=1;i<=filter;i++){
				if(i!=1){
					uiDriver.click("//*[@id='pagination_selector_fs']/div[1]/span");
					}
					String filterval = uiDriver.getDyanmicData("filters");
					String values = filterval.replace("#", Integer.toString(i));
					uiDriver.click_dynamic(values);
					SleepUtils.sleep(TimeSlab.HIGH);
					List<WebElement> ContractLines = uiDriver.webDr.findElements(By.xpath("//*[@id='contract_lines_splits']//tr"));
					int MC = ContractLines.size();
					uiDriver.executeJavaScript("(scroll(0,-300));");
					SleepUtils.sleep(TimeSlab.HIGH);
				
					if(input.get("Product").equals("Y")){
					for (int k = 0; k< MC - 1; k++) {
						
						String ProductOwner = uiDriver.getDyanmicData("ProductOwner");
						String ProductOwnerVal = ProductOwner.replace("#", Integer.toString(k));
						uiDriver.setValue(ProductOwnerVal, input.get("ProductOwnerValues"));
						SleepUtils.sleep(TimeSlab.LOW);
					}
					}
					
					if(input.get("ContractVal").equals("Y")){
						
						for (int l = 0; l < MC - 1; l++) {
							
							String FMV = uiDriver.getDyanmicData("FMV");
							String FMVVal = FMV.replace("#", Integer.toString(l));
							uiDriver.setValue(FMVVal, input.get("ContractValues"));
							SleepUtils.sleep(TimeSlab.LOW);
						}	
					
					}
					
					for (int j = 1; j < MC ; j++) {
						//String chkboxStatuses = uiDriver.getAttribute("Chkboxes", "class");
						String Chkbox = uiDriver.getDyanmicData("chkbox");
						String ChkboxChk = Chkbox.replace("#", Integer.toString(j));
						String chkboxArr[] = ChkboxChk.split("=");
						String chkboxVal = chkboxArr[1];
						String SelectedChkbox = chkboxVal.replace("\"", "");
						String actualSelectedValue = SelectedChkbox.replace("]", "").trim();
						SleepUtils.sleep(TimeSlab.LOW);
						uiDriver.executeJavaScript("document.getElementById('"+actualSelectedValue+"').click();");
						/*Actions action = new Actions(uiDriver.webDr);
			            WebElement ele = uiDriver.webDr.findElement(By.xpath(ChkboxChk));
			        	SleepUtils.sleep(TimeSlabLOW);
			            action.moveToElement(ele).click().build().perform();*/
			            SleepUtils.sleep(TimeSlab.MEDIUM);
					}
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.executeJavaScript("(scroll(0,-1500));");
					uiDriver.click("MoveDown");
					SleepUtils.sleep(TimeSlab.MEDIUM);
					
				}
				uiDriver.click("Save");
				SleepUtils.sleep(TimeSlab.HIGH);
				SleepUtils.sleep(TimeSlab.HIGH);
			
			}
			else{
				
			//do nothing	
			}	
			
	
	}	
}
	

			
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


