package moduledrivers;
import static cbf.engine.TestResultLogger.*;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;

import org.apache.james.mime4j.field.datetime.DateTime;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.python.antlr.PythonParser.continue_stmt_return;

import cbf.engine.TestResult.ResultType;
import cbf.utils.DataRow;
import cbf.utils.SleepUtils;
import cbf.utils.SleepUtils.TimeSlab;
import cbfx.basedrivers.BaseWebModuleDriver;
import cbfx.objectmaps.ObjectMap;

public class CashByTitleDriver extends BaseWebModuleDriver {
	
	
	/****************************************
 	 * Name: ResettingARAmountToZero
     * Description:EditingARAmount
     * Date:29-MArch-2017 
   ****************************************/ 
	public void ResettingARAmountToZero(DataRow input, DataRow output) throws InterruptedException 

    {		
		uiDriver.executeJavaScript("scroll(0,-200)");
		uiDriver.click("EditBtn");
		uiDriver.executeJavaScript("scroll(0,700)");
		uiDriver.click("Clear");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.switchToWindow("Title Allocation Parent - NetSuite (NBCUniversal Media, LLC - QA)");
		String AllocationAmount = uiDriver.getValue("AllocationAmt");
		if(AllocationAmount.equalsIgnoreCase("0.00")){
			
			passed("Verify the Allocation Amount",
					"Allocation Amount should be set to "+AllocationAmount+" successfully",
					"Allocation Amount is set to "+AllocationAmount+" successfully");
		}
		else
		{
			failed("Verify the Allocation Amount",
					"Allocation Amount should be set to "+AllocationAmount+" successfully",
					"Allocation Amount is not set to "+AllocationAmount+" successfully");
			}	
		
		uiDriver.switchToWindow("Title Allocation Parent - NetSuite (NBCUniversal Media, LLC - QA))");	
	}
			
	/****************************************
 	 * Name: updateReclasstoblankvalues
     * Description:updateReclasstoblankvalues
     * Date:30-MArch-2017 
   ****************************************/ 

	public void updateReclasstoblankvalues(DataRow input, DataRow output) throws InterruptedException
	{
		uiDriver.click("SaveBtn");
		if(uiDriver.isAlertPresent()){
			uiDriver.handleAlert("", "OK");
			uiDriver.executeJavaScript("scroll(0,-500)");
			uiDriver.click("saveBtn");
			uiDriver.click("DuplicateSave");		
			passed("Click On save button", "Details Should be saved successfully",
				"Details is saved successfully");
				 		
		}
		else{
			//do nothing
		}
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Edit");
		passed("Click on edit button",
				"edit button should be clicked successfully",
				"edit button should be clicked successfully");
		uiDriver.executeJavaScript("scroll(1000,2000)");
		int Rows = uiDriver.webDr.findElements(By.xpath("//*[@id='item_splits']/tbody/tr[contains(@id,'item_row')]")).size();
		for(int i=1;i<=Rows;i++)
        {
              String unbilledrevenuacct = uiDriver.getDyanmicData("unbilledrevenueaccount");
              String unbilledrevenueaccount = unbilledrevenuacct.replace("#", Integer.toString(i));
              uiDriver.click_dynamic(unbilledrevenueaccount);    
              SleepUtils.sleep(TimeSlab.LOW);
              uiDriver.setValue("editunbilledrevenueaccount","");
              passed("unbilledrevenuacct set to null",
        				"unbilledrevenuacct should be set to null",
        				"unbilledrevenuacct is set to null");
              String billedrevenuacct = uiDriver.getDyanmicData("billedrevenueaccount");
              String billedrevenueaccount = billedrevenuacct.replace("#", Integer.toString(i));
              uiDriver.click_dynamic(billedrevenueaccount);               
              uiDriver.setValue("editbilledrevenueaccount","");
              passed("billedrevenuacct set to null",
      				"billedrevenuacct should be set to null",
      				"billedrevenuacct is set to null");
              SleepUtils.sleep(TimeSlab.LOW);
              
              String billedARacct = uiDriver.getDyanmicData("billedARaccount");
              String billedARaccount = billedARacct.replace("#", Integer.toString(i));
              uiDriver.click_dynamic(billedARaccount);               
              uiDriver.setValue("editbilledARaccount","");
              passed("billedARacct set to null",
        				"billedARacct should be set to null",
        				"billedARacct is set to null");
              String unbilledARacct = uiDriver.getDyanmicData("unbilledARaccount");
              String unbilledARaccount = unbilledARacct.replace("#", Integer.toString(i));
              uiDriver.click_dynamic(unbilledARaccount);               
              uiDriver.setValue("editunbilledARaccount","");
              passed("unbilledARacct set to null",
      				"unbilledARacct should be set to null",
      				"unbilledARacct is set to null");
              
              String paiddeferredacct = uiDriver.getDyanmicData("paiddeferredaccount");
              String paiddeferredaccount = paiddeferredacct.replace("#", Integer.toString(i));
              uiDriver.click_dynamic(paiddeferredaccount);               
              uiDriver.setValue("editpaiddeferredaccount","");
              passed("paiddeferredacct set to null",
        				"paiddeferredacct should be set to null",
        				"paiddeferredacct is set to null");
              String unpaiddeferredacct = uiDriver.getDyanmicData("unpaiddeferredaccount");
              String unpaiddeferredaccount = unpaiddeferredacct.replace("#", Integer.toString(i));
              uiDriver.click_dynamic(unpaiddeferredaccount);               
              uiDriver.setValue("editunpaiddeferredaccount","");
              passed("unpaiddeferredacct set to null",
      				"unpaiddeferredacct should be set to null",
      				"unpaiddeferredacct is set to null");
              String baddebtacct = uiDriver.getDyanmicData("baddebtaccount");
              String baddebtacctaccount = baddebtacct.replace("#", Integer.toString(i));
              uiDriver.click_dynamic(baddebtacctaccount);               
              uiDriver.setValue("editbaddebtaccount","");
              passed("bad debt acct set to null",
        				"bad debt acct should be set to null",
        				"bad debt acct is set to null");
              uiDriver.click("OK");
        }
		uiDriver.click("SaveBtn");
		
		
	}
	
/****************************************
 public void VerifysaleslinkonTAP(DataRow input, DataRow output) throws InterruptedException 
 {         
                     
       
              SleepUtils.sleep(TimeSlab.MEDIUM);
              uiDriver.click("Custom");
              SleepUtils.sleep(TimeSlab.LOW);
              uiDriver.executeJavaScript("scroll(0,1600)");
              uiDriver.click("TitleAllocationParent");
              SleepUtils.sleep(TimeSlab.LOW);
              uiDriver.executeJavaScript("scroll(0,600)");
              uiDriver.click("TAPId");
              SleepUtils.sleep(5);
              String saleslink=uiDriver.getValue("saleslink");
              if(saleslink.startsWith("Sales Order #"))
              {
                     passed("Verifying the SalesOrder link",
                                  "SalesOrder link should start with Sales Order #",
                                  "SalesOrder link starts with Sales Order #");
              } 
              else
              {
                     failed("Verifying the SalesOrder link",
                                  "SalesOrder link should  start with Sales Order #",
                                  "SalesOrder link is not starting with Sales Order #");
              }
              
              uiDriver.click("saleslink");
              SleepUtils.sleep(5);
              
              if(uiDriver.checkPage("Sales Order - NetSuite (NBCUniversal Media, LLC - QA)"))
              {
                     passed("Verifying the SalesOrder page",
                                  "SalesOrder page  should be displayed",
                                  "SalesOrder  page is displayed");
              }
              else
              {
                     failed("Verifying the SalesOrder page",
                                  "SalesOrder page  should be displayed",
                                  "SalesOrder  page is not displayed");
              }
              
              
              
}	

 /****************************
     * Name: VerifypaymentlinkonTAP
     * Description:VerifypaymentlinkonTAP
     * Date:30-MArch-2017 
   ****************************************/ 
	public void VerifypaymentlinkonTAP(DataRow input, DataRow output) throws InterruptedException 

    {						
		SleepUtils.sleep(5);
		uiDriver.click("Custom");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,1600)");
		uiDriver.click("TitleAllocationParent");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,600)");
		uiDriver.click("TAPId");
		SleepUtils.sleep(5);
		String paymentlink=uiDriver.getValue("paymentlink");
		if(paymentlink.startsWith("Payment #"))
		{
			passed("Verifying the Payment link",
					"Payment link should start with Payment #",
					"Payment link starts with Payment #");
		} 
		else
		{
			failed("Verifying the Payment link",
					"Payment link should  start with Payment #",
					"Payment link should does not with Payment #");
		}
		
		uiDriver.click("paymentlink");
		SleepUtils.sleep(5);
		
		if(uiDriver.checkPage("Payment - NetSuite (NBCUniversal Media, LLC - QA)"))
		{
			passed("Verifying the Payment page",
					"Payment page  should be displayed",
					"Payment  page is displayed");
		}
		else
		{
			failed("Verifying the Payment link",
					"Payment page  should be displayed",
					"Payment  page is not displayed");
		}
		
		
		
}
	
	
	public void VerifyInvoiceParentLink(DataRow input, DataRow output) throws InterruptedException 

    {						
		SleepUtils.sleep(5);
		uiDriver.click("Custom");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,1600)");
		uiDriver.click("TitleAllocationParent");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,600)");
		uiDriver.click("TAPId");
		SleepUtils.sleep(5);
		String paymentlink=uiDriver.getValue("InvoiceLink");
		if(paymentlink.startsWith("Payment #"))
		{
			passed("Verifying the InvoiceLink link",
					"Payment link should start with InvoiceLink #",
					"Payment link starts with InvoiceLink #");
		} 
		else
		{
			failed("Verifying the InvoiceLink link",
					"Payment link should  start with InvoiceLink #",
					"Payment link should does not with InvoiceLink #");
		}
		
		uiDriver.click("InvoiceLink");
		SleepUtils.sleep(5);
		
		if(uiDriver.checkPage("Payment - NetSuite (NBCUniversal Media, LLC - QA)"))
		{
			passed("Verifying the Payment page",
					"Payment page  should be displayed",
					"Payment  page is displayed");
		}
		else
		{
			failed("Verifying the Payment link",
					"Payment page  should be displayed",
					"Payment  page is not displayed");
		}
		
		
		
}
	
	
	/****************************************
 	 * Name: ValidateCBTonsalesorder
     * Description:ValidateCBTonsalesorder
     * Date:30-MArch-2017 
   ****************************************/ 
	public void ValidateCBTonsalesorder(DataRow input, DataRow output) throws InterruptedException 

    {		
			
	
		SleepUtils.sleep(TimeSlab.MEDIUM);
    		String Num = input.get("conf");	
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");
		SleepUtils.sleep(5);
		uiDriver.refresh();
		uiDriver.executeJavaScript("scroll(0,500)");
		SleepUtils.sleep(5);
		uiDriver.click("Custom");
		uiDriver.executeJavaScript("scroll(0,1500)");
		SleepUtils.sleep(5);
		//uiDriver.executeJavaScript("document.getElementById('recmachcustrecord_nbcu_titleallocpa_contractlnk').click();");
		uiDriver.click("TitleAllocationParent");
		SleepUtils.sleep(5);
		uiDriver.click("SalesTAPId");
		SleepUtils.sleep(5);
		if(uiDriver.checkPage("Title Allocation Parent - NetSuite (NBCUniversal Media, LLC - QA)"))
		{
			passed("Verifying the Title Allocation parent page",
					"Title Allocation parent page  should be displayed",
					" Title Allocation parent  page is displayed");
		}
		else
		{
			failed("Verifying the Title Allocation parent page",
					"Title Allocation parent page  should be displayed",
					" Title Allocation parent  page is not displayed");
		}
		
		
		
}
	/***************************************
 Name: NavigateToCustomization
     *Description:  NavigateToCustomization
     * Date:22-Mar-2018 
     ****************************************/   
	
	public void NavigateToCustomization(DataRow input, DataRow output) throws InterruptedException

{
uiDriver.mouseOver("Customization");
		    SleepUtils.sleep(TimeSlab.YIELD);
		    uiDriver.mouseOver("ListsandRecords");
		    SleepUtils.sleep(TimeSlab.YIELD);
		    uiDriver.mouseOver("RecordTypes");
		    SleepUtils.sleep(TimeSlab.YIELD);
		    uiDriver.click("RecordTypes");
		    SleepUtils.sleep(TimeSlab.YIELD); 
		} 
/*******************************
Name: ValidateTitleAllocationParent
     *Description:  ValidateTitleAllocationParent
     * Date:22-Mar-2018 
     ****************************************/ 
		    
	 public void ValidateTitleAllocationParent(DataRow input, DataRow output) throws InterruptedException
		    {
		 
		 uiDriver.executeJavaScript("scroll(0,1200)");
		 		uiDriver.click("TitleAllocationParent");
		 		SleepUtils.sleep(TimeSlab.YIELD);
		    
		    String customertype=uiDriver.getValue("Customer");
		      if(customertype.equals("List/Record"))
		    {
		    	
		    	passed("Validated customertype "+customertype+"",
                        "Customertype should be validated successfully"+customertype+"",
                         "SuccessFully Validated customertype"+customertype+"");
		    }
		      else
		      {
		    	  failed("Not Validated customertype "+customertype+"",
                        "customertype should be validated successfully"+customertype+"",
                         "customertype is not validated successfully "+customertype+"");
		      }
		      
		    String Invoicetype=uiDriver.getValue("Invoice");
		      if(Invoicetype.equals("List/Record"))
		    {
		    	passed("Validated Invoicetype "+Invoicetype+"",
                        "Invoicetype should be validated successfully"+Invoicetype+"",
                         "SuccessFully Validated Invoicetype"+Invoicetype+"");
		    }
		      else
		      {
		    	  failed("Not Validated Invoicetype "+Invoicetype+"",
                        "Invoicetype should be validated successfully"+Invoicetype+"",
                         "Invoicetype is not validated successfully "+Invoicetype+"");
		      }
		    
		    String Contracttype=uiDriver.getValue("Contract");
		      if(Contracttype.equals("List/Record"))
		    {
		    	passed("Validated Contracttype "+Contracttype+"",
                        "Contracttype should be validated successfully"+Contracttype+"",
                         "SuccessFully Validated customertype"+Contracttype+"");
		    }
		      else
		      {
		    	  failed("Not Validated Contracttype "+Contracttype+"",
                        "Contracttype should be validated successfully"+Contracttype+"",
                         "Contracttype is not validated successfully "+Contracttype+"");
		      }
		    
		    String Paymenttype=uiDriver.getValue("Payment");
		      if(Paymenttype.equals("List/Record"))
		    {
		    	passed("Validated Paymenttype "+Paymenttype+"",
                        "Paymenttype should be validated successfully"+Paymenttype+"",
                         "SuccessFully Validated Paymenttype"+Paymenttype+"");
		    }
		      else
		      {
		    	  failed("Not Validated Paymenttype "+Paymenttype+"",
                        "Paymenttype should be validated successfully"+Paymenttype+"",
                         "Paymenttype is not validated successfully "+Paymenttype+"");
		      }
		
		    String InvoiceTotaltype=uiDriver.getValue("InvoiceTotal");
		      if(InvoiceTotaltype.equals("Currency"))
		    {
		    	passed("Validated InvoiceTotaltype "+InvoiceTotaltype+"",
                        "InvoiceTotaltype should be validated successfully"+InvoiceTotaltype+"",
                         "SuccessFully Validated InvoiceTotaltype"+InvoiceTotaltype+"");
		    }
		      else
		      {
		    	  failed("Not Validated InvoiceTotaltype "+InvoiceTotaltype+"",
                        "InvoiceTotaltype should be validated successfully"+InvoiceTotaltype+"",
                         "InvoiceTotaltype is not validated successfully "+InvoiceTotaltype+"");
		      }
		      
		    String AppliedtoInvoicetype=uiDriver.getValue("AppliedtoInvoice");
		      if(AppliedtoInvoicetype.equals("Currency"))
		    {
		    	passed("Validated AppliedtoInvoicetype "+AppliedtoInvoicetype+"",
                        "AppliedtoInvoicetype should be validated successfully"+AppliedtoInvoicetype+"",
                         "SuccessFully Validated AppliedtoInvoicetype "+AppliedtoInvoicetype+"");
		    }
		      else
		      {
		    	  failed("Not Validated AppliedtoInvoicetype "+AppliedtoInvoicetype+"",
                        "AppliedtoInvoicetype should be validated successfully"+AppliedtoInvoicetype+"",
                         "AppliedtoInvoicetype is not validated successfully "+AppliedtoInvoicetype+"");
		      }
		      
		    String CashAccounttype=uiDriver.getValue("CashAccount");
		      if(CashAccounttype.equals("List/Record"))
		    {
		    	passed("Validated CashAccounttype "+CashAccounttype+"",
                        "CashAccounttype should be validated successfully"+CashAccounttype+"",
                         "SuccessFully Validated CashAccounttype "+CashAccounttype+"");
		    }
		      
		      else
		      {
		    	  failed("Not Validated CashAccounttype "+CashAccounttype+"",
                        "CashAccounttype should be validated successfully"+CashAccounttype+"",
                         "CashAccounttype is not validated successfully "+CashAccounttype+"");
		      }
		      
		    String CashBasistype=uiDriver.getValue("CashBasis");
		      if(CashBasistype.equalsIgnoreCase("Check Box"))
		    {
		    	passed("Validated CashBasistype "+CashBasistype+"",
                        "CashBasistype should be validated successfully"+CashBasistype+"",
                         "SuccessFully Validated CashBasistype "+CashBasistype+"");
		    }
		      else
		      {
		    	  failed("Not Validated CashBasistype "+CashBasistype+"",
                        "CashBasistype should be validated successfully"+CashBasistype+"",
                         "CashBasistype is not validated successfully "+CashBasistype+"");
		      }
		    }

/****************************************
	 	 * Name: ValidateTitleAllocationChild
	     *Description:  ValidateTitleAllocationChild
	     * Date:22-Mar-2018 
	     ****************************************/ 

	 public void ValidateTitleAllocationChild(DataRow input, DataRow output) throws InterruptedException
	    {
		 
		 	uiDriver.click("TitleAllocationChild");
		    SleepUtils.sleep(TimeSlab.YIELD);
		    	    
			    String TitleAllocationParenttype=uiDriver.getValue("TitleAllocationParent");
				      if(TitleAllocationParenttype.equals("List/Record"))
				      	{
				    	
				    	passed("Validated TitleAllocationParenttype "+TitleAllocationParenttype+"",
			                 "TitleAllocationParenttype should be validated successfully"+TitleAllocationParenttype+"",
			                  "SuccessFully Validated TitleAllocationParenttype"+TitleAllocationParenttype+"");
				      	}
				      else
				      {
				    	  failed("Not Validated TitleAllocationParenttype "+TitleAllocationParenttype+"",
			                 "TitleAllocationParenttype should be validated successfully"+TitleAllocationParenttype+"",
			                  "TitleAllocationParenttype is not validated successfully "+TitleAllocationParenttype+"");
				      }
	 
				 String ContractLinetype = uiDriver.getValue("ContractLine");
			     if(ContractLinetype.equals("Integer Number"))
				     {
				   	
				   	passed("Validated ContractLinetype "+ContractLinetype+"",
				            "ContractLinetype should be validated successfully"+ContractLinetype+"",
				             "SuccessFully Validated ContractLinetype"+ContractLinetype+"");
				     }
				     else
				     {
				   	  failed("Not Validated ContractLinetype "+ContractLinetype+"",
				            "ContractLinetype should be validated successfully"+ContractLinetype+"",
				             "ContractLinetype is not validated successfully "+ContractLinetype+"");
				     }
			     
			     
			     
			     String InvoiceLinetype=uiDriver.getValue("InvoiceLine");
			      if(InvoiceLinetype.equals("Integer Number"))
			      	{
			    	
			    	passed("Validated InvoiceLinetype "+InvoiceLinetype+"",
		                 "InvoiceLinetype should be validated successfully"+InvoiceLinetype+"",
		                  "SuccessFully Validated InvoiceLinetype"+InvoiceLinetype+"");
			      	}
			      else
			      {
			    	  failed("Not Validated InvoiceLinetype "+InvoiceLinetype+"",
		                 "InvoiceLinetype should be validated successfully"+InvoiceLinetype+"",
		                  "InvoiceLinetype is not validated successfully "+InvoiceLinetype+"");
			      }
			      
			      
			      String Titletype=uiDriver.getValue("Title");
			      if(Titletype.equals("List/Record"))
			      	{
			    	
			    	passed("Validated Titletype "+Titletype+"",
		                 "Titletype should be validated successfully"+Titletype+"",
		                  "SuccessFully Validated Titletype"+Titletype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated Titletype "+Titletype+"",
		                 "Titletype should be validated successfully"+Titletype+"",
		                  "Titletype is not validated successfully "+Titletype+"");
			      	}
			      
			      String InvoiceLineAmounttype=uiDriver.getValue("InvoiceLineAmount");
			      if(InvoiceLineAmounttype.equals("Currency"))
			      	{
			    	
			    	passed("Validated InvoiceLineAmounttype "+InvoiceLineAmounttype+"",
		                 "InvoiceLineAmounttype should be validated successfully"+InvoiceLineAmounttype+"",
		                  "SuccessFully Validated InvoiceLineAmounttype"+InvoiceLineAmounttype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated InvoiceLineAmounttype "+InvoiceLineAmounttype+"",
		                 "InvoiceLineAmounttype should be validated successfully"+InvoiceLineAmounttype+"",
		                  "InvoiceLineAmounttype is not validated successfully "+InvoiceLineAmounttype+"");
			      	}
			      
			      String WHTPercentagetype=uiDriver.getValue("WHTPercentage");
			      if(WHTPercentagetype.equals("Percent"))
			      	{
			    	
			    	passed("Validated WHTPercentagetype "+WHTPercentagetype+"",
		                 "WHTPercentagetype should be validated successfully"+WHTPercentagetype+"",
		                  "SuccessFully Validated WHTPercentagetype"+WHTPercentagetype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated WHTPercentagetype "+WHTPercentagetype+"",
		                 "WHTPercentagetype should be validated successfully"+WHTPercentagetype+"",
		                  "WHTPercentagetype is not validated successfully "+WHTPercentagetype+"");
			      	}
			      			      
			      String RevisionNumbertype=uiDriver.getValue("RevisionNumber");
			      if(RevisionNumbertype.equals("Integer Number"))
			      	{
			    	
			    	passed("Validated RevisionNumbertype "+RevisionNumbertype+"",
		                 "RevisionNumbertype should be validated successfully"+RevisionNumbertype+"",
		                  "SuccessFully Validated RevisionNumbertype"+RevisionNumbertype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated RevisionNumbertype "+RevisionNumbertype+"",
		                 "RevisionNumbertype should be validated successfully"+RevisionNumbertype+"",
		                  "RevisionNumbertype is not validated successfully "+RevisionNumbertype+"");
			      	}
			      
			      String GLPNtype=uiDriver.getValue("GLPN");
			      if(GLPNtype.equals("List/Record"))
			      	{
			    	
			    	passed("Validated GLPNtype "+GLPNtype+"",
		                 "GLPNtype should be validated successfully"+GLPNtype+"",
		                  "SuccessFully Validated GLPNtype"+GLPNtype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated GLPNtype "+GLPNtype+"",
		                 "GLPNtype should be validated successfully"+GLPNtype+"",
		                  "GLPNtype is not validated successfully "+GLPNtype+"");
			      	}
			      
			      String MarketCodetype=uiDriver.getValue("MarketCode");
			      if(MarketCodetype.equals("List/Record"))
			      	{
			    	
			    	passed("Validated MarketCodetype "+MarketCodetype+"",
		                 "MarketCodetype should be validated successfully"+MarketCodetype+"",
		                  "SuccessFully Validated MarketCodetype"+MarketCodetype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated MarketCodetype "+MarketCodetype+"",
		                 "MarketCodetype should be validated successfully"+MarketCodetype+"",
		                  "MarketCodetype is not validated successfully "+MarketCodetype+"");
			      	}
			      String Righttype=uiDriver.getValue("Right");
			      if(Righttype.equals("List/Record"))
			      	{
			    	
			    	passed("Validated Righttype "+Righttype+"",
		                 "Righttype should be validated successfully"+Righttype+"",
		                  "SuccessFully Validated Righttype"+Righttype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated Righttype "+Righttype+"",
		                 "Righttype should be validated successfully"+Righttype+"",
		                  "Righttype is not validated successfully "+Righttype+"");
			      	}
			      String Territorytype=uiDriver.getValue("Territory");
			      if(Territorytype.equals("List/Record"))
			      	{
			    	
			    	passed("Validated Territorytype "+Territorytype+"",
		                 "Territorytype should be validated successfully"+Territorytype+"",
		                  "SuccessFully Validated Territorytype"+Territorytype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated Territorytype "+Territorytype+"",
		                 "Territorytype should be validated successfully"+Territorytype+"",
		                  "Territorytype is not validated successfully "+Territorytype+"");
			      	}
			      
			      String Closedtype=uiDriver.getValue("Closed");
			      if(Closedtype.equals("Check Box"))
			      	{
			    	
			    	passed("Validated Closedtype "+Closedtype+"",
		                 "Closedtype should be validated successfully"+Closedtype+"",
		                  "SuccessFully Validated Closedtype"+Closedtype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated Closedtype "+Closedtype+"",
		                 "Closedtype should be validated successfully"+Closedtype+"",
		                  "Closedtype is not validated successfully "+Closedtype+"");
			      	}
			      
			      String CBRecEdtype=uiDriver.getValue("CBRecEd");
			      if(CBRecEdtype.equals("Check Box"))
			      	{
			    	
			    	passed("Validated CBRecEdtype "+CBRecEdtype+"",
		                 "CBRecEdtype should be validated successfully"+CBRecEdtype+"",
		                  "SuccessFully Validated CBRecEdtype"+CBRecEdtype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated CBRecEdtype "+CBRecEdtype+"",
		                 "CBRecEdtype should be validated successfully"+CBRecEdtype+"",
		                  "CBRecEdtype is not validated successfully "+CBRecEdtype+"");
			      	}
			      
			      String RRSDtype=uiDriver.getValue("RRSD");
			      if(RRSDtype.equals("Date"))
			      	{
			    	
			    	passed("Validated RRSDtype "+RRSDtype+"",
		                 "RRSDtype should be validated successfully"+RRSDtype+"",
		                  "SuccessFully Validated RRSDtype"+RRSDtype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated RRSDtype "+RRSDtype+"",
		                 "RRSDtype should be validated successfully"+RRSDtype+"",
		                  "RRSDtype is not validated successfully "+RRSDtype+"");
			      	}
			    }
	 /****************************************
	 	 * Name: VerifysaleslinkonTAP
	     * VerifysaleslinkonTAP
	     * Date:30-MArch-2017 
	   ****************************************/ 
	 
	 public void VerifysaleslinkonTAP(DataRow input, DataRow output) throws InterruptedException 
	 {         
	                     
	       
	              SleepUtils.sleep(TimeSlab.MEDIUM);
	              uiDriver.click("Custom");
	              SleepUtils.sleep(TimeSlab.LOW);
	              uiDriver.executeJavaScript("scroll(0,1600)");
	              uiDriver.click("TitleAllocationParent");
	              SleepUtils.sleep(TimeSlab.LOW);
	              uiDriver.executeJavaScript("scroll(0,600)");
	              uiDriver.click("TAPId");
	              SleepUtils.sleep(5);
	              String saleslink=uiDriver.getValue("saleslink");
	              if(saleslink.startsWith("Sales Order #"))
	              {
	                     passed("Verifying the SalesOrder link",
	                                  "SalesOrder link should start with Sales Order #",
	                                  "SalesOrder link starts with Sales Order #");
	              } 
	              else
	              {
	                     failed("Verifying the SalesOrder link",
	                                  "SalesOrder link should  start with Sales Order #",
	                                  "SalesOrder link is not starting with Sales Order #");
	              }
	              
	              uiDriver.click("saleslink");
	              SleepUtils.sleep(5);
	              
	              if(uiDriver.checkPage("Sales Order - NetSuite (NBCUniversal Media, LLC - QA)"))
	              {
	                     passed("Verifying the SalesOrder page",
	                                  "SalesOrder page  should be displayed",
	                                  "SalesOrder  page is displayed");
	              }
	              else
	              {
	                     failed("Verifying the SalesOrder page",
	                                  "SalesOrder page  should be displayed",
	                                  "SalesOrder  page is not displayed");
	              }
	              
	              
	              
	}      

/****************************************
 	 * Name: VerifyPaidinFullPartialPayment
     * Description:VerifyPaidinFullPartialPayment
     * Date:30-MArch-2017 
   ****************************************/ 
	
	public void VerifyPaidinFullPartialPayment(DataRow input, DataRow output) throws InterruptedException 

    {					
	
		SleepUtils.sleep(TimeSlab.MEDIUM);
    		String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");
		SleepUtils.sleep(5);
		
		uiDriver.executeJavaScript("scroll(0,1000)");
		String paidinFull1=uiDriver.getValue_Text("paidinFull");
		String paidinFullDate1=uiDriver.getValue_Text("paidinFullDate");
		String paidinFull=uiDriver.getValue("paidinFull");
		String paidinFullDate=uiDriver.getValue("paidinFullDate");
		if(paidinFull1.equalsIgnoreCase(" "))
		{
			passed("Verifying the paidinFull link",
					"paidinFull link should be null",
					"paidinFull link is null");
		} 
		else
		{
			failed("Verifying the paidinFull link",
					"paidinFull link should be null",
					"paidinFull link is not null");;
		}
		
		
		if(paidinFullDate1.equals(" "))
		{
			passed("Verifying the paidinFullDate link",
					"paidinFullDate link should be null",
					"paidinFullDate link is null");
		} 
		else
		{
			failed("Verifying the paidinFullDate link",
					"paidinFullDate link should be null",
					"paidinFullDate link is not null");;
		}
		
		if(paidinFull.equals(" "))
		{
			passed("Verifying the paidinFull link",
					"paidinFull link should be null",
					"paidinFull link is null");
		} 
		else
		{
			failed("Verifying the paidinFull link",
					"paidinFull link should be null",
					"paidinFull link is not null");;
		}
		
		
		if(paidinFull1.equalsIgnoreCase(" "))
		{
			passed("Verifying the paidinFullDate link",
					"paidinFullDate link should be null",
					"paidinFullDate link is null");
		} 
		else
		{
			failed("Verifying the paidinFullDate link",
					"paidinFullDate link should be null",
					"paidinFullDate link is not null");;
		}
		
}
		/****************************************
 	 * Name: VerifyUserCannotImproperlyApplyCash
     * Description: Verify UserCannot Improperly ApplyCash when 
     * Date:30-MArch-2017 
   ****************************************/ 
	public void VerifyUserCannotImproperlyApplyCash(DataRow input, DataRow output) throws InterruptedException 

    {	
		Double ChangedARAmt = 10.00;
		uiDriver.executeJavaScript("scroll(0,-200)");
		uiDriver.click("EditBtn");
		SleepUtils.sleep(5);
		uiDriver.executeJavaScript("scroll(0,-200)");
		String ARAmt = uiDriver.getValue("ARAmount");
 		Double ARAmnt = Double.parseDouble(ARAmt);
		Double ARAmount = ARAmnt + ChangedARAmt ;
		String NewARAmount = Double.toString(ARAmount);
		uiDriver.setValue("EditedARAmount",NewARAmount );
		uiDriver.executeJavaScript("scroll(0,-500)");
		uiDriver.click("SaveBtn");
		SleepUtils.sleep(5);
		String ErrorMsg = uiDriver.getAlertText();
		SleepUtils.sleep(5);
		uiDriver.handleAlert("","OK");
		if(ErrorMsg.equalsIgnoreCase("Please enter value(s) for: Invoice Line, Invoice Line Amt")){
			
			passed("Verifying When User Cannot Improperly ApplyCash When ALLOCATION AMOUNT on the line should is equal to the INVOICE LINE AMOUNT, and there are other CBT records for that same invoice",
					"Verifying When User Cannot Improperly ApplyCash When ALLOCATION AMOUNT on the line should is equal to the INVOICE LINE AMOUNT, and there are other CBT records for that same invoice ErrorMsg Should be Displayed",
					"Verifying When User Cannot Improperly ApplyCash When ALLOCATION AMOUNT on the line should is equal to the INVOICE LINE AMOUNT, and there are other CBT records for that same invoice ErrorMsg is Displayed");
		} 
		else
		{
			failed("Verifying When User Cannot Improperly ApplyCash When ALLOCATION AMOUNT on the line should is equal to the INVOICE LINE AMOUNT, and there are other CBT records for that same invoice",
				"Verifying When User Cannot Improperly ApplyCash When ALLOCATION AMOUNT on the line should is equal to the INVOICE LINE AMOUNT, and there are other CBT records for that same invoice ErrorMsg Should be Displayed",
				"Verifying When User Cannot Improperly ApplyCash When ALLOCATION AMOUNT on the line should is equal to the INVOICE LINE AMOUNT, and there are other CBT records for that same invoice ErrorMsg is not Displayed");
		}
			
			
			
		}
	/****************************************
 	 * Name: NavigateToGlobalSearchBar
     * Description:Navigate To GlobalSearchBar For entering the Payment Number 
     * Date: 12-April-2017 
   ****************************************/ 
	
	public void NavigateToGlobalSearchBar(DataRow input, DataRow output) throws InterruptedException 

    {	
		SleepUtils.sleep(TimeSlab.MEDIUM);
    	String PaymentNumber = input.get("PaymentNumber");
    	uiDriver.setValue("SearchSO", PaymentNumber);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("PaymentNumber");
		passed("Verify the PaymentNumber", 
				"PaymentNumber Should be displayed Successfully in the Payment Screen",
				"PaymentNumber is displayed Successfully Payment Screen");
		
		if(uiDriver.checkElementPresent("PaymentLink")){
			passed("Verify the Payment Link Present in the Payment Screen",
					"Payment Link Should be displayed Successfully in the Payment Screen",
					"Payment Link is displayed Successfully in the Payment Screen");
		} 
		else
		{
			failed("Verify the Payment Link Present in the Payment Screen",
					"Payment Link Should be displayed Successfully in the Payment Screen",
					"Payment Link is not  displayed Successfully in the Payment Screen");
		}	
}	
	/****************************************
 	 * Name: VerifyPaidInFullFieldReadsYes
     * Description:Navigate To GlobalSearchBar For entering the Payment Number 
     * Date: 12-April-2017 
   ****************************************/ 
	
	public void VerifyPaidInFullFieldReadsYes(DataRow input, DataRow output) throws InterruptedException {
	
		SleepUtils.sleep(TimeSlab.MEDIUM);
       	String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");
		SleepUtils.sleep(30);
		uiDriver.executeJavaScript("scroll(1200,300)");	
		SleepUtils.sleep(20);
		if(uiDriver.checkElementPresent("PaidInFullField")){
		
			String PaidInFullStatus = uiDriver.getValue("PaidInFull");
			if(PaidInFullStatus.equalsIgnoreCase("Yes")){
				passed("Verify the PaidInFullStatus",
						"PaidInFull Status should be displayed Successfully as  "+PaidInFullStatus+" " ,
						"PaidInFull Status is displayed Successfully as  "+PaidInFullStatus+" " );
			} 
			else
			{
				failed("Verify the PaidInFullStatus",
						"PaidInFull Status should be displayed Successfully as  "+PaidInFullStatus+" " ,
						"PaidInFull Status is displayed Successfully as  "+PaidInFullStatus+" " );
			}		
	}
}	
	
	
	
	/****************************************
 	 * Name: ValidateShowbalance
     * Description:ValidateShowbalance
     * Date: 12-April-2017 
   ****************************************/ 
	
	public void ValidateShowbalance(DataRow input, DataRow output) throws InterruptedException 

    {
		String CurrentAmountexp = input.get("PartialTotalAmt");
		String OtherallocationAmountexp = input.get("RestPartialTotalAmt");
		String InvoiceAmtexp = input.get("Invoiceamount");
		uiDriver.click("ShowBalance");
		SleepUtils.sleep(5);
		uiDriver.switchToWindow("(Script) Cash By Title Allocation Balance:  Results - NetSuite (NBCUniversal Media, LLC - QA)");
		int Rows = uiDriver.webDr.findElements(By.xpath("//table[@id='div__bodytab']/tbody/tr[contains(@id,'row')]")).size();
	double totalamount=0.0;
		for(int i=0;i<Rows-1;i++)
		{
			String lineinvoiceamount = uiDriver.getDyanmicData("lineinvoiceamount");
            String lineamount = lineinvoiceamount.replace("#", Integer.toString(i));
            String amount=uiDriver.getValueByText(lineamount);   
            if(amount.contains(","))
            {
            	amount=amount.replace(",","");
            }
            
        double amount1 = Double.parseDouble(amount);
        
        totalamount=totalamount+amount1;
            
		}
		String Netinvoiceamount = Double.toString(totalamount);
		 uiDriver.executeJavaScript("scroll(1000,0)");
		SleepUtils.sleep(5);
		
		String otherallocation=uiDriver.getValue("Otherallocation");
		SleepUtils.sleep(5);
		String Currentallocation=uiDriver.getValue("Currentallocation");
		double balanceamount = Double.parseDouble(Netinvoiceamount)-	Double.parseDouble(otherallocation)-	Double.parseDouble(Currentallocation);
		String balance=Double.toString(balanceamount);
		passed("verifying Balance",
				"Balance should should be displayed as '" + balance + "' Successfully",
				"Balance is displayed  '" + balance + "' Successfully");
		if(InvoiceAmtexp.equalsIgnoreCase(Netinvoiceamount)||InvoiceAmtexp.contains(Netinvoiceamount.substring(0, Netinvoiceamount.length()-1)))
		{
		passed("verifying Net invoice amount",
				"Net invoice should be displayed as '" + InvoiceAmtexp + "' Successfully",
				"Net invoice is displayed  " + Netinvoiceamount + "Successfully");
		}
		else
		{
			failed("verifying Net invoice amount",
					"Net invoice should be displayed as '" + InvoiceAmtexp + "' Successfully",
					"Net invoice is displayed  " + Netinvoiceamount + "Successfully");
		}
		if(CurrentAmountexp.equalsIgnoreCase(Currentallocation))
		{
		passed("verifying Current amount",
				"Current amount should be displayed as '" + CurrentAmountexp + "' Successfully",
				"Current amount is displayed  " + Currentallocation + "Successfully");
		}
		if(OtherallocationAmountexp.equalsIgnoreCase(otherallocation))
		{
		passed("verifying Other allocation amount",
				"Other allocation amount should be displayed as '" + OtherallocationAmountexp + "' Successfully",
				"Other allocation amount is displayed  " + otherallocation + "Successfully");
		}
		else{
			failed("verifying Other allocation amount",
					"Other allocation amount should be displayed as '" + OtherallocationAmountexp + "' Successfully",
					"Other allocation amount is displayed  " + otherallocation + "Successfully");
			}
		
			
		
		uiDriver.switchToWindow("Title Allocation Parent - NetSuite (NBCUniversal Media, LLC - QA)");
		
		
    }
	
/****************************************
 	 * Name: VerifypaymentlinkonTAP
     * Description:VerifypaymentlinkonTAP
     * Date:30-MArch-2017 
   ****************************************/ 
	public void VerifyInvoice (DataRow input, DataRow output) throws InterruptedException 

    {		
		SleepUtils.sleep(5);
		uiDriver.click("Custom");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,1600)");
		uiDriver.click("TitleAllocationParent");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,600)");
		uiDriver.click("TAPId");
		SleepUtils.sleep(5);
		String Invoice=uiDriver.getValue("InvoiceLink");
		if(Invoice.startsWith("Invoice #"))
		{
			passed("Verifying the Payment link",
					"Payment link should start with Payment #",
					"Payment link starts with Payment #");
		} 
		else
		{
			failed("Verifying the Invoice link",
					"Payment link should  start with Invoice #",
					"Payment link should does not with Invoice #");
		}
		
		uiDriver.click("InvoiceLink");
		SleepUtils.sleep(5);
		
		if(uiDriver.checkPage("Invoice - NetSuite (NBCUniversal Media, LLC - QA)"))
		{
			passed("Verifying the Invoice page",
					"Invoice page  should be displayed",
					"Invoice  page is displayed");
		}
		else
		{
			failed("Verifying the Invoice link",
					"Invoice page  should be displayed",
					"Invoice  page is not displayed");
		}
		
		
		
}
	/****************************************
 	 * Name: ValidateCBTonInvoice
     * ValidateCBTonInvoice
     * Date:16-April-2017 
   ****************************************/ 
	public void ValidateCBTonInvoice(DataRow input, DataRow output) throws InterruptedException 

    {		
				
		SleepUtils.sleep(TimeSlab.MEDIUM);
    		String Num = input.get("conf");
		uiDriver.setValue("SearchINV",Num);    		
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Invoice");
		passed("Invoice Should be displayed Successfully",
				"Invoice is displayed Successfully",
				"Invoice is displayed Successfully");
		SleepUtils.sleep(5);
		uiDriver.refresh();
		uiDriver.executeJavaScript("scroll(0,500)");
		SleepUtils.sleep(5);
		uiDriver.click("Custom");
		uiDriver.executeJavaScript("scroll(0,1500)");
		SleepUtils.sleep(5);
		//uiDriver.executeJavaScript("document.getElementById('recmachcustrecord_nbcu_titleallocpa_contractlnk').click();");
		uiDriver.click("TitleAllocationParent");
		SleepUtils.sleep(5);
		uiDriver.click("SalesTAPId");
		SleepUtils.sleep(5);
		if(uiDriver.checkPage("Title Allocation Parent - NetSuite (NBCUniversal Media, LLC - QA)"))
		{
			passed("Verifying the Title Allocation parent page",
					"Title Allocation parent page  should be displayed",
					" Title Allocation parent  page is displayed");
		}
		else
		{
			failed("Verifying the Title Allocation parent page",
					"Title Allocation parent page  should be displayed",
					" Title Allocation parent  page is not displayed");
		}		
}		
	/****************************************
 	 * Name: VerifyTheJournalCreatedAfterWriteOff
     * Description :VerifyTheJournalCreatedAfterWriteOff
     * Date:16-April-2017 
   ****************************************/ 
	public void VerifyTheJournalCreatedAfterWriteOff(DataRow input, DataRow output) throws InterruptedException 

    {		
		String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");
		SleepUtils.sleep(5);
		uiDriver.refresh();
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("relatedRecord");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("invoiceNo");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("relatedRecord");
		//String JournalLink = uiDriver.getDyanmicData("PaymentLink");
		//String PayLink = PaymentLink.replace("#",PaymentNumber);
		if(uiDriver.checkElementPresent("JournalLink")){
		
			uiDriver.click("JournalLink");
			passed("JournalPage", "JournalPage Should be displayed Successfully ",
					"JournalPage is displayed Successfully");
			 
			uiDriver.executeJavaScript("scroll(0,400)");
			SleepUtils.sleep(TimeSlab.LOW);
		
			int invoiceRow = 2;
			int transRows = uiDriver.webDr.findElements(By.xpath("//*[@id='line_splits']//tbody/tr")).size();
					for (int i = 0; i < transRows - 1; i++) {
						uiDriver.executeJavaScript("scroll(0,100);");
						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Write Off Bad Debt Receivable"))
						{

							if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[2]").equals(""))

							{

								failed("Validating Debit Amount",
								"Validating Debit Amount should be successfull",
								"Debit amount is not Write Off Bad Debt Receivable");

							}

							else
							{

								passed("Debit Amount is Write Off Bad Debt Receivable",
										"Write Off Bad Debt Receivable Should be Debited with the amount Successfully",
										"Write Off Bad Debt Receivable is Debited with the amount Successfully");


							}

						}

						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Generic Billed"))
						{

							if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals(""))

							{

								failed("Validating Credit Amount",
								"Validating Credit Amount should be successfull",
								"Credit amount is not Generic Billed");

							}

							else
							{

								passed("Credit is Generic Billed",
								"Generic Billed Should be Credited with the amount Successfully",
								"Generic Billed is Credited with the amount Successfully");

							}

						}

						
						
						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Billed Intl AR FTV/BC"))
						{
							if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals(""))
							{

								failed("Validating Credit Amount",
								"Validating Credit Amount should be successfull",
								"Credit amount is not Contract revenue - Dom");

							}

							else
							{
								passed("Credit Amount is Billed Intl AR FTV/BC",
										"Billed Intl AR FTV/BC Should be Credit with the amount Successfully",
										"Billed Intl AR FTV/BCis Credit with the amount Successfully");

							}
						}

						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Billed Intl AR Pay"))
						{
							if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals(""))
							{

								failed("Validating Credit Amount",
								"Validating Credit Amount should be successfull",
							     "Credit amount is not Billed Dom AR");
							}

							else
							{
								passed("Credit Amount is Billed Intl AR Pay",
										"Billed Intl AR Pay Should be Credit with the amount Successfully",
										"Billed Intl AR Pay is Credit with the amount Successfully");

							}
						}

						invoiceRow++;

					}

				} 			
	
   }	
	
	
	
	
	
	
	

		
		
		
		
		
		
		
		
		
		
		
		
		


	  /*Name: ValidateAllocationARAmount
	     *Description: ValidateAllocationARAmount
	     * Date:29-Mar-2018 
	     ****************************************/  	 
	 public void ValidateAllocationARAmount(DataRow input, DataRow output) throws InterruptedException
	    {
	 
	 		SleepUtils.sleep(TimeSlab.YIELD);
	    
	    String AllocatedAramount=uiDriver.getValue("ARAmountLine1");
	      if(AllocatedAramount.equals("0.00"))
	    {
	    	
	    	passed("Validated AllocatedAramount "+AllocatedAramount+"",
                 "AllocatedAramount should be validated successfully"+AllocatedAramount+"",
                  "SuccessFully Validated AllocatedAramount"+AllocatedAramount+"");
	    }
	      else
	      {
	    	  failed("Not Validated AllocatedAramount "+AllocatedAramount+"",
                 "AllocatedAramount should be validated successfully"+AllocatedAramount+"",
                  "AllocatedAramount is not validated successfully "+AllocatedAramount+"");
	      }
	    }
	 
	 /****************************************
	 	 * Name: EditAmountToCredit
	     *Description: EditAmountToCredit
	     * Date:17-Apr-2018 
	     ****************************************/ 
	  
		public void EditAmountToCredit(DataRow input, DataRow output) throws InterruptedException 
	    {
			SleepUtils.sleep(5);
			String invoicenum = uiDriver.getValue("invoicenum");
			uiDriver.click("CreditButton");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.executeJavaScript("scroll(0,1000)");
				uiDriver.click("LineItem2");
				SleepUtils.sleep(TimeSlab.LOW);	
				uiDriver.click("RemoveButton");
				SleepUtils.sleep(5);
				uiDriver.click("ApplyBtn");	
				 String partialpayment = uiDriver.getDyanmicData("partialpaymentfield");
		            SleepUtils.sleep(TimeSlab.YIELD);
		            String ReferenceVal1 = partialpayment.replace("#", invoicenum);				
				if(uiDriver.checkElementPresent_dynamic(ReferenceVal1)){
		           	 
		         	   SleepUtils.sleep(10);
		         	   uiDriver.click_dynamic(ReferenceVal1);
		                uiDriver.click_dynamic(ReferenceVal1);  
		           }
		            else{
		          	   
		          	   SleepUtils.sleep(TimeSlab.LOW);
		          	   uiDriver.click("FilterNumber");
		          	   uiDriver.click("FirstFilteringNumber");
		          	   uiDriver.executeJavaScript("scroll(0,800)");
		          	   SleepUtils.sleep(TimeSlab.LOW);
		          	  if(uiDriver.checkElementPresent_dynamic(ReferenceVal1)){
		                
		          		uiDriver.click_dynamic(ReferenceVal1);
		                 uiDriver.click_dynamic(ReferenceVal1); 
		          	    SleepUtils.sleep(TimeSlab.MEDIUM);
		          	  }
		          	  else{
		          		  
		          	   SleepUtils.sleep(TimeSlab.LOW);
		          	  uiDriver.executeJavaScript("scroll(0,-800)");
		            	   uiDriver.click("FilterNumber");
		            	   uiDriver.click("SecondFilteringNumber");
		            	   uiDriver.executeJavaScript("scroll(0,800)");
		            	   SleepUtils.sleep(TimeSlab.LOW);
		            	  if(uiDriver.checkElementPresent_dynamic(ReferenceVal1)){
		                  
		            		uiDriver.click_dynamic(ReferenceVal1);
		                   uiDriver.click_dynamic(ReferenceVal1); 
		            	    SleepUtils.sleep(TimeSlab.MEDIUM);
		            	    
		            	  }
		            	  else{
		            		  
		            		 SleepUtils.sleep(TimeSlab.LOW);
		            		 uiDriver.executeJavaScript("scroll(0,-800)");
		              	   uiDriver.click("FilterNumber");
		              	   uiDriver.click("ThirdFilteringNumber");
		              	   uiDriver.executeJavaScript("scroll(0,800)");
		              	   SleepUtils.sleep(TimeSlab.LOW);
		              	  if(uiDriver.checkElementPresent_dynamic(ReferenceVal1)){
		                    
		              		uiDriver.click_dynamic(ReferenceVal1);
		                     uiDriver.click_dynamic(ReferenceVal1); 
		              	    SleepUtils.sleep(TimeSlab.MEDIUM);
		              	    
		              	  }
		            	  }
		          	  }
		            }
		            	  	          	  
				uiDriver.click("SaveButton");
				SleepUtils.sleep(5);
					           
	            
	    }	
	
		/****************************************
	 	 * Name: updateXPGandSOtype
	     * Description:updateXPGandSOtype
	     * Date:7-May-2018
	   ****************************************/ 
		public void updateXPGandSOtype(DataRow input, DataRow output) throws InterruptedException 

	    {
			uiDriver.click("Custom");
			uiDriver.setValue("SOType", "Guarantee");
			uiDriver.click("XPG");
			passed("XPG and SO Type update",
	                 "XPG and SO Type should be updated",
	                  "XPG and SO Type  is updated");
	    }
				
	
		/****************************************
	 	 * Name: EditReviseSalesOrderToAddLineItem
	     * Description:EditReviseSalesOrderToAddLineItem
	     * Date:06-May-2017 
	   ****************************************/ 
		
		public void EditReviseSalesOrderToAddLineItem(DataRow input, DataRow output) throws InterruptedException 
	    {
			String Num = input.get("conf");
			uiDriver.setValue("SearchSO", Num);
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("SalesOrder");
			passed("SalesOrder", "SalesOrder Should be displayed Successfully",
					"SalesOrder is displayed Successfully");
			SleepUtils.sleep(5);
			uiDriver.click("ReviseOrder");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("EditforRevise");
			SleepUtils.sleep(15);
			uiDriver.executeJavaScript("scroll(0,600)");

	    }
	
		
		/****************************************
	 	 * Name: AddSalesOrderAfterRevising
	     * Description:AddSalesOrderAfterRevising
	     * Date:06-May-2017 
	   ****************************************/ 
		
		public void AddSalesOrderAfterRevising(DataRow input, DataRow output) throws InterruptedException 
    {	
			String row = "";
			SleepUtils.sleep(TimeSlab.HIGH);
			row = uiDriver.getObjMap("addListTable");
			row = row + "//" + "tr" + "[" + i + "]" + "";
			
			//uiDriver.executeJavaScript("document.getElementById('inpt_custcol_nbcu_action10').value='New SO Line';");
			uiDriver.click("SoLineNum");
			uiDriver.setValue("SoLineNum","New SO Line");
			uiDriver.click("SoLineNum");
 			String Item = uiDriver.getDyanmicData("item");
			String ItemColumn = Integer.toString(ItemCol);
			String ItemCols = Item.replace("#", ItemColumn);
			uiDriver.click_dynamic(ItemCols);
			ItemCol++;
			
			List<WebElement> ele = uiDriver.webDr.findElements(By.xpath("//*[@id='item_headerrow']/td"));
			uiDriver.setValue("item1", input.get("item"));
			uiDriver.click("item1");
			String dataLable = "";

			for (int i = 0; i <= ele.size() - 1; i++) {
				try {
					dataLable = ele.get(i).getAttribute("data-label");
					switch (dataLable) {
					case "Market Code":

						if (!input.get("marketCode").equalsIgnoreCase("yes")) {

							uiDriver.click(row + "/td[" + (i + 1) + "]");
							uiDriver.click(row + "/td[" + (i + 1) + "]");
							uiDriver.click("marketCodeSet");
							SleepUtils.sleep(TimeSlab.YIELD);
							// uiDriver.setValue("marketCodeSet",
							// input.get("marketCode"));
							String MarketCode = uiDriver.getDyanmicData("marketCodeSet1");
							String marcode = MarketCode.replace("#",input.get("marketCode"));
							uiDriver.click(marcode);
							// uiDriver.click("market");
							// uiDriver.sendKey("enter");
							SleepUtils.sleep(TimeSlab.YIELD);
						}
						break;

					case "PTMG":

						if (input.get("ptmg").equalsIgnoreCase("yes")) {
							uiDriver.click(row + "/td[" + (i + 1) + "]");
							uiDriver.executeJavaScript("document.getElementById('item_custcol_nbcu_ptmg_fs_inp').click();");
						}

						break;

					case "On Network":

						if (input.get("onNetwork").equalsIgnoreCase("yes")) {
							SleepUtils.sleep(TimeSlab.YIELD);

							uiDriver.click(row + "/td[" + (i + 1) + "]");
							uiDriver.executeJavaScript("document.getElementById('item_custcol_nbcu_on_network_fs_inp').click()");
						}
						break;

					case "Rev Rec Method":

						SleepUtils.sleep(TimeSlab.YIELD);
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.click("revRecMthdSet");
						uiDriver.setValue("revRecMthdSet",input.get("revRecMthdSet"));
						SleepUtils.sleep(TimeSlab.YIELD);

						break;

					case "Title ID":
						SleepUtils.sleep(TimeSlab.YIELD);
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.click("titleSet");
						uiDriver.setValue("titleSet", input.get("titleSet"));
						SleepUtils.sleep(TimeSlab.YIELD);
						break;

					case "Territory":

						uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[9].click();");
						SleepUtils.sleep(TimeSlab.YIELD);
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.setValue("territorySet", input.get("territorySet"));
						uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[16].click();");
						break;

					case "Allocation Group":
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.click("allocationGroupSet");
						uiDriver.setValue("allocationGroupSet",input.get("allocationGroupSet"));
						SleepUtils.sleep(TimeSlab.YIELD);
						break;

					case "License Fee Type":
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[18].click();");
						uiDriver.click("licenseFeeTypeSet");
						uiDriver.setValue("licenseFeeTypeSet",input.get("licenseFeeTypeSet"));
						SleepUtils.sleep(TimeSlab.YIELD);
						break;

					case "Product Category":
						SleepUtils.sleep(TimeSlab.HIGH);
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[19].click();");
						uiDriver.clear("productCategorySet");
						uiDriver.click("productCategorySet");
						uiDriver.setValue("productCategorySet",input.get("productCategorySet"));
						break;

					case "Product Type":
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[20].click();");
						uiDriver.click("productTypeSet");
						uiDriver.setValue("productTypeSet",input.get("productTypeSet"));
						SleepUtils.sleep(TimeSlab.YIELD);

						break;
					case "Right":

						uiDriver.click(row + "/td[" + (i + 1) + "]");
						// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[21].click();");
						SleepUtils.sleep(TimeSlab.YIELD);
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.click("rightSet");
						String right = uiDriver.getDyanmicData("right1");
						String Right = right.replace("#", input.get("rightSet"));
						uiDriver.click(Right);
						// uiDriver.setValue("rightSet", input.get("rightSet"));
						SleepUtils.sleep(TimeSlab.YIELD);
						break;
				
					case "Quantity":
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[25].click();");
						uiDriver.click("quantitySet");		
						uiDriver.executeJavaScript("document.getElementById('quantity_formattedValue').value = ''");
						SleepUtils.sleep(5);
						uiDriver.setValue("quantitySet", input.get("quantitySet"));
						SleepUtils.sleep(TimeSlab.YIELD);

						break;

					case "Rate":
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[26].click();");
						SleepUtils.sleep(TimeSlab.YIELD);
						uiDriver.click("rateSet");
						uiDriver.setValue("rateSet", input.get("rateSet"));
						break;

					case "License Fee":
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[28].click();");
						SleepUtils.sleep(TimeSlab.YIELD);
						uiDriver.click("licensefeeSet");
						uiDriver.setValue("licensefeeSet",input.get("licensefeeSet"));
						break;

					case "License Period Start Date":
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[33].click();");
						SleepUtils.sleep(TimeSlab.YIELD);
						uiDriver.click("licenseStartDateSet");
						uiDriver.setValue("licenseStartDateSet",
								input.get("licenseStartDateSet"));
						SleepUtils.sleep(TimeSlab.YIELD);
						break;

					case "License Period End Date":
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[34].click();");
						uiDriver.click("licenseEndDateSet");
						uiDriver.setValue("licenseEndDateSet",
								input.get("licenseEndDateSet"));
						break;

					case "Delivery Date":

						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[35].click();");
						uiDriver.click("deliveryDateSet");
						uiDriver.setValue("deliveryDateSet",
								input.get("deliveryDateSet"));
						SleepUtils.sleep(TimeSlab.YIELD);
						break;

					case "Air Date":
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[36].click();");
						uiDriver.click("airDateSet");
						uiDriver.setValue("airDateSet", input.get("airDateSet"));
						uiDriver.click("addBtn");
						break;

					case "XPG FLAG":

						break;
					case "Late Night":

						break;
					case "FMV Dimension":

						break;

					}
				} catch (org.openqa.selenium.StaleElementReferenceException e) {

					continue;
				}

			}
    }	
		
		
	
	
/****************************************
 * Name: updateReclasstoblankvalues
 * Description:updateReclasstoblankvalues
 * Date:30-MArch-2017 
****************************************/ 

public void UpdateReclasstoblankvaluesForReviseSalesOrder(DataRow input, DataRow output) throws InterruptedException
{
	uiDriver.click("SaveBtn");
	if(uiDriver.isAlertPresent()){
		uiDriver.handleAlert("", "OK");
		uiDriver.executeJavaScript("scroll(0,-500)");
		uiDriver.click("saveBtn");
		uiDriver.click("DuplicateSave");		
		passed("Click On save button", "Details Should be saved successfully",
			"Details is saved successfully");
			 		
	}
	else{
		//do nothing
	}
	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("Edit");
	passed("Click on edit button",
			"edit button should be clicked successfully",
			"edit button should be clicked successfully");
	uiDriver.executeJavaScript("scroll(1000,2000)");
	int Rows = uiDriver.webDr.findElements(By.xpath("//*[@id='item_splits']/tbody/tr[contains(@id,'item_row')]")).size();
	for(int i=1;i<=Rows;i++)
    {
          String unbilledrevenuacct = uiDriver.getDyanmicData("unbilledrevenueaccount");
          String unbilledrevenueaccount = unbilledrevenuacct.replace("#", Integer.toString(i));
          uiDriver.click_dynamic(unbilledrevenueaccount);    
          SleepUtils.sleep(TimeSlab.LOW);
          uiDriver.setValue("editunbilledrevenueaccount","");
          passed("unbilledrevenuacct set to null",
    				"unbilledrevenuacct should be set to null",
    				"unbilledrevenuacct is set to null");
          String billedrevenuacct = uiDriver.getDyanmicData("billedrevenueaccount");
          String billedrevenueaccount = billedrevenuacct.replace("#", Integer.toString(i));
          uiDriver.click_dynamic(billedrevenueaccount);               
          uiDriver.setValue("editbilledrevenueaccount","");
          passed("billedrevenuacct set to null",
  				"billedrevenuacct should be set to null",
  				"billedrevenuacct is set to null");
          SleepUtils.sleep(TimeSlab.LOW);
          
          String billedARacct = uiDriver.getDyanmicData("billedARaccount");
          String billedARaccount = billedARacct.replace("#", Integer.toString(i));
          uiDriver.click_dynamic(billedARaccount);               
          uiDriver.setValue("editbilledARaccount","");
          passed("billedARacct set to null",
    				"billedARacct should be set to null",
    				"billedARacct is set to null");
          String unbilledARacct = uiDriver.getDyanmicData("unbilledARaccount");
          String unbilledARaccount = unbilledARacct.replace("#", Integer.toString(i));
          uiDriver.click_dynamic(unbilledARaccount);               
          uiDriver.setValue("editunbilledARaccount","");
          passed("unbilledARacct set to null",
  				"unbilledARacct should be set to null",
  				"unbilledARacct is set to null");
          
          String paiddeferredacct = uiDriver.getDyanmicData("paiddeferredaccount");
          String paiddeferredaccount = paiddeferredacct.replace("#", Integer.toString(i));
          uiDriver.click_dynamic(paiddeferredaccount);               
          uiDriver.setValue("editpaiddeferredaccount","");
          passed("paiddeferredacct set to null",
    				"paiddeferredacct should be set to null",
    				"paiddeferredacct is set to null");
          String unpaiddeferredacct = uiDriver.getDyanmicData("unpaiddeferredaccount");
          String unpaiddeferredaccount = unpaiddeferredacct.replace("#", Integer.toString(i));
          uiDriver.click_dynamic(unpaiddeferredaccount);               
          uiDriver.setValue("editunpaiddeferredaccount","");
          passed("unpaiddeferredacct set to null",
  				"unpaiddeferredacct should be set to null",
  				"unpaiddeferredacct is set to null");
          String baddebtacct = uiDriver.getDyanmicData("baddebtaccount");
          String baddebtacctaccount = baddebtacct.replace("#", Integer.toString(i));
          uiDriver.click_dynamic(baddebtacctaccount);               
          uiDriver.setValue("editbaddebtaccount","");
          passed("baddebtacct set to null",
    				"baddebtacct should be set to null",
    				"baddebtacct is set to null");
          uiDriver.click("OK");
    }
	uiDriver.click("SaveBtn");
	
	
}
/****************************************
 * Name: VerifyThreeLicenseTypeValues
 * Description: VerifyThreeLicenseTypeValues
 * Date: 14-May-2018 
****************************************/ 

public void VerifyThreeLicenseTypeValues(DataRow input, DataRow output) throws InterruptedException
{
	
    uiDriver.click("LicenseFeeTypeDropDown");
    List<WebElement> LicenseFeeType = uiDriver.webDr.findElements(By.xpath("//*[@id='ext-gen3']/div[7]/div/div/div"));  
   for(int i=3;i<LicenseFeeType.size();i++){
	   try{
		  
    	String LicenseValues =  LicenseFeeType.get(i).getText();
    	String Values = input.get("LicenseValues");
    	String LicenseTypeVal[] = Values.split(";");
    	String LicenseFeeType1 = LicenseTypeVal[0];
    	String LicenseFeeType2 = LicenseTypeVal[1];
    	String LicenseFeeType3 = LicenseTypeVal[2];
    	if(LicenseValues.equalsIgnoreCase(LicenseFeeType1) || LicenseValues.equalsIgnoreCase(LicenseFeeType2) || LicenseValues.equalsIgnoreCase(LicenseFeeType3) ){
    		passed("LicenseFeeType value should be displayed",
					"LicenseFeeType value should be displayed as "+LicenseValues+"  ",
					"LicenseFeeType value is displayed as "+LicenseValues+"  ");

		} else {
			failed("LicenseFeeType value should be displayed",
					"LicenseFeeType value should be displayed as "+LicenseValues+"  ",
					"LicenseFeeType value is not displayed as "+LicenseValues+"  ");

		}	
    		
   }
  
   	catch(Exception e){
   		
   		
    	
    }
	
	
   }
	
}

/****************************************
 * Name: VerifySOTypeValues
 * Description: Verify SO TypeValues
 * Date: 14-May-2018 
****************************************/ 

public void VerifyFeecalcSalesorder(DataRow input, DataRow output) throws InterruptedException
{
	
}


/****************************************
 * Name: VerifySOTypeValues
 * Description: Verify SO TypeValues
 * Date: 14-May-2018 
****************************************/ 

public void VerifySOTypeValues(DataRow input, DataRow output) throws InterruptedException
{
	uiDriver.executeJavaScript("scroll(0,200)");
	uiDriver.click("Custom");
	uiDriver.executeJavaScript("scroll(0,200)");
	uiDriver.click("SOTypeDropDown");
    List<WebElement> SOType = uiDriver.webDr.findElements(By.xpath("//*[@id='ext-gen3']/div[10]/div/div/div"));  
   for(int i=2;i<SOType.size();i++){
	   try{
		  
    	String SOValues =  SOType.get(i).getText();
    	String Values = input.get("SOValues");
    	String SOTypeVal[] = Values.split(";");
    	String SOType1 = SOTypeVal[0];
    	String SOType2 = SOTypeVal[1];
    	String SOType3 = SOTypeVal[2];
    	if(SOValues.equalsIgnoreCase(SOType1) || SOValues.equalsIgnoreCase(SOType2) || SOValues.equalsIgnoreCase(SOType3) ){
    		passed("SOType value should be displayed",
					"SOType value should be displayed as "+SOValues+"  ",
					"SOType value is displayed as "+SOValues+"  ");

		} else {
			failed("SOType value should be displayed",
					"SOType value should be displayed as "+SOValues+"  ",
					"SOType value is not displayed as "+SOValues+"  ");

		}	
    		
   }
  
   	catch(Exception e){
   		
   		
    	
    }
	
	
   }
	
}

/****************************************
 * Name: NavigateToSalesOrderScreen
 * Description: NavigateToSalesOrderScreen
 * Date: 14-May-2018 
****************************************/ 

public void NavigateToSalesOrderScreen(DataRow input, DataRow output) throws InterruptedException
{
     
      SleepUtils.sleep(TimeSlab.HIGH);
      String Num = input.get("conf");
      uiDriver.setValue("SearchSO", Num);
      SleepUtils.sleep(TimeSlab.MEDIUM);
      if(input.get("ContractNum").equals("Y")){
            uiDriver.click("//a[text()='Master Contract Parent: ']");
            SleepUtils.sleep(TimeSlab.HIGH);
            uiDriver.click("(//td[text()='Sales Order']/following-sibling::td/a)[1]");
            SleepUtils.sleep(TimeSlab.HIGH);
      }
      else{
      uiDriver.click("SalesOrder");
      SleepUtils.sleep(TimeSlab.HIGH);
      //SleepUtils.sleep(TimeSlab.HIGH);
      passed("SalesOrder", "SalesOrder Should be displayed Successfully",
            "SalesOrder is displayed Successfully");
            SleepUtils.sleep(5);
           
      }
      String SalesNum = uiDriver.getValue("SalesNum");
      output.put("SalesOrderNum", SalesNum);
}

/****************************************
 * Name: VerifyPaymentRecord
 * Description: VerifyPaymentRecord
 * Date: 11-November-2018 
****************************************/ 

public void VerifyPaymentRecord(DataRow input, DataRow output) throws InterruptedException
{
     
      SleepUtils.sleep(TimeSlab.HIGH);
      String Num = input.get("PaymentNum");
      uiDriver.setValue("SearchSO", Num);
      SleepUtils.sleep(TimeSlab.MEDIUM);      
      uiDriver.click("PaymentNumber");
      SleepUtils.sleep(TimeSlab.HIGH);
      SleepUtils.sleep(TimeSlab.HIGH);
      passed("PaymentNumber", "Payment Number Should be displayed Successfully",
            "PaymentNumber is displayed Successfully");
      SleepUtils.sleep(5);
      uiDriver.executeJavaScript("scroll(0,2500)");
      String Payamnt=uiDriver.getValue("PaymentAmount");
      if (Payamnt.contains(input.get("PaymentRecord"))) {

			passed("Verifying the PaymentRecord",
					"Amount should be displayed as " + Payamnt + " ",
					"Amount is displayed as " + input.get("PaymentRecord")
							+ " ");

		} else {
			failed("Verifying the PaymentRecord",
					"Amount should be displayed as " + Payamnt + " ",
					"Amount is displayed as " + input.get("PaymentRecord")
							+ " ");

		}     
}

/****************************************
 * Name: VerifyPaymentAmountNotApplied
 * Description: VerifyPaymentAmountNotApplied
 * Date: 11-November-2018 
****************************************/ 

public void VerifyPaymentAmountNotApplied(DataRow input, DataRow output) throws InterruptedException
{
	  uiDriver.executeJavaScript("scroll(0,2500)");
	  String Payamnt=uiDriver.getValue("PaymentAmount");
      if (Payamnt.contains(input.get("PaymentRecord"))) {

			passed("Verifying the PaymentRecord",
					"Amount should be displayed as " + Payamnt + " ",
					"Amount is displayed as " + input.get("PaymentRecord")
							+ " ");

		} else {
			failed("Verifying the PaymentRecord",
					"Amount should not be displayed as " + Payamnt + " ",
					"Amount is not displayed as " + input.get("PaymentRecord")
							+ " ");

		} 
      
      if(input.get("Record").equals("Y")){
      String NoRcds=uiDriver.getValue("NoRecords");
      if (NoRcds.contains(input.get("Status"))) {
			passed("Verifying the PaymentRecord",
					"Amount should be displayed as " + NoRcds + " ",
					"Amount is displayed as " + input.get("Status")
							+ " ");

		} else {
			failed("Verifying the PaymentRecord",
					"Amount should not be displayed as " + NoRcds + " ",
					"Amount is not displayed as " + input.get("Status")
							+ " ");

		}
      }
      uiDriver.executeJavaScript("scroll(0,-2500)");
      
	  String applied=uiDriver.getValue("PaymentAmountapplied");
      if (applied.contains(input.get("AppliedAmount"))) {

			passed("Verifying the PaymentAmountapplied",
					"Amount should not be displayed as " + applied + " ",
					"Amount is not displayed as " + input.get("AppliedAmount")
							+ " ");

		} else {
			failed("Verifying the PaymentRecord",
					"Amount should not be displayed as " + applied + " ",
					"Amount is not displayed as " + input.get("AppliedAmount")
							+ " ");

		} 
      uiDriver.executeJavaScript("scroll(0,-2500)");
      SleepUtils.sleep(TimeSlab.MEDIUM);
	  String unapplied=uiDriver.getValue("PaymentAmountunapplied");
      if (unapplied.contains(input.get("UnappliedAmount"))) {

			passed("Verifying the PaymentRecord",
					"Amount should be displayed as " + unapplied + " ",
					"Amount is displayed as " + input.get("UnAppliedAmount")
							+ " ");

		} else {
			failed("Verifying the PaymentRecord",
					"Amount should be displayed as " + unapplied + " ",
					"Amount is displayed as " + input.get("UnAppliedAmount")
							+ " ");

		} 
      
      
}

/****************************************
* Name: EditSalesOrder
* Description: EditSalesOrder
* Date: 14-May-2018 
****************************************/ 

public void EditSalesOrder(DataRow input, DataRow output) throws InterruptedException
{

	uiDriver.executeJavaScript("scroll(0,-300)");
	uiDriver.click("EditSalesOrder");
	 SleepUtils.sleep(TimeSlab.LOW);

}


/****************************************
 * Name: VerifySOSubTypeValues
 * Description: Verify SOSubType Values
 * Date: 14-May-2018 
****************************************/ 

public void VerifySOSubTypeValues(DataRow input, DataRow output) throws InterruptedException
{
	uiDriver.executeJavaScript("scroll(0,200)");
	uiDriver.click("SOSubType");
	uiDriver.click("SOSubTypeDropDown");
    List<WebElement> SOSubType = uiDriver.webDr.findElements(By.xpath("//*[@id='ext-gen3']/div[7]/div/div/div"));  
   for(int i=2;i<SOSubType.size();i++){
	   try{
		  
    	String SOSubValues =  SOSubType.get(i).getText();
    	String Values = input.get("SOSubValues");
    	String SOSubTypeVal[] = Values.split(";");
    	String SOSubType1 = SOSubTypeVal[0];
    	String SOSubType2 = SOSubTypeVal[1];
    	String SOSubType3 = SOSubTypeVal[2];
    	String SOSubType4 = SOSubTypeVal[3];
    	String SOSubType5 = SOSubTypeVal[4];
    	String SOSubType6 = SOSubTypeVal[5];
    	   	
    	if(SOSubValues.equalsIgnoreCase(SOSubType1) || SOSubValues.equalsIgnoreCase(SOSubType2) || SOSubValues.equalsIgnoreCase(SOSubType3) || SOSubValues.equalsIgnoreCase(SOSubType4) || SOSubValues.equalsIgnoreCase(SOSubType5)|| SOSubValues.equalsIgnoreCase(SOSubType6)){
    		passed("SOType value should be displayed",
					"SOType value should be displayed as "+SOSubValues+"  ",
					"SOType value is displayed as "+SOSubValues+"  ");

		} else {
			failed("SOType value should be displayed",
					"SOType value should be displayed as "+SOSubValues+"  ",
					"SOType value is not displayed as "+SOSubValues+"  ");

		}	
    		
   }
  
   	catch(Exception e){
   		
   		
    	
    }
	
	
   }
}  
   
   /****************************************
    * Name: VerifyContinuousProductionAndOnNetworkValues
    * Description: Verify SOSubType Values
    * Date: 14-May-2018 
   ****************************************/ 

   public void VerifyContinuousProductionAndOnNetworkValues(DataRow input, DataRow output) throws InterruptedException
   { 
	   
	   uiDriver.click("ContinuousProduction");
	   SleepUtils.sleep(TimeSlab.LOW);
	   uiDriver.click("ContinuousProduction");
	   SleepUtils.sleep(TimeSlab.LOW);
	   if (uiDriver.checkElementPresent("ContinuousProductionCheckBox")) {
           passed("Check for ContinuousProduction CheckBox",
                   "ContinuousProduction CheckBox Should be displayed Successfully",
                    "ContinuousProduction CheckBox is displayed Successfully");
     } else {

    	 failed("Check for ContinuousProduction CheckBox",
                 "ContinuousProduction CheckBox Should be displayed Successfully",
                  "ContinuousProduction CheckBox is not displayed Successfully");
    }
	   
	 uiDriver.click("OnNetWork");
	 SleepUtils.sleep(TimeSlab.LOW);
	 uiDriver.click("OnNetWork");
	  if (uiDriver.checkElementPresent("OnNetworkCheckBox")) {
          passed("Check for OnNetwork CheckBox",
                  "OnNetwork CheckBox Should be displayed Successfully",
                   "OnNetwork CheckBox is displayed Successfully");
    } else {

   	 failed("Check for OnNetwork CheckBox",
                "OnNetwork CheckBox Should be displayed Successfully",
                 "OnNetwork CheckBox is not displayed Successfully");
   } 
 
}


/****************************************
 * Name: VerifyRevRecMethodValues
 * Description: VerifyRevRecMethodValues
 * Date: 14-May-2018 
****************************************/ 

public void VerifyRevRecMethodValues(DataRow input, DataRow output) throws InterruptedException
{
	uiDriver.executeJavaScript("scroll(0,200)");
	uiDriver.click("RevRecMethod");
	uiDriver.click("RevRecMethodDropDown");
    List<WebElement> RevRecMethodType = uiDriver.webDr.findElements(By.xpath("//*[@id='ext-gen3']/div[7]/div/div/div"));  
   for(int i=1;i<RevRecMethodType.size();i++){
	   try{
		  
    	String RevRecMethodValues =  RevRecMethodType.get(i).getText();
    	String Values = input.get("RevRecMethodValues");
    	String RevRecMethodTypeVal[] = Values.split(";");
    	String RevRecMethodType1 = RevRecMethodTypeVal[0];
    	String RevRecMethodType2 = RevRecMethodTypeVal[1];
    	String RevRecMethodType3 = RevRecMethodTypeVal[2];
    	String RevRecMethodType4 = RevRecMethodTypeVal[3];
    	String RevRecMethodType5 = RevRecMethodTypeVal[4];
    	String RevRecMethodType6 = RevRecMethodTypeVal[5];
    	String RevRecMethodType7 = RevRecMethodTypeVal[6];
    	String RevRecMethodType8 = RevRecMethodTypeVal[7];
    	String RevRecMethodType9 = RevRecMethodTypeVal[8];
    	String RevRecMethodType10 = RevRecMethodTypeVal[9];
    	
    	if(RevRecMethodValues.contains(RevRecMethodType1) || RevRecMethodValues.equalsIgnoreCase(RevRecMethodType2) || RevRecMethodValues.equalsIgnoreCase(RevRecMethodType3) || RevRecMethodValues.equalsIgnoreCase(RevRecMethodType4)||  RevRecMethodValues.equalsIgnoreCase(RevRecMethodType5)|| RevRecMethodValues.equalsIgnoreCase(RevRecMethodType6)|| RevRecMethodValues.equalsIgnoreCase(RevRecMethodType7)||RevRecMethodValues.equalsIgnoreCase(RevRecMethodType8)|| RevRecMethodValues.equalsIgnoreCase(RevRecMethodType9)|| RevRecMethodValues.equalsIgnoreCase(RevRecMethodType10)){
    		passed("RevRecMethodType value should be displayed",
					"RevRecMethodType value should be displayed as "+RevRecMethodValues+"  ",
					"RevRecMethodType value is displayed as "+RevRecMethodValues+"  ");

		} else {
			failed("RevRecMethodType value should be displayed",
					"RevRecMethodType value should be displayed as "+RevRecMethodValues+"  ",
					"RevRecMethodType value is not displayed as "+RevRecMethodValues+"  ");

		}	
    		
   }
  
   	catch(Exception e){
   		
   		
    	
    }
	
	
   }
}  


/****************************************
 * Name: VerifyDateFieldOnTheSOLine
 * Description: VerifyDateFieldOnTheSOLine
 * Date: 15-May-2018 
****************************************/ 

public void VerifyDateFieldOnTheSOLine(DataRow input, DataRow output) throws InterruptedException
{
	 if (uiDriver.checkElementPresent("LicensePeriodStartDate")) {
         passed("Verify LicensePeriodStartDate",
                 "LicensePeriodStartDate field Should be displayed Successfully",
                  "LicensePeriodStartDate field is displayed Successfully");
   } else {

	   failed("Verify LicensePeriodStartDate",
               "LicensePeriodStartDate field Should be displayed Successfully",
                "LicensePeriodStartDate field is not displayed Successfully");
  } 

	 if (uiDriver.checkElementPresent("LicensePeriodEndDate")) {
         passed("Verify LicensePeriodEndDate",
                 "LicensePeriodEndDate field Should be displayed Successfully",
                  "LicensePeriodEndDate field is displayed Successfully");
   } else {

	   failed("Verify LicensePeriodEndDate",
               "LicensePeriodEndDate field Should be displayed Successfully",
                "LicensePeriodEndDate field is not displayed Successfully");
  } 
 
	
	 if (uiDriver.checkElementPresent("DeliveryDate")) {
         passed("Verify DeliveryDate",
                 "DeliveryDate field Should be displayed Successfully",
                  "DeliveryDate field is displayed Successfully");
   } else {

	   failed("Verify DeliveryDate",
               "DeliveryDate field Should be displayed Successfully",
                "DeliveryDate field is not displayed Successfully");
  } 
 
	 if (uiDriver.checkElementPresent("OfferedDate")) {
         passed("Verify OfferedDate",
                 "OfferedDate field Should be displayed Successfully",
                  "OfferedDate field is displayed Successfully");
   } else {

	   failed("Verify OfferedDate",
               "DeliveryDate field Should be displayed Successfully",
                "DeliveryDate field is not displayed Successfully");
  } 
 
	 if (uiDriver.checkElementPresent("AirDate")) {
         passed("Verify AirDate",
                 "AirDate field Should be displayed Successfully",
                  "AirDate field is displayed Successfully");
   } else {

	   failed("Verify AirDate",
               "AirDate field Should be displayed Successfully",
                "AirDate field is not displayed Successfully");
  } 
	 
	 if (uiDriver.checkElementPresent("RevenueRecognitionStartDate")) {
         passed("Verify RevenueRecognitionStartDate",
                 "RevenueRecognitionStartDate field Should be displayed Successfully",
                  "RevenueRecognitionStartDate field is displayed Successfully");
   } else {

	   failed("Verify RevenueRecognitionStartDate",
               "RevenueRecognitionStartDate field Should be displayed Successfully",
                "RevenueRecognitionStartDate field is not displayed Successfully");
  } 
	
	 
	 if (uiDriver.checkElementPresent("RevenueRecognitionEndDate")) {
         passed("Verify RevenueRecognitionEndDate",
                 "RevenueRecognitionEndDate field Should be displayed Successfully",
                  "RevenueRecognitionEndDate field is displayed Successfully");
   } else {

	   failed("Verify RevenueRecognitionEndDate",
               "RevenueRecognitionEndDate field Should be displayed Successfully",
                "RevenueRecognitionEndDate field is not displayed Successfully");
  }  
	 
	 if (uiDriver.checkElementPresent("MeasurementDate")) {
         passed("Verify MeasurementDate",
                 "MeasurementDate field Should be displayed Successfully",
                  "MeasurementDate field is displayed Successfully");
   } else {

	   failed("Verify MeasurementDate",
               "MeasurementDate field Should be displayed Successfully",
                "MeasurementDate field is not displayed Successfully");
  } 
	
}


/****************************************
 * Name: ValidateRevenueRecognitionMethodDerivation
 *Description:  ValidateRevenueRecognitionMethodDerivation
 * Date:22-Mar-2018 
 ****************************************/ 
	    
 public void ValidateRevenueRecognitionMethodDerivation(DataRow input, DataRow output) throws InterruptedException
{
	 
	 		uiDriver.executeJavaScript("scroll(0,1200)");
	 		uiDriver.click("RevenueRecognitionMethodDerivation");
	 		SleepUtils.sleep(TimeSlab.YIELD);
	    
	 		uiDriver.executeJavaScript("scroll(0,500)");
	    String RevenueRecognitionMethod = uiDriver.getValue("RevenueRecognitionMethod");
	      if(RevenueRecognitionMethod.equals("List/Record"))
	    {
	    	
	    	passed("Validated RevenueRecognitionMethod "+RevenueRecognitionMethod+"",
                    "RevenueRecognitionMethod should be validated successfully as"+RevenueRecognitionMethod+"",
                     "RevenueRecognitionMethod is Validated Successfully as"+RevenueRecognitionMethod+"");
	    }
	      else
	      {
	    	  failed("Validated RevenueRecognitionMethod "+RevenueRecognitionMethod+"",
	                    "RevenueRecognitionMethod should be validated successfully as"+RevenueRecognitionMethod+"",
	                     "RevenueRecognitionMethod is not Validated Successfully as"+RevenueRecognitionMethod+"");
	      }
	      
	      
	      String PayShip=uiDriver.getValue("PayShip");
	      if(PayShip.equals("Check Box"))
	    {
	    	
	    	passed("Validated PayShip "+PayShip+"",
                    "PayShip should be validated successfully"+PayShip+"",
                     "PayShip is Validated Succesfuuly as"+PayShip+"");
	    }
	      else
	      {
	    	  failed("Validated PayShip "+PayShip+"",
	                    "PayShip should be validated successfully as"+PayShip+"",
	                     "PayShip is not Validated Succesfuuly as"+PayShip+"");
	      }


	      String ContinuousProduction =uiDriver.getValue("ContinuousProduction");
	      if(ContinuousProduction.equals("Check Box"))
	    {
	    	
	    	passed("Validated ContinuousProduction "+ContinuousProduction+"",
                    "ContinuousProduction should be validated successfully as"+ContinuousProduction+"",
                     "ContinuousProduction is Validated Successfully as"+ContinuousProduction+"");
	    }
	      else
	      {
	    	  failed("Not Validated ContinuousProduction "+ContinuousProduction+"",
                    "ContinuousProduction should be validated successfully as"+ContinuousProduction+"",
                     "ContinuousProduction is not validated successfully as "+ContinuousProduction+"");
	      }


	      String OnNetwork =uiDriver.getValue("OnNetwork");
	      if(OnNetwork.equals("Check Box"))
	    {
	    	
	    	passed("Validated OnNetwork "+OnNetwork+"",
                    "OnNetwork should be validated successfully as"+OnNetwork+"",
                     "OnNetwork is Validated Successfully as"+OnNetwork+"");
	    }
	      else
	      {
	    	  failed("Not Validated OnNetwork "+OnNetwork+"",
                    "OnNetwork should be validated successfully as"+OnNetwork+"",
                     "OnNetwork is not validated successfully as "+OnNetwork+"");
	      }

	      String LicenseFeeType =uiDriver.getValue("LicenseFeeType");
	      if(LicenseFeeType.equals("List/Record"))
	    {
	    	
	    	passed("Validated LicenseFeeType "+LicenseFeeType+"",
                    "LicenseFeeType should be validated successfully as"+LicenseFeeType+"",
                     "LicenseFeeType is Validated Successfully as"+LicenseFeeType+"");
	    }
	      else
	      {
	    	  failed("Not Validated LicenseFeeType "+LicenseFeeType+"",
                    "LicenseFeeType should be validated successfully as"+LicenseFeeType+"",
                     "LicenseFeeType is not validated successfully as "+LicenseFeeType+"");
	      }
	      
	      
	      String MarketCode =uiDriver.getValue("MarketCode");
	      if(MarketCode.equals("List/Record"))
	    {
	    	
	    	passed("Validated MarketCode "+LicenseFeeType+"",
                    "MarketCode should be validated successfully as"+LicenseFeeType+"",
                     "MarketCode is Validated Successfully as"+LicenseFeeType+"");
	    }
	      else
	      {
	    	  failed("Not Validated MarketCode "+LicenseFeeType+"",
                    "MarketCode should be validated successfully as"+LicenseFeeType+"",
                     "MarketCode is not validated successfully as "+LicenseFeeType+"");
	      }

	      String Subsidairy =uiDriver.getValue("Subsidairy");
	      if(Subsidairy.equals("List/Record"))
	    {
	    	
	    	passed("Validated Subsidairy "+Subsidairy+"",
                    "Subsidairy should be validated successfully as"+Subsidairy+"",
                     "Subsidairy is Validated Successfully as"+Subsidairy+"");
	    }
	      else
	      {
	    	  failed("Not Validated Subsidairy "+Subsidairy+"",
                    "Subsidairy should be validated successfully as"+Subsidairy+"",
                     "Subsidairy is not validated successfully as "+Subsidairy+"");
	      }
   
	      
	      String SOSubType =uiDriver.getValue("SOSubType");
	      if(SOSubType.equals("List/Record"))
	    {
	    	
	    	passed("Validated SOSubType "+SOSubType+"",
                    "SOSubType should be validated successfully as"+SOSubType+"",
                     "SOSubType is Validated Successfully as"+SOSubType+"");
	    }
	      else
	      {
	    	  failed("Not Validated SOSubType "+SOSubType+"",
                    "SOSubType should be validated successfully as"+SOSubType+"",
                     "SOSubType is not validated successfully as "+SOSubType+"");
	      }
	      
	      String RRSDMethod =uiDriver.getValue("RRSDMethod");
	      if(RRSDMethod.equals("List/Record"))
	    {
	    	
	    	passed("Validated RRSDMethod "+RRSDMethod+"",
                    "RRSDMethod should be validated successfully as"+RRSDMethod+"",
                     "RRSDMethod is Validated Successfully as"+RRSDMethod+"");
	    }
	      else
	      {
	    	  failed("Not Validated RRSDMethod "+RRSDMethod+"",
                    "RRSDMethod should be validated successfully as"+RRSDMethod+"",
                     "RRSDMethod is not validated successfully as "+RRSDMethod+"");
	      }
	      
	      String RREDMethods =uiDriver.getValue("RREDMethods");
	      if(RREDMethods.equals("List/Record"))
	    {
	    	
	    	passed("Validated RREDMethods "+RREDMethods+"",
                    "RREDMethods should be validated successfully as"+RREDMethods+"",
                     "RREDMethods is Validated Successfully as"+RREDMethods+"");
	    }
	      else
	      {
	    	  failed("Not Validated RREDMethods "+RREDMethods+"",
                    "RREDMethods should be validated successfully as"+RREDMethods+"",
                     "RREDMethods is not validated successfully as "+RREDMethods+"");
	      }
	      
	      String SAPID =uiDriver.getValue("SAPID");
	      if(SAPID.equals("Free-Form Text"))
	    {
	    	
	    	passed("Validated SAPID "+SAPID+"",
                    "SAPID should be validated successfully as"+SAPID+"",
                     "SAPID is Validated Successfully as"+SAPID+"");
	    }
	      else
	      {
	    	  failed("Not Validated SAPID "+SAPID+"",
                    "SAPID should be validated successfully as"+SAPID+"",
                     "SAPID is not validated successfully as "+SAPID+"");
	      } 
	      
	      String InterCompany =uiDriver.getValue("InterCompany");
	      if(InterCompany.equals("Check Box"))
	    {
	    	
	    	passed("Validated InterCompany "+InterCompany+"",
                    "InterCompany should be validated successfully as"+InterCompany+"",
                     "InterCompany is Validated Successfully as"+InterCompany+"");
	    }
	      else
	      {
	    	  failed("Not Validated InterCompany "+InterCompany+"",
                    "InterCompany should be validated successfully as"+InterCompany+"",
                     "InterCompany is not validated successfully as "+InterCompany+"");
	      }   
}
public void verifyMarketCode(DataRow input, DataRow output) {
	
	
	String SONum = uiDriver.getValue("SONumber");
	passed("Verify the SalesOrderNumber",
			"SalesOrderNumber Should be displayed successfully",
			"SalesOrderNumber " + SONum + " is displayed successfully");

	String tableRows = uiDriver.getObjMap("tableRows");

	uiDriver.executeJavaScript("scroll(0,500)");
	String actualMARKETCODE = uiDriver.getValue(tableRows + nextRow+ uiDriver.getObjMap("marketcode"));
	String actualRIGHTS = uiDriver.getValue(tableRows + nextRow	+ uiDriver.getObjMap("Rights"));
	
	String Marketcode = input.get("marketCode");
	if (input.get("marketCode").contains(actualMARKETCODE.trim())) {
		passed("Verifying the  marketCode",
				"marketCode should be displayed as '" + Marketcode+ "' Successfully", "marketCode "	+ actualMARKETCODE + " is displayed Successfully");
	} else {
		failed("Verifying the  marketCode",	"marketCode should be displayed as '" + Marketcode+ "' Successfully",
				"marketCode "+ actualMARKETCODE	+ " is not displayed Successfully");
	}

	SleepUtils.sleep(5);
	String Rights = input.get("rightSet");
	if (input.get("rightSet").contains(actualRIGHTS)) {
		passed("Verifying the  rightSet",
			"rightSet should be displayed as '" + Rights+ "' Successfully",
			"rightSet " + actualRIGHTS+ " is displayed Successfully");
	} else {
		failed("Verifying the  rightSet",
				"rightSet should be displayed as '" + Rights+ "' Successfully",
				"rightSet " + actualRIGHTS+ " is not displayed Successfully");
		
	}
	nextRow++;
}

 
 /****************************************
  * Name: ValidateFMVAdjustment
  *Description:  ValidateFMVAdjustment
  * Date:29-Nov-2018 
  ****************************************/ 
public void ValidateFMVAdjustment(DataRow input, DataRow output) {
	SleepUtils.sleep(TimeSlab.MEDIUM);
	uiDriver.executeJavaScript("(scroll(0,300));");
	uiDriver.click("Custom");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.executeJavaScript("(scroll(0,900));");
	uiDriver.click("FMVAdjustment");
	SleepUtils.sleep(TimeSlab.MEDIUM);
	uiDriver.executeJavaScript("(scroll(0,1500));");
	String FMVTitles = uiDriver.getDyanmicData("FMVTitles");
	String FMVActualtitle = FMVTitles.replace("#", input.get("title"));
	uiDriver.click_dynamic(FMVActualtitle);
	SleepUtils.sleep(TimeSlab.MEDIUM);
	uiDriver.executeJavaScript("(scroll(0,600));");
	uiDriver.click("ContractBilledRevenue");
	SleepUtils.sleep(TimeSlab.MEDIUM);
	String FMVBilledRevenue = uiDriver.getValue_Text("FMVBilledRevenue");
	SleepUtils.sleep(TimeSlab.YIELD);
	if (FMVBilledRevenue.contains(input.get("FMVBilledRevenue"))) {
		passed("Verify the FMVBilledRevenue",
				"FMVBilledRevenue  should be displayed Successfully as "
						+ FMVBilledRevenue + "",
				"FMVBilledRevenue is displayed Successfully as "
						+ FMVBilledRevenue + "");

	} else {
		failed("Verify the FMVBilledRevenue",
				"FMVBilledRevenue should be displayed Successfully as "
						+ FMVBilledRevenue + "",
				"FMVBilledRevenue is not displayed Successfully as "
						+ FMVBilledRevenue + "");

	}
	String FMVTotal = uiDriver.getValue_Text("FMVTotal");
	SleepUtils.sleep(TimeSlab.YIELD);
	if (FMVTotal.contains(input.get("FMVTotal"))) {
		passed("Verify the FMVBilledRevenue",
				"FMVBilledRevenue  should be displayed Successfully as "
						+ FMVBilledRevenue + "",
				"FMVBilledRevenue is displayed Successfully as "
						+ FMVBilledRevenue + "");

	} else {
		failed("Verify the FMVBilledRevenue",
				"FMVBilledRevenue should be displayed Successfully as "
						+ FMVBilledRevenue + "",
				"FMVBilledRevenue is not displayed Successfully as "
						+ FMVBilledRevenue + "");

	}
	

	String FMVBilledRevenueAdjustment = uiDriver.getValue_Text("FMVBilledRevenueAdjustment");
	SleepUtils.sleep(TimeSlab.YIELD);
	if (FMVBilledRevenueAdjustment.contains(input.get("FMVBilledRevenueAdjustment"))) {
		passed("Verify the FMVBilledRevenueAdjustment",
				"FMVBilledRevenueAdjustment  should be displayed Successfully as "
						+ FMVBilledRevenueAdjustment + "",
				"FMVBilledRevenueAdjustment is displayed Successfully as "
						+ FMVBilledRevenueAdjustment + "");

	} else {
		failed("Verify the FMVBilledRevenueAdjustment",
				"FMVBilledRevenueAdjustment  should be displayed Successfully as "
						+ FMVBilledRevenueAdjustment + "",
				"FMVBilledRevenueAdjustment is not displayed Successfully as "
						+ FMVBilledRevenueAdjustment + "");

	}

	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("ContractUnBilledRevenue");
	SleepUtils.sleep(TimeSlab.LOW);
	String FMVUnBilledRevenue = uiDriver.getValue_Text("FMVUnBilledRevenue");
	SleepUtils.sleep(TimeSlab.LOW);
	if (FMVUnBilledRevenue.contains(input.get("FMVUnBilledRevenue"))) {
		passed("Verify the FMVUnBilledRevenue",
				"FMVUnBilledRevenue  should be displayed Successfully as "
						+ FMVUnBilledRevenue + "",
				"FMVUnBilledRevenue is displayed Successfully as "
						+ FMVUnBilledRevenue + "");

	} else {
		failed("Verify the FMVUnBilledRevenue",
				"FMVUnBilledRevenue should be displayed Successfully as "
						+ FMVUnBilledRevenue + "",
				"FMVUnBilledRevenue is not displayed Successfully as "
						+ FMVUnBilledRevenue + "");

	}

	String FMVUnBilledRevenueAdjustment = uiDriver.getValue_Text("FMVUnBilledRevenueAdjustment");
	SleepUtils.sleep(TimeSlab.YIELD);
	if (FMVUnBilledRevenueAdjustment.contains(input.get("FMVUnBilledRevenueAdjustment"))) {
		passed("Verify the FMVUnBilledRevenueAdjustment",
				"FMVUnBilledRevenueAdjustment  should be displayed Successfully as "
						+ FMVUnBilledRevenueAdjustment + "",
				"FMVUnBilledRevenueAdjustment is displayed Successfully as "
						+ FMVUnBilledRevenueAdjustment + "");

	} else {
		failed("Verify the FMVUnBilledRevenueAdjustment",
				"FMVUnBilledRevenueAdjustment  should be displayed Successfully as "
						+ FMVUnBilledRevenueAdjustment + "",
				"FMVUnBilledRevenueAdjustment is not displayed Successfully as "
						+ FMVUnBilledRevenueAdjustment + "");

	}

	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("ContractBilledAR");
	SleepUtils.sleep(TimeSlab.LOW);
	String FMVBilledAR = uiDriver.getValue_Text("FMVBilledAR");
	SleepUtils.sleep(TimeSlab.LOW);
	if (FMVBilledAR.contains(input.get("FMVBilledAR"))) {
		passed("Verify the FMVBilledAR",
				"FMVBilledAR  should be displayed Successfully as "
						+ FMVBilledAR + "",
				"FMVBilledAR is displayed Successfully as " + FMVBilledAR
						+ "");

	} else {
		passed("Verify the FMVBilledAR",
				"FMVBilledAR should be displayed Successfully as "
						+ FMVBilledAR + "",
				"FMVBilledAR is displayed Successfully as "
						+ FMVBilledAR + "");

	}

	String FMVBilledARAdjustment = uiDriver.getValue_Text("FMVBilledARAdjustment");
	SleepUtils.sleep(TimeSlab.YIELD);
	if (FMVBilledARAdjustment.contains(input.get("FMVBilledARAdjustment"))) {
		passed("Verify the FMVBilledARAdjustment",
				"FMVBilledARAdjustment  should be displayed Successfully as "
						+ FMVBilledARAdjustment + "",
				"FMVBilledARAdjustment is displayed Successfully as "
						+ FMVBilledARAdjustment + "");

	} else {
		failed("Verify the FMVBilledARAdjustment",
				"FMVBilledARAdjustment  should be displayed Successfully as "
						+ FMVBilledARAdjustment + "",
				"FMVBilledARAdjustment is not displayed Successfully as "
						+ FMVBilledARAdjustment + "");

	}

	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("ContractUnBilledAR");
	SleepUtils.sleep(TimeSlab.LOW);
	String FMVUnBilledAR = uiDriver.getValue_Text("FMVUnBilledAR");
	SleepUtils.sleep(TimeSlab.LOW);
	if (FMVUnBilledAR.contains(input.get("FMVUnBilledAR"))) {
		passed("Verify the FMVUnBilledAR",
				"FMVUnBilledAR  should be displayed Successfully as "
						+ FMVUnBilledAR + "",
				"FMVUnBilledAR is displayed Successfully as "
						+ FMVUnBilledAR + "");

	} else {
		failed("Verify the FMVUnBilledAR",
				"FMVUnBilledAR should be displayed Successfully as "
						+ FMVUnBilledAR + "",
				"FMVUnBilledAR is not displayed Successfully as "
						+ FMVUnBilledAR + "");

	}

	String FMVUnBilledARAdjustment = uiDriver.getValue_Text("FMVUnBilledARAdjustment");
	SleepUtils.sleep(TimeSlab.YIELD);
	if (FMVUnBilledARAdjustment.contains(input.get("FMVUnBilledARAdjustment"))) {
		passed("Verify the FMVUnBilledARAdjustment",
				"FMVUnBilledARAdjustment  should be displayed Successfully as "
						+ FMVUnBilledARAdjustment + "",
				"FMVUnBilledARAdjustment is displayed Successfully as "
						+ FMVUnBilledARAdjustment + "");

	} else {
		failed("Verify the FMVUnBilledARAdjustment",
				"FMVUnBilledARAdjustment  should be displayed Successfully as "
						+ FMVUnBilledARAdjustment + "",
				"FMVUnBilledARAdjustment is not displayed Successfully as "
						+ FMVUnBilledARAdjustment + "");

	}

	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("ContractUnpaidDeferred");
	SleepUtils.sleep(TimeSlab.LOW);
	String FMVUnpaidDeferred = uiDriver.getValue_Text("FMVUnpaidDeferred");
	SleepUtils.sleep(TimeSlab.LOW);
	if (FMVUnpaidDeferred.contains(input.get("FMVUnpaidDeferred"))) {
		passed("Verify the FMVUnpaidDeferred",
				"FMVUnpaidDeferred  should be displayed Successfully as "
						+ FMVUnpaidDeferred + "",
				"FMVUnpaidDeferred is displayed Successfully as "
						+ FMVUnpaidDeferred + "");

	} else {
		failed("Verify the FMVUnpaidDeferred",
				"FMVUnpaidDeferred should be displayed Successfully as "
						+ FMVUnpaidDeferred + "",
				"FMVUnpaidDeferred is not displayed Successfully as "
						+ FMVUnpaidDeferred + "");

	}

	String FMVUnpaidDeferredAdjustment = uiDriver
			.getValue_Text("FMVUnpaidDeferredAdjustment");
	SleepUtils.sleep(TimeSlab.YIELD);
	if (FMVUnpaidDeferredAdjustment.contains(input.get("FMVUnpaidDeferredAdjustment"))) {
		passed("Verify the FMVUnpaidDeferredAdjustment",
				"FMVUnpaidDeferredAdjustment  should be displayed Successfully as "
						+ FMVUnpaidDeferredAdjustment + "",
				"FMVUnpaidDeferredAdjustment is displayed Successfully as "
						+ FMVUnpaidDeferredAdjustment + "");

	} else {
		failed("Verify the FMVUnpaidDeferredAdjustment",
				"FMVUnpaidDeferredAdjustment  should be displayed Successfully as "
						+ FMVUnpaidDeferredAdjustment + "",
				"FMVUnpaidDeferredAdjustment is not displayed Successfully as "
						+ FMVUnpaidDeferredAdjustment + "");

	}

	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("ContractPaidDeferred");
	SleepUtils.sleep(TimeSlab.LOW);
	String FMVPaidDeferred = uiDriver.getValue_Text("FMVPaidDeferred");
	SleepUtils.sleep(TimeSlab.LOW);
	if (FMVPaidDeferred.contains(input.get("FMVPaidDeferred"))) {
		passed("Verify the FMVPaidDeferred",
				"FMVPaidDeferred  should be displayed Successfully as "
						+ FMVPaidDeferred + "",
				"FMVPaidDeferred is displayed Successfully as "
						+ FMVPaidDeferred + "");

	} else {
		failed("Verify the FMVPaidDeferred",
				"FMVPaidDeferred should be displayed Successfully as "
						+ FMVPaidDeferred + "",
				"FMVPaidDeferred is not displayed Successfully as "
						+ FMVPaidDeferred + "");

	}

	String FMVPaidDeferredAdjustment = uiDriver.getValue_Text("FMVPaidDeferredAdjustment");
	SleepUtils.sleep(TimeSlab.YIELD);
	if (FMVPaidDeferredAdjustment.contains("0")) {
		passed("Verify the FMVPaidDeferredAdjustment",
				"FMVPaidDeferredAdjustment  should be displayed Successfully as "
						+ FMVPaidDeferredAdjustment + "",
				"FMVPaidDeferredAdjustment is displayed Successfully as "
						+ FMVPaidDeferredAdjustment + "");

	} else {
		failed("Verify the FMVPaidDeferredAdjustment",
				"FMVPaidDeferredAdjustment  should be displayed Successfully as "
						+ FMVPaidDeferredAdjustment + "",
				"FMVPaidDeferredAdjustment is not displayed Successfully as "
						+ FMVPaidDeferredAdjustment + "");

	}

	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("ContractFXGainLoss");
	SleepUtils.sleep(TimeSlab.LOW);
	String FMVFXGainLoss = uiDriver.getValue_Text("FMVFXGainLoss");
	SleepUtils.sleep(TimeSlab.LOW);
	if (FMVFXGainLoss.contains("0")) {
		passed("Verify the FMVFXGainLoss",
				"FMVFXGainLoss  should be displayed Successfully as "
						+ FMVFXGainLoss + "",
				"FMVFXGainLoss is displayed Successfully as "
						+ FMVFXGainLoss + "");

	} else {
		failed("Verify the FMVFXGainLoss",
				"FMVFXGainLoss should be displayed Successfully as "
						+ FMVFXGainLoss + "",
				"FMVFXGainLoss is not displayed Successfully as "
						+ FMVFXGainLoss + "");

	}

	String FMVFXGainLossAdjustment = uiDriver
			.getValue_Text("FMVFXGainLossAdjustment");
	SleepUtils.sleep(TimeSlab.YIELD);
	if (FMVFXGainLossAdjustment.contains("0")) {
		passed("Verify the FMVFXGainLossAdjustment",
				"FMVFXGainLossAdjustment  should be displayed Successfully as "
						+ FMVFXGainLossAdjustment + "",
				"FMVFXGainLossAdjustment is displayed Successfully as "
						+ FMVFXGainLossAdjustment + "");

	} else {
		failed("Verify the FMVFXGainLossAdjustment",
				"FMVFXGainLossAdjustment  should be displayed Successfully as "
						+ FMVFXGainLossAdjustment + "",
				"FMVFXGainLossAdjustment is not displayed Successfully as "
						+ FMVFXGainLossAdjustment + "");

	}

	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("ContractWHT");
	SleepUtils.sleep(TimeSlab.LOW);
	String FMVWHT = uiDriver.getValue_Text("FMVWHT");
	SleepUtils.sleep(TimeSlab.LOW);
	if (FMVWHT.contains("0")) {
		passed("Verify the FMVWHT",
				"FMVWHT  should be displayed Successfully as " + FMVWHT
						+ "", "FMVWHT is displayed Successfully as "
						+ FMVWHT + "");

	} else {
		failed("Verify the FMVWHT",
				"FMVWHT should be displayed Successfully as " + FMVWHT + "",
				"FMVWHT is not displayed Successfully as " + FMVWHT + "");

	}

	String FMVWHTAdjustment = uiDriver.getValue_Text("FMVWHTAdjustment");
	SleepUtils.sleep(TimeSlab.YIELD);
	if (FMVWHTAdjustment.contains("0")) {
		passed("Verify the FMVWHTAdjustment",
				"FMVWHTAdjustment  should be displayed Successfully as "
						+ FMVWHTAdjustment + "",
				"FMVWHTAdjustment is displayed Successfully as "
						+ FMVWHTAdjustment + "");

	} else {
		failed("Verify the FMVWHTAdjustment",
				"FMVWHTAdjustment  should be displayed Successfully as "
						+ FMVWHTAdjustment + "",
				"FMVWHTAdjustment is not displayed Successfully as "
						+ FMVWHTAdjustment + "");

	}

}

	
	

/****************************************
 * Name: initializeRow 
 * Description:Method to validate Debit and Credit Amount
 * Date: 22-May-2018
 ****************************************/

public void initializeRow(DataRow input, DataRow output)
{
	nextRow=2;
	firstRow=2;
	ItemCol =2;
	
}

public static int i = 4, j = 2;
int nextRow =2, firstRow = 2, ItemCol =4;
String orderId, FMVDimention, SONum;
List<WebElement> fmvValue = new ArrayList<WebElement>();
List<String> fmvVal = new ArrayList<String>();

}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
  
	
	
	
	
	
	
	
