package moduledrivers;

import static cbf.engine.TestResultLogger.*;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.Console;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import cbf.engine.TestResult.ResultType;
import cbf.utils.DataRow;
import cbf.utils.SleepUtils;
import cbf.utils.SleepUtils.TimeSlab;
import cbfx.basedrivers.BaseWebModuleDriver;

import org.apache.pdfbox.io.RandomAccessRead;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.PDFTextStripperByArea;

//import sun.net.ftp.impl.FtpClient;

import java.io.File;
import java.io.IOException;

public class FilmtrackDriver extends BaseWebModuleDriver {

	/**
	 * Logs Procedure in Application
	 * 
	 * @param input
	 *            DataRow of input parameters
	 * @param output
	 *            empty DataRow passed to capture any runtime output during
	 *            execution of component
	 */

	/****************************************
	 * Name: report Description: report Date: 11-July-2018
	 ****************************************/
	public void report(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("report");
	}

	/****************************************
	 * Name: askingPrices
	 * Description: askingPrices
	 * Date: 11-July-2018
	 ****************************************/
	public void askingPrices(DataRow input, DataRow output) {

		uiDriver.click("askingprices");
		// Time taken to load Report page(start time)
		passed("Report Page", "Response time of Report Page",
				"Successfully loded the Report Page");

	}

	
	
	/****************************************
	 * Name: VerifymultipleFMVtitles
	 * Description: VerifymultipleFMVtitles
	 * Date: 11-July-2018
	 ****************************************/
	public void VerifymultipleFMVtitles(DataRow input, DataRow output) {

		uiDriver.click("//a[text()='ustom']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,1000)");
		uiDriver.click("//a[text()='V Adjustment']");
		List<WebElement> lst = uiDriver.webDr.findElements(By.xpath("//*[@id='recmachcustrecord_nbcu_so__tab']//tbody//tr"));
		for(int i=1;i<=lst.size();i++)
		{
			String fmv=uiDriver.getValue_Text("//*[@id='recmachcustrecord_nbcu_so__tab']/tbody/tr["+i+"]/td[count(//table[@id='recmachcustrecord_nbcu_so__tab']//td/div[contains(text(),'FMV Indicator')]/../preceding-sibling::*)+1]");
			passed("Verify FMV indicator", "FMV value should be"+fmv+"",
					"FMV value is "+fmv+"");
			
			String licensefee=uiDriver.getValue_Text("//*[@id='recmachcustrecord_nbcu_so__tab']/tbody/tr/td[count(//table[@id='recmachcustrecord_nbcu_so__tab']//td/div[contains(text(),'Net License Fee')]/../preceding-sibling::*)+1]");
			passed("Verify FMV indicator", "FMV value should be"+licensefee+"",
					"FMV value is "+licensefee+"");	
			
			String Right=uiDriver.getValue_Text("//*[@id='recmachcustrecord_nbcu_so__tab']/tbody/tr/td[count(//table[@id='recmachcustrecord_nbcu_so__tab']//td/div[contains(text(),'Right')]/../preceding-sibling::*)+1]");
			passed("Verify FMV indicator", "FMV value should be"+Right+"",
					"FMV value is "+Right+"");	
			
			
			String TotalFMV=uiDriver.getValue_Text("//*[@id='recmachcustrecord_nbcu_so__tab']/tbody/tr/td[count(//table[@id='recmachcustrecord_nbcu_so__tab']//td/div[contains(text(),'Total FMV')]/../preceding-sibling::*)+1]");
			passed("Verify FMV indicator", "FMV value should be"+TotalFMV+"",
					"FMV value is "+TotalFMV+"");
		}
		
		
	}

	/****************************************
	 * Name: EditDefaultAllocationPTV
	 * Description: EditDefaultAllocationPTV
	 * Date: 11-July-2018
	 ****************************************/
	public void EditDefaultAllocationPTV(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.click("Editicon");
		SleepUtils.sleep(5);
		String Name = input.get("Name");
		uiDriver.setValue("Name", Name);
		uiDriver.setValue("Note", input.get("Note"));

		//uiDriver.click("InvoiceItemCategory");
		//SleepUtils.sleep(TimeSlab.YIELD);
		//uiDriver.click("InvoiceItemCategoryInput");
		SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("InvoiceItemCurrency");
		// uiDriver.click("InvoiceItemCurrencyInput");
		Boolean Result = uiDriver.webDr.findElement(
				By.id("TerritoriesCheckbox")).isSelected();
		if (Result.equals(false)) {

			uiDriver.click("Territories");
		} else {
			// do nothing
		}

		Boolean RightResult = uiDriver.webDr.findElement(
				By.id("RightsCheckbox")).isSelected();
		if (RightResult.equals(false)) {

			uiDriver.click("Rights");
		} else {
			// do nothing
		}
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		//SleepUtils.sleep(TimeSlab.HIGH);
		//SleepUtils.sleep(TimeSlab.HIGH);
		// uiDriver.executeJavaScript("document.getElementsByClassName('k-formatted-value k-input')[0].value=100;");
		Actions action = new Actions(uiDriver.webDr);
		WebElement ele = uiDriver.webDr.findElement(By
				.xpath("//*[@id='allocationWidget']/div/span/span/input[1]"));
		action.sendKeys("ele", "").build().perform();
		action.sendKeys(ele, "100.00").build().perform();
		// uiDriver.click("IncreaseArrow");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("(//*[contains(text(),'USA (USA)')])[2]/../..//td[1]/input");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.HIGH);
		// SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("NameChkBox");
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		List<WebElement> lis = uiDriver.webDr.findElements(By.xpath("//input[@value='50.00000000']"));
		for(int k=0;k<lis.size();k++)
		{
			WebElement w = lis.get(k);
			w.clear();
			//w.sendKeys("100.00");
			//action.sendKeys(w,"").build().perform();
			//action.sendKeys(w,"0.00").build().perform();
		}
		SleepUtils.sleep(TimeSlab.HIGH);
		if(input.get("rights").equals("PTV"))
		{
		uiDriver.click("NameChkBoxNext");
		}
		else if(input.get("rights").equals("FTV"))
		{
		uiDriver.click("NameChkBoxNext1");
		}
		else
		{
			uiDriver.click("//*[@id='rightsGrid']/div[2]/table//tr/td/input");//span[text()='Basic Cable']/../..//td[1]/input
		}
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.clear("//*[text()='SOD']/../..//input[@type='text']");
		
	SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Finish");
		SleepUtils.sleep(TimeSlab.HIGH);
		//output.put("Name", Name);
		String actrights =uiDriver.getValue("rights1");
		String exprights=input.get("rights");
		String actterritories =uiDriver.getValue("territories1");
		String expterritories=input.get("territories");
		//*[@id="ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_AllocationRulesGrid_ctl00__0"]/td[6]
		if(actrights.equals(exprights)) 
		{
			passed("Validate rights allocation",
					"Rights allocation should be "+exprights,
					"Rights allocation is "+actrights);
		}
		else
		{
			failed("Validate rights allocation",
					"Rights allocation should be"+exprights,
					"Rights allocation is  "+actrights);
		}
		if(actterritories.equalsIgnoreCase(expterritories))
		{
			passed("Validate territories allocation",
					"Territories allocation should be "+expterritories,
					"Territories allocation is "+actrights);
		}
		else
		{
			failed("Validate territories allocation",
					"Territories allocation should be"+expterritories,
					"Territories allocation is  "+actrights);
		}
		output.put("Name", Name);
	}
	
	/****************************************
	 * Name: EditDefaultAllocationFTVCAN
	 * Description: EditDefaultAllocationFTVCAN
	 * Date: 11-July-2018
	 ****************************************/
	public void EditDefaultAllocationCANADA(DataRow input, DataRow output)
			throws InterruptedException {
		SleepUtils.sleep(5);
		uiDriver.click("//td[contains(text(),'Default')]/..//td[1]/input");
		//uiDriver.click("Editicon");
		SleepUtils.sleep(5);
		String Name = input.get("Name");
		uiDriver.setValue("Name", Name);
		uiDriver.setValue("Note", input.get("Note"));

		uiDriver.click("InvoiceItemCategory");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("InvoiceItemCategoryInput");
		SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("InvoiceItemCurrency");
		// uiDriver.click("InvoiceItemCurrencyInput");
		Boolean Result = uiDriver.webDr.findElement(
				By.id("TerritoriesCheckbox")).isSelected();
		if (Result.equals(false)) {

			uiDriver.click("Territories");
		} else {
			// do nothing
		}

		Boolean RightResult = uiDriver.webDr.findElement(
				By.id("RightsCheckbox")).isSelected();
		if (RightResult.equals(false)) {

			uiDriver.click("Rights");
		} else {
			// do nothing
		}
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		// uiDriver.executeJavaScript("document.getElementsByClassName('k-formatted-value k-input')[0].value=100;");
		Actions action = new Actions(uiDriver.webDr);
		WebElement ele = uiDriver.webDr.findElement(By
				.xpath("//*[@id='allocationWidget']/div/span/span/input[1]"));
		action.sendKeys("ele", "").build().perform();
		action.sendKeys(ele, "100.00").build().perform();
		SleepUtils.sleep(TimeSlab.MEDIUM);
		
		//SleepUtils.sleep(TimeSlab.HIGH);
		// uiDriver.click("IncreaseArrow");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("NameChkBox");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.HIGH);
		// SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("NameChkBox");
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		List<WebElement> lis = uiDriver.webDr.findElements(By.xpath("(//input[contains(@value,'33')])[2]"));
		for(int k=0;k<lis.size();k++)
		{
			WebElement w = lis.get(k);
			w.click();
			w.clear();
			//w.sendKeys("100.00");
			//action.sendKeys(w,"").build().perform();
			//action.sendKeys(w,"0.00").build().perform();
		}
		String Rights = uiDriver.getDyanmicData("NameChkBoxNext");
		String rights1 = Rights.replace("#",input.get("Rights"));
		uiDriver.click(rights1);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Finish");
		SleepUtils.sleep(TimeSlab.YIELD);
		output.put("Name", Name);

	}

	/****************************************
	 * Name: EditDefaultAllocationFTVCAN
	 * Description: EditDefaultAllocationFTVCAN
	 * Date: 11-July-2018
	 ****************************************/
	public void EditDefault1AllocationCANADA(DataRow input, DataRow output)
			throws InterruptedException {
		SleepUtils.sleep(10);
		uiDriver.click("//td[contains(text(),'Default-1')]/..//td[1]/input");

		//uiDriver.click("Editicon");
		SleepUtils.sleep(5);
		String Name = input.get("Name");
		uiDriver.setValue("Name", Name);
		uiDriver.setValue("Note", input.get("Note"));

		uiDriver.click("InvoiceItemCategory");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("InvoiceItemCategoryInput");
		SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("InvoiceItemCurrency");
		// uiDriver.click("InvoiceItemCurrencyInput");
		Boolean Result = uiDriver.webDr.findElement(
				By.id("TerritoriesCheckbox")).isSelected();
		if (Result.equals(false)) {

			uiDriver.click("Territories");
		} else {
			// do nothing
		}

		Boolean RightResult = uiDriver.webDr.findElement(
				By.id("RightsCheckbox")).isSelected();
		if (RightResult.equals(false)) {

			uiDriver.click("Rights");
		} else {
			// do nothing
		}
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		// uiDriver.executeJavaScript("document.getElementsByClassName('k-formatted-value k-input')[0].value=100;");
		Actions action = new Actions(uiDriver.webDr);
		WebElement ele = uiDriver.webDr.findElement(By
				.xpath("//*[@id='allocationWidget']/div/span/span/input[1]"));
		action.sendKeys("ele", "").build().perform();
		action.sendKeys(ele, "100.00").build().perform();
		//List<WebElement> lis = uiDriver.webDr.findElements(By.xpath("(//input[@value='100.00000000'])[2]"));
		//for(int k=0;k<lis.size();k++)
		//{
			//WebElement w = lis.get(k);
			//w.click();
		//	w.clear();
			//w.sendKeys("100.00");
			//action.sendKeys(w,"").build().perform();
			//action.sendKeys(w,"0.00").build().perform();
		//}
		SleepUtils.sleep(TimeSlab.MEDIUM);
		// uiDriver.click("IncreaseArrow");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("NameChkBox");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		// SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("NameChkBox");
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		for(int d=1;d<=3;d++)
		{
		String amount1=uiDriver.getDyanmicData("amount1");
		String amount=amount1.replace("#",Integer.toString(d));
		uiDriver.click_dynamic(amount);
		WebElement w = uiDriver.webDr.findElement(By.xpath(amount));
		w.clear();
		SleepUtils.sleep(TimeSlab.MEDIUM);
		//List<WebElement> lis = uiDriver.webDr.findElements(By.xpath("(//input[@value='100.00000000'])[2]"));
		//for(int k=0;k<lis.size();k++)
		//{
			//WebElement w = lis.get(k);
			//w.click();
			//w.clear();
			//w.sendKeys("100.00");
			//action.sendKeys(w,"").build().perform();
			//action.sendKeys(w,"0.00").build().perform();
		}
		String Rights = uiDriver.getDyanmicData("NameChkBoxNext");
		String rights1 = Rights.replace("#",input.get("Rights"));
		uiDriver.click(rights1);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Finish");
		SleepUtils.sleep(TimeSlab.YIELD);
		output.put("Name", Name);
		
		

	}

	

	/****************************************
	 * Name: updateContractName
	 * Description: updateContractName
	 * Date: 11-July-2018
	 ****************************************/
	public void updateContractName(DataRow input, DataRow output)
			throws InterruptedException {

		String originalname = uiDriver.getValue("contractfield");
		String contractidwithoutrevision = (originalname.split("-"))[0];
		String revision = (originalname.split("-"))[1];
		String newname=contractidwithoutrevision+"EE"+input.get("name")+"-"+revision;
		uiDriver.setValue("contractfield", newname);
		String NetSuitename=contractidwithoutrevision+"EE"+input.get("name")+"A";
		String InvoiceName=contractidwithoutrevision+"EE"+input.get("name");
		uiDriver.click("Save");
		output.put("updatedName", newname);
		output.put("SalesOrderNum", NetSuitename);
		output.put("InvoiceName", InvoiceName);
	
}
/****************************************
 * Name: ChangeRoleToAdminUAT
 * Description: Changing the role from administrator 10K to administrator UAT
 * Date: 30-Nov-2017
 ****************************************/
public void ChangeRoleToAdminUAT(DataRow input, DataRow output)
{
	SleepUtils.sleep(10);
	uiDriver.mouseOver("Profile");
	SleepUtils.sleep(5);
	uiDriver.click("AdminUAT");
	SleepUtils.sleep(5);
	if(uiDriver.checkElementPresent("AdminUAT")){
	//uiDriver.click("Manager1");
			passed("Verify Changing the role from administrator 10K to administrator UAT",
			"administrator 10K to administrator UAT Role must be changed Successfully",
			"administrator 10K to administrator UAT Role is changed Successfully");
	SleepUtils.sleep(5);
	}

	}


/****************************************
* Name: Verifytaxcodeforinvoices
* Description: Verifytaxcodeforinvoices
* Date: 30-Nov-2017
****************************************/
public void Verifytaxcodeforinvoices(DataRow input, DataRow output)
{
	uiDriver.click("relatedrecord");
	SleepUtils.sleep(5);
	List<WebElement> invoicerow = uiDriver.webDr.findElements(By.xpath("//td[text()='Invoice']/.."));
	for(int row=1;row<=invoicerow.size();row++)
	{
		uiDriver.click("relatedrecord");
		String invoice=uiDriver.getDyanmicData("invoicelink");
		String invoice1=invoice.replace("#", Integer.toString(row));
		uiDriver.click(invoice1);
		SleepUtils.sleep(5);
		List<WebElement> irow = uiDriver.webDr.findElements(By.xpath("//*[@id='item_splits']/tbody/tr[contains(@class,'uir-machine-row uir-machine-row')]"));
		for(int invrow=2;invrow<=irow.size();invrow++)
		{
			String taxcode=uiDriver.getDyanmicData("taxcode");
			String taxcode1=taxcode.replace("#", Integer.toString(invrow));
			String taxcodevalue = uiDriver.getValue(taxcode1);
			String exptaxcode=input.get("taxcode");
			if(taxcodevalue.contains(input.get("taxcode")))
			{
				passed("Verify tax code for invoice lines",
						"Tax code should be"+exptaxcode,
						"Tax code is "+taxcodevalue);
			}
			else
			{
				failed("Verify tax code for invoice lines",
						"Tax code should be"+exptaxcode,
						"Tax code is not "+exptaxcode);
			}
		}
		uiDriver.back();
		
	}

	}

	
	/****************************************
	 * Name: assignAllocations
	 * Description: assignAllocations
	 * Date: 11-July-2018
	 ****************************************/
	public void assignAllocations(DataRow input, DataRow output)
			throws InterruptedException {
		uiDriver.click("allocations");
		SleepUtils.sleep(TimeSlab.YIELD);
		String numofbillschedules = input.get("numbill");
		int num = Integer.parseInt(numofbillschedules);
		for (int i = 1; i <= num; i++) {
			uiDriver.click("recalculate");
			SleepUtils.sleep(TimeSlab.HIGH);
			//SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("next");
			SleepUtils.sleep(TimeSlab.YIELD);
			SleepUtils.sleep(TimeSlab.HIGH);
		}

	}
	/****************************************
	 * Name: Readpayment Description: Readpayment Date: 06-Dec-2018
	 ****************************************/
	public void Readpayment(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.click("custom");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.executeJavaScript("scroll(0,1000)");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("tapinvoice");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("payment");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String paymentnum=uiDriver.getValue("paymentvalue");
		output.put("paymentvalue",paymentnum);
	}
	
	/****************************************
	 * Name: revRecJournalEntry10K 
	 * Description: revRecJournalEntry
	 * Date:30-Nov-2017
	 ****************************************/
	public void revRecJournalEntry10K(DataRow input, DataRow output)
			throws ParseException {

		//SleepUtils.sleep(TimeSlab.HIGH);
		//SleepUtils.sleep(TimeSlab.HIGH);
		//SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.mouseOver("transactions");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("financial");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("revrecjournal");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("runNow");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.handleAlert("", "OK");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("customerdropdownimage");
		uiDriver.handleAlert("", "OK");
		SleepUtils.sleep(5);
		uiDriver.click("customerlist");
		SleepUtils.sleep(5);
		uiDriver.setValue("searchcustomerinput", input.get("revreccustomer"));
		SleepUtils.sleep(5);
		uiDriver.click("searchcustomerbutton");
		SleepUtils.sleep(5);
		uiDriver.click("cussearchresult");
		SleepUtils.sleep(TimeSlab.LOW);
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("postingperiod");
		uiDriver.setValue("postingperiod", input.get("posting"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("postingperiod");
		uiDriver.click("deliveryDate");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("deliveryDate", input.get("delivery"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Subsidiary");
		uiDriver.setValue("Subsidiary", input.get("Subsidiary"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Subsidiary");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.handleAlert("", "OK");
		String revreclist = uiDriver.getDyanmicData("revreclist");
		String revenuenum = input.get("revenuenum");
		String revrecchklist = revreclist.replace("#", revenuenum);
try{
		if (uiDriver.checkElementPresent_dynamic(revrecchklist)) {
			List<WebElement> ele = uiDriver.webDr.findElements(By
					.xpath(revrecchklist));
			int rowSize = ele.size();
			for (int i = 0; i < rowSize; i++) {

				SleepUtils.sleep(TimeSlab.LOW);

				ele.get(i).click();
			}
		} else {
			uiDriver.click("pagefilterdropdown");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("secondfilter");
			if (uiDriver.checkElementPresent_dynamic(revrecchklist)) {
				List<WebElement> ele = uiDriver.webDr.findElements(By
						.xpath(revrecchklist));
				int rowSize = ele.size();
				for (int i = 0; i < rowSize; i++) {

					SleepUtils.sleep(TimeSlab.LOW);

					ele.get(i).click();
				}
			} else {
				uiDriver.click("pagefilterdropdown");

				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.click("thirdfilter");
				if (uiDriver.checkElementPresent_dynamic(revrecchklist)) {
					List<WebElement> ele = uiDriver.webDr.findElements(By
							.xpath(revrecchklist));
					int rowSize = ele.size();
					for (int i = 0; i < rowSize; i++) {

						SleepUtils.sleep(TimeSlab.LOW);

						ele.get(i).click();
					}
				} else {
					uiDriver.click("pagefilterdropdown");

					SleepUtils.sleep(TimeSlab.LOW);
					uiDriver.click("fourthfilter");
					if (uiDriver.checkElementPresent_dynamic(revrecchklist)) {
						List<WebElement> ele = uiDriver.webDr.findElements(By
								.xpath(revrecchklist));
						int rowSize = ele.size();
						for (int i = 0; i < rowSize; i++) {

							SleepUtils.sleep(TimeSlab.LOW);

							ele.get(i).click();
						}
					}

				}
			}
		}
}
catch(Exception e){}
		uiDriver.executeJavaScript("scroll(0,-1000)");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("createjournalentries");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();

		Date date = new Date();
		DateFormat dateFormat = new SimpleDateFormat("h:mm");
		String strDate = dateFormat.format(date);
		Date d = dateFormat.parse(strDate);
		Calendar cal = Calendar.getInstance();
		cal.setTime(d);
		cal.add(Calendar.MINUTE, -1);
		String newTime = dateFormat.format(cal.getTime());
		String Complete = uiDriver.getDyanmicData("CompleteStatus1");
		String CompleteStaus = Complete.replace("#", newTime);
		cal.add(Calendar.MINUTE, 0);
		String newTime2 = dateFormat.format(cal.getTime());
		String Complete2 = uiDriver.getDyanmicData("CompleteStatus2");
		String CompleteStaus2 = Complete2.replace("#", newTime2);
		cal.add(Calendar.MINUTE, 1);
		String newTime3 = dateFormat.format(cal.getTime());
		String Complete3 = uiDriver.getDyanmicData("CompleteStatus3");
		String CompleteStaus3 = Complete3.replace("#", newTime3);
		if (uiDriver.checkElementPresent_dynamic(CompleteStaus)) {
			uiDriver.click_dynamic(CompleteStaus);
		} else {
			// do nothing
		}

		if (uiDriver.checkElementPresent_dynamic(CompleteStaus2)) {
			uiDriver.click_dynamic(CompleteStaus2);
		} else {
			// do nothing
		}
		if (uiDriver.checkElementPresent_dynamic(CompleteStaus3)) {
			uiDriver.click_dynamic(CompleteStaus3);
		} else {
			// do nothing
		}

		passed("Verify Processed Revenue recognition Journal entries",
				"Processed Revenue recognition Journal entries page should be displayed",
				"Processed Revenue recognition Journal entries page is displayed");

		if (uiDriver.checkElementPresent("completesubmissionstatus")) {
			uiDriver.click("completesubmissionstatus");

		} else {
			// do nothing
		}

		// uiDriver.click("createjournalentries");
		// SleepUtils.sleep(TimeSlab.LOW);
		// uiDriver.click("completeBtn");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Journal");
		uiDriver.executeJavaScript("(scroll(0,500));");
		int invoiceRow = 2;
		int accRows = uiDriver.webDr.findElements(
				By.xpath("//*[@id='line_splits']/tbody/tr")).size();
		for (i = 0; i < accRows - 1; i++) {
			String creditamount = uiDriver.getValue("creditamount");
			String debitamount = uiDriver.getValue("debitamount");
			if (uiDriver
					.getValue(
							"//*[@id='line_splits']/tbody/tr[" + invoiceRow
									+ "]/td[1]").contains(
							"Deferred Rev - Unpaid"))

			{
				if (uiDriver.getValue(
						"//*[@id='line_splits']/tbody/tr[" + invoiceRow
								+ "]/td[2]").equals("")) {
					failed("Validating Credit Amount",
							"Validating Credit Amount should be successfull",
							"Credit amount is not Deferred Rev - Generic");
				} else {
					passed("Credit is Deferred Rev - Generic " + creditamount
							+ "", "Credit is Deferred Rev - Generic "
							+ creditamount + "",
							"Credit amount is Deferred Rev - Generic "
									+ creditamount + "");
				}
			}
			if (uiDriver
					.getValue(
							"//*[@id='line_splits']/tbody/tr[" + invoiceRow
									+ "]/td[1]").contains(
							"GAAP contract revenue"))

			{
				if (uiDriver.getValue(
						"//*[@id='line_splits']/tbody/tr[" + invoiceRow
								+ "]/td[3]").equals("")) {
					failed("Validating Debit Amount",
							"Validating Debit Amount should be successfull",
							"Debit amount is not GAAP contract revenue");
				} else {
					passed("Debit is Deferred Rev - Generic " + debitamount
							+ "", "Debit is Deferred Rev - Generic "
							+ debitamount + "",
							"Debit amount is GAAP contract revenue "
									+ debitamount + "");
				}
			}

			invoiceRow++;
		}
	}

	// String Debitamount=uiDriver.getValue("debitamount");
	// String Creditamount=uiDriver.getValue("creditamount");

	/****************************************
	 * Name: NaviagteToBillingSchedule 
	 * Description: NaviagteToBillingSchedule
	 * Date: 11-July-2018
	 ****************************************/
	public void NavigateToBillingSchedule(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billing");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billingschedules");
		SleepUtils.sleep(TimeSlab.LOW);
		
		uiDriver.click("//span[@class='k-dropdown-wrap k-state-default']");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("(//*[@class='k-item'])[1]");
		/*Select all = new Select(uiDriver.findElement(By.class("k-icon k-i-arrow-60-down")));
		all.selectByVisibleText("All");
		SleepUtils.sleep(TimeSlab.LOW);*/
		
		int accRows = uiDriver.webDr
				.findElements(
						By.xpath("tr//*[@id='contract-billing-schedules-grid']/div[3]/table/tbody/"))
				.size();
		if (accRows >= 1) {
			passed("Billing Schedule displayed",
					"B illing Schedule Should be displayed",
					"Billing Schedule is displayed");
		} else {
			failed("Billing Schedule not displayed",
					"Billing Schedule Should be displayed",
					"Billing Schedule is not displayed");
		}
		String actualproject = uiDriver.getValue("project");
		String actualamount = uiDriver.getValue("Amount");
		String actualamount1=actualamount.replace(",", "").replace(".00", "");
		String actualduedate = uiDriver.getValue("DueDate");
		if (input.get("projects").contains(actualproject)
				|| actualproject.contains(input.get("projects"))) {
			passed("Validating Project", "Project Should be displayed as '"
					+ input.get("projects") + "' successfully",
					"Project is  displayed as '" + actualproject
							+ "' successfully");
		} else {
			failed("Validating Project",
					"Project Flag Should be displayed as '"
							+ input.get("projects") + "' successfully",
					"Project Flag is  not displayed as '" + actualproject
							+ "' successfully");
		}

		if (input.get("Amount").contains(actualamount1)) {
			passed("Validating Amount", "Amount Should be displayed as '"
					+ input.get("Amount") + "' successfully",
					"Amount is  displayed as '" + actualamount
							+ "' successfully");
		} else {
			failed("Validating Amount", "Amount Should be displayed as '"
					+ input.get("Amount") + "' successfully",
					"Amount is  not displayed as '" + actualamount
							+ "' successfully");
		}
		if (input.get("DueDate").contains(actualduedate)) {
			passed("Validating Due Date", "Due Date Should be displayed as '"
					+ input.get("DueDate") + "' successfully",
					"Due Date is  displayed as '" + actualduedate
							+ "' successfully");
		} else {
			failed("Validating Due Date", "Due Date Should be displayed as '"
					+ input.get("DueDate") + "' successfully",
					"Due Date is  displayed as '" + actualduedate
							+ "' successfully");
		}
	}
	
	
	
	/****************************************
	 * Name: NavandValBillingSchedule 
	 * Description: NaviagteToBillingSchedule and validate all fields
	 * Date: 13-August-2019
	 ****************************************/
	public void NavandValBillingSchedule(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billing");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billingschedules");
		SleepUtils.sleep(TimeSlab.LOW);
		
		uiDriver.click("//span[@class='k-dropdown-wrap k-state-default']");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("(//*[@class='k-item'])[1]"); 
		SleepUtils.sleep(TimeSlab.LOW);
		 
		int accRows = uiDriver.webDr
				.findElements(
						By.xpath("//*[@id='contract-billing-schedules-grid']/div[3]/table//tr"))
				.size();
		if (accRows >= 1) {
			passed("Billing Schedule displayed",
					"B illing Schedule Should be displayed",
					"Billing Schedule is displayed");
		} else {
			failed("Billing Schedule not displayed",
					"Billing Schedule Should be displayed",
					"Billing Schedule is not displayed");
		}
		
		String project=input.get("Projects");
		String Projects[]=project.split(";");
		
		List<WebElement> title = uiDriver.webDr.findElements(By.xpath("//*[@id='contract-billing-schedules-grid']/div[3]/table//tr"));
		 int titlesize = title.size();
		 
		 for(int i=0;i<titlesize-1;i++){
			 
			 if(uiDriver.checkElementPresent("//*[@id='contract-billing-schedules-grid']/div[3]/table/tbody/tr["+(i+2)+"]/td[8]")){
			 
			 String ActualTitle=uiDriver.getValue_Text("//*[@id='contract-billing-schedules-grid']/div[3]/table/tbody/tr["+(i+2)+"]/td[8]");
			 String ExpectedTitle=Projects[i];
			 if(ActualTitle.contains(ExpectedTitle)){
				 passed("Validating Project", "Project Should be displayed as '"
							+ Projects[i] + "' successfully",
							"Project is  displayed as '" + ActualTitle
									+ "' successfully");
				} else {
					failed("Validating Project", "Project Should be displayed as '"
							+ Projects[i] + "' successfully",
							"Project is not  displayed as '" + ActualTitle
									+ "' successfully");
				}
			 }
		 }
		 }
		 //String title1 = uiDriver.getValue() ; //(//*[@id="contract-billing-schedules-grid"]/div[3]/table//tr)[2]
		
		
		
		/*if (input.get("projects").contains(actualproject)
				|| actualproject.contains(input.get("projects"))) {
			passed("Validating Project", "Project Should be displayed as '"
					+ input.get("projects") + "' successfully",
					"Project is  displayed as '" + actualproject
							+ "' successfully");
		} else {
			failed("Validating Project",
					"Project Flag Should be displayed as '"
							+ input.get("projects") + "' successfully",
					"Project Flag is  not displayed as '" + actualproject
							+ "' successfully");
		}

		if (input.get("Amount").contains(actualamount1)) {
			passed("Validating Amount", "Amount Should be displayed as '"
					+ input.get("Amount") + "' successfully",
					"Amount is  displayed as '" + actualamount
							+ "' successfully");
		} else {
			failed("Validating Amount", "Amount Should be displayed as '"
					+ input.get("Amount") + "' successfully",
					"Amount is  not displayed as '" + actualamount
							+ "' successfully");
		}
		if (input.get("DueDate").contains(actualduedate)) {
			passed("Validating Due Date", "Due Date Should be displayed as '"
					+ input.get("DueDate") + "' successfully",
					"Due Date is  displayed as '" + actualduedate
							+ "' successfully");
		} else {
			failed("Validating Due Date", "Due Date Should be displayed as '"
					+ input.get("DueDate") + "' successfully",
					"Due Date is  displayed as '" + actualduedate
							+ "' successfully");
		}*/
	
	
	
     
     
     
     /****************************************
 	 * Name: VerifyBilledARJE 
 	 * Description:Method to VerifyBilledARJE
 	 * Date: 6-Aug-2019
 	 ****************************************/
 	public void VerifyBilledARJE(DataRow input, DataRow output)
 			throws InterruptedException {
 	
 		SleepUtils.sleep(TimeSlab.LOW);
 		uiDriver.executeJavaScript("scroll(0,500)");
 		uiDriver.click("//*[text()='lated Transactions']");
 		SleepUtils.sleep(TimeSlab.HIGH);
 			uiDriver.executeJavaScript("scroll(0,1500)");
 				SleepUtils.sleep(5);
 			if(uiDriver.checkElementPresent("BilledARLink")){
 				passed("Validating JE type",
 						"Reclass Billed AR should be present",
 						"Reclass Billed AR JE Type is present");
 				SleepUtils.sleep(5);
 				uiDriver.click("BilledARLink");
 				SleepUtils.sleep(5);
 				uiDriver.executeJavaScript("scroll(0,800)");
 				int invoiceRow = 2;
 				int transRows = uiDriver.webDr.findElements(
 						By.xpath("//*[@id='line_splits']//tbody/tr")).size();
 				
 				String[] accounts = input.get("Account").split(";");
 				String[] debit = input.get("Debit").split(";");
 				String[] credit = input.get("Credit").split(";");
 				
 				String[] memo = input.get("Memo").split(";");
 				String[] name = input.get("Name").split(";");
 				String[] marketCode = input.get("Market Code").split(";");
 				
 				String[] territory = input.get("Territory").split(";");
 				String[] title = input.get("Title").split(";");
 				String[] SOLine = input.get("SO Line").split(";");
 				
 				String[] sourceLine = input.get("Source Line").split(";");
 				String[] FTLineUniqueKey = input.get("FT Line Unique Key").split(";");
 				String[] salesorder = input.get("Sales order").split(";");
 				
 				String[] Invoicelineuniquekey = input.get("Invoice line unique key").split(";");
 				String[] GLPN = input.get("GLPN").split(";");
 				String[] Costcenter = input.get("Cost center").split(";");
 				
 				String[] Profitcenter = input.get("Profit center").split(";");
 				String[] Contractexchangerate = input.get("Contract exchange rate").split(";");
 				String[] Basecurrency = input.get("Base currency").split(";");
 				
 				String[] Basecurrencyvalue = input.get("Base currency value").split(";");
 				String[] Localcontractcurrency = input.get("Local contract currency").split(";");
 				String[] Localcontractcurrencyvalue = input.get("Local contract currency value").split(";");
 				
 				String[] Startedate = input.get("Starte date").split(";");
 				String[] Enddate = input.get("End date").split(";");
 				String[] History = input.get("History").split(";");
 				
 				for (i = 0; i < transRows-1; i++) {
 					String actualAccount = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]");
 					String debitAmount = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[2]");
 					String creditAmount = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[3]");
 					String actualmemo = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[4]");
 					String actualname = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[5]");
 					String actualmarketCode = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[6]");
 					String actualterritory = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[7]");
 					String actualtitle = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[8]");
 					String actualSOLine = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[9]");
 					String actualsourceLine = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[10]");
 					String actualFTLineUniqueKey = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[11]");
 					String actualsalesorder = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[12]");
 					String actualInvoicelineuniquekey = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[13]");
 					String actualGLPN = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[14]");
 					String actualCostcenter = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[15]");
 					String actualProfitcenter = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[16]");
 					String actualContractexchangerate = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[17]");
 					String actualBasecurrency = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[18]");
 					String actualBasecurrencyvalue = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[19]");
 					String actualLocalcontractcurrency = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[20]");
 					String actualLocalcontractcurrencyvalue = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[21]");
 					String actualStartedate = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[22]");
 					String actualEnddate = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[23]");
 					String actualHistory = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[24]");
 					
 					
 					uiDriver.executeJavaScript("scroll(0,100);");
 					if (actualAccount.contains(accounts[i])) {
 						passed("Validating account details",
 								"account should be"+accounts[i],
 								actualAccount+"account details correctly displayed");
 					}else{
 						failed("Validating account details",
 								"account details should be "+accounts[i],
 								actualAccount+"account details are incorrect");
 					}
 				
 					String expected_debit = debit[i].trim();

 					expected_debit= expected_debit.replace("Null", " ");
 				
 					
 					if (debitAmount.contains(expected_debit)) {
 						passed("Validating amount details",
 								" debit amount should be "+expected_debit,
 								debitAmount+"debit amount details correctly displayed");
 					}else{
 						failed("Validating amount details",
 								"Validating debit amount should be dispaying correctly"+expected_debit,
 								debitAmount+"debit amount details are incorrect");
 					}
 					
 					String expected_credit = credit[i].trim();

 					expected_credit= expected_credit.replace("Null", " ");
 				
 					if (creditAmount.contains(expected_credit)) {
 						passed("Validating total credit amount details",
 								"total credit amount should be "+expected_credit,
 								creditAmount+" total credit amount correctly displayed");
 					}else{
 						failed("Validating credit amount details",
 								"total credit amount should be "+expected_credit,
 								creditAmount+" total credit amount details are incorrect");
 					}
 					
 					String expected_memo = memo[i].trim();

 					expected_memo= expected_memo.replace("Null", " ");
 				
 					if (actualmemo.contains(expected_memo)) {
 						passed("Validating memo details",
 								"memo should be "+expected_memo,
 								actualmemo+" memo correctly displayed");
 					}else{
 						failed("Validating memo details",
 								"memo should be "+expected_memo,
 								actualmemo+" memo details are incorrect");
 					}
 					
 					String expected_name = name[i].trim();

 					expected_name= expected_name.replace("Null", " ");
 				
 					if (actualname.contains(expected_name)) {
 						passed("Validating name details",
 								"name should be "+expected_name,
 								actualname+" name correctly displayed");
 					}else{
 						failed("Validating namedetails",
 								"name should be "+expected_name,
 								actualname+"name details are incorrect");
 					}
 					
 					String expected_marketcode = marketCode[i].trim();

 					expected_marketcode= expected_marketcode.replace("Null", " ");
 				
 					if (actualmarketCode.contains(expected_marketcode)) {
 						passed("Validating market code details",
 								"market code should be "+expected_marketcode,
 								actualmarketCode+" market code correctly displayed");
 					}else{
 						failed("Validating market code details",
 								"market code should be "+expected_marketcode,
 								actualmarketCode+" market code details are incorrect");
 					}
 					
 					String expected_territory = territory[i].trim();

 					expected_territory= expected_territory.replace("Null", " ");
 				
 					if (actualterritory.contains(expected_territory)) {
 						passed("Validating territory details",
 								"territory should be "+expected_territory,
 								actualterritory+" territory correctly displayed");
 					}else{
 						failed("Validating territory details",
 								"territory should be "+expected_territory,
 								actualterritory+" territory details are incorrect");
 					}
 					
 					String expected_title= title[i].trim();

 					expected_title= expected_title.replace("Null", " ");
 				
 					if (actualtitle.contains(expected_title)) {
 						passed("Validating title details",
 								"title should be "+expected_title,
 								actualtitle+" title correctly displayed");
 					}else{
 						failed("Validating title details",
 								"title should be "+expected_title,
 								actualtitle+" title details are incorrect");
 					}
 					
 					String expected_SOLine= SOLine[i].trim();

 					expected_SOLine= expected_SOLine.replace("Null", " ");
 				
 					if (actualSOLine.contains(expected_SOLine)) {
 						passed("Validating soline details",
 								"soline should be "+expected_SOLine,
 								actualSOLine+" soline correctly displayed");
 					}else{
 						failed("Validating soline details",
 								"soline should be "+expected_SOLine,
 								actualSOLine+" soline details are incorrect");
 					}
 					
 					String expected_sourceLine= sourceLine[i].trim();

 					expected_sourceLine= expected_sourceLine.replace("Null", " ");
 				
 					if (actualsourceLine.contains(expected_sourceLine)) {
 						passed("Validating sourceline details",
 								"sourceline should be "+expected_sourceLine,
 								actualsourceLine+" sourceline correctly displayed");
 					}else{
 						failed("Validating sourceline details",
 								"sourceline should be "+expected_sourceLine,
 								actualsourceLine+" sourceline details are incorrect");
 					}
 					String expected_FTLineUniqueKey = FTLineUniqueKey[i].trim();

 					expected_FTLineUniqueKey= expected_FTLineUniqueKey.replace("Null", " ");
 				
 					if (actualFTLineUniqueKey.contains(expected_FTLineUniqueKey)) {
 						passed("Validating FTLineUniqueKey details",
 								"FTLineUniqueKey should be "+expected_FTLineUniqueKey,
 								actualFTLineUniqueKey+" FTLineUniqueKey correctly displayed");
 					}else{
 						failed("Validating FTLineUniqueKey details",
 								"FTLineUniqueKey should be "+expected_FTLineUniqueKey,
 								actualFTLineUniqueKey+" FTLineUniqueKey details are incorrect");
 					}
 					String expected_salesorder= salesorder[i].trim();

 					expected_salesorder= expected_salesorder.replace("Null", " ");
 				
 					if (actualsalesorder.contains(expected_salesorder)) {
 						passed("Validating salesorder details",
 								"salesorder should be "+expected_salesorder,
 								actualsalesorder+" salesorder correctly displayed");
 					}else{
 						failed("Validating salesorder details",
 								"salesorder should be "+expected_salesorder,
 								actualsalesorder+" salesorder details are incorrect");
 					}
 					
 					String expected_Invoicelineuniquekey = Invoicelineuniquekey[i].trim();

 					expected_Invoicelineuniquekey= expected_Invoicelineuniquekey.replace("Null", " ");
 				
 					if (actualInvoicelineuniquekey.contains(expected_Invoicelineuniquekey)) {
 						passed("Validating Invoicelineuniquekey details",
 								"Invoicelineuniquekey should be "+expected_Invoicelineuniquekey,
 								actualInvoicelineuniquekey+" Invoicelineuniquekey correctly displayed");
 					}else{
 						failed("Validating Invoicelineuniquekey details",
 								"Invoicelineuniquekey should be "+expected_Invoicelineuniquekey,
 								actualInvoicelineuniquekey+" Invoicelineuniquekey details are incorrect");
 					}
 					
 					String expected_GLPN= GLPN[i].trim();

 					expected_GLPN= expected_GLPN.replace("Null", " ");
 				
 					if (actualGLPN.contains(expected_GLPN)) {
 						passed("Validating GLPN details",
 								"GLPN should be "+expected_GLPN,
 								actualGLPN+" GLPN correctly displayed");
 					}else{
 						failed("Validating GLPN details",
 								"GLPN should be "+expected_GLPN,
 								actualGLPN+" GLPN details are incorrect");
 					}
 					
 					String expected_Costcenter = Costcenter[i].trim();

 					expected_Costcenter= expected_Costcenter.replace("Null", " ");
 				
 					if (actualCostcenter.contains(expected_Costcenter)) {
 						passed("Validating Costcenter details",
 								"Costcenter should be "+expected_Costcenter,
 								actualCostcenter+" Costcenter correctly displayed");
 					}else{
 						failed("Validating Costcenter details",
 								"Costcenter should be "+expected_Costcenter,
 								actualCostcenter+" Costcenter details are incorrect");
 					}
 					
 					String expected_Profitcenter = Profitcenter[i].trim();

 					expected_Profitcenter= expected_Profitcenter.replace("Null", " ");
 				
 					if (actualProfitcenter.contains(expected_Profitcenter)) {
 						passed("Validating Profitcenter details",
 								"Profitcenter should be "+expected_Profitcenter,
 								actualProfitcenter+" Profitcenter correctly displayed");
 					}else{
 						failed("Validating Profitcenter details",
 								"Profitcenter should be "+expected_Profitcenter,
 								actualProfitcenter+" Profitcenter details are incorrect");
 					}
 					
 					String expected_Contractexchangerate = Contractexchangerate[i].trim();

 					expected_Contractexchangerate= expected_Contractexchangerate.replace("Null", " ");
 				
 					if (actualContractexchangerate.contains(expected_Contractexchangerate)) {
 						passed("Validating Contractexchangerate details",
 								"Contractexchangerate should be "+expected_Contractexchangerate,
 								actualContractexchangerate+" Contractexchangerate correctly displayed");
 					}else{
 						failed("Validating Contractexchangerate details",
 								"Contractexchangerate should be "+expected_Contractexchangerate,
 								actualContractexchangerate+" Contractexchangerate details are incorrect");
 					}
 					
 					String expected_Basecurrency = Basecurrency[i].trim();

 					expected_Basecurrency= expected_Basecurrency.replace("Null", " ");
 				
 					if (actualBasecurrency.contains(expected_Profitcenter)) {
 						passed("Validating Basecurrency details",
 								"Basecurrency should be "+expected_Basecurrency,
 								actualBasecurrency+" Basecurrency correctly displayed");
 					}else{
 						failed("Validating Basecurrency details",
 								"Basecurrency should be "+expected_Basecurrency,
 								actualBasecurrency+" Basecurrency details are incorrect");
 					}
 					
 					String expected_Basecurrencyvalue = Basecurrencyvalue[i].trim();

 					expected_Basecurrencyvalue= expected_Basecurrencyvalue.replace("Null", " ");
 				
 					if (actualBasecurrencyvalue.contains(expected_Basecurrencyvalue)) {
 						passed("Validating Basecurrencyvalue details",
 								"Basecurrencyvalue should be "+expected_Basecurrencyvalue,
 								actualBasecurrencyvalue+" Basecurrencyvalue correctly displayed");
 					}else{
 						failed("Validating Basecurrencyvalue details",
 								"Basecurrencyvalue should be "+expected_Basecurrencyvalue,
 								actualBasecurrencyvalue+" Basecurrencyvalue details are incorrect");
 					}
 					
 					String expected_Localcontractcurrency = Localcontractcurrency[i].trim();

 					expected_Localcontractcurrency= expected_Localcontractcurrency.replace("Null", " ");
 				
 					if (actualLocalcontractcurrency.contains(expected_Localcontractcurrency)) {
 						passed("Validating Localcontractcurrency details",
 								"Localcontractcurrency should be "+expected_Localcontractcurrency,
 								actualLocalcontractcurrency+" Localcontractcurrency correctly displayed");
 					}else{
 						failed("Validating Localcontractcurrency details",
 								"Localcontractcurrency should be "+expected_Localcontractcurrency,
 								actualLocalcontractcurrency+" Localcontractcurrency details are incorrect");
 					}
 					
 					String expected_Localcontractcurrencyvalue = Localcontractcurrencyvalue[i].trim();

 					expected_Localcontractcurrencyvalue= expected_Localcontractcurrencyvalue.replace("Null", " ");
 				
 					if (actualLocalcontractcurrencyvalue.contains(expected_Localcontractcurrencyvalue)) {
 						passed("Validating Localcontractcurrencyvalue details",
 								"Localcontractcurrencyvalue should be "+expected_Localcontractcurrencyvalue,
 								actualLocalcontractcurrencyvalue+" Localcontractcurrencyvalue correctly displayed");
 					}else{
 						failed("Validating Localcontractcurrencyvalue details",
 								"Localcontractcurrencyvalue should be "+expected_Localcontractcurrencyvalue,
 								actualLocalcontractcurrencyvalue+" Localcontractcurrencyvalue details are incorrect");
 					}
 					
 					String expected_Startedate = Startedate[i].trim();

 					expected_Startedate= expected_Startedate.replace("Null", " ");
 				
 					if (actualStartedate.contains(expected_Startedate)) {
 						passed("Validating Startedate details",
 								"Startedate should be "+expected_Startedate,
 								actualStartedate+" Startedate correctly displayed");
 					}else{
 						failed("Validating Startedate details",
 								"Startedate should be "+expected_Startedate,
 								actualStartedate+" Startedate details are incorrect");
 					}
 					
 					String expected_Enddate = Enddate[i].trim();

 					expected_Enddate= expected_Enddate.replace("Null", " ");
 				
 					if (actualEnddate.contains(expected_Enddate)) {
 						passed("Validating Enddate details",
 								"Enddate should be "+expected_Enddate,
 								actualEnddate+" Enddate correctly displayed");
 					}else{
 						failed("Validating Enddate details",
 								"Enddate should be "+expected_Enddate,
 								actualEnddate+" Enddate details are incorrect");
 					}
 					
 					String expected_History = History[i].trim();

 					expected_History= expected_History.replace("Null", " ");
 				
 					if (actualHistory.contains(expected_History)) {
 						passed("Validating History details",
 								"History should be "+expected_History,
 								actualHistory+" History correctly displayed");
 					}else{
 						failed("Validating History details",
 								"History should be "+expected_History,
 								actualHistory+" History details are incorrect");
 					}
 					invoiceRow++;
 				}
 			}
 				else{
 					failed("Validating JE type",
 							"Reclass Billed AR should be present",
 							"Reclass Billed AR is not present");
 				}
 			
 				if(uiDriver.checkElementPresent("//input[@id='_back']")) {
 				     uiDriver.executeJavaScript("scroll(0,-1000)");
 				     uiDriver.click("//input[@id='_back']");
 				    } else {
 				     uiDriver.back();
 				    }
 	}
 	
 	
 	
 	
 	
 	
 	public void VerifyDeferredRevJE(DataRow input, DataRow output)

            throws InterruptedException {



      SleepUtils.sleep(TimeSlab.LOW);

            uiDriver.click("//*[text()='lated Transactions']");

            SleepUtils.sleep(TimeSlab.LOW);

            if(uiDriver.checkElementPresent("revenueLink")){

                  passed("Validating JE type",

                                "Reclass Deferred revenue should be present",

                                "Reclass Deferred revenue JE Type is present");

                  SleepUtils.sleep(5);

                  uiDriver.click("revenueLink");

                  SleepUtils.sleep(5);

                  uiDriver.executeJavaScript("scroll(0,300)");

                  int invoiceRow = 2;

                  int transRows = uiDriver.webDr.findElements(

                                By.xpath("//*[@id='line_splits']//tbody/tr")).size();

                 

                   String[] accounts = input.get("Account").split(";");

                  String[] debit = input.get("Debit").split(";");

                  String[] credit = input.get("Credit").split(";");

                 

                   //String[] memo = input.get("Memo").split(";");

                  String[] name = input.get("Name").split(";");

                  String[] marketCode = input.get("Market Code").split(";");

                 

                   String[] territory = input.get("Territory").split(";");

                  //String[] title = input.get("Title").split(";");

                  //String[] SOLine = input.get("SO Line").split(";");

                 

                   //String[] sourceLine = input.get("Source Line").split(";");

                  //String[] FTLineUniqueKey = input.get("FT Line Unique Key").split(";");

                  //String[] salesorder = input.get("Sales order").split(";");

                 

                   //String[] Invoicelineuniquekey = input.get("Invoice line unique key").split(";");

                  String[] GLPN = input.get("GLPN").split(";");

                  //String[] Costcenter = input.get("Cost center").split(";");

                 

                   //String[] Profitcenter = input.get("Profit center").split(";");

                  //String[] Contractexchangerate = input.get("Contract exchange rate").split(";");

                  //String[] Basecurrency = input.get("Base currency").split(";");

                 

                   //String[] Basecurrencyvalue = input.get("Base currency value").split(";");

                  //String[] Localcontractcurrency = input.get("Local contract currency").split(";");

                  //String[] Localcontractcurrencyvalue = input.get("Local contract currency value").split(";");

                 

                   //String[] Startedate = input.get("Starte date").split(";");

                  //String[] Enddate = input.get("End date").split(";");

                  //String[] History = input.get("History").split(";");

                 

                   for (i = 0; i < transRows-1; i++) {

                         uiDriver.executeJavaScript("scroll(0,100);");

                         String actualAccount = uiDriver.getValue(

                                       "//*[@id='line_splits']/tbody/tr[" + invoiceRow

                                       + "]/td[1]");

                         String debitAmount = uiDriver.getValue(

                                       "//*[@id='line_splits']/tbody/tr[" + invoiceRow

                                       + "]/td[2]").replace(",", "");

                         String creditAmount = uiDriver.getValue(

                                       "//*[@id='line_splits']/tbody/tr[" + invoiceRow

                                                     + "]/td[3]");

                        

                          //String actualmemo = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[4]");

                         String actualname = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[5]");

                         String actualmarketCode = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[6]");

                         String actualterritory = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[7]");

                         String actualGLPN = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[14]");

                         /*String actualtitle = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[8]");

                         String actualSOLine = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[9]");

                         String actualsourceLine = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[10]");

                         String actualFTLineUniqueKey = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[11]");

                         String actualsalesorder = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[12]");

                         String actualInvoicelineuniquekey = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[13]");

                         String actualGLPN = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[14]");

                         String actualCostcenter = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[15]");

                         String actualProfitcenter = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[16]");

                         String actualContractexchangerate = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[17]");

                         String actualBasecurrency = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[18]");

                         String actualBasecurrencyvalue = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[19]");

                         String actualLocalcontractcurrency = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[20]");

                         String actualLocalcontractcurrencyvalue = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[21]");

                         String actualStartedate = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[22]");

                         String actualEnddate = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[23]");

                         String actualHistory = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[24]");*/

                        

                         

                          if (actualAccount.contains(accounts[i])||accounts[i].contains(actualAccount)) {

                                passed("Validating account details",

                                              "account should be"+accounts[i],

                                              actualAccount+"account details correctly displayed");

                         }else{

                                failed("Validating account details",

                                              "account details should be "+accounts[i],

                                              actualAccount+"account details are incorrect");

                         }

                         String expected_debit = debit[i].trim();



                         expected_debit= expected_debit.replace("Null", " ");

                         if (debitAmount.contains(expected_debit)) {

                                passed("Validating amount details",

                                              " debit amount should be "+expected_debit,

                                              debitAmount+"debit amount details correctly displayed");

                         }else{

                                failed("Validating amount details",

                                              "Validating debit amount should be dispaying correctly"+expected_debit,

                                              debitAmount+"debit amount details are incorrect");

                         }

                 

                          String expected_credit = credit[i].trim().replace(",", "");



                         expected_credit= expected_credit.replace("Null", " ");

                         if (creditAmount.replace(",", "").contains(expected_credit)) {

                                passed("Validating amount details",

                                              " credit amount should be "+expected_credit,

                                              creditAmount+"credit amount details correctly displayed");

                         }else{

                                failed("Validating amount details",

                                              "credit amount should be "+expected_credit,

                                              creditAmount+"credit amount details are incorrect");

                         }

                        

                          /*String expected_memo = memo[i].trim();



                         expected_memo= expected_memo.replace("Null", " ");

                 

                          if (actualmemo.contains(expected_memo)) {

                                passed("Validating memo details",

                                              "memo should be "+expected_memo,

                                              actualmemo+" memo correctly displayed");

                         }else{

                                failed("Validating memo details",

                                              "memo should be "+expected_memo,

                                              actualmemo+" memo details are incorrect");

                         }*/

                        

                          String expected_name = name[i].trim();



                         expected_name= expected_name.replace("Null", " ");

                 

                          if (actualname.contains(expected_name)) {

                                passed("Validating name details",

                                              "name should be "+expected_name,

                                              actualname+" name correctly displayed");

                         }else{

                                failed("Validating namedetails",

                                              "name should be "+expected_name,

                                              actualname+"name details are incorrect");

                         }

                        

                          String expected_marketcode = marketCode[i].trim();



                         expected_marketcode= expected_marketcode.replace("Null", " ");

                 

                          if (actualmarketCode.contains(expected_marketcode)) {

                                passed("Validating market code details",

                                              "market code should be "+expected_marketcode,

                                              actualmarketCode+" market code correctly displayed");

                         }else{

                                failed("Validating market code details",

                                              "market code should be "+expected_marketcode,

                                              actualmarketCode+" market code details are incorrect");

                         }

                        

                          String expected_territory = territory[i].trim();



                         expected_territory= expected_territory.replace("Null", " ");

                 

                          if (actualterritory.contains(expected_territory)) {

                                passed("Validating territory details",

                                              "territory should be "+expected_territory,

                                              actualterritory+" territory correctly displayed");

                         }else{

                                failed("Validating territory details",

                                              "territory should be "+expected_territory,

                                              actualterritory+" territory details are incorrect");

                         }

                         String expected_GLPN= GLPN[i].trim();



                         expected_GLPN= expected_GLPN.replace("Null", " ");

                 

                          if (actualGLPN.contains(expected_GLPN)) {

                                passed("Validating GLPN details",

                                              "GLPN should be "+expected_GLPN,

                                              actualGLPN+" GLPN correctly displayed");

                         }else{

                                failed("Validating GLPN details",

                                              "GLPN should be "+expected_GLPN,

                                              actualGLPN+" GLPN details are incorrect");

                               

                                

                          }

                         invoiceRow++;

                  }

            }

                 

                          /*String expected_title= title[i].trim();



                         expected_title= expected_title.replace("Null", " ");

                 

                          if (actualtitle.contains(expected_title)) {

                                passed("Validating title details",

                                              "title should be "+expected_title,

                                              actualtitle+" title correctly displayed");

                         }else{

                                failed("Validating title details",

                                              "title should be "+expected_title,

                                              actualtitle+" title details are incorrect");

                         }

                        

                          String expected_SOLine= SOLine[i].trim();



                         expected_SOLine= expected_SOLine.replace("Null", " ");

                 

                          if (actualSOLine.contains(expected_SOLine)) {

                                passed("Validating soline details",

                                              "soline should be "+expected_SOLine,

                                              actualSOLine+" soline correctly displayed");

                         }else{

                                failed("Validating soline details",

                                              "soline should be "+expected_SOLine,

                                              actualSOLine+" soline details are incorrect");

                         }

                        

                          String expected_sourceLine= sourceLine[i].trim();



                         expected_sourceLine= expected_sourceLine.replace("Null", " ");

                 

                          if (actualsourceLine.contains(expected_sourceLine)) {

                                passed("Validating sourceline details",

                                              "sourceline should be "+expected_sourceLine,

                                              actualsourceLine+" sourceline correctly displayed");

                         }else{

                                failed("Validating sourceline details",

                                              "sourceline should be "+expected_sourceLine,

                                              actualsourceLine+" sourceline details are incorrect");

                         }

                         String expected_FTLineUniqueKey = FTLineUniqueKey[i].trim();



                         expected_FTLineUniqueKey= expected_FTLineUniqueKey.replace("Null", " ");

                 

                          if (actualFTLineUniqueKey.contains(expected_FTLineUniqueKey)) {

                                passed("Validating FTLineUniqueKey details",

                                              "FTLineUniqueKey should be "+expected_FTLineUniqueKey,

                                              actualFTLineUniqueKey+" FTLineUniqueKey correctly displayed");

                         }else{

                                failed("Validating FTLineUniqueKey details",

                                              "FTLineUniqueKey should be "+expected_FTLineUniqueKey,

                                              actualFTLineUniqueKey+" FTLineUniqueKey details are incorrect");

                         }

                         String expected_salesorder= salesorder[i].trim();



                         expected_salesorder= expected_salesorder.replace("Null", " ");

                 

                          if (actualsalesorder.contains(expected_salesorder)) {

                                passed("Validating salesorder details",

                                              "salesorder should be "+expected_salesorder,

                                              actualsalesorder+" salesorder correctly displayed");

                         }else{

                                failed("Validating salesorder details",

                                              "salesorder should be "+expected_salesorder,

                                              actualsalesorder+" salesorder details are incorrect");

                         }

                        

                          String expected_Invoicelineuniquekey = Invoicelineuniquekey[i].trim();



                         expected_Invoicelineuniquekey= expected_Invoicelineuniquekey.replace("Null", " ");

                 

                          if (actualInvoicelineuniquekey.contains(expected_Invoicelineuniquekey)) {

                                passed("Validating Invoicelineuniquekey details",

                                              "Invoicelineuniquekey should be "+expected_Invoicelineuniquekey,

                                              actualInvoicelineuniquekey+" Invoicelineuniquekey correctly displayed");

                         }else{

                                failed("Validating Invoicelineuniquekey details",

                                              "Invoicelineuniquekey should be "+expected_Invoicelineuniquekey,

                                              actualInvoicelineuniquekey+" Invoicelineuniquekey details are incorrect");

                         }

                        

                         

                         

                          String expected_Costcenter = Costcenter[i].trim();



                         expected_Costcenter= expected_Costcenter.replace("Null", " ");

                 

                          if (actualCostcenter.contains(expected_Costcenter)) {

                                passed("Validating Costcenter details",

                                              "Costcenter should be "+expected_Costcenter,

                                              actualCostcenter+" Costcenter correctly displayed");

                         }else{

                                failed("Validating Costcenter details",

                                              "Costcenter should be "+expected_Costcenter,

                                              actualCostcenter+" Costcenter details are incorrect");

                         }

                        

                          String expected_Profitcenter = Profitcenter[i].trim();



                         expected_Profitcenter= expected_Profitcenter.replace("Null", " ");

                 

                           if (actualProfitcenter.contains(expected_Profitcenter)) {

                                passed("Validating Profitcenter details",

                                              "Profitcenter should be "+expected_Profitcenter,

                                              actualProfitcenter+" Profitcenter correctly displayed");

                         }else{

                                failed("Validating Profitcenter details",

                                              "Profitcenter should be "+expected_Profitcenter,

                                              actualProfitcenter+" Profitcenter details are incorrect");

                         }

                        

                          String expected_Contractexchangerate = Contractexchangerate[i].trim();



                         expected_Contractexchangerate= expected_Contractexchangerate.replace("Null", " ");

                 

                          if (actualContractexchangerate.contains(expected_Contractexchangerate)) {

                                passed("Validating Contractexchangerate details",

                                              "Contractexchangerate should be "+expected_Contractexchangerate,

                                              actualContractexchangerate+" Contractexchangerate correctly displayed");

                         }else{

                                failed("Validating Contractexchangerate details",

                                              "Contractexchangerate should be "+expected_Contractexchangerate,

                                              actualContractexchangerate+" Contractexchangerate details are incorrect");

                         }

                        

                          String expected_Basecurrency = Basecurrency[i].trim();



                         expected_Basecurrency= expected_Basecurrency.replace("Null", " ");

                 

                          if (actualBasecurrency.contains(expected_Profitcenter)) {

                                passed("Validating Basecurrency details",

                                              "Basecurrency should be "+expected_Basecurrency,

                                              actualBasecurrency+" Basecurrency correctly displayed");

                         }else{

                                failed("Validating Basecurrency details",

                                              "Basecurrency should be "+expected_Basecurrency,

                                              actualBasecurrency+" Basecurrency details are incorrect");

                         }

                        

                          String expected_Basecurrencyvalue = Basecurrencyvalue[i].trim();



                         expected_Basecurrencyvalue= expected_Basecurrencyvalue.replace("Null", " ");

                 

                          if (actualBasecurrencyvalue.contains(expected_Basecurrencyvalue)) {

                                passed("Validating Basecurrencyvalue details",

                                              "Basecurrencyvalue should be "+expected_Basecurrencyvalue,

                                              actualBasecurrencyvalue+" Basecurrencyvalue correctly displayed");

                         }else{

                                failed("Validating Basecurrencyvalue details",

                                              "Basecurrencyvalue should be "+expected_Basecurrencyvalue,

                                              actualBasecurrencyvalue+" Basecurrencyvalue details are incorrect");

                         }

                        

                          String expected_Localcontractcurrency = Localcontractcurrency[i].trim();



                         expected_Localcontractcurrency= expected_Localcontractcurrency.replace("Null", " ");

                 

                          if (actualLocalcontractcurrency.contains(expected_Localcontractcurrency)) {

                                passed("Validating Localcontractcurrency details",

                                              "Localcontractcurrency should be "+expected_Localcontractcurrency,

                                              actualLocalcontractcurrency+" Localcontractcurrency correctly displayed");

                         }else{

                                failed("Validating Localcontractcurrency details",

                                              "Localcontractcurrency should be "+expected_Localcontractcurrency,

                                              actualLocalcontractcurrency+" Localcontractcurrency details are incorrect");

                         }

                        

                          String expected_Localcontractcurrencyvalue = Localcontractcurrencyvalue[i].trim();



                         expected_Localcontractcurrencyvalue= expected_Localcontractcurrencyvalue.replace("Null", " ");

                 

                          if (actualLocalcontractcurrencyvalue.contains(expected_Localcontractcurrencyvalue)) {

                                passed("Validating Localcontractcurrencyvalue details",

                                              "Localcontractcurrencyvalue should be "+expected_Localcontractcurrencyvalue,

                                              actualLocalcontractcurrencyvalue+" Localcontractcurrencyvalue correctly displayed");

                         }else{

                                failed("Validating Localcontractcurrencyvalue details",

                                              "Localcontractcurrencyvalue should be "+expected_Localcontractcurrencyvalue,

                                              actualLocalcontractcurrencyvalue+" Localcontractcurrencyvalue details are incorrect");

                         }

                        

                          String expected_Startedate = Startedate[i].trim();



                         expected_Startedate= expected_Startedate.replace("Null", " ");

                 

                          if (actualStartedate.contains(expected_Startedate)) {

                                passed("Validating Startedate details",

                                              "Startedate should be "+expected_Startedate,

                                              actualStartedate+" Startedate correctly displayed");

                         }else{

                                failed("Validating Startedate details",

                                              "Startedate should be "+expected_Startedate,

                                              actualStartedate+" Startedate details are incorrect");

                         }

                        

                          String expected_Enddate = Enddate[i].trim();



                         expected_Enddate= expected_Enddate.replace("Null", " ");

                 

                          if (actualEnddate.contains(expected_Enddate)) {

                                passed("Validating Enddate details",

                                              "Enddate should be "+expected_Enddate,

                                              actualEnddate+" Enddate correctly displayed");

                         }else{

                                failed("Validating Enddate details",

                                              "Enddate should be "+expected_Enddate,

                                              actualEnddate+" Enddate details are incorrect");

                         }

                        

                          String expected_History = History[i].trim();



                         expected_History= expected_History.replace("Null", " ");

                 

                          if (actualHistory.contains(expected_History)) {

                                passed("Validating History details",

                                              "History should be "+expected_History,

                                              actualHistory+" History correctly displayed");

                         }else{

                                failed("Validating History details",

                                              "History should be "+expected_History,

                                              actualHistory+" History details are incorrect");

                         }



                         invoiceRow++;

                  }

            }*/

            else{

                  failed("Validating JE type",

                                "Reclass deferred revenue JE Type should be present",

                                "Reclass deferred revenue JE Type is not present");

            }

}

	

	/****************************************
	 * Name: Applycash 
	 * Description: Applycash 
	 * Date: 19-July-2018
	 ****************************************/
	

		
		public void Applycash(DataRow input, DataRow output) {

			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.mouseOver("transactions");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.mouseOver("financial");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("makejournalentry");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Subsidiary");
			uiDriver.setValue("Subsidiary", input.get("Subsidiary"));
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("Subsidiary");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("invoicedropdownimage");
			uiDriver.handleAlert("", "OK");
			SleepUtils.sleep(5);
			uiDriver.click("invoicelist");
			SleepUtils.sleep(5);
			String invoice = "Invoice #" + input.get("Invoicenum");
			uiDriver.setValue("searchinvoiceinput", invoice);
			SleepUtils.sleep(5);
			uiDriver.click("searchinvoicebutton");
			SleepUtils.sleep(5);
			uiDriver.click("invsearchresult");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.executeJavaScript("scroll(0,1200)");
			uiDriver.click("accountdebit");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.setValue("editdebitaccount", input.get("debit"));
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("selecteddebit");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("debit");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.setValue("editdebit", input.get("debitamount"));
			SleepUtils.sleep(TimeSlab.LOW);
			WebElement w = uiDriver.webDr.findElement(By.xpath("//*[@id='line_splits']/tbody/tr[2]/td[5]/div"));
			JavascriptExecutor j=(JavascriptExecutor)uiDriver.webDr;
			j.executeScript("arguments[0].click();",w);
		
			/*uiDriver.click("cust");
			if (uiDriver.checkElementPresent("cust")) {
				uiDriver.click("cust");
			}*/

			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("custdropdownimage");
			uiDriver.handleAlert("", "OK");
			SleepUtils.sleep(5);
			uiDriver.click("custlist");
			SleepUtils.sleep(5);

			uiDriver.setValue("searchcustinput", input.get("custedit"));
			SleepUtils.sleep(5);
			uiDriver.click("searchcustbutton");
			SleepUtils.sleep(5);
			uiDriver.click("custsearchresult");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.executeJavaScript("document.getElementById('line_addedit').click();");
			// *[@id="line_addedit"]
			// uiDriver.click("creditamount");
			// uiDriver.click("accountcredit");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.setValue("editcreditaccount", input.get("credit"));
			SleepUtils.sleep(TimeSlab.LOW);
			// Actions action=new Actions(uiDriver.webDr);
			// WebElement ele =
			// uiDriver.webDr.findElement(By.xpath("//table[@id='line_splits']/tbody/tr[3]/td[3]/div"));
			// action.sendKeys(ele, "").build().perform();
			// SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("credit");
			uiDriver.click("credit");
			SleepUtils.sleep(TimeSlab.LOW);
			WebElement w1 = uiDriver.webDr.findElement(By.xpath("//*[@id='line_splits']/tbody/tr[3]/td[5]/div"));
			JavascriptExecutor j1=(JavascriptExecutor)uiDriver.webDr;
			j1.executeScript("arguments[0].click();",w1);
			/*uiDriver.click("cust1");
			if (uiDriver.checkElementPresent("cust1")) {
				uiDriver.click("cust1");
			}*/

			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("custdropdownimage");
			uiDriver.handleAlert("", "OK");
			SleepUtils.sleep(5);
			uiDriver.click("custlist");
			SleepUtils.sleep(5);

			uiDriver.setValue("searchcustinput", input.get("custedit"));
			SleepUtils.sleep(5);
			uiDriver.click("searchcustbutton");
			SleepUtils.sleep(5);
			uiDriver.click("custsearchresult");
			uiDriver.setValue("JEtype", "Intercompany AR Clearing");
			// action.sendKeys(ele ,input.get("debitamount")).build().perform();
			// uiDriver.setValue("editcreditamount", input.get("debitamount"));
			// SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("Save");
			// uiDriver.executeJavaScript("document.getElementById('secondarysubmitter').click();");
			SleepUtils.sleep(TimeSlab.HIGH);
			String journalnum = uiDriver.getValue("JournalNumber");
			passed("Verifying Journal is created",
					"Journal should be  created", "Journal is  created");
		
			output.put("JournalId", journalnum);
		}
			
	
		

	/****************************************
	 * Name: updateRevenueArreangemet
	 * Description:updateRevenueArreangement10K
	 * Date: 30-Nov-2017
	 ****************************************/
	public void updateRevenueArreangement10K(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.LOW);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("transactions");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("financial");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("updateRevenueArrangement");
		SleepUtils.sleep(TimeSlab.YIELD);
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
	    String s = formatter.format(date);
	    System.out.println(s);
	    uiDriver.setValue("sourcedate", s);
		uiDriver.click("updateRevenueArrBtn");
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		 uiDriver.setValue("sourcedate", s);
		uiDriver.click("updateRevenuePlanBtn");
		uiDriver.executeJavaScript("scroll(0,-1000)");
		uiDriver.click("refreshBtn");
		// uiDriver.click("updaterevenuplan");
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		uiDriver.click("refreshBtn");
		// uiDriver.click("updaterevenuplan");
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		/*uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");*/
	}

	/****************************************
	 * Name: ApproveJournal 
	 * Description:Method to ApproveJournal
	 * Date: 14-Aug-2018
	 ****************************************/
	public void ApproveJournal(DataRow input, DataRow output) {

		String Num = input.get("journ");
		uiDriver.setValue("SearchJournal", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Journal");
		SleepUtils.sleep(TimeSlab.HIGH);
		// uiDriver.click("Approved");
		WebElement w = uiDriver.webDr.findElement(By.xpath("(//input[@value='Approve'])[1]"));
		String id = w.getAttribute("id");
		uiDriver.executeJavaScript("document.getElementById('"+id+"').click();");
		SleepUtils.sleep(TimeSlab.HIGH);
		if (uiDriver.checkElementPresent("Approve")) {
			passed("Verifying Journal is approved",
					"Journal should be  approved", "Journal is  approved");
		}
	}
	
	
	/****************************************
	 * Name: Verifyrevisedamount
	 * Description:Method to ApproveJournal
	 * Date: 14-Aug-2018
	 ****************************************/
	public void Verifyrevisedamount(DataRow input, DataRow output) {

		String amount=uiDriver.getValue("amount");
		String expamount=input.get("amount");
		if(amount.equalsIgnoreCase(expamount))
		{
			passed("Verifying amount",
					"Amount should be"+expamount+"", "Amount is"+amount+"");
		}
		else
		{

			failed("Verifying amount",
					"Amount should be"+expamount+"", "Amount is not"+expamount+"");
		
		}
		}
	
	/****************************************
	 * Name: confirmallocationBAS
	 * Description:Method to confirm allocations
	 * Date: 18-Nov-2018
	 ****************************************/
	public void confirmallocationBAS(DataRow input, DataRow output) {

		uiDriver.click("editbutton");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("next");
		SleepUtils.sleep(TimeSlab.HIGH);
		String percent=uiDriver.getValue("Territories");
		if(percent.startsWith("100.00"))
		{
			passed("Verifying allocation for territory",
					"territory allocation should be"+percent+"", "territory allocation is"+percent+"");
		}
		else
		{
			failed("Verifying allocation for territory",
					"territory allocation should be"+percent+"", "territory allocation is not "+percent+"");
		}
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("next");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		String BASallocation=uiDriver.getValue("basiccable");
		if(BASallocation.startsWith("100.00"))
		{
			passed("Verifying allocation for territory",
					"territory allocation should be"+BASallocation+"", "territory allocation is"+BASallocation+"");
		}
		else
		{
			failed("Verifying allocation for territory",
					"territory allocation should be"+BASallocation+"", "territory allocation is not "+BASallocation+"");
		}
		
		uiDriver.click("finish");
		SleepUtils.sleep(TimeSlab.HIGH);
		}
	
	
	/****************************************
	 * Name: confirmallocationFTV
	 * Description:Method to confirm allocations
	 * Date: 18-Nov-2018
	 ****************************************/
	public void confirmallocationFTV(DataRow input, DataRow output) {

		uiDriver.click("editbutton");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("next");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.YIELD);
		String percent=uiDriver.getValue("Territories");
		if(percent.startsWith("100.00"))
		{
			passed("Verifying allocation for territory",
					"territory allocation should be"+percent+"", "territory allocation is"+percent+"");
		}
		else
		{
			passed("Verifying allocation for territory",
					"territory allocation should be"+percent+"", "territory allocation is not "+percent+"");
		}
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("next");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.YIELD);
		String ftvallocation=uiDriver.getValue("ftv");
		if(ftvallocation.startsWith("100.00"))
		{
			passed("Verifying allocation for territory",
					"territory allocation should be"+ftvallocation+"", "territory allocation is"+ftvallocation+"");
		}
		else
		{
			failed("Verifying allocation for territory",
					"territory allocation should be"+ftvallocation+"", "territory allocation is not "+ftvallocation+"");
		}
		
		uiDriver.click("finish");
		SleepUtils.sleep(TimeSlab.HIGH);
		}
	/****************************************
	 * Name: VerifyInvoiceStatus
	 * Description:Method to VerifyInvoiceStatus 
	 * Date: 14-Aug-2018
	 ****************************************/
	public void VerifyInvoiceStatus(DataRow input, DataRow output) {

		String Status = uiDriver.getValue("Status");
		if (Status.equalsIgnoreCase(input.get("Status"))) {

			passed("Verifying the  Invoice Status",
					"Invoice Status should be displayed as '"
							+ input.get("Status") + "' Successfully",
					"Invoice Status " + Status + " is displayed Successfully");
		} else {
			failed("Verifying the  Invoice Status",
					"Invoice Status should be displayed as '"
							+ input.get("Status") + "' Successfully",
					"Invoice Status " + Status
							+ " is not displayed Successfully");
		}

	}
/****************************************
	 * Name: VerifyInvoiceJournalsinUAT
	 * Description:Method to VerifyInvoiceJournals
	 * Date: 29-Jul-2018
	 ****************************************/
	public void VerifyInvoiceJournals_UAT(DataRow input, DataRow output)
			throws InterruptedException {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("reclassJEntry");
		SleepUtils.sleep(TimeSlab.HIGH);
		List<WebElement> ele = uiDriver.webDr
				.findElements(By
						.xpath("//*[@id='recmachcustbody_nbcu_related_record__tab']/tbody/tr"));
		int rowSize = ele.size();
		for (int r = 1; r < rowSize; r++) {
			uiDriver.executeJavaScript("document.getElementById('custom25txt').click();");
			//uiDriver.click("reclassJEntry");
			SleepUtils.sleep(2);
			uiDriver.executeJavaScript("scroll(0,1500)");
			String s1 = uiDriver.getDyanmicData("DocNum");
			String s2 = s1.replace("#", Integer.toString(r));
			if (uiDriver.checkElementPresent_dynamic(s2)) {

				SleepUtils.sleep(5);
				uiDriver.click(s2);
				SleepUtils.sleep(5);
				uiDriver.executeJavaScript("scroll(0,800)");
				int invoiceRow = 2;
				int transRows = uiDriver.webDr.findElements(
						By.xpath("//*[@id='line_splits']//tbody/tr")).size();
				for (i = 0; i < transRows - 1; i++) {
					uiDriver.executeJavaScript("scroll(0,100);");
					if (uiDriver.getValue(
							"//*[@id='line_splits']/tbody/tr[" + invoiceRow
									+ "]/td[1]").contains(
							"Deferred Rev - Generic")) {
						if (uiDriver.getValue(
								"//*[@id='line_splits']/tbody/tr[" + invoiceRow
										+ "]/td[2]").equals("")) {

							failed("Validating Debit Amount",
									"Validating Debit Amount should be successfull",
									"Debit amount is not Deferred Rev - Generic");
						} else {

							passed("Debit is Deferred Rev - Generic",
									"Debit is Deferred Rev - Generic",
									"Debit amount is Deferred Rev - Generic");

						}

					}

					if (uiDriver.getValue(
							"//*[@id='line_splits']/tbody/tr[" + invoiceRow
									+ "]/td[1]").contains("Bad Debt")) {

						if (uiDriver.getValue(
								"//*[@id='line_splits']/tbody/tr[" + invoiceRow
										+ "]/td[2]").equals("")) {

							failed("Validating Debit Amount",
									"Validating Debit Amount should be successfull",
									"Debit amount is not Bad Debt");

						} else {
							passed("Debit is Deferred Rev - Generic",
									"Debit is Bad Debt",
									"Debit amount is Bad Debt");
						}
					}
					if (uiDriver.getValue(
							"//*[@id='line_splits']/tbody/tr[" + invoiceRow
									+ "]/td[1]").contains("Internal Dom")) {

						if (uiDriver.getValue(
								"//*[@id='line_splits']/tbody/tr[" + invoiceRow
										+ "]/td[2]").equals("")) {

							failed("Validating Debit Amount",
									"Validating Debit Amount should be successfull",
									"Debit amount is not Bad Debt");

						} else {
							passed("Debit is Internal Dom",
									"Debit is Bad Debt",
									"Debit amount is Bad Debt");
						}
					}

					if (uiDriver.getValue(
							"//*[@id='line_splits']/tbody/tr[" + invoiceRow
									+ "]/td[1]").contains("Generic Billed")) {
						if (uiDriver.getValue(
								"//*[@id='line_splits']/tbody/tr[" + invoiceRow
										+ "]/td[3]").equals("")) {
							failed("Validating Credit Amount",
									"Validating Credit Amount should be successfull",
									"Credit amount is not Generic Billed");

						}

						else {
							passed("Debit is Generic Billed",
									"Credit is Generic Billed",
									"Credit amount is Generic Billed");

						}

					}

					if (uiDriver.getValue(
							"//*[@id='line_splits']/tbody/tr[" + invoiceRow
									+ "]/td[1]").contains("Contract revenue")) {
						if (uiDriver.getValue(
								"//*[@id='line_splits']/tbody/tr[" + invoiceRow
										+ "]/td[2]").equals("")) {

							failed("Validating Debit Amount",
									"Validating Credit Amount should be successfull",
									"Credit amount is not Contract revenue");
						}

						else {
							passed("Debit is Contract revenue",
									"Credit is Contract revenue",
									"Credit amount is Contract revenue");

						}
					}

					if (uiDriver.getValue(
							"//*[@id='line_splits']/tbody/tr[" + invoiceRow
									+ "]/td[1]").contains("Bad Debt Revenue")) {
						if (uiDriver.getValue(
								"//*[@id='line_splits']/tbody/tr[" + invoiceRow
										+ "]/td[3]").equals("")) {

							failed("Validating Credit Amount",
									"Validating Credit Amount should be successfull",
									"Credit amount is not Bad Debt Revenue");
						}

						else

						{
							passed("Credit is Generic Billed",
									"Credit is Bad Debt Revenue",
									"Credit amount is Bad Debt Revenue");

						}
					}

					if (uiDriver.getValue(
							"//*[@id='line_splits']/tbody/tr[" + invoiceRow
									+ "]/td[1]").contains("Billed Intl")) {
						if (uiDriver.getValue(
								"//*[@id='line_splits']/tbody/tr[" + invoiceRow
										+ "]/td[3]").equals("")) {

							failed("Validating Credit Amount",
									"Validating Credit Amount should be successfull",
									"Credit amount is not Billed Intl");

						}

						else {
							passed("Debit is Billed Intl",
									"Credit is Billed Intl",
									"Credit amount is Billed Intl");

						}

					}

					if (uiDriver.getValue(
							"//*[@id='line_splits']/tbody/tr[" + invoiceRow
									+ "]/td[1]").contains(
							"Deferred Rev - Unpaid")) {
						if (uiDriver.getValue(
								"//*[@id='line_splits']/tbody/tr[" + invoiceRow
										+ "]/td[3]").equals("")) {

							failed("Validating CREDIT Amount",
									"Validating CREDIT Amount should be successfull",
									"CREDIT amount is not Deferred Rev - Unpaid");

						}

						else {

							passed("CREDIT is Deferred Rev - Unpaid",
									"CREDIT is Deferred Rev - Unpaid",
									"CREDIT amount is Deferred Rev - Unpaid");

						}
					}
					
					if (uiDriver.getValue(
							"//*[@id='line_splits']/tbody/tr[" + invoiceRow
									+ "]/td[1]").contains(
							"HST ON")) {
						if (uiDriver.getValue(
								"//*[@id='line_splits']/tbody/tr[" + invoiceRow
										+ "]/td[3]").equals("")) {

							failed("Validating CREDIT Amount",
									"Validating CREDIT Amount should be successfull",
									"CREDIT amount is not HST ON");

						}

						else {

							passed("CREDIT is HST ON",
									"CREDIT is HST ON",
									"CREDIT amount is HST ON");

						}
					}

					invoiceRow++;
				}

				uiDriver.executeJavaScript("scroll(0,800)");
				SleepUtils.sleep(5);
				uiDriver.click("Back1");
				SleepUtils.sleep(5);
				uiDriver.executeJavaScript("scroll(0,-500)");
				SleepUtils.sleep(5);
			}

			else {
				// do nothindf
			}

		}

	}
	
	
	/****************************************
	 * Name: VerifyInvoiceJournals 
	 * Description:Method to VerifyInvoiceJournals
	 * Date: 29-Jul-2018
	 ****************************************/
	public void VerifyInvoiceJournals(DataRow input, DataRow output)
			throws InterruptedException {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("//*[text()='lated Transactions']");
		SleepUtils.sleep(TimeSlab.HIGH);
		List<WebElement> ele = uiDriver.webDr
				.findElements(By
						.xpath("//*[text()='Transaction']/following::table//td[text()='Journal' or text()='Invoice' or text()='Credit Memo']"));
		int rowSize = ele.size();
		for (int r = 1; r<=rowSize; r++) {
			WebElement w = uiDriver.webDr.findElement(By.xpath("//*[text()='lated Transactions']"));
			String id = w.getAttribute("id");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("scroll(0,-1000)");
		//if(uiDriver.checkElementPresent_dynamic("reclassJEntry")){
		uiDriver.executeJavaScript("document.getElementById('"+id+"').click();");
			//uiDriver.click("reclassJEntry");
			SleepUtils.sleep(2);
			uiDriver.executeJavaScript("scroll(0,1500)");
			String s1 = uiDriver.getDyanmicData("DocNum");
			String s2 = s1.replace("#", Integer.toString(r));
			if (uiDriver.checkElementPresent_dynamic(s2)) {

				SleepUtils.sleep(5);
				uiDriver.click(s2);
				SleepUtils.sleep(5);
				uiDriver.executeJavaScript("scroll(0,800)");
				int invoiceRow = 2;
				int transRows = uiDriver.webDr.findElements(
						By.xpath("//*[@id='line_splits']//tbody/tr")).size();
				for (i = 0; i < transRows - 1; i++) {
					uiDriver.executeJavaScript("scroll(0,100);");
					if (uiDriver.getValue(
							"//*[@id='line_splits']/tbody/tr[" + invoiceRow
									+ "]/td[1]").contains(
							"Deferred Rev - Generic")) {
						if (uiDriver.getValue(
								"//*[@id='line_splits']/tbody/tr[" + invoiceRow
										+ "]/td[2]").equals("")) {

							failed("Validating Debit Amount",
									"Validating Debit Amount should be successfull",
									"Debit amount is not Deferred Rev - Generic");
						} else {

							passed("Debit is Deferred Rev - Generic",
									"Debit is Deferred Rev - Generic",
									"Debit amount is Deferred Rev - Generic");

						}

					}

					if (uiDriver.getValue(
							"//*[@id='line_splits']/tbody/tr[" + invoiceRow
									+ "]/td[1]").contains("Bad Debt")) {

						if (uiDriver.getValue(
								"//*[@id='line_splits']/tbody/tr[" + invoiceRow
										+ "]/td[2]").equals("")) {

							failed("Validating Debit Amount",
									"Validating Debit Amount should be successfull",
									"Debit amount is not Bad Debt");

						} else {
							passed("Debit is Deferred Rev - Generic",
									"Debit is Bad Debt",
									"Debit amount is Bad Debt");
						}
					}
					if (uiDriver.getValue(
							"//*[@id='line_splits']/tbody/tr[" + invoiceRow
									+ "]/td[1]").contains("Internal Dom")) {

						if (uiDriver.getValue(
								"//*[@id='line_splits']/tbody/tr[" + invoiceRow
										+ "]/td[2]").equals("")) {

							failed("Validating Debit Amount",
									"Validating Debit Amount should be successfull",
									"Debit amount is not Bad Debt");

						} else {
							passed("Debit is Internal Dom",
									"Debit is Bad Debt",
									"Debit amount is Bad Debt");
						}
					}

					if (uiDriver.getValue(
							"//*[@id='line_splits']/tbody/tr[" + invoiceRow
									+ "]/td[1]").contains("Generic Billed")) {
						if (uiDriver.getValue(
								"//*[@id='line_splits']/tbody/tr[" + invoiceRow
										+ "]/td[3]").equals("")) {
							failed("Validating Credit Amount",
									"Validating Credit Amount should be successfull",
									"Credit amount is not Generic Billed");

						}

						else {
							passed("Debit is Generic Billed",
									"Credit is Generic Billed",
									"Credit amount is Generic Billed");

						}

					}

					if (uiDriver.getValue(
							"//*[@id='line_splits']/tbody/tr[" + invoiceRow
									+ "]/td[1]").contains("Contract revenue")) {
						if (uiDriver.getValue(
								"//*[@id='line_splits']/tbody/tr[" + invoiceRow
										+ "]/td[2]").equals("")) {

							failed("Validating Debit Amount",
									"Validating Credit Amount should be successfull",
									"Credit amount is not Contract revenue");
						}

						else {
							passed("Debit is Contract revenue",
									"Credit is Contract revenue",
									"Credit amount is Contract revenue");

						}
					}

					if (uiDriver.getValue(
							"//*[@id='line_splits']/tbody/tr[" + invoiceRow
									+ "]/td[1]").contains("Bad Debt Revenue")) {
						if (uiDriver.getValue(
								"//*[@id='line_splits']/tbody/tr[" + invoiceRow
										+ "]/td[3]").equals("")) {

							failed("Validating Credit Amount",
									"Validating Credit Amount should be successfull",
									"Credit amount is not Bad Debt Revenue");
						}

						else

						{
							passed("Credit is Generic Billed",
									"Credit is Bad Debt Revenue",
									"Credit amount is Bad Debt Revenue");

						}
					}

					if (uiDriver.getValue(
							"//*[@id='line_splits']/tbody/tr[" + invoiceRow
									+ "]/td[1]").contains("Billed Intl")) {
						if (uiDriver.getValue(
								"//*[@id='line_splits']/tbody/tr[" + invoiceRow
										+ "]/td[3]").equals("")) {

							failed("Validating Credit Amount",
									"Validating Credit Amount should be successfull",
									"Credit amount is not Billed Intl");

						}

						else {
							passed("Debit is Billed Intl",
									"Credit is Billed Intl",
									"Credit amount is Billed Intl");

						}

					}

					if (uiDriver.getValue(
							"//*[@id='line_splits']/tbody/tr[" + invoiceRow
									+ "]/td[1]").contains(
							"Deferred Rev - Unpaid")) {
						if (uiDriver.getValue(
								"//*[@id='line_splits']/tbody/tr[" + invoiceRow
										+ "]/td[3]").equals("")) {

							failed("Validating CREDIT Amount",
									"Validating CREDIT Amount should be successfull",
									"CREDIT amount is not Deferred Rev - Unpaid");

						}

						else {

							passed("CREDIT is Deferred Rev - Unpaid",
									"CREDIT is Deferred Rev - Unpaid",
									"CREDIT amount is Deferred Rev - Unpaid");

						}
					}
					
					if (uiDriver.getValue(
							"//*[@id='line_splits']/tbody/tr[" + invoiceRow
									+ "]/td[1]").contains(
							"HST ON")) {
						if (uiDriver.getValue(
								"//*[@id='line_splits']/tbody/tr[" + invoiceRow
										+ "]/td[3]").equals("")) {

							failed("Validating CREDIT Amount",
									"Validating CREDIT Amount should be successfull",
									"CREDIT amount is not HST ON");

						}

						else {

							passed("CREDIT is HST ON",
									"CREDIT is HST ON",
									"CREDIT amount is HST ON");

						}
					}

					invoiceRow++;
				}

				uiDriver.executeJavaScript("scroll(0,800)");
				SleepUtils.sleep(5);
				uiDriver.click("Back1");
				SleepUtils.sleep(5);
				uiDriver.executeJavaScript("scroll(0,-500)");
				SleepUtils.sleep(5);
			}

			else {
				// do nothindf
			}

		}

	}

	/****************************************
	 * Name: projectType
	 * Description: projectType 
	 * Date: 11-July-2018
	 ****************************************/
	public void projectType(DataRow input, DataRow output) {
		// new function
		uiDriver.setValue("projecttype", input.get("projecttype"));
		// Time taken to load Report page(end time)
		SleepUtils.sleep(TimeSlab.YIELD);
	}

	/****************************************
	 * Name: project
	 *  Description: project 
	 *  Date: 11-July-2018
	 ****************************************/
	public void project(DataRow input, DataRow output) {
		// new function
		uiDriver.click("project");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("project", input.get("project"));
		SleepUtils.sleep(TimeSlab.YIELD);

	}

	/****************************************
	 * Name: reportsearch 
	 * Description: reportsearch
	 *  Date: 11-July-2018
	 ****************************************/
	public void reportsearch(DataRow input, DataRow output) {

		// start time to load report search page
		uiDriver.click("reportsearch");
		SleepUtils.sleep(TimeSlab.MEDIUM);

	}

	/****************************************
	 * Name: contracts 
	 * Description: contracts
	 *  Date: 11-July-2018
	 ****************************************/
	public void contracts(DataRow input, DataRow output) {
		// end time to load report search page

		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("contracts");
		passed("Report Page", "Time taken to search the report",
				"Successfully searched the report");

	}

	/****************************************
	 * Name: contractSearchOption 
	 * Description: contractSearchOption
	 *  Date: 11-July-2018
	 ****************************************/
	public void contractSearchOption(DataRow input, DataRow output) {
		// start time to load contract search page
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("contractsearchoption");
		SleepUtils.sleep(TimeSlab.YIELD);
		passed("Contract Search Page", "Response time of Contract Search page",
				"Successfully loded the Contract Search page");
	}

	/****************************************
	 * Name: clickcontractSearchDescription 
	 * Description: clickcontractSearchDescription
	 * Date: 11-July-2018
	 ****************************************/
	public void clickcontractSearchDescription(DataRow input, DataRow output) {

		// end time to load contract search page
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("contractsearchdescription");
	}

	/****************************************
	 * Name: contractSearchDescription 
	 * Description: contractSearchDescription
	 * Date: 11-July-2018
	 ****************************************/
	public void contractSearchDescription(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("contractsearchdescription",
				input.get("contractsearchdescription"));
	}

	/****************************************
	 * Name: contactsearch 
	 * Description: contactsearch
	 *  Date: 11-July-2018
	 ****************************************/
	public void contactsearch(DataRow input, DataRow output) { // start time to
																// load search
																// time
																// (contract
																// search)
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("contactsearch");

	}

	/****************************************
	 * Name: contractcard Description: contractcard Date: 11-July-2018
	 ****************************************/

	public void contractcard(DataRow input, DataRow output) { // end time to
																// load search
																// time(contract
																// search)
		SleepUtils.sleep(TimeSlab.LOW);

		SleepUtils.sleep(TimeSlab.LOW);
		// page loadlin time of contract card(start time)
		uiDriver.click("contractcard");
		SleepUtils.sleep(TimeSlab.YIELD);
		passed("Contract Search Page", "Time taken to perform search",
				"Successfully searched the contract");
	}

	/****************************************
	 * Name: contractcarddescription 
	 * Description: contractcarddescription 
	 * Date: 11-July-2018
	 ****************************************/
	public void contractcarddescription(DataRow input, DataRow output) {
		uiDriver.click("contractcarddescription");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("contractcarddescription",
				input.get("contractcarddescription"));
		passed("Contract card Search Page",
				"Response time of Contract Search page",
				"Successfully loded the Contract card Search page");
	}

	/****************************************
	 * Name: contractcardsearch 
	 * Description: contractcardsearch
	 * Date:11-July-2018
	 ****************************************/

	public void contractcardsearch(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("contractcardsearch");

	}

	/****************************************
	 * Name: contractInfo
	 *  Description: contractInfo 
	 *  Date: 11-July-2018
	 ****************************************/

	public void contractInfo(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("contractInfo");
		passed("contract card search page",
				"Time taken to perform contract card search",
				"Successfully searched the contract card");

	}
	
	
	/****************************************
	 * Name: VerifyARMRinvoice
	 * Description: contractFilter
	 *  Date: 11-July-2018
	 ****************************************/
	public void verifyARMRinvoice(DataRow input, DataRow output) {
		// start time to load contract search page
		uiDriver.click("(//a[text()='Invoices'])[1]");
		SleepUtils.sleep(5);
		uiDriver.click("//a[text()='Invoice Search']");
		SleepUtils.sleep(5);
		String armrinvoice=input.get("Armrinvoice");
		uiDriver.setValue("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_InvoiceCenterPanels_i0_i0_ContractCodeEdit']", armrinvoice);
		SleepUtils.sleep(5);
		uiDriver.click("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_InvoiceCenterPanels_i0_i0_SearchButton']");
		SleepUtils.sleep(5);
		uiDriver.executeJavaScript("scroll(0,1000)");
		uiDriver.click("//td[contains(text(),'Royalty Report')]/../td[2]/a");
		String invoicetotal=uiDriver.getValue("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentHeader_InvoiceTotalValueLabel']");
		if(invoicetotal.equalsIgnoreCase(input.get("invoicetotal")))
				{
			passed("Verifying ARMR invoice total",
					"Invoice total should be"+invoicetotal,
					"Invoice total is  "+invoicetotal);
				}
		else
		{
			failed("Verifying ARMR invoice total",
					"Invoice total should be"+invoicetotal,
					"Invoice total is not"+invoicetotal);
		}
		}

	/****************************************
	 * Name: verifyFeecalcinvoice
	 * Description: verifyFeecalcinvoice
	 *  Date: 11-July-2018
	 ****************************************/
	public void verifyFeecalcinvoice(DataRow input, DataRow output) {
		// start time to load contract search page
		uiDriver.click("(//a[text()='Invoices'])[1]");
		SleepUtils.sleep(5);
		uiDriver.click("//a[text()='Invoice Search']");
		SleepUtils.sleep(5);
		String armrinvoice=input.get("Armrinvoice");
		uiDriver.setValue("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_InvoiceCenterPanels_i0_i0_ContractCodeEdit']", armrinvoice);
		SleepUtils.sleep(5);
		uiDriver.click("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_InvoiceCenterPanels_i0_i0_SearchButton']");
		SleepUtils.sleep(5);
		uiDriver.executeJavaScript("scroll(0,1000)");
		SleepUtils.sleep(5);
		String month=uiDriver.getDyanmicData("Month");
		String month1 = month.replace("#", input.get("month"));
		uiDriver.click_dynamic(month1);
		String invoicetotal=uiDriver.getValue("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentHeader_InvoiceTotalValueLabel']");
		if(invoicetotal.equalsIgnoreCase(input.get("invoicetotal")))
				{
			passed("Verifying ARMR invoice total",
					"Invoice total should be"+invoicetotal,
					"Invoice total is  "+invoicetotal);
				}
		else
		{
			failed("Verifying ARMR invoice total",
					"Invoice total should be"+invoicetotal,
					"Invoice total is not"+invoicetotal);
		}
		
		}
	
	/****************************************
	 * Name: contractFilter
	 * Description: contractFilter
	 *  Date: 11-July-2018
	 ****************************************/
	public void contractFilter(DataRow input, DataRow output) {
		// start time to load contract search page
		SleepUtils.sleep(TimeSlab.YIELD);
		String Contract = input.get("contract");
		String ContractNetsuite = Contract;
		String Contract1 = ContractNetsuite + "*";
		String NSContract=ContractNetsuite+"A";
		String ARMRcontract=Contract+"-0";
		uiDriver.setValue("ContractSearch", Contract1);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Search");
		// SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		passed("Contract Search Page", "Response time of Contract Search page",
				"Successfully loded the Contract Search page");
		uiDriver.click("ContractID");
		output.put("ContractId", Contract1);
		output.put("ContractNetSuite", ContractNetsuite);
		output.put("NSContract",NSContract);
		output.put("ARMRcontract",ARMRcontract);

	}
	/****************************************
	 * Name: VerifySubsidiary Description: VerifySubsidiary
	 * Date: 05-March-2019
	 ****************************************/
	public void VerifySubsidiary(DataRow input, DataRow output) {
		uiDriver.click("//a[text()='Information']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//a[text()='Additional Info']");
		if(uiDriver.checkElementPresent("//span[text()='Subsidiary']/../..//td[3]//span[text()='F210']"))
		{
			
				passed("Verify the Subsidiary id F210",
						"Subsidiary should be F210", "Subsidiary should  be F210");
			} else {

				failed("Verify the Subsidiary id F210",
						"Subsidiary should be F210", "Subsidiary should not be F210");

			}	
		}
	
	public void VerifyTAPforpayment(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("document.getElementById('customtxt').click();");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,1000)");
		List<WebElement> lst = uiDriver.webDr.findElements(By.xpath("//tr[@id='recmachcustrecord_nbcu_titleallocpa_paymentrow-10' or @id='recmachcustrecord_nbcu_titleallocpa_paymentrow1']"));
		int rowsize = lst.size();
		if(rowsize>=1)
		{
			
			passed("Verify the TAP records",
					"TAP records should be displayed", "TAP records is displayed");
		} else {

			failed("Verify the TAP records",
					"TAP records should be displayed", "TAP records is not displayed");

		}	
		
		}
		
		
	
	
	/****************************************
	 * Name: VerifyEstimate
	 * Description: VerifyEstimate
	 *  Date: 11-July-2018
	 ****************************************/
	public void ValidateEstimate(DataRow input, DataRow output) {
		// start time to load contract search page
		uiDriver.click("RelatedTransactions");
		SleepUtils.sleep(TimeSlab.LOW);
		String estimate=uiDriver.getDyanmicData("Estimate");
		String salesnum = input.get("conf");
		String mastercontract = salesnum.substring(0, salesnum.length()-1);
		String conf1=mastercontract+"-1A";
		String estimate1=estimate.replace("#", conf1);
		uiDriver.click_dynamic(estimate1);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String validation=input.get("validation");
		if(validation.equalsIgnoreCase("y"))
		{
			uiDriver.executeJavaScript("document.getElementById('custpage_validate_est').click();");
		SleepUtils.sleep(TimeSlab.HIGH);
		String ContractValidation = uiDriver.getValue_Text("ContractValidation");
		if (ContractValidation.contains("This revision is valid for committing")) {

			passed("Validating the estimate",
					"Estimate should be displayed as This revision is valid for committing",
					"ContractValidation is displayed as"+ContractValidation+"");
		} 

		else {
			failed("Validating the estimate",
					"Estimate should be displayed as This revision is valid for committing.",
					"ContractValidation is displayed as"+ContractValidation+"");
		}

		uiDriver.click("OK");
		SleepUtils.sleep(TimeSlab.HIGH);
		}
		else
		{
		
			WebElement email = uiDriver.webDr.findElement(By
					.xpath("//*[@id='custbody_nbcu_transaction_isinactive_fs']/img"));
			String estimatecheckboxvalue = email.getAttribute("alt");
			if (estimatecheckboxvalue.equalsIgnoreCase("checked")) {
				passed("Verify Estimate",
						"Estimate should be committed",

						"Estimate is committed");

			} else {
				failed("Verify Estimate",
						"Estimate should be committed",

						"Estimate is not committed");

			}			
			uiDriver.click("masterestimate");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			String masterestimatestatus = uiDriver.getValue("masterestimatestatus");
			if(masterestimatestatus.equalsIgnoreCase("Committed"))
			{
				passed("verifying the master estimate status",
						"Master Estimate status should be committed",
						"Master Estimate status is committed");
			}
			else
			{
				failed("verifying the master estimate status",
						"Master Estimate status should be committed",
						"Master Estimate status is not committed");
			}
			
			}

	}

	/****************************************
	 * Name: updateFinancestatus Description: updateFinancestatus Date:
	 * 11-July-2018
	 ****************************************/
	public void updateFinancestatus(DataRow input, DataRow output) {

		uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("FinanceSummary");
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.HIGH);
		
		SleepUtils.sleep(TimeSlab.HIGH);
		//uiDriver.refresh();
		//SleepUtils.sleep(TimeSlab.HIGH);
		//uiDriver.refresh();
		//SleepUtils.sleep(TimeSlab.HIGH);
		////uiDriver.refresh();
		String difference = uiDriver.getValue("difference");
		if (difference.equalsIgnoreCase("0.00")) {
			passed("Verify difference field", "Difference should be 0",
					"Difference is 0");
		} else {
			uiDriver.click("updatecontract");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Yes");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("updatecontract");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Yes");
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
		}
		
		String finaldifference = uiDriver.getValue("difference");
		if (finaldifference.equalsIgnoreCase("0.00")) {
			passed("Verify difference field", "Difference should be 0",
					"Difference is 0");
		}
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		
	}

	/****************************************
	 * Name: NavigateToStarCM Description: NavigateToStarCM Date: 11-July-2018
	 ****************************************/
	public void NavigateToStarCM(DataRow input, DataRow output) {
		uiDriver.click("List");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("STARCM");
		passed("FilmTrack CMPage", "FilmTrack CMPage Should be displayed",
				"FilmTrack CMPage is displayed");
		uiDriver.switchToWindow("Welcome to the StarCm - FilmTrack *CM");
		if (uiDriver.checkElementPresent("//*[@id='UserName']")) {
			uiDriver.setValue("//*[@id='UserName']", "206525318");
			uiDriver.setValue("//*[@id='PassWord']", "Pa$$word123");
			uiDriver.click("//*[@id='LoginButton']");
			passed("Login to FilmTrack Application",
					"Should loginto the Application",
					"FilmTrack Application opened sucessfully!");

		} else {

			// do nothing
		}
		uiDriver.setValue("ProjectId", input.get("ProjectId"));
		// SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ProjectIDList");
		// SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("OtherData");
		// SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("OnNetwrkFlg");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String OnNetworkFlag = uiDriver.getValue_Text("OnNetworkFlag");
		SleepUtils.sleep(TimeSlab.LOW);
		if (OnNetworkFlag.equalsIgnoreCase("No")) {

			passed("Verify the OnNetwork Flag",
					"OnNetwork Flag should be unchecked Successfully",
					"OnNetwork Flag is unchecked Successfully");

		} else {
			passed("Verify the OnNetwork Flag",
					"OnNetwork Flag should be unchecked Successfully",
					"OnNetwork Flag is not unchecked Successfully");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContinuousProd");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String ContinuousProduction = uiDriver
				.getValue_Text("ContinuousProduction");
		if (ContinuousProduction.equalsIgnoreCase("Yes")) {

			passed("Verify the ContinuousProduction Flag",
					"ContinuousProduction Flag should be checked Successfully",
					"ContinuousProduction Flag is checked Successfully");

		} else {
			failed("Verify the ContinuousProduction Flag",
					"ContinuousProduction Flag should be checked Successfully",
					"ContinuousProduction Flag is not checked Successfully");

		}
		uiDriver.switchToWindow("Contract - Details");
		SleepUtils.sleep(TimeSlab.LOW);
	}

	/****************************************
	 * Name: NavigateToStarCMAlltitles
	 Description: NavigateToStarCM 
	 Date: 11-July-2018
	 ****************************************/
	public void NavigateToStarCMAlltitles(DataRow input, DataRow output) {
		uiDriver.click("List");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("STARCM");
		passed("FilmTrack CMPage", "FilmTrack CMPage Should be displayed",
				"FilmTrack CMPage is displayed");
		uiDriver.switchToWindow("Welcome to the StarCm - FilmTrack *CM");
		if (uiDriver.checkElementPresent("//*[@id='UserName']")) {
			uiDriver.setValue("//*[@id='UserName']", "206525318");
			uiDriver.setValue("//*[@id='PassWord']", "Pa$$word123");
			uiDriver.click("//*[@id='LoginButton']");
			passed("Login to FilmTrack Application",
					"Should loginto the Application",
					"FilmTrack Application opened sucessfully!");

		} else {

			// do nothing
		}
		uiDriver.setValue("ProjectId", input.get("ProjectId"));
		SleepUtils.sleep(TimeSlab.HIGH);
		
	
		// SleepUtils.sleep(TimeSlab.LOW);
		List<WebElement> titlerow = uiDriver.webDr.findElements(By.xpath("(//table[@class='rgMasterTable rgClipCells'])[2]//tbody/tr"));
		for(int rown=1;rown<=titlerow.size();rown++)
		{
			
			
			String ProjectIDList =uiDriver.getDyanmicData("ProjectIDList");
			String ProjectIDList1 = ProjectIDList.replace("#", Integer.toString(rown));
			uiDriver.click(ProjectIDList1);
			
		// SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("OtherData");
		// SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("OnNetwrkFlg");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String OnNetworkFlag = uiDriver.getValue_Text("OnNetworkFlag");
		//SleepUtils.sleep(TimeSlab.LOW);
		if (OnNetworkFlag.equalsIgnoreCase("Yes")) {

			passed("Verify the OnNetwork Flag",
					"OnNetwork Flag should be checked Successfully",
					"OnNetwork Flag is checked Successfully");

		} else {
			failed("Verify the OnNetwork Flag",
					"OnNetwork Flag should be checked Successfully",
					"OnNetwork Flag is not unchecked Successfully");

		}
		uiDriver.setValue("ProjectId", input.get("ProjectId"));
		 SleepUtils.sleep(TimeSlab.MEDIUM);
		
	}
				
		uiDriver.switchToWindow("Contract - Timeline Items");
		SleepUtils.sleep(TimeSlab.HIGH);
	}
	
	/****************************************
	 * Name: Navigate to Parties Description:Navigate to Parties
	 * Date:11-July-2018
	 ****************************************/
	public void AddMarketCode(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Information");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Additionalinfo");
		passed("Additional Info Page", "PartySearch Page Should be displayed",
				"PartySearch Page is displayed");
		uiDriver.click("Add");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.setValue("Value", "First Run Canada");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Save");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);

	}

	/****************************************
	 * Name: Navigate to Parties Description:Navigate to Parties
	 * Date:11-July-2018
	 ****************************************/
	public void NavigateToParties(DataRow input, DataRow output) {
		uiDriver.click("Parties");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("PartySearch");
		passed("PartySearch Page", "PartySearch Page Should be displayed",
				"PartySearch Page is displayed");
		uiDriver.setValue("LegalName", input.get("Legal Name"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Search");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Customerlink");

	}

	/****************************************
	 * Name: Check Customer Additional information Description:Check Customer
	 * Additional information Date:11-July-2018
	 ****************************************/
	public void CustomerAdditionalInfo(DataRow input, DataRow output) {
		uiDriver.click("Information");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Additionalinfo");
		passed("Info Page", "Info Page Should be displayed",
				"Info Page is displayed");
		uiDriver.click("Customerlink");
		SleepUtils.sleep(TimeSlab.YIELD);
		String intercompany = uiDriver.getValue("Intercompanyvalue");
		if (intercompany.equals(input.get("intercompany"))) {
			passed("Validating Intercompany Flag",
					"Intercompany Flag Should be displayed as '"
							+ input.get("intercompany") + "' successfully",
					"Intercompany Flag is  displayed as '" + intercompany
							+ "' successfully");
		} else {
			failed("Validating Intercompany Flag",
					"Intercompany Flag Should be displayed as '"
							+ input.get("intercompany") + "' successfully",
					"Intercompany Flag is not displayed as '" + intercompany
							+ "' successfully");
		}
	}
	
	
	/****************************************
	 * Name: Check Customer Additional information Description:Check Customer
	 * Additional information Date:11-July-2018
	 ****************************************/
	public void regenerateallocations(DataRow input, DataRow output) {
		uiDriver.click("allocations");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("recalculate");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		
	}

	/****************************************
	 * Name: UpdateDealType Description: UpdateDealType Date: 11-July-2018
	 ****************************************/
	public void UpdateDealType(DataRow input, DataRow output) {
		/*
		 * uiDriver.click("List"); SleepUtils.sleep(TimeSlab.YIELD);
		 * uiDriver.click("Avails"); SleepUtils.sleep(TimeSlab.YIELD);
		 * uiDriver.setValue("ContractSearch", "122758-0");
		 * SleepUtils.sleep(TimeSlab.YIELD); uiDriver.click("Search");
		 * SleepUtils.sleep(TimeSlab.YIELD); uiDriver.click("ContractID");
		 * SleepUtils.sleep(TimeSlab.YIELD);
		 * if(uiDriver.checkElementPresent("ContractDetailsPage")){
		 * 
		 * passed("Verify the ContractDetailsPage",
		 * "ContractDetailsPage should be displayed Successfully",
		 * "ContractDetailsPage is displayed Successfully");
		 * 
		 * } else{ failed("Verify the ContractDetailsPage",
		 * "ContractDetailsPage should be Displayed Successfully",
		 * "ContractDetailsPage is not Displayed Successfully");
		 * 
		 * }
		 */
		uiDriver.click("DealType");
		SleepUtils.sleep(TimeSlab.LOW);
		String DealTypeName = uiDriver.getDyanmicData("DealTypeName");
		String DealName = input.get("DealType");
		String DealTypeName1 = DealTypeName.replace("#", DealName);
		uiDriver.click(DealTypeName1);
		SleepUtils.sleep(TimeSlab.LOW);
		passed("Verify the DealTypeName", "DealTypeName" + DealName
				+ " should be set  Successfully", "DealTypeName" + DealName
				+ " is set  Successfully");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Save");
		SleepUtils.sleep(TimeSlab.HIGH);

	}

	public void validateprojectdetails(DataRow input, DataRow output)
			throws InterruptedException {
		uiDriver.executeJavaScript("scroll(0,-1000)");
		uiDriver.click("projectdetails");
		SleepUtils.sleep(TimeSlab.YIELD);
		String expallocationname = input.get("AllocationRule");
		String numofbillschedules = input.get("numbill");
		int num = Integer.parseInt(numofbillschedules);
		for (int i = 1; i <= num; i++) {
			String actallocationname = uiDriver.getValue("allocationrule");
			if (actallocationname.equalsIgnoreCase(expallocationname)) {
				passed("verify allocation rule in project details",

				"Allocation rules should be" + expallocationname + "",

				"Allocation rules is" + actallocationname + "");
			}

			uiDriver.click("next");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			//SleepUtils.sleep(TimeSlab.HIGH);
		}

	}

	public void AddFMV(DataRow input, DataRow output)
			throws InterruptedException {
		uiDriver.click("Edit");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.setValue("Title", "Q3969|BASTILLE DAY");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("ApplyFilters");
		SleepUtils.sleep(TimeSlab.HIGH);
		List<WebElement> chkboxes = uiDriver.webDr.findElements(By.xpath("//img[@class=\"checkboximage\"]"));
		for(WebElement w:chkboxes)
		{
			w.click();
		}
		//uiDriver.click("checkbox");
		//SleepUtils.sleep(TimeSlab.YIELD);
		//uiDriver.setValue("productOwner", "TH");
		
		List<WebElement> productowner = uiDriver.webDr.findElements(By.xpath("//input[@class='inputreq uir-custom-field']"));
		for(WebElement w:productowner)
		{
			w.clear();
			w.sendKeys("TH");
		}
		
		List<WebElement> fmv = uiDriver.webDr.findElements(By.xpath("//input[contains(@name,'fmv')  and contains(@id,'fmv')]"));
		for(WebElement w:fmv)
		{
			w.clear();
			w.sendKeys("C");
		}
		
		
		//SleepUtils.sleep(TimeSlab.YIELD);
		//uiDriver.setValue("fmv", "C");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("movedown");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Save");
		SleepUtils.sleep(TimeSlab.HIGH);

	}

	public void GeneratepartialInvoice(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Invoices");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("BulkOperations");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("GenerateInvoices");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Filter");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("searchinput");
		String ContractId = input.get("contractId");
		uiDriver.setValue("searchinput", input.get("contractId"));
		// uiDriver.setValue("searchinput", "123178");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//*[@id=\"advancedSearchButton\"]");
		//uiDriver.sendKey("enter");
		//uiDriver.sendKey("enter");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("sortdate");	
		SleepUtils.sleep(TimeSlab.MEDIUM);
	uiDriver.click("grid");
	SleepUtils.sleep(TimeSlab.MEDIUM);
		String ContractNum = uiDriver.getDyanmicData("Contractnum");
		SleepUtils.sleep(TimeSlab.YIELD);
		String ContractNumber = ContractNum.replace("#", ContractId);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		List<WebElement> ele = uiDriver.webDr.findElements(By
				.xpath(ContractNumber));
		SleepUtils.sleep(TimeSlab.MEDIUM);
		int rowSize = Integer.parseInt(input.get("numtobebilled"));
		
		for (int b=0;b<rowSize;b++) {
			/*
			 * String RevenuechkBox = uiDriver.getDyanmicData("RevenueChkBox");
			 * String Revenuechkbox1=RevenuechkBox.replace("$",revenuenum);
			 * String RevchkBox = Revenuechkbox1.replace("#",
			 * Integer.toString(i)); if
			 * (uiDriver.checkElementPresent_dynamic(RevchkBox)) {
			 * 
			 * uiDriver.click_dynamic(RevchkBox); } else { // do nothing }
			 */
			SleepUtils.sleep(TimeSlab.MEDIUM);
			ele.get(b).click();
			
			SleepUtils.sleep(TimeSlab.MEDIUM);

		}

		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.executeJavaScript("scroll(0,-1000)");
		uiDriver.click("Createinvoice");
		SleepUtils.sleep(TimeSlab.LOW);
		String invoicenum = uiDriver.getValue("InvoiceID");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("InvoiceID");
		SleepUtils.sleep(TimeSlab.YIELD);
		
		
		passed("Verify the Invoice",
				"Invoice should be displayed successfully",
				"Invoice is displayed successfully");
		output.put("Invoice", invoicenum);

	}
	
	/****************************************
	 * Name:ValidatethefieldsinFT 
	 * Description: Validating the fields in FT 
	 * Date: 09-August-2019
	 ****************************************/
	
	
	public void ValidatethefieldsinFT(DataRow input, DataRow output) {

        String contractid=uiDriver.getValue("contractid");
        
        String contractid1=contractid;
        String dealtype=uiDriver.getValue("dealtype");

        String licensee=uiDriver.getValue("licensee");

        String amount=uiDriver.getValue("amount");

        String currency=uiDriver.getValue("currency");

        String Rights=uiDriver.getValue("rights");

        String Titlestatus=uiDriver.getValue("titlestatus");

       
        if(contractid1.contains(contractid))

        {

               passed("Verifying the  Contractid",

                            "Contract id Status should be displayed as "+input.get("contractid")+"'"

                                          ,

                            "Contract id Status is displayed as "+contractid1);

        }

        else

        {

               failed("Verifying the  Contractid",

                            "Contract id Status should be displayed as "+input.get("contractid")+"'"

                                          ,

                            "Contract id Status is not displayed as "+contractid);

        }

       

        if(dealtype.contains(input.get("dealtype")))

        {

               passed("Verifying the  dealtype",

                            "dealtype should be displayed as "+input.get("dealtype")+"'"

                                          ,

                            "dealtype is displayed as "+dealtype);

        }

        else

        {

               failed("Verifying the  dealtype",

                            "dealtype should be displayed as "+input.get("dealtype")+"'"

                                          ,

                            "dealtype is not displayed as "+dealtype);

        }

       

       

        if(licensee.contains(input.get("licensee")))

        {

               passed("Verifying the  licensee",

                            "licensee should be displayed as "+input.get("licensee")+"'"

                                          ,

                            "licensee is displayed as "+licensee);

        }

        else

        {

               failed("Verifying the  licensee",

                            "licensee should be displayed as "+input.get("licensee")+"'"

                                          ,

                            "licensee is not displayed as "+licensee);

        }

       

       

        if(amount.contains(input.get("amount")))

        {

               passed("Verifying the  amount",

                            "amount should be displayed as "+input.get("amount")+"'"

                                          ,

                            "amount is displayed as "+amount);

        }

        else

        {

               failed("Verifying the  amount",

                            "Contract id Status should be displayed as "+input.get("amount")+"'"

                                          ,

                            "Contract id Status is not displayed as "+amount);

        }

       

        if(currency.contains(input.get("currency")))

        {

               passed("Verifying the  currency",

                            "currency should be displayed as "+input.get("currency")+"'"

                                          ,

                            "currency is displayed as "+currency);

        }

        else

        {

               failed("Verifying the  currency",

                            "currency should be displayed as "+input.get("currency")+"'"

                                          ,

                            "currency is not displayed as "+currency);

        }

       

        if(Rights.contains(input.get("Rights")))

        {

               passed("Verifying the  Rights",

                            "Rights should be displayed as "+input.get("Rights")+"'"

                                          ,

                            "Rights is displayed as "+Rights);

        }

        else

        {

               failed("Verifying the  Rights",

                            "Rights should be displayed as "+input.get("Rights")+"'"

                                          ,

                            "Rights is displayed as "+Rights);

        }

       

        if(Titlestatus.equalsIgnoreCase(input.get("Titlestatus")))

        {

               passed("Verifying the  Titlestatus",

                            "title status should be displayed as "+input.get("Titlestatus")+"'"

                                          ,

                            "title status is displayed as "+Titlestatus);

        }

        else

        {

               failed("Verifying the  Titlestatus",

                            "Contract id Status should be displayed as "+input.get("Titlestatus")+"'"

                                          ,

                            "Contract id Status is  displayed as "+Titlestatus);

        }

   }

	/****************************************
	 * Name: NaviagteToBillingSchedule Description: NaviagteToBillingSchedule
	 * Date: 11-July-2018
	 ****************************************/
	public void Multibilling(DataRow input, DataRow output) {
		uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billing");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billingschedules");
		SleepUtils.sleep(TimeSlab.HIGH);
		String accRows1 = input.get("num");
		SleepUtils.sleep(TimeSlab.YIELD);

		int accRows = Integer.parseInt(accRows1);
		
		String pages=uiDriver.getValue("//*[@id=\"contract-billing-schedules-grid\"]/div[5]/ul/li[2]/span");
		

		if (pages.contains("1")) {
			passed("Billing Schedule displayed ",
					"No. of Billing Schedule Should be displayed as" + accRows
							+ "", "No. of Billing Schedule is displayed"
							+ accRows + "");
		} else {
			failed("Billing Schedule not displayed",
					"Billing Schedule Should be displayed",
					"Billing Schedule is not displayed");
		}
		String actualproject = uiDriver.getValue("project");
		String actualamount = uiDriver.getValue("Amount");
		String actualduedate = uiDriver.getValue("DueDate");
		if (input.get("projects").contains(actualproject)
				|| actualproject.contains(input.get("projects"))) {
			passed("Validating Project", "Project Should be displayed as '"
					+ input.get("projects") + "' successfully",
					"Project is  displayed as '" + actualproject
							+ "' successfully");
		} 

		if (input.get("Amount").contains(actualamount)) {
			passed("Validating Amount", "Amount Should be displayed as '"
					+ input.get("Amount") + "' successfully",
					"Amount is  displayed as '" + actualamount
							+ "' successfully");
		} 
		if (input.get("DueDate").contains(actualduedate)) {
			passed("Validating Due Date", "Due Date Should be displayed as '"
					+ input.get("DueDate") + "' successfully",
					"Due Date is  displayed as '" + actualduedate
							+ "' successfully");
		} 

		output.put("num", accRows1);
	}
	
	/****************************************
	 * Name:verifymultiplebillingscheduleFT 
	 * Description: verifymultiplebillingscheduleFT
	 * Date: 16-Aug-2019
	 ****************************************/
	
	
	
	public void verifymultiplebillingscheduleFT(DataRow input, DataRow output)

            throws InterruptedException {

//     uiDriver.executeJavaScript("scroll(0,1000)");
//
//     uiDriver.click("//*[@id='contract-billing-schedules-grid']/div[5]/span[1]/span/span");
//
//     SleepUtils.sleep(5);
//
//      uiDriver.click("(//*[@class='k-item'])[1]");//li[text()='All']

		uiDriver.click("//span[@class='k-dropdown-wrap k-state-default']");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//li[text()='All']"); 
		SleepUtils.sleep(TimeSlab.LOW);

     

      String amount=input.get("Amount");

     String Amount[]=amount.split(";");

    

      String duedate=input.get("Duedate");

     String Duedate[]=duedate.split(";");

     String projects=input.get("proj");

     String Project[]=projects.split(";");

    

      for(int i=0;i<Project.length;i++)

     {

            String actualproject=uiDriver.getValue("//table[@role='treegrid']//p[contains(text(),'"+Project[i]+"')]/../..//td[count(//*[@role='grid']//a[text()='Projects']/../preceding-sibling::*)+1]");

            String expproject=Project[i];

           

              if(actualproject.contains(expproject)){



               passed("Validate Project Details",



                           " project should be displayed in Line items "+expproject,



                          "project is displayed in Line items"+expproject);



              }

              else {

                    failed("Validate Project Details",



                                  " project should be displayed in Line items "+expproject,



                                 "project is not displayed in Line items"+expproject);

                    

               }

             

              

             String actualamount=uiDriver.getValue("//table[@role='treegrid']//p[contains(text(),'"+Project[i]+"')]/../..//td[count(//*[@role='grid']//a[text()='Amount']/../preceding-sibling::*)+1]");

            String expamount=Amount[i];

           

              if(actualamount.replace(",", "").contains(expamount)){



               passed("Validate Amount Details",



                           " Amount should be displayed in Line items "+expamount,



                          "Amount is displayed in Line items"+expamount);



              }

              else {

                    failed("Validate Amount Details",



                                  " Amount should be displayed in Line items "+expamount,



                                 "Amount is not displayed in Line items"+expamount);

                    

               }

             

              

             String actualdate=uiDriver.getValue("//table[@role='treegrid']//p[contains(text(),'"+Project[i]+"')]/../..//td[count(//*[@role='grid']//a[text()='Due Date']/../preceding-sibling::*)+1]");

            String expdate=Duedate[i];

           

              if(actualdate.contains(actualdate)){



               passed("Validate Date Details",



                           " Date should be displayed in Line items "+expdate,



                          "Date is displayed in Line items"+expdate);



              }

              else {

                    failed("Validate Amount Details",



                                  " Amount should be displayed in Line items "+expdate,



                                 "Amount is not displayed in Line items"+expdate);

                    

               }

           

      }

    

     

}

	/****************************************
	 * Name:NavigatetoContractDetailPage Description:Navigate to Contract
	 * Date:11-July-2018
	 ****************************************/
	public void NavigatetoContractDetailPage(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Contracts");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("SearchContract");
		uiDriver.setValue("ContractSearch", input.get("contract"));
		SleepUtils.sleep(TimeSlab.LOW);
		passed("Contracts info", "Contracts info Should be displayed",
				"Contracts info is displayed");
		uiDriver.click("Search");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("ContractID");
		// SleepUtils.sleep(TimeSlab.HIGH);
		//SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		//SleepUtils.sleep(TimeSlab.MEDIUM);
		if (uiDriver.checkPage("Contract - Details")) {

			passed("Verify the ContractDetailsPage",
					"ContractDetailsPage should be displayed Successfully",
					"ContractDetailsPage is displayed Successfully");

		} else {
			failed("Verify the ContractDetailsPage",
					"ContractDetailsPage should be displayed Successfully",
					"ContractDetailsPage is not displayed Successfully");

		}

	}

	/****************************************
	 * Name: ChangeStatusToProcessContract Description:
	 * ChangeStatusToProcessContract Date: 11-July-2018
	 ****************************************/
	public void ChangeStatusToProcessContract(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("StatusChange");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//*[@id=\"ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_WorkflowStateChangeCtrl_NextWorkflowStatesList_Arrow\"]");
		SleepUtils.sleep(TimeSlab.YIELD);
		String StatusInput = uiDriver.getDyanmicData("Status");
		String Status = StatusInput.replace("#", input.get("Status"));
		String CurrentStatus = uiDriver.getValueByText(Status);
		uiDriver.click_dynamic(Status);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.handleAlert("", "OK");
		SleepUtils.sleep(TimeSlab.HIGH);
		//SleepUtils.sleep(TimeSlab.HIGH);
		//SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		if (input.get("Status").equalsIgnoreCase(CurrentStatus)) {

			passed("Verify the Status " + CurrentStatus + " ",
					"Status should be Clicked Successfully as" + CurrentStatus
							+ "", "Status is Clicked Successfully as"
							+ CurrentStatus + "");
		} else {

			failed("Verify the Status " + CurrentStatus + "",
					"Status should be Clicked Successfully as" + CurrentStatus
							+ "", "Status is not Clicked Successfully as"
							+ CurrentStatus + "");

		}
	}
	
	/****************************************
	 * Name: GenerateBillingShedule
	 * Description: GenerateBillingShedule
	 * Date: 05-March-2019
	 ****************************************/
		public void GeneratetwoBillingShedules(DataRow input, DataRow output){
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("Finance");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("Billing");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("Billingschedules");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("GenerateSchedule");
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Scheduleitem");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("Manualbyamount");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//*[@id='AllocationRuleDropDownWrapper']/span[1]/span/span[2]/span");
			SleepUtils.sleep(TimeSlab.LOW);
			//uiDriver.setValue("AllocationRule", input.get("allocationname"));
			
			uiDriver.click("Next");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("Add");
			SleepUtils.sleep(TimeSlab.LOW);
			WebElement w = uiDriver.webDr.findElement(By.xpath("(//tr[@role='row'])[2]"));
			new Actions(uiDriver.webDr).moveToElement(w).build().perform();
			SleepUtils.sleep(TimeSlab.MEDIUM);
			WebElement w1 = uiDriver.webDr.findElement(By.xpath("(//tr[@role='row'])[2]/td[4]"));
			new Actions(uiDriver.webDr).moveToElement(w1).build().perform();
			System.out.println("moved to amount field");
			SleepUtils.sleep(TimeSlab.MEDIUM);
		((JavascriptExecutor)uiDriver.webDr).executeScript("arguments[0].click();",w1);
			
			System.out.println("clicked on amount field");
			String Amount=input.get("amount");
			 uiDriver.setText(Amount);
			
			uiDriver.click("Duedate");
			uiDriver.setValue("Duedate1",input.get("date"));
			
			uiDriver.click("Savechanges");
			uiDriver.click("Add");
			SleepUtils.sleep(TimeSlab.LOW);
			WebElement w2 = uiDriver.webDr.findElement(By.xpath("(//tr[@role='row'])[2]"));
			new Actions(uiDriver.webDr).moveToElement(w2).build().perform();
			SleepUtils.sleep(TimeSlab.MEDIUM);
			WebElement w3 = uiDriver.webDr.findElement(By.xpath("(//tr[@role='row'])[2]/td[4]"));
			new Actions(uiDriver.webDr).moveToElement(w3).build().perform();
			System.out.println("moved to amount field");
			SleepUtils.sleep(TimeSlab.MEDIUM);
		((JavascriptExecutor)uiDriver.webDr).executeScript("arguments[0].click();",w3);
			
			System.out.println("clicked on amount field");
			String Amount1=input.get("amount");
			
           uiDriver.setText(Amount1);
			
			uiDriver.click("Duedate");
			uiDriver.setValue("Duedate1",input.get("date1"));
			
			uiDriver.click("Savechanges");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("Next");
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);	
			
			uiDriver.click("//*[@id=\"projectsTree\"]/div[3]/span[2]/span/span/span[1]");
			SleepUtils.sleep(2);
		uiDriver.click("//div[@class='k-list-scroller']//ul[@aria-hidden='false']//li[text()='40']");
			SleepUtils.sleep(TimeSlab.LOW);
			 List<WebElement> lst = uiDriver.webDr.findElements(By.xpath("(//table[@role='grid']/tbody)[2]/tr/td[3]"));
			int rows= lst.size();
			for(int r=1;r<=rows;r++)
			{
				
				SleepUtils.sleep(TimeSlab.LOW);
				
				String amount=uiDriver.getValue("(//table[@role='grid']/tbody)[2]/tr["+r+"]/td[3]//input");
				SleepUtils.sleep(TimeSlab.LOW);
				//SleepUtils.sleep(TimeSlab.HIGH);
				
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.click_dynamic("(//table[@role='grid']/tbody)[2]/tr["+r+"]/td[6]/div[1]/div/input");
				SleepUtils.sleep(TimeSlab.LOW);
				WebElement z = uiDriver.webDr.findElement(By.xpath("(//table[@role='grid']/tbody)[2]/tr["+r+"]/td[6]/div[1]/div/input"));
				z.sendKeys(Keys.chord(Keys.CONTROL,"a"));
				z.sendKeys(Keys.DELETE);
				SleepUtils.sleep(TimeSlab.LOW);
				if(r!=21)
				{
				uiDriver.setValue("(//table[@role='grid']/tbody)[2]/tr["+r+"]/td[6]/div[1]/div/input", amount);
				}
				else
				{
				
					uiDriver.setValue("(//table[@role='grid']/tbody)[2]/tr["+r+"]/td[6]/div[1]/div/input", "406000.00");
				}
				if(r!=20)
				{
				WebElement chkbox = uiDriver.webDr.findElement(By.xpath("(//table[@role='grid']/tbody)[2]/tr["+r+"]/td[1]//input"));
				((JavascriptExecutor)uiDriver.webDr).executeScript("arguments[0].click();", chkbox);
				}
				if(r>10)
				{
					uiDriver.executeJavaScript("scroll(0,500)");
				}
				
			}
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("//*[@id='next']");
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
			Actions action = new Actions(uiDriver.webDr);
			WebElement ele = uiDriver.webDr.findElement(By
					.xpath("//*[@id='stepTerritories']/div[2]/div/div[1]/div/span[2]/span/input[1]"));
			action.sendKeys("ele", "").build().perform();
			SleepUtils.sleep(TimeSlab.LOW);
			action.sendKeys(ele, "100.00").build().perform();
	
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("//span[contains(text(),'China (CHN)')]/../..//td[1]/input");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Spread");
			SleepUtils.sleep(TimeSlab.HIGH);
			
			uiDriver.click("Next");
			SleepUtils.sleep(TimeSlab.HIGH);
			
			SleepUtils.sleep(TimeSlab.HIGH);
			WebElement ele1 = uiDriver.webDr.findElement(By
					.xpath("//*[@id='stepRights']/div[2]/div/div[1]/div/span[2]/span/input[1]"));
			action.sendKeys(ele1, "").build().perform();
			SleepUtils.sleep(TimeSlab.LOW);
			action.sendKeys(ele1, "100.00").build().perform();
		
			uiDriver.click("//span[contains(text(),'VOD')]/../..//td[1]/input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//div[@class='rights allocation-toolbar']//button[text()='Spread']");
			SleepUtils.sleep(TimeSlab.LOW);			
			
			
			uiDriver.click("Finish");
			SleepUtils.sleep(TimeSlab.HIGH);	
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
			
			
		}
		
		/****************************************
		 * Name: GenerateBillingSheduleNZL
		 * Description: GenerateBillingSheduleNZL
		 * Date: 05-March-2019
		 * @throws AWTException 
		 ****************************************/
			public void GenerateBillingSheduleNZL(DataRow input, DataRow output) throws AWTException{
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.click("Finance");
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.click("Billing");
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.click("Billingschedules");
				SleepUtils.sleep(TimeSlab.HIGH);
				uiDriver.click("GenerateSchedule");
				SleepUtils.sleep(TimeSlab.HIGH);
				SleepUtils.sleep(TimeSlab.HIGH);							
				uiDriver.click("Itemby");
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.click("UsingFeeCalculations");
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.click("Nextbutton");
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.click("Aggregatedropdown");
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.click("Average");
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.click("Evaluationdropdown");
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.click("Statementfirst");
				SleepUtils.sleep(TimeSlab.YIELD);
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.click("ReallocationMethod");
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.click("ReallocationNone");
				SleepUtils.sleep(TimeSlab.YIELD);
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.click("DaysThreshold");
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.click("DaysThresholdValue");
				SleepUtils.sleep(TimeSlab.YIELD);
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.click("Add");
				SleepUtils.sleep(TimeSlab.MEDIUM);
				
				uiDriver.click("//*[@id='feeCalcsGrid']/div[3]/table/tbody/tr/td[1]/span[1]/span/span[1]");
				SleepUtils.sleep(TimeSlab.MEDIUM);
				uiDriver.click("//li[text()='Statement']");
				SleepUtils.sleep(TimeSlab.MEDIUM);
				
				uiDriver.click("//*[text()='Billing Group End Date']");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.click("//*[text()='Billing Group End Date']");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.click("//*[text()='Earliest License Start']");
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.click("Savechanges");
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.click("//button[text()='Next']");
				SleepUtils.sleep(TimeSlab.YIELD);
				
				SleepUtils.sleep(TimeSlab.YIELD);
				//uiDriver.click("Nextbutton");
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.click("//div[@id='manualGrid']/div[1]/a[1]");
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.click("//*[@id='manualGrid']/div[1]/a[2]");
				SleepUtils.sleep(TimeSlab.YIELD);				
				uiDriver.click("//*[@id='next']");
				SleepUtils.sleep(TimeSlab.HIGH);
				SleepUtils.sleep(TimeSlab.HIGH);
				
				uiDriver.executeJavaScript("scroll(0,1000)");
				uiDriver.click("//*[@id='projectsTree']/div[3]/span[2]/span/span/..");
				SleepUtils.sleep(TimeSlab.LOW);
				
			uiDriver.click("//li[text()='100']");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.executeJavaScript("scroll(0,-1000)");
			uiDriver.click("//input[@class='check-all']");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.executeJavaScript("scroll(0,1000)");
			uiDriver.click("//*[@id='next']");
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
			String s = uiDriver.getValue("//*[@id='territoriesGrid']/div[2]/table/tbody/tr/td[5]/div[1]/div/input");
			if(s.contains("100.00"))
			{
				passed("NZL Territory Info", "100% should be assigned to NZL.",
						"100% is  assigned to NZL.");
			}
			else
			{
				failed("NZL Territory Info", "100% should be assigned to NZL.",
						"100% is  not assigned to NZL.");
			}
			
			uiDriver.click("//*[@id='next']");
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
			String s1 = uiDriver.getValue("//*[@id='rightsGrid']/div[2]/table/tbody/tr[1]/td[5]/div[1]/div/input");
			if(s1.contains("100.00"))
			{
				passed("Paytv Rights Info", "100% should be assigned to Pay TV.",
						"100% is  assigned to Pay TV.");
			}
			else
			{
				failed("Pay TV Territory Info", "100% should be assigned to Pay TV.",
						"100% is  not assigned to Paytv.");
			}
			uiDriver.click("Finish");	
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
				}
			/****************************************
			 * Name: Validate title licensefee
			 * Description: Validate title licensefee
			 * Date: 05-March-2019
			 * @throws AWTException 
			 ****************************************/
		       public void Validatetitlelicensefee(DataRow input, DataRow output) 
		       {
		        
		        SleepUtils.sleep(TimeSlab.HIGH);
		        uiDriver.click("(//*[@id=\"custbody_nbcu_so_master_fs_lbl_uir_label\"]/../..//a)[2]");
		        SleepUtils.sleep(TimeSlab.HIGH);
		        uiDriver.click("//div[text()='Document Number']/../../../following-sibling::tbody/tr/td[3]/a");
		        SleepUtils.sleep(TimeSlab.HIGH);
		        uiDriver.executeJavaScript("scroll(0,400)");
		        SleepUtils.sleep(TimeSlab.LOW);
		        List<WebElement> fil = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']/tbody/tr"));
		int filter = fil.size();
		for(int i=2;i<=filter;i++)
		{
		String title=uiDriver.getValueByText("//table[@id='item_splits']/tbody/tr["+i+"]/td[5]");
		String amount=uiDriver.getValueByText("//table[@id='item_splits']/tbody/tr["+i+"]/td[17]");
		String Territory=uiDriver.getValueByText("//table[@id='item_splits']/tbody/tr["+i+"]/td[11]");
		String Subtype=uiDriver.getValueByText("//table[@id='item_splits']/tbody/tr["+i+"]/td[3]");
		String PRODUCTTYPE=uiDriver.getValueByText("//table[@id='item_splits']/tbody/tr["+i+"]/td[8]");
		String Marketcode=uiDriver.getValueByText("//table[@id='item_splits']/tbody/tr["+i+"]/td[13]");
		String Right=uiDriver.getValueByText("//table[@id='item_splits']/tbody/tr["+i+"]/td[12]");
		passed("Validate Title license fee", "For title "+title+" "
		+ ",Amount should be "+amount+" Territory should be "+Territory+" Subtype should be "+Subtype+" PRODUCTTYPE should be "+PRODUCTTYPE+" Marketcode should be "+Marketcode+
		" Right should be "+Right,
		"For title "+title+" "
		+ ",Amount is  "+amount+" Territory is "+Territory+" Subtype  is "+Subtype+" PRODUCTTYPE is "+PRODUCTTYPE+" Marketcode is "+Marketcode+
		" Right is"+Right);
		}
		       }


			
			/****************************************
			 * Name: VerifyFeecalcSalesorder
			 * Description: VerifyFeecalcSalesorder
			 * Date: 10-May-2019
			****************************************/ 

			public void VerifyFeecalcSalesorder(DataRow input, DataRow output) throws InterruptedException
			{
				if(uiDriver.checkElementPresent("Placeholder"))
				{
					passed("Verify Placeholder Line item", "Item should be placeholder",
							"Item is placeholder");
				}
				else
				{
					failed("Verify Placeholder Line item", "Item should be placeholder",
							"Item is not placeholder");
				}
				
				uiDriver.click("Custom");
				
				if(uiDriver.checkElementPresent("Sotype"))
				{
					passed("Verify So Type", "So Type should be Usage",
							"So Type is Usage");
				}
				else
				{
					failed("Verify So Type", "So Type should be Usage",
							"So Type is not Usage");
				}
			}


			/****************************************
			 * Name: AddDateTrigger
			 * Description: AddDateTrigger
			 * Date: 7-May-2019
			 ****************************************/
			public void AddDateTrigger(DataRow input, DataRow output)
					throws InterruptedException {
					uiDriver.click("//*[@id='contract-billing-schedules-grid']/div[3]/table/tbody/tr[2]/td[14]/div/a");
					SleepUtils.sleep(TimeSlab.MEDIUM);
					uiDriver.setFrame("//iframe[contains(@src,'DueDate')]");
					SleepUtils.sleep(TimeSlab.MEDIUM);
					uiDriver.click("//*[@id='dt-control-wrap']/div[1]/div[2]/span/span/span[1]");
					SleepUtils.sleep(TimeSlab.LOW);
					uiDriver.click("//li[text()='License Start Date']");
					SleepUtils.sleep(TimeSlab.LOW);
					String days=input.get("days");
					uiDriver.sendKey("tab");
					SleepUtils.sleep(TimeSlab.LOW);
					uiDriver.sendKey("tab");
					WebElement w = uiDriver.webDr.findElement(By.xpath("//*[@id='requiredByKendo']"));
					w.click();
					w.clear();
					uiDriver.setText(days);
					//((JavascriptExecutor)uiDriver.webDr).executeScript("args[0].value=30", w);
					//uiDriver.setValue("//*[@id='requiredByKendo']",days);
					SleepUtils.sleep(TimeSlab.MEDIUM);
					uiDriver.click("//*[@id='calculation-params']/div/div[2]/div[2]/span/span/span[1]");
					SleepUtils.sleep(TimeSlab.LOW);
					uiDriver.click("//li[text()='Last Day of Month']");
					SleepUtils.sleep(TimeSlab.LOW);
					uiDriver.click("//button[text()='Save']");
					uiDriver.resetFrame();
					
					
			
			}
			/****************************************
			 * Name: VerifyStatmentTemplate
			 * Description: VerifyStatmentTemplate
			 * Date: 7-May-2019
			 ****************************************/
			public void VerifyStatmentTemplate(DataRow input, DataRow output)
					throws InterruptedException {
				
				uiDriver.click("Maintenance");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.click("FinanceAccounting");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.click("Feecalculation");
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.click("Statementtemplate");
				SleepUtils.sleep(TimeSlab.HIGH);
				if(uiDriver.checkElementPresent("Skynewzealand"))
				{
					passed("verify skynewzealand template is present","skynewzealand template should be present","skynewzealand template should be present");
				}
				uiDriver.click("FinanceAccounting");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.click("Feecalculation");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.click("//a[text()='Statement Input Categories']");
				SleepUtils.sleep(TimeSlab.HIGH);
				if(uiDriver.checkElementPresent("Subscribers"))
				{
					passed("verify subscribers is present","subscribers should be present","subscribers is  present");
				}
				
			}
		/****************************************
		 * Name: SyncfromFinancialSummary
		 * Description: SyncfromFinancialSummary
		 * Date: 24-Mar-2018
		 ****************************************/
		public void SyncfromFinancialSummary(DataRow input, DataRow output)
				throws InterruptedException {
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("//ul[@id=\"ft-context-menu\"]/li/a[text()='Finance']");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//a[text()='Financial Summary']");
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("//*[text()='Sync From Schedule Items']");
			 SleepUtils.sleep(TimeSlab.LOW);
			 uiDriver.click("//*[text()='Are you sure you want to update Amounts from schedule items?']//following::button[2]");
			 SleepUtils.sleep(TimeSlab.HIGH);
				SleepUtils.sleep(TimeSlab.HIGH);
				SleepUtils.sleep(TimeSlab.HIGH);
				SleepUtils.sleep(TimeSlab.HIGH);
            uiDriver.click("//button[text()='Update Contract Total']");
            SleepUtils.sleep(TimeSlab.LOW);
            SleepUtils.sleep(TimeSlab.LOW);
            SleepUtils.sleep(TimeSlab.HIGH);
            SleepUtils.sleep(TimeSlab.HIGH);
            uiDriver.click("//*[text()='Are you sure you want to update the contract total?']//following::button[2]");
            SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
            String ContractTotal=uiDriver.getValue_Text("//label[text()='Contract Total:']/../span");  
            if(ContractTotal.contains(input.get("contracttotal"))||input.get("contracttotal").contains(ContractTotal))
            {
            	passed("Verify the Contract total" + ContractTotal + " ",
    					"Contract total should be " + input.get("contracttotal")
    							+ "", "Contract total is"
    							+ ContractTotal + "");
            }
            else
            {
            	failed("Verify the Contract total" + ContractTotal + " ",
    					"Contract total should be " + input.get("contracttotal")
    							+ "", "Contract total is not "
    							+ ContractTotal + "");
            }
           
            String AllocationsTotal=uiDriver.getValue_Text("//label[text()='Allocations Total:']/../span");  
            if(AllocationsTotal.contains(input.get("alloctotal"))||input.get("alloctotal").contains(AllocationsTotal))
            {
            	passed("Verify the Allocations total" + AllocationsTotal + " ",
    					"Allocations total should be " + input.get("alloctotal")
    							+ "", "Allocations total is"
    							+ AllocationsTotal + "");
            }
            else
            {
            	failed("Verify the Allocations total" + AllocationsTotal + " ",
    					"Allocations total should be " + input.get("alloctotal")
    							+ "", "Allocations total is not "
    							+ AllocationsTotal + "");
            }

            
            String Difference=uiDriver.getValue_Text("//label[text()='Difference:']/../span");  
            if(Difference.contains(input.get("diff"))||input.get("diff").contains(Difference))
            {
            	passed("Verify the Difference" + Difference + " ",
    					"Difference should be " + input.get("diff")
    							+ "", "Difference is"
    							+ Difference + "");
            }
            else
            {
            	failed("Verify the Difference" + Difference + " ",
    					"Difference should be " + input.get("diff")
    							+ "", "Difference is not "
    							+ Difference + "");
            }
			
		
		
		}
	/****************************************
	 * Name: EditDefaultAllocationPTV
	 * Description: EditDefaultAllocationPTV
	 * Date: 11-July-2018
	 ****************************************/
	public void EditDefaultAllocationVOD(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.click("Editicon");
		SleepUtils.sleep(5);
		String Name = input.get("Name");
		uiDriver.setValue("Name", Name);
		uiDriver.setValue("Note", input.get("Note"));

		uiDriver.click("InvoiceItemCategory");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("InvoiceItemCategoryInput");
		SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("InvoiceItemCurrency");
		// uiDriver.click("InvoiceItemCurrencyInput");
		Boolean Result = uiDriver.webDr.findElement(
				By.id("TerritoriesCheckbox")).isSelected();
		if (Result.equals(false)) {

			uiDriver.click("Territories");
		} else {
			// do nothing
		}

		Boolean RightResult = uiDriver.webDr.findElement(
				By.id("RightsCheckbox")).isSelected();
		if (RightResult.equals(false)) {

			uiDriver.click("Rights");
		} else {
			// do nothing
		}
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		// uiDriver.executeJavaScript("document.getElementsByClassName('k-formatted-value k-input')[0].value=100;");
		Actions action = new Actions(uiDriver.webDr);
		WebElement ele = uiDriver.webDr.findElement(By
				.xpath("//*[@id='allocationWidget']/div/span/span/input[1]"));
		action.sendKeys("ele", "").build().perform();
		action.sendKeys(ele, "100.00").build().perform();
		// uiDriver.click("IncreaseArrow");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("NameChkBox");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.HIGH);
		// SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("NameChkBox");
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		List<WebElement> lis = uiDriver.webDr.findElements(By.xpath("//input[@value='50.00000000']"));
		for(int k=0;k<lis.size();k++)
		{
			WebElement w = lis.get(k);
			w.clear();
			//w.sendKeys("100.00");
			//action.sendKeys(w,"").build().perform();
			//action.sendKeys(w,"0.00").build().perform();
		}
		SleepUtils.sleep(TimeSlab.HIGH);
	
			uiDriver.click("//span[text()='VOD']/../..//td[1]/input");
	
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Finish");
		SleepUtils.sleep(TimeSlab.HIGH);
		output.put("Name", Name);

	}
	
	/****************************************
	 * Name: EditDefaultAllocationCHINA
	 * Description: EditDefaultAllocationCHINA
	 * Date: 11-July-2018
	 ****************************************/
	public void EditDefaultAllocationCHINA(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.click("Editicon");
		SleepUtils.sleep(5);
		String Name = input.get("Name");
		uiDriver.setValue("Name", Name);
		uiDriver.setValue("Note", input.get("Note"));

		uiDriver.click("InvoiceItemCategory");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("InvoiceItemCategoryInput");
		SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("InvoiceItemCurrency");
		// uiDriver.click("InvoiceItemCurrencyInput");
		Boolean Result = uiDriver.webDr.findElement(
				By.id("TerritoriesCheckbox")).isSelected();
		if (Result.equals(false)) {

			uiDriver.click("Territories");
		} else {
			// do nothing
		}

		Boolean RightResult = uiDriver.webDr.findElement(
				By.id("RightsCheckbox")).isSelected();
		if (RightResult.equals(false)) {

			uiDriver.click("Rights");
		} else {
			// do nothing
		}
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		// uiDriver.executeJavaScript("document.getElementsByClassName('k-formatted-value k-input')[0].value=100;");
		Actions action = new Actions(uiDriver.webDr);
		WebElement ele = uiDriver.webDr.findElement(By
				.xpath("//*[@id='allocationWidget']/div/span/span/input[1]"));
		action.sendKeys("ele", "").build().perform();
		action.sendKeys(ele, "100.00").build().perform();
		// uiDriver.click("IncreaseArrow");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("NameChkBox");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		// SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("NameChkBox");
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		
		SleepUtils.sleep(TimeSlab.HIGH);
	
			uiDriver.click("//span[text()='VOD']/../..//td[1]/input");
	
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Finish");
		SleepUtils.sleep(TimeSlab.HIGH);
		output.put("Name", Name);

	}
	
	/****************************************
	 * Name: verifyNoBillingSchedule
	 * Description: verifyNoBillingSchedule
	 * Date: 30-Apr-2019
	 ****************************************/
	public void verifyNoBillingSchedule(DataRow input, DataRow output) 
	{

	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("Finance");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("Billing");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("Billingschedules");
	SleepUtils.sleep(TimeSlab.HIGH);
	String billingschedule=input.get("text");
	String billingdisplayed=uiDriver.getValue_Text("Displayedtext");
	if(billingschedule.equals(billingdisplayed))
	{
	passed("Verify the billingschedule", "There is "+billingdisplayed,
	"Billingschedule is "+billingdisplayed);
	}
	else
	{
	failed("Verify the billingschedule", "There is "+billingdisplayed,
	"Billingschedule is "+billingdisplayed);

	}
	SleepUtils.sleep(TimeSlab.HIGH);
	}

	
	
	/****************************************
	 * Name: AddnewrecordinBillinggroup
	 * Description: AddnewrecordinBillinggroup
	 * Date: 30-Apr-2019
	 ****************************************/
	public void AddnewrecordinBillinggroup(DataRow input, DataRow output) 
	{

	SleepUtils.sleep(TimeSlab.LOW);
	uiDriver.click("Finance");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("Billing");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("BillingGroups");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("Addnewrecord");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.setValue("Name", "Default");
	SleepUtils.sleep(TimeSlab.YIELD);
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("Select");
	SleepUtils.sleep(TimeSlab.YIELD);	
	uiDriver.click("Manual");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.setValue("Startdate",input.get("startdate"));
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.setValue("Enddate",input.get("enddate"));
	SleepUtils.sleep(TimeSlab.YIELD);
    uiDriver.click("Save");
    SleepUtils.sleep(TimeSlab.YIELD);
    uiDriver.click("Return");
	
	}

	
	/****************************************
	 * Name: AddAllocationNZ
	 * Description: AddAllocationNZ
	 * Date: 11-July-2018
	 ****************************************/
	public void AddAllocationNZ(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.click("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_AllocationRulesGrid_ctl00_ctl02_ctl00_AddAllocationRuleLinkButton']");
		SleepUtils.sleep(5);
		String Name = input.get("Name");
		uiDriver.setValue("Name", Name);
		uiDriver.setValue("Note", input.get("Note"));

		uiDriver.click("InvoiceItemCategory");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("InvoiceItemCategoryInput");
		SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("InvoiceItemCurrency");
		// uiDriver.click("InvoiceItemCurrencyInput");
		Boolean Result = uiDriver.webDr.findElement(
				By.id("TerritoriesCheckbox")).isSelected();
		if (Result.equals(false)) {

			uiDriver.click("Territories");
		} else {
			// do nothing
		}

		Boolean RightResult = uiDriver.webDr.findElement(
				By.id("RightsCheckbox")).isSelected();
		if (RightResult.equals(false)) {

			uiDriver.click("Rights");
		} else {
			// do nothing
		}
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		// uiDriver.executeJavaScript("document.getElementsByClassName('k-formatted-value k-input')[0].value=100;");
		Actions action = new Actions(uiDriver.webDr);
		WebElement ele = uiDriver.webDr.findElement(By
				.xpath("//*[@id='allocationWidget']/div/span/span/input[1]"));
		action.sendKeys("ele", "").build().perform();
		action.sendKeys(ele, "100.00").build().perform();
		// uiDriver.click("IncreaseArrow");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("NameChkBox");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		// SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("NameChkBox");
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		
		SleepUtils.sleep(TimeSlab.HIGH);
	
			uiDriver.click("//span[text()='Pay TV']/../..//td[1]/input");
	
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Finish");
		SleepUtils.sleep(TimeSlab.HIGH);
		output.put("Name", Name);

	}
	
	
	
	/****************************************
     * Name: AddCard
     * Description: AddCard
     * Date: 11-July-2018
     ****************************************/
     
     public void AddCardChina(DataRow input, DataRow output) throws InterruptedException 
     { 
            
            uiDriver.click("//a[text()='Add Card']");
            SleepUtils.sleep(TimeSlab.HIGH);
            SleepUtils.sleep(TimeSlab.HIGH);
            uiDriver.click("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_ContractCardEdit1_ProjectAssignmentGrid_ctl00_ctl02_ctl00_AddProjectRecordImage']");
            SleepUtils.sleep(TimeSlab.HIGH);
            uiDriver.setFrame("//iframe[@name='ProjectSelectionWindow']");
            SleepUtils.sleep(TimeSlab.HIGH);
            uiDriver.setValue("//input[@id='NameTxt']", input.get("ProjectName"));
            //uiDriver.setValue("ProjectName",input.get("ProjectName"));
            SleepUtils.sleep(TimeSlab.HIGH);
            SleepUtils.sleep(TimeSlab.HIGH);
            uiDriver.click("//*[@id='MultiProjectSelectTree']/div[2]/div/ul/li/div/span[1]/input");
            SleepUtils.sleep(TimeSlab.LOW);
            uiDriver.click("//button[text()='Add Selected �']");
            SleepUtils.sleep(TimeSlab.HIGH);
            uiDriver.click("//*[@id='ctl00_MainContent_FinishButton']");
            SleepUtils.sleep(TimeSlab.HIGH);
            SleepUtils.sleep(TimeSlab.LOW);
            uiDriver.resetFrame();
            uiDriver.click("//span[text()='Add/Update']");
            SleepUtils.sleep(TimeSlab.HIGH);
            SleepUtils.sleep(TimeSlab.HIGH);
            uiDriver.setFrame("//*[@id='RadWindowWrapper_ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_ContractCardEdit1_TerritorySelectionWindow']/table/tbody/tr[2]/td[2]/iframe");
            SleepUtils.sleep(TimeSlab.LOW);
            uiDriver.click("//*[@id='ctl00_MainContent_TerritorySelectionControl_TerritoryTree']/ul/li[29]/div/span[2]");
            SleepUtils.sleep(TimeSlab.HIGH);
            uiDriver.click("//*[@id='ctl00_MainContent_TerritorySelectionControl_TerritoryTree']/ul/li[29]/ul/li[3]/div/span[2]");
            SleepUtils.sleep(TimeSlab.HIGH);
            uiDriver.click("//span[text()='China (CHN)']/../..//input");
            SleepUtils.sleep(TimeSlab.HIGH);
            uiDriver.click("//*[@id='ctl00_MainContent_TerritorySelectionControl_AddButton']");
            SleepUtils.sleep(TimeSlab.HIGH);
            uiDriver.click("//*[@id='ctl00_MainContent_OkButton']");
            SleepUtils.sleep(TimeSlab.HIGH);
            uiDriver.resetFrame();
            uiDriver.click("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_ContractCardEdit1_RightGroupAssignmentGrid_ctl00_ctl02_ctl00_AddRightLinkButton']/div[1]");
            SleepUtils.sleep(TimeSlab.HIGH);
            uiDriver.setFrame("//iframe[@name='RightSelectionWindow']");
            uiDriver.click("//span[text()='VOD']/../../label/input");
            SleepUtils.sleep(TimeSlab.HIGH);
            uiDriver.click("//*[@id='ctl00_MainContent_RightSelectionControl_AddButton']");
            SleepUtils.sleep(TimeSlab.HIGH);
            uiDriver.setValue("//*[@id='ctl00_MainContent_StartDateEdit_dateInput']", "12/31/2050");
            SleepUtils.sleep(TimeSlab.LOW);
            uiDriver.setValue("//*[@id='ctl00_MainContent_EndDateEdit_dateInput']", "12/31/2050");
            SleepUtils.sleep(TimeSlab.LOW);
            uiDriver.click("//*[@id='ctl00_MainContent_IsStartDateEst']");
            SleepUtils.sleep(TimeSlab.LOW);
            uiDriver.click("//*[@id='ctl00_MainContent_IsEndDateEst']");
            SleepUtils.sleep(TimeSlab.LOW);
            uiDriver.click("//*[@id='ctl00_MainContent_OkButton']");
            SleepUtils.sleep(TimeSlab.HIGH);
            uiDriver.resetFrame();
            uiDriver.click("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_ContractCardEdit1_LicenseTypeEdit_Arrow']");
            SleepUtils.sleep(TimeSlab.HIGH);
            
            uiDriver.click("//li[text()='Non-Exclusive']");
            SleepUtils.sleep(TimeSlab.HIGH);
            uiDriver.click("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_ContractCardEdit1_SaveButton']");
            SleepUtils.sleep(TimeSlab.HIGH);
     }             


	/****************************************
	 * Name: VerifyContractDetails
	 * Description: VerifyEstimateReason 
	 * Date: 26-Sept-2018
    ****************************************/	
	public void VerifyContractDetails(DataRow input, DataRow output)
	{
		SleepUtils.sleep(TimeSlab.LOW);
		String ActualdealType = uiDriver.getValue("dealType");
		if (input.get("ContractType").equalsIgnoreCase(ActualdealType)) {

			passed("Verifying the Contract Type",
					"Contract Type  "+ input.get("ContractType")+ "  should be displayed successfully",
					"Contract Type is displayed successfully"+  ActualdealType + "");
		} else {
			failed("Verifying the Contract Type",
					"Contract Type  "+ input.get("ContractType")+ "  should be displayed successfully",
					"Contract Type is not displayed successfully"+  ActualdealType + "");
		}
		
		String ActualcontractName = uiDriver.getValue("contractName");
		if (input.get("ExpcontractName").equalsIgnoreCase(ActualcontractName)) {

			passed("Verifying the Contract Name",
					"Contract Name  "+ input.get("ExpcontractName")+ "  should be displayed successfully",
					"Contract Name is displayed successfully"+  ActualcontractName + "");
		} else {
			failed("Verifying the Contract Name",
					"Contract Name  "+ input.get("ExpcontractName")+ "  should be displayed successfully",
					"Contract Name is not displayed successfully"+  ActualcontractName + "");
		}
		
		String ActualLicensor = uiDriver.getValue("Licensor");
		if (input.get("ExpLicensor").equalsIgnoreCase(ActualLicensor)) {

			passed("Verifying the Licensor",
					"Licensor  "+ input.get("ExpLicensor")+ "  should be displayed successfully",
					"Licensor is displayed successfully"+  ActualLicensor + "");
		} else {
			failed("Verifying the Licensor",
					"Licensor  "+ input.get("ExpLicensor")+ "  should be displayed successfully",
					"Licensor is not displayed successfully"+  ActualLicensor + "");
		}
		
		String ActualLicensee = uiDriver.getValue("Licensee");
		if (input.get("ExpLicensee").equalsIgnoreCase(ActualLicensee)) {

			passed("Verifying the Licensee",
					"Licensee  "+ input.get("ExpLicensee")+ "  should be displayed successfully",
					"Licensee is displayed successfully"+  ActualLicensee + "");
		} else {
			failed("Verifying the Licensee",
					"Licensee  "+ input.get("ExpLicensee")+ "  should be displayed successfully",
					"Licensee is not displayed successfully"+  ActualLicensee + "");
		}
		
		String ActualAmount = uiDriver.getValue("Amount");
		if (input.get("ExpAmount").equalsIgnoreCase(ActualAmount)) {

			passed("Verifying the Amount",
					"Amount  "+ input.get("ExpAmount")+ "  should be displayed successfully",
					"Amount is displayed successfully"+  ActualAmount + "");
		} else {
			failed("Verifying the Amount",
					"Amount  "+ input.get("ExpAmount")+ "  should be displayed successfully",
					"Amount is not displayed successfully"+  ActualAmount + "");
		}
		
		String ActualcurrencyType = uiDriver.getValue("currencyType");
		if (input.get("ExpcurrencyType").equalsIgnoreCase(ActualcurrencyType)) {

			passed("Verifying the currency Type",
					"currency Type  "+ input.get("ExpcurrencyType")+ "  should be displayed successfully",
					"currency Type is displayed successfully"+  ActualcurrencyType + "");
		} else {
			failed("Verifying the currency Type",
					"currency Type  "+ input.get("ExpcurrencyType")+ "  should be displayed successfully",
					"currency Type is not displayed successfully"+  ActualcurrencyType + "");
		}
		
	}
	/****************************************
	 * Name: VerifyNewlyGeneratedCustomerCredit Description:
	 * VerifyNewlyGeneratedCustomerCredit Date: 31-October-2018
	 ****************************************/
	public void VerifyNewlyGeneratedCustomerCredit(DataRow input, DataRow output) {

		uiDriver.click("RelatedRecords");
		SleepUtils.sleep(TimeSlab.YIELD);
		String RevenueArrangement = uiDriver.getValueByText("RevenueArrangement");
		passed("Verify the Status " + RevenueArrangement + " ",
				"RevenueArrangement is displayed as" + RevenueArrangement
						+ "", "Newly Generated Customer Credit is Successfully displayed as"
						+ RevenueArrangement + "");
		
	}
	
	/****************************************
	 * Name: Update Deal Type Description:Update Deal Type Date:11-July-2018
	 ****************************************/
	public void UpdateDealType1(DataRow input, DataRow output) {

		uiDriver.setValue("DealType", input.get("DealType"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("SaveDeal");
	}

	/****************************************
	 * Name: Billing Schedule Description:Billing Schedule Date:11-July-2018
	 ****************************************/
	public void BillingSchedule(DataRow input, DataRow output) {

		uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billing");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billingschedules");
	}

	
	/****************************************
	 * Name: Add Default1 Allocationrole Description: NavigateToAllocationRules
	 * Date: 11-July-2018
	 ****************************************/
	public void AddDefault1(DataRow input, DataRow output) {
		uiDriver.click("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_AllocationRulesGrid_ctl00_ctl02_ctl00_AddAllocationRuleLinkButton']");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("//*[@id='AllocationRuleName']", "Default-1");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//*[@id='finish']");
		SleepUtils.sleep(TimeSlab.HIGH);
		
	}
	
	
	/****************************************
	 * Name: Add Default2 Allocationrole Description: NavigateToAllocationRules
	 * Date: 11-July-2018
	 ****************************************/
	public void AddDefault2(DataRow input, DataRow output) {
		uiDriver.click("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_AllocationRulesGrid_ctl00_ctl02_ctl00_AddAllocationRuleLinkButton']");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("//*[@id='AllocationRuleName']", "Default-2");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//*[@id='finish']");
		SleepUtils.sleep(TimeSlab.HIGH);
		
	}
	
	/****************************************
	 * Name: NavigateToAllocationRules Description: NavigateToAllocationRules
	 * Date: 11-July-2018
	 ****************************************/
	public void NavigateToAllocationRules(DataRow input, DataRow output) {
		String test = input.get("numbill");
		uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("AllocationRule");
		SleepUtils.sleep(TimeSlab.YIELD);
	}

	/****************************************
	 * Name: updateSubsidiary Description: updateSubsidiary
	 * Date: 3-July-2019
	 ****************************************/
	public void updateSubsidiary(DataRow input, DataRow output) {
		String subsidiary = input.get("subsidiary");
		uiDriver.click("//a[text()='Information']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//a[text()='Additional Info']");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("//span[text()='Subsidiary']/../..//input[@title='Edit']");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.setValue("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_OtherDataAttributeValueGrid_ctl00_ctl17_EditFormControl_ValueStringEdit']",subsidiary );
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_OtherDataAttributeValueGrid_ctl00_ctl17_EditFormControl_SaveButton']");
		SleepUtils.sleep(TimeSlab.MEDIUM);
	}
	
	
	/****************************************
	 * Name: RefireDatetrigger Description: RefireDatetrigger
	 * Date: 3-July-2019
	 ****************************************/
	public void RefireDatetrigger(DataRow input, DataRow output) {
		uiDriver.click("//div[@id='ft-context-nav']//li/a[contains(text(),'Finance')]");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//a[text()='Billing']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//a[text()='Billing Schedules']");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("//a[contains(text(),'Re-Fire Date Triggers')]");
		SleepUtils.sleep(TimeSlab.LOW);
	}
	

	/****************************************
	 * Name: VerifyBillingpreference Description: VerifyBillingpreference
	 * Date: 3-July-2019
	 ****************************************/
	public void VerifyBillingpreference(DataRow input, DataRow output) {
		String customer = input.get("customer");
		String billingtype=input.get("Billingtype");
		String subsidiary=input.get("subsidiary");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("//*[@id='_searchstring']", customer);
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//a[contains(text(),'Customer')]/span");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//a[text()='references']");
		switch(billingtype)
		{
		case "fedex":
		WebElement w = uiDriver.webDr.findElement(By.xpath("//span[@id='custentity_nbcu_fedex_fs']/img"));
		String fedexchecked = w.getAttribute("alt");
		if(fedexchecked.equalsIgnoreCase("checked"))
		{
			passed("Verifying the Billing Preference",
					"Billing preference should be"+billingtype,
					"Billing preference is"+billingtype);
			break;
		}
		else
		{
			failed("Verifying the Billing Preference",
					"Billing preference should be"+billingtype,
					"Billing preference is not"+billingtype);
			break;
		}
		case "post":
			WebElement w1 = uiDriver.webDr.findElement(By.xpath("//span[@id='custentity_nbcu_post_fs']/img"));
			String postchecked = w1.getAttribute("alt");
			if(postchecked.equalsIgnoreCase("checked"))
			{
				passed("Verifying the Billing Preference",
						"Billing preference should be"+billingtype,
						"Billing preference is"+billingtype);
				break;
			}
			else
			{
				failed("Verifying the Billing Preference",
						"Billing preference should be"+billingtype,
						"Billing preference is not"+billingtype);
				break;
			}
			default:
				break;
				
				
				
		}
		
		String ActualSubsidiary = uiDriver.getValue_Text("//span[@id='subsidiary_lbl_uir_label']/following-sibling::*/span");	
		if(ActualSubsidiary.contains(subsidiary))
		{
			passed("Verifying the Subsidiary",
					"Subsidiary should be"+subsidiary,
					"Subsidiary should is"+subsidiary);
		}
		else
		{
			failed("Verifying the Subsidiary",
					"Subsidiary should be"+subsidiary,
					"Subsidiary should is"+subsidiary);
		}
		
	}
	
	
	/****************************************
	 * Name: AddAllocationRules Description: AddAllocationRules Date:
	 * 11-July-2018
	 ****************************************/
	public void AddAllocationRules(DataRow input, DataRow output) {
		uiDriver.click("AddAllocationButton");
		String Name = input.get("Name");
		uiDriver.setValue("Name", Name);
		uiDriver.setValue("Note", input.get("Note"));
		uiDriver.click("InvoiceItemCategory");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("InvoiceItemCategoryInput");
		SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("InvoiceItemCurrency");
		// uiDriver.click("InvoiceItemCurrencyInput");
		uiDriver.click("Territories");
		uiDriver.click("Rights");
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.executeJavaScript("document.getElementsByClassName('k-formatted-value k-input')[0].value=100;");
		Actions action = new Actions(uiDriver.webDr);
		WebElement ele = uiDriver.webDr.findElement(By
				.xpath("//*[@id='allocationWidget']/div/span/span/input[1]"));
		action.sendKeys("ele", "").build().perform();
		action.sendKeys(ele, "100.00").build().perform();
		// uiDriver.click("IncreaseArrow");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("NameChkBox");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.YIELD);
		// SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("NameChkBox");
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("NameChkBoxNext");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Finish");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		output.put("Name", Name);

	}

	/****************************************
	 * Name: AddAllocationRulesTerritory Description: AddAllocationRules Date:
	 * 12-November-2018
	 ****************************************/
	public void AddAllocationRulesTerritory(DataRow input, DataRow output) {
		uiDriver.click("AddAllocationButton");
		String Name = input.get("Name");
		uiDriver.setValue("Name", Name);
		uiDriver.setValue("Note", input.get("Note"));
		uiDriver.click("InvoiceItemCategory");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("InvoiceItemCategoryInput");
		SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("InvoiceItemCurrency");
		// uiDriver.click("InvoiceItemCurrencyInput");
		uiDriver.click("Territories");
		uiDriver.click("Rights");
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		// uiDriver.executeJavaScript("document.getElementsByClassName('k-formatted-value k-input')[0].value=100;");
		Actions action = new Actions(uiDriver.webDr);
		WebElement ele = uiDriver.webDr.findElement(By
				.xpath("//*[@id='allocationWidget']/div/span/span/input[1]"));
		action.sendKeys("ele", "").build().perform();
		action.sendKeys(ele, "100.00").build().perform();
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("GBR");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("NameChkBoxNext");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Finish");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		output.put("Name", Name);

	}
	
	/****************************************
	 * Name: AllocationRuleAssignedToBillingSchedule Description:
	 * AllocationRuleAssignedToBillingSchedule Date: 11-July-2018
	 ****************************************/
	public void AllocationRuleAssignedToBillingSchedule(DataRow input,
			DataRow output) {
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Edit");
		uiDriver.executeJavaScript("scroll(900,0)");
		uiDriver.setValue("AllocationRule", input.get("AllocationRule"));
		Boolean Result = uiDriver.webDr.findElement(
				By.id("TerritoriesCheckbox")).isSelected();
		if (Result.equals(false)) {
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.executeJavaScript("document.getElementById('TerritoriesCheckbox').click();");
		} else {
			// do nothing
		}

		Boolean RightResult = uiDriver.webDr.findElement(
				By.id("RightsCheckbox")).isSelected();
		if (RightResult.equals(false)) {

			uiDriver.click("Rights");
		} else {
			// do nothing
		}
		uiDriver.click("Next");
		//uiDriver.click("Next");
		/*Boolean Result1 = uiDriver.webDr.findElement(
				By.id("TerritoriesCheckbox")).isSelected();
		if (Result1.equals(false)) {

			uiDriver.click("Territories");
		} else {
			// do nothing
		}

		Boolean RightResult1 = uiDriver.webDr.findElement(
				By.id("RightsCheckbox")).isSelected();
		if (RightResult1.equals(false)) {

			uiDriver.click("Rights");
		} else {
			// do nothing
		}*/
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		Actions action = new Actions(uiDriver.webDr);
		WebElement ele = uiDriver.webDr.findElement(By
				.xpath("//*[@id='allocationWidget']/div/span/span/input[1]"));
		action.sendKeys("ele", "").build().perform();
		String amount = uiDriver.getValue("Amountfield");
		action.sendKeys(ele, amount).build().perform();
		uiDriver.click("SelectChkBox");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Spread");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("SelectChkBoxes");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Finish");
		SleepUtils.sleep(TimeSlab.HIGH);

	}

	/****************************************
	 * Name: VerifyCustomerbillingpreference Description:
	 * AllocationRuleAssignedToBillingSchedule Date: 13-August-2018
	 ****************************************/
	public void VerifyRevplaneachlineitem(DataRow input, DataRow output) {
		List<WebElement> lst = uiDriver.webDr.findElements(By.xpath("//table[@id='revenueelement_splits']/tbody/tr[contains(@class,'uir-machine-row')]"));
		 int scrol=100;
		for(int a=2;a<=10;a++)
		{
			SleepUtils.sleep(TimeSlab.MEDIUM);
			if(a>8){
			//uiDriver.executeJavaScript("scroll(0,1500)");
		}
			uiDriver.click("//table[@id='revenueelement_splits']/tbody/tr["+a+"]/td[1]/a");
			SleepUtils.sleep(5);
			String ItemType = uiDriver.getValue_Text("//a[text()='Item']/../../../span[2]/span");
			String revenuestatus=uiDriver.getValue_Text("//a[text()='Revenue Plan Status']/../../../span[2]/span");
			if(ItemType.equalsIgnoreCase("Title"))
					{
				if(revenuestatus.equalsIgnoreCase("Completed"))
				{
					passed("Verify the revenue status" + revenuestatus + " ",
	    					"revenue status should be " + revenuestatus
	    							+ "", "revenue status is"
	    							+ revenuestatus + "");
	            }
	            else
	            {
	            	failed("Verify the revenue status" + revenuestatus + " ",
	    					"revenue status should be " + revenuestatus
							+ "", "revenue status is not"
							+ revenuestatus + "");
				}
					}
			if(ItemType.equalsIgnoreCase("PTMG Estimate"))
			{
		if(revenuestatus.equalsIgnoreCase("Not Started"))
		{
			passed("Verify the revenue status" + revenuestatus + " ",
					"revenue status should be " + revenuestatus
							+ "", "revenue status is"
							+ revenuestatus + "");
        }
        else
        {
        	failed("Verify the revenue status" + revenuestatus + " ",
					"revenue status should be " + revenuestatus
					+ "", "revenue status is not"
					+ revenuestatus + "");
		}
			}
			
			uiDriver.back();
			  uiDriver.executeJavaScript("scroll(0,"+(scrol*a)+")");
			  
			  if (a == 10) 
				   break;

		}
		
	}
	
	
	/****************************************
	 * Name: updateairdatefortitle Description:
	 * updateairdatefortitle Date: 26-june-2019
	 ****************************************/
	public void updateairdatefortitle(DataRow input, DataRow output) {
		uiDriver.setValue("Search", input.get("title"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Titlelink");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("edit");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.setValue("airdate", input.get("airdate"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Save");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.handleAlert("", "OK");
		SleepUtils.sleep(TimeSlab.HIGH);
	}
	
	/****************************************
	 * Name: verifyupdatedRRmethod Description:
	 * verifyupdatedRRmethod Date: 26-june-2019
	 ****************************************/
	public void verifyupdatedRRmethod(DataRow input, DataRow output) {
		List<WebElement> lst = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tr[contains(@class,'machine') and not(contains(@class,'header'))]"));
		
		for(int i=1;i<=lst.size();i++)
		{
		
			
			String rrmethod=uiDriver.getValueByText("(//table[@id='item_splits']//tr[contains(@class,'machine') and not(contains(@class,'header'))])["+i+"]//td[count(//table[@id='item_splits']//td/div[contains(text(),'Meth')]/../preceding-sibling::*)");
			String rrstartdate=uiDriver.getValueByText("(//table[@id='item_splits']//tr[contains(@class,'machine') and not(contains(@class,'header'))])["+i+"]//td[count(//table[@id='item_splits']//td/div[contains(text(),'Start')]/../preceding-sibling::*)");
			String rrenddate=uiDriver.getValueByText("(//table[@id='item_splits']//tr[contains(@class,'machine') and not(contains(@class,'header'))])["+i+"]//td[count(//table[@id='item_splits']//td/div[contains(text(),'End')]/../preceding-sibling::*)");
			
			if (rrmethod.equals(input.get("rrmethod"))) {

				passed("Verify the revrecmethod",
						"revrecmethod Should be displayed" +rrmethod+"",
						"ContractNum is displayed Successfully"+rrmethod+"");

			} else {
				failed("Verify the ContractNum",
						"ContractNum Should be displayed Successfully"+rrmethod+"",
						"ContractNum is not displayed Successfully"+rrmethod+"");

			}
			
			
			if (rrstartdate.equals(input.get("rrstartdate"))) {

				passed("Verify the revrecmethod",
						"revrecmethod Should be displayed" +rrstartdate+"",
						"ContractNum is displayed Successfully"+rrstartdate+"");

			} else {
				failed("Verify the ContractNum",
						"ContractNum Should be displayed Successfully"+rrstartdate+"",
						"ContractNum is not displayed Successfully"+rrstartdate+"");

			}
			
			
			
			if (rrenddate.equals(input.get("rrenddate"))) {

				passed("Verify the revrecmethod",
						"revrecmethod Should be displayed" +rrenddate+"",
						"ContractNum is displayed Successfully"+rrenddate+"");

			} else {
				failed("Verify the ContractNum",
						"ContractNum Should be displayed Successfully"+rrenddate+"",
						"ContractNum is not displayed Successfully"+rrenddate+"");

			}
		}
	}
	
	
	/****************************************
	 * Name: VerifyCustomerbillingpreference Description:
	 * AllocationRuleAssignedToBillingSchedule Date: 13-August-2018
	 ****************************************/
	public void VerifyCustomerbilling(DataRow input, DataRow output) {
		String cust = input.get("customer");
		uiDriver.setValue("SearchCust", cust);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Customer");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("preferences");
		// String
		// emailcheckbox=uiDriver.getValueCheckBox("(//a[text()='Email'])[2]/../../..//img");
		WebElement email = uiDriver.webDr.findElement(By
				.xpath("//*[@id='custentity_nbcu_email_fs']/img"));
		String emailcheckboxvalue = email.getAttribute("alt");
		if (emailcheckboxvalue.equalsIgnoreCase("checked")) {
			passed("Verify Customer delivery preference",
					"Delivery preference Should be set to email",

					"Delivery preference is set to email");

		} else {
			failed("Verify Customer delivery preference",
					"Delivery preference Should be set to email",

					"Delivery preference is not set to email");

		}
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("custom");
		// String
		// eastcoastcheckbox=uiDriver.getValueCheckBox("//a[text()='East Coast']/../../..//img");
		WebElement eastcoastcheckbox = uiDriver.webDr.findElement(By
				.xpath("(//a[text()='Email'])[2]/../../..//img"));
		String eastcoastcheckboxvalue = eastcoastcheckbox.getAttribute("alt");
		if (eastcoastcheckboxvalue.equalsIgnoreCase("checked")) {
			passed("Verify East coast check box is checked",
					"East coast Should be set to checked",

					"East coast is set to checked");

		} else {
			failed("Verify East coast check box is checked",
					"East coast Should be set to checked",

					"East coast is not set to checked");

		}

	}

	/****************************************
	 * Name: ValidatetheContractNumInNetSuite Description:
	 * ValidatetheContractNumInNetSuite Date: 11-July-2018
	 ****************************************/
	public void ValidatetheContractNumInNetSuite(DataRow input, DataRow output) {
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();
		// SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();
		String ContractNum = input.get("ContractNum");
		uiDriver.click("QuickSort");
		uiDriver.click("RecentlyCreated");
		String DocNum = uiDriver.getDyanmicData("DocumentNum");
		String DocumentNum = DocNum.replace("#", ContractNum);
		if (uiDriver.checkElementPresent_dynamic(DocumentNum)) {

			passed("Verify the ContractNum",
					"ContractNum Should be displayed Successfully",
					"ContractNum is displayed Successfully");

		} else {
			failed("Verify the ContractNum",
					"ContractNum Should be displayed Successfully",
					"ContractNum is not displayed Successfully");

		}
		uiDriver.click_dynamic(DocumentNum);
		SleepUtils.sleep(TimeSlab.LOW);
		if (uiDriver
				.checkPage("Sales Order - NetSuite (NBCUniversal Media, LLC 10K QA)")) {
			passed("Verify SalesOrderPage",
					"SalesOrder Page Should be displayed Successfully",
					"SalesOrder Page  is displayed Successfully");

		} else {

			failed("Verify SalesOrderPage",
					"SalesOrder Page Should be displayed Successfully",
					"SalesOrder Page is not displayed Successfully");

		}

		String SalesNum = uiDriver.getValue("SalesNum");
		output.put("SalesOrderNum", SalesNum);

	}

	/****************************************
	 * Name: ValidateTheFieldsInNetSuite Description:
	 * ValidatetheContractNumInNetSuite Date: 11-July-2018
	 ****************************************/
	public void ValidateTheFieldsInNetSuite(DataRow input, DataRow output) {
		String tableRows = uiDriver.getObjMap("tableRows");

		uiDriver.executeJavaScript("scroll(0,500)");
		String actualMARKETCODE = uiDriver.getValue(tableRows + nextRow	+ uiDriver.getObjMap("marketcode"));
		String actualItemType = uiDriver.getValue(tableRows + nextRow+ uiDriver.getObjMap("Itemtype"));
		String actualRevRecMethod = uiDriver.getValue(tableRows + nextRow+ uiDriver.getObjMap("RevRecMethod"));
		String actualContinuousProduction = uiDriver.getValue(tableRows	+ nextRow + uiDriver.getObjMap("ContinuousProduction"));
		String actualOnNetwork = uiDriver.getValue(tableRows + nextRow+ uiDriver.getObjMap("OnNetwork"));
		String Customer = uiDriver.getValue("Customer");
		String Subsidairy = uiDriver.getValue("Subsidairy");
		String Payship = uiDriver.getValue("PayShip");
		String RevisionNumber = uiDriver.getValue("RevisionNumber");
		String InterCompanyFlag = uiDriver.getValue("InterCompanyFlag");
		String LicenseFeeType = uiDriver.getValue("LicenseFeeType");
		String CashBasis = uiDriver.getValue("CashBasis");
		String Status = uiDriver.getValue("Status");

		/*String Marketcode = input.get("marketCode");
		SleepUtils.sleep(TimeSlab.YIELD);
		if (Marketcode.contains(actualMARKETCODE.trim())) {
			passed("Verifying the  marketCode",
					"marketCode should be displayed as '" + Marketcode
							+ "' Successfully", "marketCode "
							+ actualMARKETCODE + " is displayed Successfully");
		} else {
			failed("Verifying the  marketCode",
					"marketCode should be displayed as '" + Marketcode
							+ "' Successfully", "marketCode "
							+ actualMARKETCODE
							+ " is not displayed Successfully");
		}*/

		String Itemtype = input.get("Itemtype");
		SleepUtils.sleep(TimeSlab.YIELD);
		if (Itemtype.contains(actualItemType.trim())) {
			passed("Verifying the  Itemtype",
					"Itemtype should be displayed as '" + Itemtype
							+ "' Successfully", "Itemtype " + actualItemType
							+ " is displayed Successfully");
		} else {
			failed("Verifying the  Itemtype",
					"Itemtype should be displayed as '" + Itemtype
							+ "' Successfully", "Itemtype " + actualItemType
							+ " is not displayed Successfully");
		}

		String RevRecMethod = input.get("RevRecMethod");
		SleepUtils.sleep(TimeSlab.YIELD);
		if (RevRecMethod.contains(actualRevRecMethod.trim())) {
			passed("Verifying the  RevRecMethod",
					"RevRecMethod should be displayed as '" + RevRecMethod
							+ "' Successfully", "RevRecMethod "
							+ actualRevRecMethod + " is displayed Successfully");
		} else {
			failed("Verifying the  RevRecMethod",
					"RevRecMethod should be displayed as '" + RevRecMethod
							+ "' Successfully", "RevRecMethod "
							+ actualRevRecMethod
							+ " is not displayed Successfully");
		}

		String ContinuousProduction = input.get("ContinuousProduction");
		if (ContinuousProduction.contains(actualContinuousProduction.trim())) {
			passed("Verifying the  ContinuousProduction",
					"ContinuousProduction should be displayed as '"
							+ ContinuousProduction + "' Successfully",
					"ContinuousProduction " + ContinuousProduction
							+ " is displayed Successfully");
		} else {
			failed("Verifying the  ContinuousProduction",
					"ContinuousProduction should be displayed as '"
							+ ContinuousProduction + "' Successfully",
					"ContinuousProduction " + actualContinuousProduction
							+ " is not displayed Successfully");
		}

		String OnNetwork = input.get("OnNetwork");
		SleepUtils.sleep(TimeSlab.YIELD);
		if (OnNetwork.contains(actualOnNetwork.trim())) {
			passed("Verifying the  OnNetwork",
					"OnNetwork should be displayed as '" + OnNetwork
							+ "' Successfully", "OnNetwork " + OnNetwork
							+ " is displayed Successfully");
		} else {
			failed("Verifying the  OnNetwork",
					"OnNetwork should be displayed as '" + OnNetwork
							+ "' Successfully", "OnNetwork " + actualOnNetwork
							+ " is not displayed Successfully");
		}

		SleepUtils.sleep(TimeSlab.YIELD);
		if (Customer.trim().contains(input.get("Customer"))) {
			passed("Verifying the  Customer",
					"Customer should be displayed as '" + Customer
							+ "' Successfully", "Customer " + Customer
							+ " is displayed Successfully");
		} else {
			failed("Verifying the  Customer",
					"Customer should be displayed as '" + Customer
							+ "' Successfully", "Customer " + Customer
							+ " is not displayed Successfully");
		}

		SleepUtils.sleep(TimeSlab.YIELD);
		if (input.get("Subsidairy").contains(Subsidairy.trim())) {
			passed("Verifying the  Subsidairy",
					"Subsidairy should be displayed as '" + Subsidairy
							+ "' Successfully", "Subsidairy " + Subsidairy
							+ " is displayed Successfully");
		} else {
			failed("Verifying the  Subsidairy",
					"Subsidairy should be displayed as '" + Subsidairy
							+ "' Successfully", "Subsidairy " + Subsidairy
							+ " is not displayed Successfully");
		}

		SleepUtils.sleep(TimeSlab.YIELD);
		if (input.get("Payship").contains(Payship.trim())) {
			passed("Verifying the  Payship", "Payship should be displayed as '"
					+ Payship + "' Successfully", "marketCode " + Payship
					+ " is displayed Successfully");
		} else {
			failed("Verifying the  Payship", "Payship should be displayed as '"
					+ Payship + "' Successfully", "Payship " + Payship
					+ " is not displayed Successfully");
		}

		SleepUtils.sleep(TimeSlab.YIELD);
		if (input.get("RevisionNumber").contains(RevisionNumber.trim())) {
			passed("Verifying the  RevisionNumber",
					"RevisionNumber should be displayed as '" + RevisionNumber
							+ "' Successfully", "RevisionNumber "
							+ RevisionNumber + " is displayed Successfully");
		} else {
			failed("Verifying the  RevisionNumber",
					"RevisionNumber should be displayed as '" + RevisionNumber
							+ "' Successfully", "marketCode " + RevisionNumber
							+ " is not displayed Successfully");
		}

		SleepUtils.sleep(TimeSlab.YIELD);
		if (input.get("InterCompanyFlag").contains(InterCompanyFlag.trim())) {
			passed("Verifying the  InterCompanyFlag",
					"InterCompanyFlag should be displayed as '"
							+ input.get("InterCompanyFlag") + "' Successfully",
					"InterCompanyFlag " + input.get("InterCompanyFlag")
							+ " is displayed Successfully");
		} else {
			failed("Verifying the  InterCompanyFlag",
					"InterCompanyFlag should be displayed as '"
							+ InterCompanyFlag + "' Successfully",
					"InterCompanyFlag " + InterCompanyFlag
							+ " is not displayed Successfully");
		}

		SleepUtils.sleep(TimeSlab.YIELD);
		if (input.get("LicenseFeeType").contains(LicenseFeeType.trim())) {
			passed("Verifying the  LicenseFeeType",
					"LicenseFeeType should be displayed as '" + LicenseFeeType
							+ "' Successfully", "LicenseFeeType "
							+ LicenseFeeType + " is displayed Successfully");
		} else {
			failed("Verifying the  LicenseFeeType",
					"LicenseFeeType should be displayed as '" + LicenseFeeType
							+ "' Successfully", "LicenseFeeType "
							+ LicenseFeeType + " is not displayed Successfully");
		}

		SleepUtils.sleep(TimeSlab.YIELD);
		if (input.get("Status").equalsIgnoreCase(Status.trim())) {
			passed("Verifying the  Status", "Status should be displayed as '"
					+ Status + "' Successfully", "Status " + Status
					+ " is displayed Successfully");
		} else {
			failed("Verifying the  Status", "Status should be displayed as '"
					+ Status + "' Successfully", "Status " + Status
					+ " is not displayed Successfully");
		}

		SleepUtils.sleep(TimeSlab.YIELD);
		if (input.get("CashBasis").contains(CashBasis.trim())) {
			passed("Verifying the  CashBasis",
					"CashBasis should be displayed as '" + input.get("CashBasis")
							+ "' Successfully", "CashBasis " + input.get("CashBasis")
							+ " is displayed Successfully");
		} else {
			failed("Verifying the  CashBasis",
					"CashBasis should be displayed as '" + CashBasis
							+ "' Successfully", "CashBasis " + CashBasis
							+ " is not displayed Successfully");
		}

	}
	
	/****************************************
	 * Name: VerifytheLineitemsinNetsuite Description: ValidateSalesOrder Date:
	 * 11-July-2018
	 ****************************************/
	public void VerifytheLineitemsinNetsuite(DataRow input, DataRow output) {
		List<WebElement> rowitems = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody/tr[contains(@class,'uir-machine-row')]"));
		int rowsize = rowitems.size();
		for(int rown=2;rown<rowsize+1;rown++)
		{
			String Rights = uiDriver.getDyanmicData("Rights");
			String Rights1 = Rights.replace("#", Integer.toString(rown));
			String Rightsvalue = uiDriver.getValueByText(Rights1);
			String MarketCode = uiDriver.getDyanmicData("MarketCode");
			String MarketCode1 = MarketCode.replace("#", Integer.toString(rown));
			String MarketCodevalue = uiDriver.getValueByText(MarketCode1);
			String OnNetworkflag = uiDriver.getDyanmicData("OnNetworkflag");
			String OnNetworkflag1 = OnNetworkflag.replace("#", Integer.toString(rown));
			String OnNetworkflagvalue = uiDriver.getValueByText(OnNetworkflag1);
			if(Rightsvalue.equalsIgnoreCase("FTV"))
			{
				if(MarketCodevalue.equalsIgnoreCase("CNWS"))
				{
					passed("Verifying the  The lines with Free TV rights should have Market Code CNWS",
							"The lines with Free TV rights should have Market Code CNWS",
							"The lines with Free TV rights is having Market Code CNWS");
				}
				else
				{
					failed("Verifying the  The lines with Free TV rights should have Market Code CNWS",
							"The lines with Free TV rights should have Market Code CNWS",
							"The lines with Free TV rights is not having Market Code CNWS");
				}
			}
			if(Rightsvalue.equalsIgnoreCase("BAS"))
			{
				if(MarketCodevalue.equalsIgnoreCase("CNWB"))
				{
					passed("Verifying the  The lines with BAS rights should have Market Code CNWB",
							"The lines with BAS rights should have Market Code CNWB",
							"The lines with BAS rights is having Market Code CNWB");
				}
				else
				{
					failed("Verifying the  The lines with BAS rights should have Market Code CNWB",
							"The lines with BAS rights should have Market Code CNWB",
							"The lines with BAS rights is not having Market Code CNWB");
				}
			}
			
			if(OnNetworkflagvalue.equalsIgnoreCase(input.get("Onnetwork")))
			{
				passed("Verifying the  On network flag",
							"The lines should have On network flag has yes",
							"The lines is having On network flag as yes");
			}
				else
				{
					failed("Verifying the  On network flag",
							"The lines should have On network flag as yes",
							"The lines is NOT having On network flag as yes");
				}
			}
			
		}
		

	/****************************************
	 * Name: ValidateSalesOrder Description: ValidateSalesOrder Date:
	 * 11-July-2018
	 ****************************************/
	public void ValidateSalesOrder(DataRow input, DataRow output) {
		
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("scroll(0,-500)");
		uiDriver.click("ValidateSalesOrder");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		String ContractValidation = uiDriver.getValue_Text("ContractValidation");
		if (ContractValidation.contains("This contract is valid for approval.")) {

			passed("Verifying the  ContractValidation",
					"ContractValidation should be displayed as This contract is valid for approval",
					"ContractValidation is displayed as This contract is valid for approval");
		} else if (ContractValidation
				.contains("This contract is not valid for approval.")) {
			passed("Verifying the  ContractValidation error",
					"ContractValidation should be displayed as"
							+ ContractValidation + "",
					"ContractValidation is displayed as" + ContractValidation
							+ "");
		}

		else {
			failed("Verifying the  ContractValidation",
					"ContractValidation should be displayed as This contract is valid for approval",
					"ContractValidation is not displayed as This contract is valid for approval");
		}

		uiDriver.click("OK");
		SleepUtils.sleep(TimeSlab.HIGH);
		
		

	}

	/****************************************
	 * Name: NavigateToAcceptCustomerPayment Description:
	 * NavigateToAcceptCustomerPayment Date: 11-July-2018
	 ****************************************/
	public void NavigateToAcceptCustomerPayment(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("transactions");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("CustomerPay");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("AcceptPayment");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.YIELD);

		uiDriver.click("AcceptPayment");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.YIELD);
		String cust = input.get("customer");
		uiDriver.click("customerdropdownimage");
		SleepUtils.sleep(5);
		uiDriver.click("customerlist");
		SleepUtils.sleep(5);
		uiDriver.setValue("searchcustomerinput", cust);
		SleepUtils.sleep(5);
		uiDriver.click("searchcustomerbutton");
		SleepUtils.sleep(5);
		uiDriver.click("cussearchresult");

	}
	
	
	/********************************************
	 * Name: ValidatePTMGamountfortitle Description: ValidatePTMGamountfortitle Date: 07-April-2019
	 ****************************************/
	public void ValidatePTMGamountfortitle(DataRow input, DataRow output) {
	uiDriver.click("(//a[text()='Finance'])[2]");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("//a[text()='Financial Summary']");
	SleepUtils.sleep(TimeSlab.HIGH);
	String amount=uiDriver.getValue("//span[text()='04109|MANCHESTER BY THE SEA']/../..//td[4]//input[@value='199,000.00']");
	
if(amount.equals(input.get("amount")))
{
	passed("Verify PTMG amount ",
			"PTMG amount should displayed as"+ amount + "",
			"PTMG amoun is displayed as" + amount+"");
}
else
{
	failed("Verify PTMG amount ",
			"PTMG amount should displayed as"+ amount + "",
			"PTMG amoun is not displayed as" + amount+"");
}
	
	}
	/********************************************
	 * Name: Editmultiplebillingschedule 
	 * Description: Editmultiplebillingschedule 
	 * Date: 07-April-2019
	 ****************************************/
	public void Editmultiplebillingschedule(DataRow input, DataRow output) {
		uiDriver.click("(//a[text()='Finance'])[2]");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//a[text()='Billing']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//a[text()='Billing Schedules']");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		for(int r=2;r<=3;r++)
		{
			
			SleepUtils.sleep(TimeSlab.LOW);
			
			uiDriver.click("//tr["+r+"]//td[4]//a");
			SleepUtils.sleep(TimeSlab.HIGH);
            uiDriver.click("//button[text()='Next']");
        	SleepUtils.sleep(TimeSlab.HIGH);
            uiDriver.click("//button[text()='Next']");
        	SleepUtils.sleep(TimeSlab.HIGH);
uiDriver.click("//*[@id='projectsTree']/div[3]/span[2]/span/span/span[1]");
SleepUtils.sleep(TimeSlab.LOW);
uiDriver.click("/html/body/div[17]/div/div[2]/ul/li[2]");
SleepUtils.sleep(TimeSlab.HIGH);

for(int k=1;k<=22;k++)
{
	
	
	if(k==13)
	{
	
	WebElement z = uiDriver.webDr.findElement(By.xpath("(//table[@role='grid']/tbody)[2]/tr["+k+"]/td[6]/div[1]/div/input"));
	
	uiDriver.click_dynamic("(//table[@role='grid']/tbody)[2]/tr["+k+"]/td[6]/div[1]/div/input");
	SleepUtils.sleep(TimeSlab.LOW);
	z.sendKeys(Keys.chord(Keys.CONTROL,"a"));
	z.sendKeys(Keys.DELETE);
	SleepUtils.sleep(TimeSlab.LOW);
	
	uiDriver.setValue("(//table[@role='grid']/tbody)[2]/tr["+k+"]/td[6]/div[1]/div/input", input.get("amount"));
	WebElement chkbox = uiDriver.webDr.findElement(By.xpath("(//table[@role='grid']/tbody)[2]/tr["+k+"]/td[1]//input"));
	chkbox.click();
	}
	else if(k==22)
	{
		uiDriver.executeJavaScript("scroll(0,1000)");
		SleepUtils.sleep(TimeSlab.LOW);
		WebElement chkbox = uiDriver.webDr.findElement(By.xpath("(//table[@role='grid']/tbody)[2]/tr["+k+"]/td[1]//input"));
		chkbox.click();
		
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click_dynamic("(//table[@role='grid']/tbody)[2]/tr["+k+"]/td[6]/div[1]/div/input");
		SleepUtils.sleep(TimeSlab.LOW);
		WebElement z = uiDriver.webDr.findElement(By.xpath("(//table[@role='grid']/tbody)[2]/tr["+k+"]/td[6]/div[1]/div/input"));
		z.sendKeys(Keys.chord(Keys.CONTROL,"a"));
		z.sendKeys(Keys.DELETE);
		SleepUtils.sleep(TimeSlab.LOW);
		
		uiDriver.setValue("(//table[@role='grid']/tbody)[2]/tr["+k+"]/td[6]/div[1]/div/input", input.get("amount1"));
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.LOW);
		
		
	}

	
	
	
}
			uiDriver.click("//*[@id='next']");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("//*[@id='next']");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("//*[@id='finish']");
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
		
		}
	}
	/********************************************
	 * Name: AddTimelineItemManchester Description: AddTimelineItemManchester Date: 07-April-2019
	 ****************************************/
	public void AddTimelineItemManchester(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Dates");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimeLineItems");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("AddTimeLineItem");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setFrame("//*[@id='RadWindowWrapper_ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_TimelineItemWindow']/table/tbody/tr[2]/td[2]/iframe");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimelineItemType");
		// uiDriver.setValue("TimelineItemType",input.get("Type"));
		SleepUtils.sleep(TimeSlab.LOW);
		String Timeline = uiDriver.getDyanmicData("TimelineItemTypeValue");
		String Timeline1 = Timeline.replace("#",input.get("Type"));
		uiDriver.click(Timeline1);
		uiDriver.click("EST");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("Date", input.get("Date"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Notes");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Project");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//span[text()='04109|MANCHESTER BY THE SEA']/../../..//input");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//*[@id='ctl00_MainContent_Project_userControl_ProjectSelectionControlLocal_AddButton']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//*[@id='ctl00_MainContent_FinishButton']");
		SleepUtils.sleep(TimeSlab.HIGH);
		
		uiDriver.resetFrame();
	}
	
	
	/********************************************
	 * Name: GenerateInvoice Description: GenerateInvoice Date: 13-July-2018
	 ****************************************/
	public void GenerateInvoice(DataRow input, DataRow output) {
	
		uiDriver.click("Invoices");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("BulkOperations");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("GenerateInvoices");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Filter");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("searchinput");
		String ContractId = input.get("ContractId");
		uiDriver.setValue("searchinput", input.get("ContractId"));
		// uiDriver.setValue("searchinput", "123178");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//*[@id='advancedSearchButton']/span");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("//*[text()='Effective Due Date: All']");
        SleepUtils.sleep(TimeSlab.YIELD);
        uiDriver.setValue("//*[text()='Before']/following::span//input[@placeholder='Date']",input.get("DueDate"));
        SleepUtils.sleep(TimeSlab.LOW);
        uiDriver.click("//*[@id=\"advancedSearchButton\"]");
        SleepUtils.sleep(TimeSlab.HIGH);
        uiDriver.click("//*[@id='AdvancedSearchResultsGrid']/div[1]/a");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("//*[@id='generateAll']/div/div[2]/button[2]");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("(//a[text()='Invoice Queue'])[2]");
		//uiDriver.click("CheckAllRows");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		//uiDriver.click("Createinvoice");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.MEDIUM);
		/*	String invoicenum = uiDriver.getValue("//a[text()='Invoice #']/../../../following-sibling::tbody/tr[1]/td[4]");
		//String invoicenum = uiDriver.getValue("InvoiceID");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		//uiDriver.click("InvoiceID");
		uiDriver.click("//a[text()='Invoice #']/../../../following-sibling::tbody/tr[1]/td[4]");
		SleepUtils.sleep(TimeSlab.MEDIUM);*/
		passed("Verify the Invoice",
		"Invoice should be displayed successfully",
		"Invoice is displayed successfully");
		//output.put("Invoice", invoicenum);
		SleepUtils.sleep(TimeSlab.LOW);
		//uiDriver.click("Invoices");
		//SleepUtils.sleep(TimeSlab.YIELD);
		//output.put("Invoice", invoicenum);
		uiDriver.back();
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		/*String ContractNum = uiDriver.getDyanmicData("Contractnum");
		SleepUtils.sleep(TimeSlab.YIELD);
		String ContractNumber = ContractNum.replace("#", ContractId);
		List<WebElement> ele = uiDriver.webDr.findElements(By
				.xpath(ContractNumber));
		int rowSize = ele.size();
		for (int i = 0; i < rowSize; i++) {
			/*
			 * String RevenuechkBox = uiDriver.getDyanmicData("RevenueChkBox");
			 * String Revenuechkbox1=RevenuechkBox.replace("$",revenuenum);
			 * String RevchkBox = Revenuechkbox1.replace("#",
			 * Integer.toString(i)); if
			 * (uiDriver.checkElementPresent_dynamic(RevchkBox)) {
			 * 
			 * uiDriver.click_dynamic(RevchkBox); } else { // do nothing }
			 
			SleepUtils.sleep(TimeSlab.HIGH);
			ele.get(i).click();
			SleepUtils.sleep(TimeSlab.MEDIUM);

		}

		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Createinvoice");*/
		//WebElement w=uiDriver.webDr.findElement(By.id("//*[@id='checkAllRows']"));
		//uiDriver.executeJavaScript("document.getElementById('checkAllRows').click();");
		//uiDriver.click("checkall");
		//SleepUtils.sleep(TimeSlab.MEDIUM);
		//uiDriver.click("createselected");
		//SleepUtils.sleep(TimeSlab.HIGH);
		//uiDriver.click("Createinvoice");
		//SleepUtils.sleep(TimeSlab.HIGH);
		//uiDriver.click("Createinvoice");
		//SleepUtils.sleep(TimeSlab.HIGH);
		//SleepUtils.sleep(TimeSlab.HIGH);
		//String invoicenum = uiDriver.getValue("InvoiceID");
		//SleepUtils.sleep(TimeSlab.YIELD);
		//uiDriver.click("InvoiceID");
		//SleepUtils.sleep(TimeSlab.YIELD);
		//passed("Verify the Invoice",
				//"Invoice should be displayed successfully",
				//"Invoice is displayed successfully");
		//output.put("Invoice", invoicenum);

	}

	/****************************************
	 * Name: Change Invoice Status Description: Change Invoice Status Date:
	 * 13-July-2018
	 ****************************************/
	public void ChangeInvoiceStatus(DataRow input, DataRow output) {

		// uiDriver.click("Menu");
		// SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("Avails");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Invoices");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("BulkOperations");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("ChangeWFStates");
		SleepUtils.sleep(TimeSlab.YIELD);
		String invoicenum = input.get("Invoice");
		// String invoicenum="INV-990";
		String Invoicecheckbox = uiDriver.getDyanmicData("Invoicecheckbox");
		SleepUtils.sleep(TimeSlab.YIELD);
		String InvoiceNumber = Invoicecheckbox.replace("#", invoicenum);
		SleepUtils.sleep(TimeSlab.YIELD);

		String numofpages = uiDriver.getValue("lastpagenum");
		int pagenum = Integer.parseInt(numofpages);
		for (int i = 1; i <= pagenum; i++) {
			if (uiDriver.checkElementPresent_dynamic(InvoiceNumber)) {

				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.click_dynamic(InvoiceNumber);
				break;

			} else {

				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.executeJavaScript("scroll(0,1500)");
				uiDriver.click("nextbutton");
				SleepUtils.sleep(TimeSlab.HIGH);
			}
		}
		// uiDriver.click_dynamic(InvoiceNumber);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.executeJavaScript("scroll(0,-1000)");
		uiDriver.click("Invoicedropdown");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("SendforInvoice");
		uiDriver.click("SendforInvoice");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Transitiontoworkflow");
		passed("Verify the Invoice is posted", "Invoice posted successfully",
				"Invoice posted successfully");

	}

	/****************************************
	 * Name: NavigateToInvoiceList Description: NavigateToInvoiceList Date:
	 * 30-Nov-2017
	 ****************************************/

	public void NavigateToSalesList(DataRow input, DataRow output)
			throws InterruptedException {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setFrame("frame");
		uiDriver.mouseOver("transactions");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("sales");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("enterSalesOrder");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("list");
		passed("Verify the ListPage",
				"ListPage should be displayed successfully",
				"ListPage is displayed successfully");

	}

	/****************************************
	 * Name: ViewInvoiceRecord Description: ViewInvoiceRecord Date: 30-Nov-2017
	 ****************************************/

	public void ViewInvoiceRecord(DataRow input, DataRow output)
			throws InterruptedException {

		/*
		 * String ContractNum = input.get("ContractId");
		 * uiDriver.click("QuickSort"); uiDriver.click("RecentlyCreated");
		 * String DocNum = uiDriver.getDyanmicData("DocumentNum"); String
		 * DocumentNum = DocNum.replace("#", ContractNum);
		 * if(uiDriver.checkElementPresent_dynamic(DocumentNum)){
		 * 
		 * passed("Verify the ContractNum",
		 * "ContractNum Should be displayed Successfully",
		 * "ContractNum is displayed Successfully");
		 * 
		 * } else{ failed("Verify the ContractNum",
		 * "ContractNum Should be displayed Successfully",
		 * "ContractNum is not displayed Successfully");
		 * 
		 * } uiDriver.click_dynamic(DocumentNum);
		 * uiDriver.click("relatedRecord"); uiDriver.click("date");
		 */
		String Status = uiDriver.getValue_Text("Status");
		String InvoiceType = uiDriver.getValue_Text("InvoiceType");
		if (Status.equalsIgnoreCase("Open")) {

			passed("Verifying the Status", "Status should be displayed as "
					+ Status + "  ", "Status is displayed as " + Status + "  ");
		} else {
			failed("Verifying the Status", "Status should be displayed as "
					+ Status + "  ", "Status is not displayed as " + Status
					+ "  ");
		}

		if (InvoiceType.equalsIgnoreCase("Title Invoice")) {

			passed("Verifying the InvoiceType",
					"InvoiceType should be displayed as " + InvoiceType + "  ",
					"InvoiceType is displayed as " + InvoiceType + "  ");
		} else {
			failed("Verifying the InvoiceType",
					"InvoiceType should be displayed as " + InvoiceType + "  ",
					"InvoiceType is not displayed as " + InvoiceType + "  ");
		}

	}
	
	/****************************************
	 * Name: verifyPaymentapplied Description: verifyPaymentapplied Date: 30-Nov-2017
	 ****************************************/
	public void verifypaymentapplied(DataRow input, DataRow output)
			throws InterruptedException {
		
		uiDriver.click("//a[contains(text(),'lated Records')]");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("//td[text()='Payment']/..//td[1]/a");
		SleepUtils.sleep(TimeSlab.MEDIUM);
String appliedamount = uiDriver.getValueByText("//a[text()='Applied']/../../../span[2]");
if(appliedamount.equalsIgnoreCase(input.get("appliedamount")))
		{
	passed("Verifying the applied amount",
			"Applied amount should be displayed as " + appliedamount + "  ",
			"Applied amount is displayed as " + input.get("appliedamount") + "  ");
		}
else
{
	failed("Verifying the applied amount",
			"Applied amount should be displayed as " + appliedamount + "  ",
			"Applied amount is not displayed as " + input.get("appliedamount") + "  ");
}

	}

	/****************************************
	 * Name: verifyPaymentunapplied Description: verifyPaymentunapplied Date: 30-Nov-2017
	 ****************************************/
	public void verifyPaymentunapplied(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.click("custom");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.executeJavaScript("scroll(0,1000)");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("tapinvoice");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("payment");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String paymentnum=uiDriver.getValue("paymentvalue");
		String applied=uiDriver.getValue("applied");
		String unapplied=uiDriver.getValue("unapplied");
		String expunapplied=input.get("unapplied");
		if(applied.startsWith("0.00")|unapplied.equalsIgnoreCase(expunapplied))
		{
			passed("Verifying the payment is unapplied",
					"Payment should be unapplied",
					"Payment is unapplied ");
		}
		else
		{
			failed("Verifying the payment is unapplied",
					"Payment should be unapplied",
					"Payment is not unapplied ");

		}
		
		uiDriver.click("custom");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.executeJavaScript("scroll(0,1000)");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("tappayment");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.executeJavaScript("scroll(0,1500)");
		String creditmemo = uiDriver.getValue("creditmemototal");
		String appliedtoinvoice = uiDriver.getValue("appliedtoinvoice");
		if(appliedtoinvoice.startsWith("0.00")|creditmemo.equalsIgnoreCase(expunapplied))
		{
			passed("Verifying the payment is unapplied",
					"Payment should be unapplied",
					"Payment is unapplied ");
		}
		else
		{
			failed("Verifying the payment is unapplied",
					"Payment should be unapplied",
					"Payment is not unapplied ");

		}
		/*uiDriver.click("id");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("//*[text()='llocation Detail']");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Transactions");
		int accRows = uiDriver.webDr
				.findElements(
						By.xpath("//table[@id='recmachcustrecord_nbcu_titleallocpa_payment__tab']/tbody/tr"))
				.size();
		SleepUtils.sleep(TimeSlab.HIGH);
		for (int r = 0; r <= accRows - accRows; r++) {

			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.executeJavaScript("scroll(0,900)");
			SleepUtils.sleep(TimeSlab.HIGH);
			String s1 = uiDriver.getDyanmicData("DynamicTapid");
			SleepUtils.sleep(TimeSlab.HIGH);
			String s2 = s1.replace("#", Integer.toString(r));
			SleepUtils.sleep(TimeSlab.HIGH);
			if (uiDriver.checkElementPresent_dynamic(s2))
				SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click_dynamic(s2);
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.executeJavaScript("scroll(0,300)");
			SleepUtils.sleep(TimeSlab.HIGH);
			WebElement w = uiDriver.webDr.findElement(By.xpath("//*[text()='llocation Detail']"));
			String id = w.getAttribute("id");
		SleepUtils.sleep(TimeSlab.HIGH);
		//uiDriver.executeJavaScript("scroll(0,-1000)");
		//if(uiDriver.checkElementPresent_dynamic("reclassJEntry")){
		uiDriver.executeJavaScript("document.getElementById('"+id+"').click();");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Transactions");
			SleepUtils.sleep(TimeSlab.HIGH);
			List<WebElement> Journal = uiDriver.webDr
					.findElements(By
							.xpath("//*[@id='recmachcustbody_nbcu_titleallocation__tab']/tbody//tr"));
			SleepUtils.sleep(TimeSlab.HIGH);
			int Journals = Journal.size();
			for (int i = 0; i < Journals; i++) {

				SleepUtils.sleep(TimeSlab.HIGH);
				String JournalLink = uiDriver.getDyanmicData("Journal");
				String JournalLinkValue = JournalLink.replace("#",
						Integer.toString(i));
				uiDriver.click_dynamic(JournalLinkValue);
				SleepUtils.sleep(TimeSlab.HIGH);
				int invoiceRow = 2;
				SleepUtils.sleep(TimeSlab.HIGH);
				if (uiDriver.getValue(
						"//*[@id='line_splits']//tbody/tr[" + invoiceRow
								+ "]/td[1]").contains(
						"110051XX Generic Billed AR")||uiDriver.getValue(
						"//*[@id='line_splits']//tbody/tr[" + (invoiceRow + 1)
								+ "]/td[1]").contains(
						"11015052 Canada Cash Clearing")) {

					if (uiDriver.getValue(
							"//*[@id='line_splits']//tbody/tr[" + invoiceRow
									+ "]/td[2]").equals(""))

					{

						failed("Validating Debit Amount",

						"Validating Debit Amount should be successfull",

						"Debit amount is not Deferred Rev -Generic ");
					}

					else

					{

						passed("Debit is Deferred Rev - Generic",

								"Debit is Deferred Rev - Generic",

								"110051XX Generic Billed AR");
					}

				}

				SleepUtils.sleep(TimeSlab.HIGH);
				if (uiDriver.getValue(
						"//*[@id='line_splits']//tbody/tr[" + (invoiceRow + 1)
								+ "]/td[1]").contains(
						"11015102 Billed Intl AR FTV/BC")||uiDriver.getValue(
						"//*[@id='line_splits']//tbody/tr[" + (invoiceRow + 1)
								+ "]/td[1]").contains(
						"11015052 Canada Cash Clearing"))
				{

					if (uiDriver.getValue(
							"//*[@id='line_splits']//tbody/tr["
									+ (invoiceRow + 1) + "]/td[3]").equals("")) {
						failed("Validating Credit Amount",

						"Validating Credit Amount should be successfull",

						"Credit amount is not Generic billed AR");

					} else

					{

						passed("Credit is generic billed AR",

								"Credit is generic billed AR",

								"11015102 Billed Intl AR FTV/BC/11015052 Canada Cash Clearing	");

					}

				}
				
				
				
				SleepUtils.sleep(TimeSlab.HIGH);
				uiDriver.click("Back");
				SleepUtils.sleep(TimeSlab.MEDIUM);
				uiDriver.click("AllocationDetail");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.click("Transactions");*/

			//}

		//}

//output.put("paymentvalue",paymentnum);
	}

	/****************************************
	 * Name: NavigateToCommunicationFiles Description:
	 * NavigateToCommunicationFiles Date: 30-Nov-2017
	 ****************************************/

	public void NavigateToCommunicationFiles(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.executeJavaScript("scroll(0,300)");
		uiDriver.click("Communication");
		// uiDriver.click("Files");
		uiDriver.executeJavaScript("scroll(0,300)");
		if (uiDriver.checkElementPresent("PDFFile")) {

			passed("Verifying the PDFFile Link",
					"PDFFile Link should be displayed",
					"PDFFile Link is displayed ");
		} else {
			failed("Verifying the PDFFile Link",
					"PDFFile Link should be displayed",
					"PDFFile Link is displayed ");
		}

	}

	/****************************************
	 * Name: VerifyMasterContractStatus Description: VerifyStatus Date:
	 * 30-Nov-2017
	 ****************************************/

	public void VerifyMasterContractStatus(DataRow input, DataRow output)
			throws InterruptedException {
		
		uiDriver.click("MasterContract");
		SleepUtils.sleep(TimeSlab.YIELD);
		String status = uiDriver.getValue("Status");
		if (status.equalsIgnoreCase("Posted")) {

			passed("Verifying the  Sales order Status",
					"Sales order Status should be displayed as '" + status
							+ "' Successfully", "Sales order Status " + status
							+ " is displayed Successfully");
		} else {
			failed("Verifying the  Sales order Status",
					"Sales order Status should be displayed as '" + status
							+ "' Successfully", "Sales order Status " + status
							+ " is not displayed Successfully");
		}

	}

	/****************************************
	 * Name: VerifyStatus Description: VerifyStatus Date: 30-Nov-2017
	 ****************************************/

	public void VerifyContractStatus(DataRow input, DataRow output)
			throws InterruptedException {
		/*uiDriver.refresh();
		SleepUtils.sleep(120);
		uiDriver.refresh();
		SleepUtils.sleep(60);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		SleepUtils.sleep(60);
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		SleepUtils.sleep(60);
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		SleepUtils.sleep(60);
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		SleepUtils.sleep(60);
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();

		uiDriver.refresh();*/
		for(int i=1;i<=50;i++)
		{
			String ContractStatus = uiDriver.getValue("ContractStatus");
			if (ContractStatus.equalsIgnoreCase("Contract Processed")
					|| ContractStatus.equalsIgnoreCase("Posted Successfully")) {

				passed("Verifying the  Sales order Status",
						"Sales order Status should be displayed as '"
								+ input.get("Status") + "' Successfully",
						"Sales order Status " + ContractStatus
								+ " is displayed Successfully");
				break;
			} 
			else if(ContractStatus.equalsIgnoreCase("Error:Contract Processing")||ContractStatus.startsWith("Error"))
			
			{
				failed("Verifying the  Sales order Status",
						"Sales order Status should be displayed as '"
								+ input.get("Status") + "' Successfully",
						"Sales order Status " + ContractStatus
								+ " is not displayed Successfully");
				break;
			}
				else {
			
				uiDriver.refresh();
				SleepUtils.sleep(TimeSlab.MEDIUM);
				uiDriver.refresh();
				SleepUtils.sleep(TimeSlab.MEDIUM);
				uiDriver.refresh();
				SleepUtils.sleep(5);
			}
		}
		

	}

	/****************************************
	 * Name: VerifyStatus Description: VerifyStatus Date: 30-Nov-2017
	 ****************************************/

	public void VerifyStatus(DataRow input, DataRow output)
			throws InterruptedException {
		SleepUtils.sleep(30);
		uiDriver.refresh();
		String CurrentStatus = uiDriver.getValue_Text("CurrentStatus");
		if (CurrentStatus.equalsIgnoreCase(input.get("Status"))) {

			passed("Verifying the  Sales order Status",
					"Sales order Status should be displayed as '"
							+ input.get("Status") + "' Successfully",
					"Sales order Status " + CurrentStatus
							+ " is displayed Successfully");
		} else {
			failed("Verifying the  Sales order Status",
					"Sales order Status should be displayed as '"
							+ input.get("Status") + "' Successfully",
					"Sales order Status " + CurrentStatus
							+ " is not displayed Successfully");
		}

	}

	/****************************************
	 * Name: NavigateToCommunicationMessages Description:
	 * NavigateToCommunicationMessages Date: 30-Nov-2017
	 ****************************************/

	public void NavigateToCommunicationMessages(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.executeJavaScript("scroll(0,300)");
		uiDriver.click("Communication");
		uiDriver.click("Messages");
		if (uiDriver.checkElementPresent("ToBeEmailedLink")) {

			passed("Verifying the ToBeEmailedLink Link",
					"ToBeEmailedLink Link should be displayed",
					"ToBeEmailedLink Link is displayed ");
		} else {
			failed("Verifying the ToBeEmailedLink Link",
					"ToBeEmailedLink Link should be displayed",
					"ToBeEmailedLink Link is not displayed ");
		}
	}

	/****************************************
	 * Name: ValidateMasterInvoice Description: ValidateMasterInvoice Date:
	 * 30-Nov-2017
	 * 
	 * @throws IOException
	 * @throws InvalidPasswordException
	 ****************************************/

	public void ValidateMasterInvoicePDF(DataRow input, DataRow output)
			throws InterruptedException, InvalidPasswordException, IOException {

		String Masterinvoice = uiDriver.getValue("MasterInvoice");
		uiDriver.click("MasterInvoice");
		String invoice = uiDriver.getValue("//*[text()='Master Invoice Parent']/following::*[text()='Invoice']/..//td[3]");

		String masterinvoice1 = Masterinvoice + "A";
		if (invoice.equalsIgnoreCase(masterinvoice1)) {
			passed("Verify native invoice number is the master invoice number with an 'A' appended on the end",
					"Invoice number should be master invoice number with an 'A' appended on the end",
					"Invoice number is master invoice number with an 'A' appended on the end");
		} else {
			failed("Verify native invoice number is the master invoice number with an 'A' appended on the end",
					"Invoice number should be master invoice number with an 'A' appended on the end",
					"Invoice number is master invoice number with an 'A' appended on the end");
		}

		//String contractkey = uiDriver.getValue("contractkey");
		String contractkey = uiDriver.getValue_Text("contractkey");
		String contractnum = input.get("ContractId");
		if (contractkey.equals(contractnum)) {

			passed("Verify contractkey",
					"Contract key in invoice record should match Contract Number",
					"Contract key in invoice record is matching Contract Number");
		}

		else {
			failed("Verify contractkey",
					"Contract key in invoice record should match Contract Number",
					"Contract key in invoice record is not matching Contract Number");
		}
		for(int i=1;i<=50;i++){
		if(uiDriver.checkElementPresent("//a[text()='download']")){
			uiDriver.click("//a[text()='download']");
			break;
		}else{
			uiDriver.refresh();
	    	SleepUtils.sleep(TimeSlab.HIGH);
	    	uiDriver.refresh();
	    	SleepUtils.sleep(TimeSlab.HIGH);
	    	uiDriver.refresh();
	    	SleepUtils.sleep(TimeSlab.HIGH);
	    	
		}
		}
		/*String invoicevalue=uiDriver.getValue("//*[@id=\"main_form\"]/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[3]/td/div/span[2]/a[1]");
		int val=invoicevalue.indexOf("NBCU");
		String pdfvalue=invoicevalue.substring(val,invoicevalue.length()-4);

				String presentwindow = uiDriver.webDr.getWindowHandle();
				// boolean flag = false;
				/*uiDriver.click("Communication");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.executeJavaScript("scroll(0,1000)");
				uiDriver.click("viewPDFattachment");
				SleepUtils.sleep(TimeSlab.LOW);

				Set<String> whandles = uiDriver.webDr.getWindowHandles();
				for (String w : whandles) {
					if (!w.equals(presentwindow)) {
						uiDriver.webDr.switchTo().window(w);
						String PDFWindowURL = uiDriver.webDr.getCurrentUrl();
						URL url = new URL(PDFWindowURL);
						SleepUtils.sleep(TimeSlab.LOW);
						uiDriver.sendKey("save");
						SleepUtils.sleep(TimeSlab.LOW);

						Random random = new Random();
						int limit = random.nextInt(1000);
						String inv = Integer.toString(limit);
						String text = "Invoice" + inv;
						StringSelection stringSelection = new StringSelection(text);
						Clipboard clipboard = Toolkit.getDefaultToolkit()
								.getSystemClipboard();
						clipboard.setContents(stringSelection, stringSelection);
						SleepUtils.sleep(TimeSlab.LOW);
						uiDriver.sendKey("paste");
						SleepUtils.sleep(TimeSlab.LOW);
						uiDriver.sendKey("enter");

						SleepUtils.sleep(TimeSlab.LOW);*/
					/*	String path = System.getProperty("user.home");
						// try(PDDocument document = PDDocument.load(new
						// File(path+"/Downloads/"+FileName+".pdf"))){
						PDDocument document = PDDocument.load(new File(path
								+ "/Downloads/" + pdfvalue + ".pdf"));

						document.getClass();

						if (!document.isEncrypted()) {

							PDFTextStripperByArea stripper = new PDFTextStripperByArea();
							stripper.setSortByPosition(true);

							PDFTextStripper tStripper = new PDFTextStripper();

							String pdfFileInText = tStripper.getText(document);
							// System.out.println("Text:" + st);

							// split by whitespace
							String lines[] = pdfFileInText.split("\\r?\\n");
							for (String line : lines) {
								System.out.println(line);
								if (input.get("BilledBy").contains(line)) {
									passed("Verifying the BilledBy info in pdf",
											"BilledBy info should be displayed as "
													+ input.get("BilledBy") + " ",
											"BilledBy info is displayed as "
													+ input.get("BilledBy") + " ");
								} else if ((input.get("Remit").contains(line))) {
									passed("Verifying the Remit info in pdf",
											"Remit info should be displayed as "
													+ input.get("Remit") + " ",
											"Remit info is displayed as "
													+ input.get("Remit") + " ");

								} else if (input.get("BillTo").contains(line)) {
									passed("Verifying the BillTo info in pdf",
											"BillTo info should be displayed as "
													+ input.get("BillTo") + " ",
											"BillTo info is displayed as "
													+ input.get("BillTo") + " ");
									;

								}

								else if (input.get("SendTo").contains(line)) {
									passed("Verifying the SendTo info in pdf",
											"SendTo info should be displayed as "
													+ input.get("SendTo") + " ",
											"SendTo info is displayed as "
													+ input.get("SendTo") + " ");
									;

								} else if (input.get("TotalAmount").contains(line)) {
									passed("Verifying the TotalAmount in pdf",
											"TotalAmount should be displayed as "
													+ input.get("TotalAmount") + " ",
											"TotalAmount is displayed as "
													+ input.get("TotalAmount") + " ");
									;

								} else if (input.get("RemitInformation").contains(line)) {
									passed("Verifying the RemitInformation in pdf",
											"RemitInformation should be displayed as "
													+ input.get("RemitInformation")
													+ " ",
											"RemitInformation is displayed as "
													+ input.get("RemitInformation")
													+ " ");
									;

								}

							}
						}*/
		//String presentwindow = uiDriver.webDr.getWindowHandle();
		// boolean flag = false;
		/*uiDriver.click("viewmasterpdf");
		SleepUtils.sleep(TimeSlab.LOW);

		SleepUtils.sleep(TimeSlab.LOW);

		Set<String> whandles = uiDriver.webDr.getWindowHandles();
		for (String w : whandles) {
			if (!w.equals(presentwindow)) {
				uiDriver.webDr.switchTo().window(w);
				String PDFWindowURL = uiDriver.webDr.getCurrentUrl();
				URL url = new URL(PDFWindowURL);
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.sendKey("save");
				SleepUtils.sleep(TimeSlab.LOW);

				Random random = new Random();
				int limit = random.nextInt(1000);
				String inv = Integer.toString(limit);
				String text = "MasterInvoice" + inv;
				StringSelection stringSelection = new StringSelection(text);
				Clipboard clipboard = Toolkit.getDefaultToolkit()
						.getSystemClipboard();
				clipboard.setContents(stringSelection, stringSelection);
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.sendKey("paste");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.sendKey("enter");

				SleepUtils.sleep(TimeSlab.LOW);
				String path = System.getProperty("user.home");
				// try(PDDocument document = PDDocument.load(new
				// File(path+"/Downloads/"+FileName+".pdf"))){
				PDDocument document = PDDocument.load(new File(path
						+ "/Downloads/" + text + ".pdf"));

				document.getClass();

				if (!document.isEncrypted()) {

					PDFTextStripperByArea stripper = new PDFTextStripperByArea();
					stripper.setSortByPosition(true);

					PDFTextStripper tStripper = new PDFTextStripper();

					String pdfFileInText = tStripper.getText(document);
					// System.out.println("Text:" + st);

					// split by whitespace
					String lines[] = pdfFileInText.split("\\r?\\n");
					for (String line : lines) {
						System.out.println(line);
						if (input.get("BilledBy").contains(line)) {
							passed("Verifying the BilledBy info in pdf",
									"BilledBy info should be displayed as "
											+ input.get("BilledBy") + " ",
									"BilledBy info is displayed as "
											+ input.get("BilledBy") + " ");
						} else if ((input.get("Remit").contains(line))) {
							passed("Verifying the Remit info in pdf",
									"Remit info should be displayed as "
											+ input.get("Remit") + " ",
									"Remit info is displayed as "
											+ input.get("Remit") + " ");

						} else if (input.get("BillTo").contains(line)) {
							passed("Verifying the BillTo info in pdf",
									"BillTo info should be displayed as "
											+ input.get("BillTo") + " ",
									"BillTo info is displayed as "
											+ input.get("BillTo") + " ");
							;

						}

						else if (input.get("SendTo").contains(line)) {
							passed("Verifying the SendTo info in pdf",
									"SendTo info should be displayed as "
											+ input.get("SendTo") + " ",
									"SendTo info is displayed as "
											+ input.get("SendTo") + " ");
							;

						} else if (input.get("TotalAmount").contains(line)) {
							passed("Verifying the TotalAmount in pdf",
									"TotalAmount should be displayed as "
											+ input.get("TotalAmount") + " ",
									"TotalAmount is displayed as "
											+ input.get("TotalAmount") + " ");
							;

						} else if (input.get("RemitInformation").contains(line)) {
							passed("Verifying the RemitInformation in pdf",
									"RemitInformation should be displayed as "
											+ input.get("RemitInformation")
											+ " ",
									"RemitInformation is displayed as "
											+ input.get("RemitInformation")
											+ " ");
							;

						}

					}
				}

				uiDriver.webDr.close();

			}
			uiDriver.webDr.switchTo().window(presentwindow);
			uiDriver.executeJavaScript("scroll(0,-1000)");
			// uiDriver.switchToWindow("Invoice - NetSuite (NBCUniversal Media, LLC 10K QA)");

		}*/

		uiDriver.click("//table[@id='customsublist18__tab']//tbody//tr//td[3]//a");
		SleepUtils.sleep(TimeSlab.HIGH);

	}

	/****************************************
	 * Name: ValidateSalesOrderinMasterContract Description:
	 * ValidateSalesOrderinMasterContract Date: 30-Nov-2017
	 ****************************************/

	public void ValidateSalesOrderinMasterContract(DataRow input, DataRow output)
			throws InterruptedException {
		String mastercontract = uiDriver.getValue("mastercontractparent");
		uiDriver.click("mastercontractparent");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("transactions");
		SleepUtils.sleep(TimeSlab.YIELD);
		String salesordernum = uiDriver.getValue("SalesorderNum");
		String mastercontract1 = mastercontract + "A";
		if (salesordernum.equalsIgnoreCase(mastercontract1)) {
			passed("Verifying the contract is under master contract in transactions tab",
					"The contract should be under master contract in transactions tab",
					"The contract is under master contract in transactions tab");
		} else {
			failed("Verifying the contract is under master contract in transactions tab",
					"The contract should be under master contract in transactions tab",
					"The contract is not under master contract in transactions tab");
		}
		uiDriver.click("SalesorderNum");

	}

	/****************************************
	 * Name: NavigateToGLImpact Description: NavigateToGLImpact Date:
	 * 30-Nov-2017
	 ****************************************/

	public void NavigateToGLImpact(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.executeJavaScript("scroll(0,-1000)");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.mouseOver("action");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Glimpact");
	}

	/****************************************
	 * Name: ApproveJEByManager Description: ApproveJEByManager Date:
	 * 23-July-2018
	 ****************************************/
	public void ApproveJEByManager(DataRow input, DataRow output) {
		String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		SleepUtils.sleep(5);
		uiDriver.refresh();
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("relatedRecord");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("date");
		SleepUtils.sleep(TimeSlab.LOW);
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ApproveJE");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("goback");
		SleepUtils.sleep(TimeSlab.LOW);
	}

	/****************************************
	 * Name: ViewAndReadPDF Description: ViewAndReadPDF Date: 30-Nov-2017
	 ****************************************/

	public void ViewAndReadPDF(DataRow input, DataRow output)
			throws InterruptedException, InvalidPasswordException, IOException {

		/*
		 * uiDriver.click("Files"); String PDFLink =
		 * uiDriver.getValue("PDFLink"); String FileName =
		 * PDFLink.split("\\.")[0]; uiDriver.click("Edit");
		 * SleepUtils.sleep(TimeSlab.LOW); uiDriver.switchToWindow("File");
		 * SleepUtils.sleep(TimeSlab.LOW); String Name =
		 * uiDriver.getValue("FileName"); String ReplaceName =
		 * Name.replace("/",""); uiDriver.setValue("FileName",ReplaceName );
		 * uiDriver.click("Save"); SleepUtils.sleep(TimeSlab.HIGH);
		 * 
		 * uiDriver.switchToWindow(
		 * "Sales Order - NetSuite (NBCUniversal Media, LLC - DEV (New))");
		 * SleepUtils.sleep(TimeSlab.LOW); uiDriver.click("PDFDownload");
		 */
uiDriver.click("//a[text()='download']");
String invoicevalue=uiDriver.getValue("//*[@id=\"main_form\"]/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[3]/td/div/span[2]/a[1]");
int val=invoicevalue.indexOf("NBCU");
String pdfvalue=invoicevalue.substring(val,invoicevalue.length()-4);

		String presentwindow = uiDriver.webDr.getWindowHandle();
		// boolean flag = false;
		/*uiDriver.click("Communication");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,1000)");
		uiDriver.click("viewPDFattachment");
		SleepUtils.sleep(TimeSlab.LOW);

		Set<String> whandles = uiDriver.webDr.getWindowHandles();
		for (String w : whandles) {
			if (!w.equals(presentwindow)) {
				uiDriver.webDr.switchTo().window(w);
				String PDFWindowURL = uiDriver.webDr.getCurrentUrl();
				URL url = new URL(PDFWindowURL);
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.sendKey("save");
				SleepUtils.sleep(TimeSlab.LOW);

				Random random = new Random();
				int limit = random.nextInt(1000);
				String inv = Integer.toString(limit);
				String text = "Invoice" + inv;
				StringSelection stringSelection = new StringSelection(text);
				Clipboard clipboard = Toolkit.getDefaultToolkit()
						.getSystemClipboard();
				clipboard.setContents(stringSelection, stringSelection);
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.sendKey("paste");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.sendKey("enter");

				SleepUtils.sleep(TimeSlab.LOW);*/
				String path = System.getProperty("user.home");
				// try(PDDocument document = PDDocument.load(new
				// File(path+"/Downloads/"+FileName+".pdf"))){
				PDDocument document = PDDocument.load(new File(path
						+ "/Downloads/" + pdfvalue + ".pdf"));

				document.getClass();

				if (!document.isEncrypted()) {

					PDFTextStripperByArea stripper = new PDFTextStripperByArea();
					stripper.setSortByPosition(true);

					PDFTextStripper tStripper = new PDFTextStripper();

					String pdfFileInText = tStripper.getText(document);
					// System.out.println("Text:" + st);

					// split by whitespace
					String lines[] = pdfFileInText.split("\\r?\\n");
					for (String line : lines) {
						System.out.println(line);
						if (input.get("BilledBy").contains(line)) {
							passed("Verifying the BilledBy info in pdf",
									"BilledBy info should be displayed as "
											+ input.get("BilledBy") + " ",
									"BilledBy info is displayed as "
											+ input.get("BilledBy") + " ");
						} else if ((input.get("Remit").contains(line))) {
							passed("Verifying the Remit info in pdf",
									"Remit info should be displayed as "
											+ input.get("Remit") + " ",
									"Remit info is displayed as "
											+ input.get("Remit") + " ");

						} else if (input.get("BillTo").contains(line)) {
							passed("Verifying the BillTo info in pdf",
									"BillTo info should be displayed as "
											+ input.get("BillTo") + " ",
									"BillTo info is displayed as "
											+ input.get("BillTo") + " ");
							;

						}

						else if (input.get("SendTo").contains(line)) {
							passed("Verifying the SendTo info in pdf",
									"SendTo info should be displayed as "
											+ input.get("SendTo") + " ",
									"SendTo info is displayed as "
											+ input.get("SendTo") + " ");
							;

						} else if (input.get("TotalAmount").contains(line)) {
							passed("Verifying the TotalAmount in pdf",
									"TotalAmount should be displayed as "
											+ input.get("TotalAmount") + " ",
									"TotalAmount is displayed as "
											+ input.get("TotalAmount") + " ");
							;

						} else if (input.get("RemitInformation").contains(line)) {
							passed("Verifying the RemitInformation in pdf",
									"RemitInformation should be displayed as "
											+ input.get("RemitInformation")
											+ " ",
									"RemitInformation is displayed as "
											+ input.get("RemitInformation")
											+ " ");
							;

						}

					}
				}

				//uiDriver.webDr.close();

			}
			//uiDriver.webDr.switchTo().window(presentwindow);
			//uiDriver.executeJavaScript("scroll(0,-1000)");
			// uiDriver.switchToWindow("Invoice - NetSuite (NBCUniversal Media, LLC 10K QA)");

		
	

	/****************************************
	 * Name: VerifyPDFdeleivery Description: VerifyPDFdeleivery Date:
	 * 30-Nov-2017
	 ****************************************/

	public void VerifyPDFdelivery(DataRow input, DataRow output) {
		uiDriver.click("Communication");
		String deliverytype = uiDriver.getValue("type");

	}

	/****************************************
	 * Name: NavigatetoInvoice Description: NavigatetoInvoice Date: 23-July-2018
	 ****************************************/
	public void NavigatetoInvoice(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.MEDIUM);
		String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		SleepUtils.sleep(5);
		uiDriver.refresh();
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("relatedRecord");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("invoiceNo");
		SleepUtils.sleep(TimeSlab.LOW);
		SleepUtils.sleep(TimeSlab.LOW);
		String InvoiceNum = uiDriver.getValue("invoicenum");
		output.put("InvoiceNum", InvoiceNum);
		// uiDriver.click("writeOffRemainingAmount");
		// SleepUtils.sleep(TimeSlab.MEDIUM);
		// uiDriver.click("goback");
		// SleepUtils.sleep(TimeSlab.LOW);
	}

	/****************************************
	 * Name: AcceptPaymentForMultipleInvoices Description:
	 * AcceptPaymentForMultipleInvoices Date: 30-Nov-2017
	 ****************************************/
	public void acceptPaymentForMultipleInvoices(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.setFrame("frame");
		uiDriver.mouseOver("transactions");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("CustomerPay");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("AcceptPayment");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.YIELD);

		uiDriver.click("AcceptPayment");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.YIELD);
		String cust = input.get("customer");
		uiDriver.click("customerdropdownimage");
		SleepUtils.sleep(5);
		uiDriver.click("customerlist");
		SleepUtils.sleep(5);
		uiDriver.setValue("searchcustomerinput", cust);
		SleepUtils.sleep(5);
		uiDriver.click("searchcustomerbutton");
		SleepUtils.sleep(5);
		uiDriver.click("cussearchresult");
		uiDriver.click("acctradiobutton");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("Account", "30 Undeposited Funds");
		SleepUtils.sleep(TimeSlab.YIELD);
		String InvoiceNum = input.get("invoicenumber");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("scroll(0,900);");
		SleepUtils.sleep(TimeSlab.YIELD);
		String ReferenceNum = uiDriver.getDyanmicData("ReferenceNum");
		SleepUtils.sleep(TimeSlab.YIELD);
		String ReferenceVal = ReferenceNum.replace("#", InvoiceNum);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click_dynamic(ReferenceVal);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("saveacceptPayment");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("action");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Glimpact");
	}

	/****************************************
	 * Name: ReadInvoice Description:ReadInvoice Date: 30-Nov-2017
	 * 
	 * @return
	 ****************************************/
	public void ReadInvoice(DataRow input, DataRow output)
			throws InterruptedException {
		/*
		 * SleepUtils.sleep(TimeSlab.HIGH); String Num = input.get("conf");
		 * uiDriver.setValue("SearchSO", Num);
		 * SleepUtils.sleep(TimeSlab.MEDIUM); uiDriver.click("SalesOrder");
		 * passed("SalesOrder", "SalesOrder Should be displayed Successfully",
		 * "SalesOrder is displayed Successfully"); SleepUtils.sleep(5);
		 * uiDriver.refresh();
		 */
		uiDriver.executeJavaScript("scroll(0,400)");
		uiDriver.click("relatedRecord");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//*[@id='linksheader']/td[3]/div");
		List<WebElement> Inv = uiDriver.webDr
				.findElements(By
						.xpath("//*[@id='links_splits']/tbody//td[text()='Invoice']/../td[3]"));
		int invoiceSize = Inv.size();
		String invSize = Integer.toString(invoiceSize);
		output.put("InvoiceSize", invSize);
		for (int i = 0; i < invoiceSize; i++) {
			String ele = Inv.get(i).getText();
			System.out.println(ele);
			output.put("invoice" + i, ele);

		}

	}
	
	
	/****************************************
	 * Name: ReadInvoicebyamount Description:ReadInvoice Date: 30-Nov-2017
	 * 
	 * @return
	 ****************************************/
	public void ReadInvoicebyamount(DataRow input, DataRow output)
			throws InterruptedException {
		/*
		 * SleepUtils.sleep(TimeSlab.HIGH); String Num = input.get("conf");
		 * uiDriver.setValue("SearchSO", Num);
		 * SleepUtils.sleep(TimeSlab.MEDIUM); uiDriver.click("SalesOrder");
		 * passed("SalesOrder", "SalesOrder Should be displayed Successfully",
		 * "SalesOrder is displayed Successfully"); SleepUtils.sleep(5);
		 * uiDriver.refresh();
		 */
		uiDriver.executeJavaScript("scroll(0,400)");
		uiDriver.click("//*[contains(text(),'elated Records')]");
		SleepUtils.sleep(TimeSlab.LOW);
		
		String invoices = uiDriver.getDyanmicData("invoice");
		String invoiceAmt = invoices.replace("#", input.get("invoiceAmount")); 
		List<WebElement> Inv = uiDriver.webDr.findElements(By.xpath(invoiceAmt));		
		int invoiceSize = Inv.size();
		String invSize = Integer.toString(invoiceSize);
		output.put("InvoiceSize", invSize);
		for (int i = 0; i < invoiceSize; i++) {
			String ele = Inv.get(i).getText();
			System.out.println(ele);
			output.put("invoice" + i, ele);

		}

	}

	/****************************************
	 * Name: ReadSingleInvoice 
	 * Description:ReadSingleInvoice 
	 * Date: 30-Nov-2017
	 * @return
	 ****************************************/
	public void ReadSingleInvoice(DataRow input, DataRow output)
			throws InterruptedException {

		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.executeJavaScript("scroll(0,400)");
		uiDriver.click("//span[text()='R']");
		SleepUtils.sleep(TimeSlab.LOW);
		List<WebElement> Inv = uiDriver.webDr
				.findElements(By
						.xpath("//*[@id='links_splits']/tbody//td[text()='Invoice']/../td[3]"));
		int invoiceSize = Inv.size();
		String invSize = Integer.toString(invoiceSize);
		output.put("InvoiceSize", invSize);
	//	String invoice = uiDriver.getValue_Text("//td[text()='30,000.00']/../td[3]");
		String invoices = uiDriver.getDyanmicData("Invoices");
		String invoiceAmt = invoices.replace("#", input.get("invoiceAmount")); 
		String invoice = uiDriver.getValueByText(invoiceAmt);
		output.put("invoice", invoice);

	}

	/****************************************
	 * Name: WriteInvoice Description:ReadInvoice Date: 30-Nov-2017
	 * 
	 * @return
	 ****************************************/
	/*
	 * public void WriteInvoice(DataRow input, DataRow output) throws
	 * InterruptedException {
	 * 
	 * List<String> i=ReadInvoice(input,output); for(int j=0;j<i.size();j++){
	 * 
	 * i.get(j);
	 * 
	 * 
	 * 
	 * }
	 * 
	 * }
	 */

	/****************************************
	 * Name: NavigateToChangeInvoiceStatus
	 * Description: NavigateToChangeInvoiceStatus 
	 * Date: 13-July-2018
	 ****************************************/
	public void NavigateToChangeInvoiceStatus(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Invoices");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("BulkOperations");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("ChangeWFStates");
		SleepUtils.sleep(TimeSlab.HIGH);
		//SleepUtils.sleep(TimeSlab.HIGH);
		//SleepUtils.sleep(TimeSlab.HIGH);
		//SleepUtils.sleep(TimeSlab.HIGH);
		//SleepUtils.sleep(TimeSlab.HIGH);
		//SleepUtils.sleep(TimeSlab.HIGH);
		while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
			SleepUtils.sleep(TimeSlab.YIELD);
		}
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);

		uiDriver.click("Filter");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("searchinput");
		String ContractId = input.get("ContractId");
		uiDriver.setValue("searchinput", input.get("ContractId"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//*[@id=\"advancedSearchButton\"]");
		//uiDriver.sendKey("enter");
		//uiDriver.sendKey("enter");
		SleepUtils.sleep(TimeSlab.MEDIUM);
	}

	/****************************************
	 * Name: ChangeInvoiceStatusForMultipleInvoices Description:
	 * ChangeInvoiceStatusForMultipleInvoices Date: 13-July-2018
	 ****************************************/
	public void ChangeInvoiceStatusForMultipleInvoices(DataRow input,
			DataRow output) {
		SleepUtils.sleep(TimeSlab.HIGH);
		String ContractId = input.get("ContractId");
		String ContractNum = uiDriver.getDyanmicData("Contractnumber");
		SleepUtils.sleep(TimeSlab.YIELD);
		String ContractNumber = ContractNum.replace("#", ContractId);
		List<WebElement> ele = uiDriver.webDr.findElements(By
				.xpath(ContractNumber));
		int rowSize = ele.size();
		for (int n = 0; n < rowSize; n++) {
			String ContractNum1 = uiDriver.getDyanmicData("Contractnumber1");
			String ContractNumber1 = ContractNum1.replace("#", ContractId);
			String RowContractNum = ContractNumber1.replace("$",
					Integer.toString(n + 1));
			WebElement ele1 = uiDriver.webDr.findElement(By
					.xpath(RowContractNum));
			SleepUtils.sleep(TimeSlab.LOW);
			ele1.click();
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.executeJavaScript("scroll(0,-1000)");
			uiDriver.click("Invoicedropdown");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("SendforInvoice");
			uiDriver.click("SendforInvoice");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("Transitiontoworkflow");
			SleepUtils.sleep(TimeSlab.HIGH);
			passed("Verify the Invoice is posted",
					"Invoice posted successfully",
					"Invoice posted successfully");
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);

		}

	}

	/****************************************
	 * Name: ChangeInvoiceStatusForMultipleInvoices Description:
	 * ChangeInvoiceStatusForMultipleInvoices Date: 13-July-2018
	 ****************************************/
	public void ChangeInvoiceStatusForpartialInvoices(DataRow input,
			DataRow output) {
		SleepUtils.sleep(TimeSlab.HIGH);
		String ContractId = input.get("ContractId");
		String ContractNum = uiDriver.getDyanmicData("Contractnumber");
		SleepUtils.sleep(TimeSlab.YIELD);
		String ContractNumber = ContractNum.replace("#", ContractId);
		//List<WebElement> ele = uiDriver.webDr.findElements(By
				//.xpath(ContractNumber));
		int rowSize = Integer.parseInt(input.get("invoicecount"));
		uiDriver.click("//span[text()='Due Date']");
		if(uiDriver.checkElementPresent("//span[text()='Due Date']/following-sibling::span[@class='k-icon k-i-sort-asc-sm']"))
		{
			passed("Verifying the  invoices are in ascending order",
					"invoice are in ascending order of due dates'"
							,
					"invoice are in ascending order of due dates");
		}
		else
		{
			uiDriver.click("//span[text()='Due Date']");
			SleepUtils.sleep(TimeSlab.YIELD);
			if(uiDriver.checkElementPresent("//span[text()='Due Date']/following-sibling::span[@class='k-icon k-i-sort-asc-sm']"))
			{
				passed("Verifying the  invoices are in ascending order",
						"invoice are in ascending order of due dates'"
								,
						"invoice are in ascending order of due dates");
			}
		}
		for (int n = 0; n < rowSize; n++) {
			String ContractNum1 = uiDriver.getDyanmicData("Contractnumber1");
			String ContractNumber1 = ContractNum1.replace("#", ContractId);
			String RowContractNum = ContractNumber1.replace("$",
					Integer.toString(n + 1));
			WebElement ele1 = uiDriver.webDr.findElement(By
					.xpath(RowContractNum));
			SleepUtils.sleep(TimeSlab.LOW);
			ele1.click();
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.executeJavaScript("scroll(0,-1000)");
			uiDriver.click("Invoicedropdown");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("SendforInvoice");
			uiDriver.click("SendforInvoice");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("Transitiontoworkflow");
			while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			passed("Verify the Invoice is posted",
					"Invoice posted successfully",
					"Invoice posted successfully");
					}
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.HIGH);
		
		SleepUtils.sleep(TimeSlab.MEDIUM);
		
	}

	
	
	/****************************************
	 * Name: ChangeInvoiceStatusForMultipleInvoices Description:
	 * ChangeInvoiceStatusForMultipleInvoices Date: 13-July-2018
	 ****************************************/
	public void ChangeInvoiceStatusForSpecifiedInvoices(DataRow input,
			DataRow output) {
		SleepUtils.sleep(TimeSlab.HIGH);
		String amount = input.get("amount");
		String amount1 = uiDriver.getDyanmicData("amount");
		SleepUtils.sleep(TimeSlab.YIELD);
		String amount2 = amount1.replace("#", amount);
		uiDriver.click_dynamic(amount2);
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.executeJavaScript("scroll(0,-1000)");
			uiDriver.click("Invoicedropdown");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("SendforInvoice");
			uiDriver.click("SendforInvoice");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("Transitiontoworkflow");
			SleepUtils.sleep(TimeSlab.HIGH);
			String invoicestatus=uiDriver.getDyanmicData("invoicestatus");
			String invstatus = invoicestatus.replace("#", amount);
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.refresh();
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Filter");
			SleepUtils.sleep(TimeSlab.HIGH);
		     uiDriver.click("searchinput");
		     SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.setValue("searchinput", input.get("ContractId"));
			SleepUtils.sleep(TimeSlab.MEDIUM);
		
			uiDriver.click("Search");
			while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			for(int i=0;i<50;i++)
			{
				 List<WebElement> lst = uiDriver.webDr.findElements(By.xpath("//table[@role='grid']//tbody//tr//td[11]"));
				 
				 List<WebElement> lstpostedsuccessfully = uiDriver.webDr.findElements(By.xpath("//table[@role='grid']//tbody//tr//td[text()='Posted Successfully']"));
				 
				 if(lst.size()==lstpostedsuccessfully.size())
				 {
					 passed("Verify the Invoice is posted", "Invoice posted successfully",
								"Invoice posted successfully");
					 break;
				 }
				 else
				 {
					 uiDriver.refresh();
						while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
							SleepUtils.sleep(TimeSlab.YIELD);
						}
						uiDriver.click("Filter");
						SleepUtils.sleep(TimeSlab.MEDIUM);
					     uiDriver.click("searchinput");
						uiDriver.setValue("searchinput", input.get("ContractId"));
						SleepUtils.sleep(TimeSlab.MEDIUM);
						uiDriver.click("Search");
						while(uiDriver.checkElementPresent("//div[@class='loading-message']")) {
							SleepUtils.sleep(TimeSlab.YIELD);
				 }
				 
				 }
			}
			
			for(int i=1;i<=50;i++)
			{
				String invstatus1=uiDriver.getValueByText(invstatus);
				if (invstatus1.equalsIgnoreCase("Posted Successfully")) {

					passed("Verifying the  invoice Status",
							"Sales order Status should be displayed as Posted Successfully'"
									,
							"Sales order Status is Posted Successfully");
					break;
				} 
				else if(invstatus1.equalsIgnoreCase("Error:Contract Processing")||invstatus1.startsWith("Error"))
				
				{
					failed("Verifying the  invoice Status",
							"Sales order Status should be displayed as Posted Successfully'"
									,
							"Sales order Status is Error:Invoice");
					break;
				}
					else {
				
					
					uiDriver.click("Filter");
					SleepUtils.sleep(TimeSlab.HIGH);
					uiDriver.click("searchinput");
					String ContractId = input.get("ContractId");
					uiDriver.setValue("searchinput", input.get("ContractId"));
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("//*[@id=\"advancedSearchButton\"]");
				}
			}
			

		}
		
	/****************************************
	* Name: AddFeeCalculationInput
	* Description: AddFeeCalculationInput 
	* Date: 23-April-2019
	****************************************/
	public void AddFeeCalculationInput(DataRow input, DataRow output) 
	{
	SleepUtils.sleep(TimeSlab.MEDIUM);
	uiDriver.click("Finance");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("FeeCalculation");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("Input");
	SleepUtils.sleep(TimeSlab.YIELD);
	for(int i=1;i<=11;i++)
	{
	uiDriver.click("Addinput");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("Projectcatagory");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("Select");
	SleepUtils.sleep(TimeSlab.YIELD);
	String xpath="//li[contains(text(),'#')]";
	String project=input.get("Project"+i);
	String newxpath=xpath.replace("#", project);
	uiDriver.click(newxpath);
	//uiDriver.click("//ul[@class='k-list k-reset']/li["+i+"])[2]");
	//uiDriver.click("CurrentMegahit");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("Inputtype");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("Select");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("Inputtypevalue");
	SleepUtils.sleep(TimeSlab.HIGH);
	uiDriver.click("//*[@id='contract-fee-calc-inputs-grid']/div[3]/table/tbody/tr/td[5]/input");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("Amount");
	SleepUtils.sleep(TimeSlab.YIELD);
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.webDr.findElement(By.xpath("//input[@name='Amount']")).clear();
	SleepUtils.sleep(TimeSlab.HIGH);
	//uiDriver.webDr.findElement(By.xpath("(//input[@type='text'])[1]")).click();
	//SleepUtils.sleep(TimeSlab.YIELD);
	String amount=input.get("amount"+i);
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.setText(amount);
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("Savechanges");
	SleepUtils.sleep(TimeSlab.HIGH);
	}
	if(input.get("guaranteesubs").equals("Y"))
	{
	uiDriver.click("Addinput");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("Inputtype");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("Select");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("InputGuaranteedSubs");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("Amount");
	SleepUtils.sleep(TimeSlab.YIELD);
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.webDr.findElement(By.xpath("//input[@name='Amount']")).clear();
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.webDr.findElement(By.xpath("(//input[@type='text'])[1]")).click();
	SleepUtils.sleep(TimeSlab.YIELD);
	String Guaranteedamount=input.get("GuaranteedSubsamount");
	uiDriver.setText(Guaranteedamount);
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("Savechanges");
	}
	}


	/****************************************
	* Name: SingleSubscribermapping
	* Description: Single Subscribers Mapping 
	* Date: 23-April-2019
	****************************************/
	public void SingleSubscribermappingNZL(DataRow input, DataRow output) 
	{
	SleepUtils.sleep(TimeSlab.MEDIUM);
	uiDriver.click("Finance");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("FeeCalculation");
	SleepUtils.sleep(TimeSlab.YIELD);
	//uiDriver.click("FeeCalculation");
	//SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("Statements");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("dropdown");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("SingleSubscriber");
	SleepUtils.sleep(TimeSlab.YIELD);
	uiDriver.click("Save");
	/*String subscribers=uiDriver.getValueByText("//td[text()='Single Subscriber']");
	passed("Single Subscriber info", "Single Subscriber Should be exists",
	"Single Subscriber is displayed");*/
	SleepUtils.sleep(TimeSlab.YIELD);
	}




	public void ChangeInvoiceStatusForSpecifiedamounts(DataRow input,
			DataRow output) {
		
		String amount = input.get("amount");
		String amount1 = uiDriver.getDyanmicData("amount");
		SleepUtils.sleep(TimeSlab.YIELD);
		String amount2 = amount1.replace("#", amount);
		List<WebElement> ele = uiDriver.webDr.findElements(By
				.xpath(amount2));
		for(int i=0;i<ele.size();i++)
		{
			ele.get(i).click();
		}
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.executeJavaScript("scroll(0,-1000)");
			uiDriver.click("Invoicedropdown");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("SendforInvoice");
			uiDriver.click("SendforInvoice");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("Transitiontoworkflow");
			SleepUtils.sleep(TimeSlab.HIGH);
		
			String invoicestatus=uiDriver.getDyanmicData("invoicestatus");
			String invstatus = invoicestatus.replace("#", amount);
			
			
			for(int i=1;i<=50;i++)
			{
				String invstatus1=uiDriver.getValueByText(invstatus);
				if (invstatus1.equalsIgnoreCase("Posted Successfully")) {

					passed("Verifying the  invoice Status",
							"Sales order Status should be displayed as Posted Successfully'"
									,
							"Sales order Status is Posted Successfully");
					break;
				} 
				else if(invstatus1.equalsIgnoreCase("Error:Contract Processing")||invstatus1.startsWith("Error"))
				
				{
					failed("Verifying the  invoice Status",
							"Sales order Status should be displayed as Posted Successfully'"
									,
							"Sales order Status is Error:Invoice");
					break;
				}
					else {
				
				uiDriver.refresh();
				SleepUtils.sleep(TimeSlab.HIGH);
				SleepUtils.sleep(TimeSlab.HIGH);
				SleepUtils.sleep(TimeSlab.HIGH);
					uiDriver.click("Filter");
					SleepUtils.sleep(TimeSlab.HIGH);
					uiDriver.click("searchinput");
					String ContractId = input.get("ContractId");
					uiDriver.setValue("searchinput", input.get("ContractId"));
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("//*[@id=\"advancedSearchButton\"]");
				}
			}
			

		}
		


	/****************************************
	 * Name: verifyARMRinvoicestatus
	 * Description:Method to verify ARMR invoice status
	 *  Date:30-Nov-2017 
	 ****************************************/
    public void verifyARMRinvoicestatus(DataRow input, DataRow output) throws InterruptedException 
    {
    	String amount1 = uiDriver.getDyanmicData("//*[text()='#']/..//td[11]");
		SleepUtils.sleep(TimeSlab.YIELD);
		String amount=input.get("amount");
		String amount2 = amount1.replace("#", amount);
		String status=uiDriver.getValueByText(amount2);
		for(int i=0;i<50;i++)
		{
		if(status.equalsIgnoreCase("Posted Succesfully"))
		{
			passed("Verify the Invoice is posted",
					"Invoice posted successfully",
					"Invoice posted successfully");
		
		}
		else
		{
			uiDriver.refresh();
			uiDriver.click("//*[@id='CriteriaContainer']/div[1]/div/span[1]/..");
			SleepUtils.sleep(5);
			uiDriver.setValue("//*[@id='CriteriaContainer']/div[1]/ul/li[1]/input",input.get("contract"));
			SleepUtils.sleep(5);
			uiDriver.click("//*[@id='advancedSearchButton']");
			
				
		}
		}
    }
	 /****************************************
		 * Name: NavigateToInvoiceScreen
		 * Description:Method to Navigate To Invoice Screen
		 *  Date:30-Nov-2017 
		 ****************************************/
	    public void NavigateToRevisedInvoice(DataRow input, DataRow output) throws InterruptedException 
	    {
	    	SleepUtils.sleep(TimeSlab.MEDIUM);
	    	String Num = input.get("conf");
			uiDriver.setValue("SearchSO", Num);
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("SalesOrder");
			passed("SalesOrder", "SalesOrder Should be displayed Successfully",
					"SalesOrder is displayed Successfully");
			SleepUtils.sleep(5);
			uiDriver.refresh();
			uiDriver.executeJavaScript("scroll(0,500)");
			uiDriver.click("relatedRecord");
			String invoice=uiDriver.getDyanmicData("invoice");
			String invoice1 = invoice.replace("#", input.get("amount"));
			uiDriver.click_dynamic(invoice1);
			//uiDriver.click("invoiceNo");
			passed("InvoiceNo", "InvoiceNo Should be Clicked Successfully",
					"InvoiceNo is Clicked Successfully");
			String invoicenumber=uiDriver.getValue("Invoicenum");
			output.put("InvoiceNum", invoicenumber);
			String Masterinvoice = invoicenumber.substring(0, invoicenumber.length()-1);
			output.put("MasterInvoice", Masterinvoice);
	    }
			 
	
	/****************************************
	 * Name: VerifyRevPlanDates Description: VerifyRevPlanDates Date:
	 * 13-July-2018
	 * 
	 * @throws ParseException
	 ****************************************/
	public void VerifyRevPlanDates(DataRow input, DataRow output)
			throws ParseException {
		int planRows = uiDriver.webDr
				.findElements(
						By.xpath("(//*[@class='uir-machine-table'])[1]/tbody/tr[contains(@class,'uir-machine-row uir-machine-row')]"))
				.size();
		String viewicon = uiDriver.getDyanmicData("viewicon");
		String viewicon1 = viewicon.replace("#", Integer.toString(i));
		uiDriver.executeJavaScript("window.scrollBy(0,500)");
		WebElement ele = uiDriver.webDr.findElement(By.xpath(viewicon1));
		String ele1 = "(//*[@class='uir-machine-table'])[1]/tbody/tr[2]/td[17]";
		WebElement ele2 = uiDriver.webDr.findElement(By.xpath(ele1));
		Actions action = new Actions(uiDriver.webDr);
		action.moveToElement(ele2).build().perform();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click_dynamic(viewicon1);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setFrame("iconframe");
		SleepUtils.sleep(TimeSlab.YIELD);
		String actualRevRecStartDate = uiDriver.getValue("RevRecStartDate");
		String actualRevRecEndDate = uiDriver.getValue("RevRecEndDate");
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy ");
		Date date = new Date();
		String date1 = dateFormat.format(date);
		if (actualRevRecStartDate.contains(date1)) {
			passed("Verifying the Revenue Recognition StartDate",
					"Revenue Recognition StartDate should be displayed as "
							+ actualRevRecStartDate + " ",
					"Revenue Recognition StartDate is displayed as "
							+ actualRevRecStartDate + " ");
			;

		} else {
			failed("Verifying the Revenue Recognition StartDate",
					"Revenue Recognition StartDate should be displayed as "
							+ actualRevRecStartDate + " ",
					"Revenue Recognition StartDate is not displayed as "
							+ actualRevRecStartDate + " ");
			;

		}

		if (actualRevRecEndDate.contains(date1)) {
			passed("Verifying the Revenue Recognition EndDate",
					"Revenue Recognition EndDate should be displayed as "
							+ actualRevRecEndDate + " ",
					"Revenue Recognition EndDate is displayed as "
							+ actualRevRecEndDate + " ");
			;

		} else {
			failed("Verifying the Revenue Recognition EndDate",
					"Revenue Recognition EndDate should be displayed as "
							+ actualRevRecEndDate + " ",
					"Revenue Recognition EndDate is not displayed as "
							+ actualRevRecEndDate + " ");
			;

		}

	}

	/****************************************
	 * Name: NavigateToPaymentWizard 
	 * Description: NavigateToPaymentWizard 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void NavigateToPaymentWizard(DataRow input, DataRow output)
			throws InterruptedException

	{
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.mouseOver("transactions");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Customer");
		SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("ScrollDown");
		// SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("PaymentWizard");
		SleepUtils.sleep(TimeSlab.YIELD);
	}

	/****************************************
	 * Name: CreateUnpaidtounbilled
	 * Description: CreateUnpaidtounbilled 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void CreateUnpaidtounbilled(DataRow input, DataRow output)
			throws InterruptedException

	{
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.mouseOver("Customization");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Scripting");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Scripts");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Scripts");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.LOW);
		if(uiDriver.checkElementPresent("EditUnpaidtoUnbilled"))
		{
			uiDriver.click("EditUnpaidtoUnbilled");
		}
		else
		{
		uiDriver.click("dropdownbtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("NBCUFMV");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("EditUnpaidtoUnbilled");
		SleepUtils.sleep(TimeSlab.LOW);
		}
		uiDriver.click("Deployments");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("NBCUFMVCALCENGINE");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("EditScript");
		SleepUtils.sleep(TimeSlab.LOW);
		if(uiDriver.checkElementPresent("SaveAndExecute"))
		{	
			uiDriver.click("SaveAndExecute");
			uiDriver.handleAlert("", "OK");
		}
		else{
			for(int i=0;i<=50;i++){
				SleepUtils.sleep(30);
				uiDriver.refresh();		
				uiDriver.mouseOver("dropdown");
				System.out.println("***********************"+i);
				if(uiDriver.checkElementPresent("SaveAndExecute"))
				{	
					uiDriver.click("SaveAndExecute");
					uiDriver.handleAlert("", "OK");
					break;
				}
					
				
			}	
			}
		uiDriver.refresh();	
		SleepUtils.sleep(30);
		uiDriver.refresh();	
		for(int i=0;i<=50;i++){
			SleepUtils.sleep(30);
			uiDriver.refresh();			
			System.out.println("***********************"+i);
			System.out.println(uiDriver.getValue("Status"));
			if(uiDriver.getValue("Status").equalsIgnoreCase("Complete"))
				passed("Verify CompleteStatus",
						"CompleteStatus should be displayed successfully",
						"CompleteStatus is not displayed successfully");
			break;
			
		}	
  		
		

	}

	/****************************************
	 * Name: verifyrevenuedetails 
	 * Description: verifyrevenuedetails 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void verifyrevenuedetails(DataRow input, DataRow output)
			throws InterruptedException

	{
		//String amount = uiDriver.getValue("amount");
		String deferralaccount = uiDriver.getValue("deferredaccount");
		String recognitionaccount = uiDriver.getValue("recognitionaccount");
		//String recognitionstartdate = uiDriver.getValue("recognitionstartdate");
		//String recognitionenddate = uiDriver.getValue("recognitionenddate");
		/*
		 * if(amount.contains(input.get("amount"))) {
		 * 
		 * passed("Verifying the Amount",
		 * "Amount should be displayed as "+amount+" ",
		 * "Amount is displayed as "+input.get("amount")+" ");
		 * 
		 * 
		 * } else { failed("Verifying the Amount",
		 * "Amount should be displayed as "+amount+" ",
		 * "Amount is displayed as "+input.get("amount")+" ");
		 * 
		 * }
		 */
		String billaccount="//a[text()='#']";
		//String billaccount1=uiDriver.getDyanmicData(billaccount);
		String bc = billaccount.replaceAll("#", input.get("deferredaccount"));
		if(uiDriver.checkElementPresent(bc))
		{
			passed("Verifying the deferralaccount",
					"Amount should be displayed as " + deferralaccount + " ",
					"Amount is displayed as " + input.get("deferredaccount")
							+ " ");
		}
		else {
			failed("Verifying the deferralaccount",
					"Amount should be displayed as " + deferralaccount + " ",
					"Amount is displayed as " + input.get("deferredaccount")
							+ " ");

		}
		String ra = billaccount.replaceAll("#", input.get("recognitionaccount"));
		if(uiDriver.checkElementPresent(ra))
		{
			passed("Verifying the recognitionaccount",
					"recognitionaccount should be displayed as "
							+ recognitionaccount + " ",
					"recognitionaccount is displayed as "
							+ input.get("recognitionaccount") + " ");

		} else {
			failed("Verifying the recognitionaccount",
					"recognitionaccount should be displayed as "
							+ recognitionaccount + " ",
					"recognitionaccount is displayed as "
							+ input.get("recognitionaccount") + " ");


		}
		
		

		/*if (deferralaccount.contains(input.get("deferredaccount"))) {

			passed("Verifying the deferralaccount",
					"Amount should be displayed as " + deferralaccount + " ",
					"Amount is displayed as " + input.get("deferredaccount")
							+ " ");

		} else {
			failed("Verifying the deferralaccount",
					"Amount should be displayed as " + deferralaccount + " ",
					"Amount is displayed as " + input.get("deferredaccount")
							+ " ");

		}*/

		/*if (recognitionaccount.contains(input.get("recognitionaccount"))) {

			passed("Verifying the recognitionaccount",
					"recognitionaccount should be displayed as "
							+ recognitionaccount + " ",
					"recognitionaccount is displayed as "
							+ input.get("recognitionaccount") + " ");

		} else {
			failed("Verifying the recognitionaccount",
					"recognitionaccount should be displayed as "
							+ recognitionaccount + " ",
					"recognitionaccount is displayed as "
							+ input.get("recognitionaccount") + " ");

		}*/

		/*
		 * if(recognitionstartdate.contains(input.get("recognitionstartdate")))
		 * {
		 * 
		 * passed("Verifying the recognitionaccount",
		 * "recognitionaccount should be displayed as "
		 * +recognitionstartdate+" ",
		 * "recognitionaccount is displayed as "+input
		 * .get("recognitionstartdate")+" ");
		 * 
		 * 
		 * } else{ failed("Verifying the recognitionaccount",
		 * "recognitionaccount should be displayed as "
		 * +recognitionstartdate+" ",
		 * "recognitionaccount is displayed as "+input
		 * .get("recognitionstartdate")+" ");
		 * 
		 * }
		 * 
		 * 
		 * if(recognitionstartdate.contains(input.get("recognitionenddate"))) {
		 * 
		 * passed("Verifying the recognitionaccount",
		 * "recognitionaccount should be displayed as "+recognitionenddate+" ",
		 * "recognitionaccount is displayed as "
		 * +input.get("recognitionenddate")+" ");
		 * 
		 * 
		 * } else{ failed("Verifying the recognitionaccount",
		 * "recognitionaccount should be displayed as "+recognitionenddate+" ",
		 * "recognitionaccount is displayed as "
		 * +input.get("recognitionenddate")+" ");
		 * 
		 * }
		 */

	}

	/****************************************
	 * Name: AllocateCashtoTitleMapScriptDeployment 
	 * Description:Method to Allocate Cash to TitleMap 
	 * Date:30-Nov-2017
	 ****************************************/
	public void AllocateCashtoTitleMapScriptDeployment(DataRow input,
			DataRow output) throws InterruptedException { // method change
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.mouseOver("Customization");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Scripting");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Scripts");
		SleepUtils.sleep(TimeSlab.YIELD);
		if(uiDriver.checkElementPresent("EditBtnAllocateCashtoTitleMap"))
		{
			uiDriver.click("EditBtnAllocateCashtoTitleMap");
		}
		else
		{
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("EditBtnAllocateCashtoTitleMap");
		}
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("deployments");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("manualscript");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("edit");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.mouseOver("SaveBtndropdown");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("SaveAndExecute");
		uiDriver.handleAlert("", "OK");
		uiDriver.click("refresh");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("refresh");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refresh");
		uiDriver.click("refresh");
		uiDriver.click("refresh");
		uiDriver.click("refresh");
		passed("Verifying the batch job",
				"create cbt batch job should  be excuted", "create cbt batch job is excuted");
	
	}
	/****************************************
	 * Name: AllocateCashtoTitleMapScriptDeployment 
	 * Description:Method to Allocate Cash to TitleMap 
	 * Date:30-Nov-2017
	 ****************************************/
	public void updateairdatescript(DataRow input,
			DataRow output) throws InterruptedException { // method change
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.mouseOver("Customization");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Scripting");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Scripts");
		SleepUtils.sleep(TimeSlab.YIELD);
		for(int i=0;i<=12;i++)
		{
		if(uiDriver.checkElementPresent("Airdatescript"))
		{
			uiDriver.click("Airdatescript");
			break;
		}
		else
		{
		uiDriver.click("Next");
		
		}
		}
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("deployments");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("manualscript");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("edit");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.mouseOver("SaveBtndropdown");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("SaveAndExecute");
		uiDriver.handleAlert("", "OK");
		uiDriver.click("refresh");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("refresh");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("refresh");
 		uiDriver.click("refresh");
		uiDriver.click("refresh");
		uiDriver.click("refresh");
		passed("Verifying the update air datebatch job",
				"update air date batch job should  be excuted", "update air date batch job is excuted");
	
	}


	/****************************************
	 * Name: AllocateCashtoTitleMapScriptDeployment 
	 * Description:Method to Allocate Cash to TitleMap 
	 * Date:30-Nov-2017
	 ****************************************/
	public void updaterevplanscript(DataRow input,
			DataRow output) throws InterruptedException { // method change
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.mouseOver("Customization");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Scripting");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Scripts");
		SleepUtils.sleep(TimeSlab.YIELD);
		for(int i=0;i<=12;i++)
		{
		if(uiDriver.checkElementPresent("updaterevplanscript"))
		{
			uiDriver.click("updaterevplanscript");
			break;
		}
		else
		{
		uiDriver.click("Next");
		
		}
		}
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("deployments");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("manualscript");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("edit");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.mouseOver("SaveBtndropdown");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("SaveAndExecute");
		uiDriver.handleAlert("", "OK");
		uiDriver.click("refresh");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("refresh");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refresh");
		uiDriver.click("refresh");
		uiDriver.click("refresh");
		uiDriver.click("refresh");
		passed("Verifying the batch job",
				"update air date batch job should  be excuted", "pdate air date batch job is excuted");
	
	}
	/****************************************
	 * Name: AcceptPaymentForMultipleInvoices AcceptPaymentForMultipleInvoices
	 * Date: 30-Nov-2017
	 ****************************************/
	/*
	 * public void AcceptPaymentForMultipleInvoices(DataRow input, DataRow
	 * output) throws InterruptedException {
	 * 
	 * List<String> i=ReadInvoice(input,output); for(int j=0;j<i.size();j++){
	 * 
	 * System.out.println(i.get(j));
	 * 
	 * 
	 * }
	 * 
	 * 
	 * 
	 * }
	 */

	/****************************************
	 * Name: CorrectingtheSubsidiaryValue 
	 * Description: CorrectingtheSubsidiaryValue 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void CorrectingtheSubsidiaryValue(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.click("Information");
		uiDriver.click("AdditionalInfo");
		uiDriver.executeJavaScript("document.getElementById('ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_OtherDataAttributeValueGrid_ctl00_ctl14_EditButton').click()");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("document.getElementById('ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_OtherDataAttributeValueGrid_ctl00_ctl15_EditFormControl_ValueStringEdit').value=''");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.setValue("ValueField", input.get("SubsidiaryValue"));
		SleepUtils.sleep(TimeSlab.MEDIUM);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("save");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		passed("Verify the Subsidairy Value",
				"Subsidairy value should be set to F057 Successfully",
				"Subsidairy value is set to F057 Successfully");

	}

	/****************************************
	 * Name: NavigatingToBillingAllocation 
	 * Description:NavigatingToBillingAllocation 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void NavigatingToBillingAllocation(DataRow input, DataRow output)
			throws InterruptedException {

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billing");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Allocation");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Regenerate");
		SleepUtils.sleep(TimeSlab.YIELD);
		String numofbillschedules = input.get("numbill");
		int num = Integer.parseInt(numofbillschedules);
		for (int i = 1; i <= num; i++) {
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("Regenerate");
			SleepUtils.sleep(TimeSlab.HIGH);
			passed("Verifying the billing account generation",
					"Billing Account should be regenerated successfully",
					"Billing Account is regenerated successfully!");

			uiDriver.click("next");
			SleepUtils.sleep(TimeSlab.LOW);
		}

	}

	/****************************************
	 * Name: ApplyPaymentToInvoice1 
	 * Description: ApplyPaymentToInvoice1 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void ApplyPaymentToInvoice1(DataRow input, DataRow output)
			throws InterruptedException

	{
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Subsidiary");
		SleepUtils.sleep(TimeSlab.YIELD);
		String Subsidairy = uiDriver.getDyanmicData("SubsidiaryValue");
		String SubsidairyValue = Subsidairy.replace("#",
				input.get("SubsidairyVal"));
		uiDriver.click_dynamic(SubsidairyValue);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Customer");
		String Customer = uiDriver.getDyanmicData("SubsidiaryValue");
		String CustomerValue = Customer.replace("#", input.get("CustomerVal"));
		uiDriver.click_dynamic(CustomerValue);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("USD");
		SleepUtils.sleep(TimeSlab.HIGH);
		
		
		if(input.get("USD").equals("Y"))
		{
		uiDriver.click("USDValue");
		}
		else
		{
			uiDriver.click("Canadadollar");
		}
		uiDriver.setValue("Account", input.get("Account"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("ARAccount");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("ARAccountValue");
		uiDriver.setValue("PaymentAmount", input.get("PaymentAmount"));
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.setValue(
				"//*[@id='custpage_cash_adj_bank_charges_formattedValue']", "");
		uiDriver.executeJavaScript("document.getElementById('secondarysubmitter').click();");
		SleepUtils.sleep(TimeSlab.HIGH);

		String InvoiceSize = input.get("InvoiceSize");
		int invsize = Integer.parseInt(InvoiceSize);
		if(input.get("USD").equals("Y"))
		{

		for (i = 1; i < invsize; i++) {
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy ");
			Date date = new Date();
			String date1 = dateFormat.format(date);
			// uiDriver.setValue("FromDate",date1 );
			// uiDriver.setValue("Todate",date1 );
			uiDriver.setValue("MI",input.get("invioice" + i).substring(0,input.get("invioice" + i).length() - 1));
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("ApplyFilters");
			SleepUtils.sleep(TimeSlab.HIGH);
			String invchk = uiDriver.getDyanmicData("InvoiceChkbox");
			String invoiceChk = invchk.replace("#", Integer.toString(i));
			uiDriver.click_dynamic(invoiceChk);
			SleepUtils.sleep(TimeSlab.LOW);
			/*
			 * uiDriver.sendKey("selectAll"); SleepUtils.sleep(TimeSlab.YIELD);
			 * uiDriver.sendKey("delete"); SleepUtils.sleep(TimeSlab.YIELD);
			 */
			uiDriver.executeJavaScript("document.getElementById('custpage_sublist_payment"
					+ Integer.toString(i) + "_formattedValue').value='';");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.setValue(invoiceChk, "30000.00");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("//*[@id='custpage_filter_from']");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.executeJavaScript("(scroll(0,-400));");

		}
		}
		else
		{
			uiDriver.setValue("MI",input.get("MasterInvoice"));	
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("ApplyFilters");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("invoice");
		}

		uiDriver.executeJavaScript("document.getElementById('submitter').click();");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
	}
	/****************************************
	 * Name: UnapplyPaymentToInvoice1 Description: UnapplyPaymentToInvoice Date:
	 * 30-Nov-2017
	 ****************************************/
	public void UnapplyPaymentToInvoice(DataRow input, DataRow output)
			throws InterruptedException

	{
		
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Subsidiary");
		SleepUtils.sleep(TimeSlab.YIELD);
		String Subsidairy = uiDriver.getDyanmicData("SubsidiaryValue");
		String SubsidairyValue = Subsidairy.replace("#",
				input.get("SubsidairyVal"));
		uiDriver.click_dynamic(SubsidairyValue);
		
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Customer");
		String Customer = uiDriver.getDyanmicData("SubsidiaryValue");
		String CustomerValue = Customer.replace("#", input.get("CustomerVal"));
		uiDriver.click_dynamic(CustomerValue);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("payment");
		String payment = uiDriver.getDyanmicData("paymentValue");
		String paymentValue = payment.replace("#", input.get("paymentval"));
		uiDriver.click_dynamic(paymentValue);
		SleepUtils.sleep(TimeSlab.YIELD);
		
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.executeJavaScript("document.getElementById('secondarysubmitter').click();");
		SleepUtils.sleep(TimeSlab.MEDIUM);

		
		
			uiDriver.setValue("MI",input.get("MasterInvoice"));	
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("ApplyFilters");
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("invoice");
		

		uiDriver.executeJavaScript("document.getElementById('submitter').click();");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
	}

	/****************************************
	 * Name: UnapplyPaymentTomultipleInvoice Description: UnapplyPaymentToInvoice Date:
	 * 30-Nov-2017
	 ****************************************/
	public void UnapplyPaymentTomultipleInvoice(DataRow input, DataRow output)
			throws InterruptedException

	{
		
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Subsidiary");
		SleepUtils.sleep(TimeSlab.YIELD);
		String Subsidairy = uiDriver.getDyanmicData("SubsidiaryValue");
		String SubsidairyValue = Subsidairy.replace("#",
				input.get("SubsidairyVal"));
		uiDriver.click_dynamic(SubsidairyValue);
		
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Customer");
		String Customer = uiDriver.getDyanmicData("SubsidiaryValue");
		String CustomerValue = Customer.replace("#", input.get("CustomerVal"));
		uiDriver.click_dynamic(CustomerValue);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("payment");
		String payment = uiDriver.getDyanmicData("paymentValue");
		String paymentValue = payment.replace("#", input.get("paymentval"));
		uiDriver.click_dynamic(paymentValue);
		SleepUtils.sleep(TimeSlab.YIELD);
		
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.executeJavaScript("document.getElementById('secondarysubmitter').click();");
		SleepUtils.sleep(TimeSlab.MEDIUM);

		
		String inv1=input.get("invoice1").substring(0, input.get("invoice1").length()-1);
			uiDriver.setValue("MI",inv1);	
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("ApplyFilters");
			//SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.LOW);
			
			String invchkbox=uiDriver.getDyanmicData("invoice");
			String invoicechkbox = invchkbox.replace("#", inv1);
			uiDriver.click_dynamic(invoicechkbox);
			
			String inv2=input.get("invoice2").substring(0, input.get("invoice2").length()-1);
			uiDriver.setValue("MI",inv2);
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("ApplyFilters");
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.LOW);
			
			String invchkbox1=uiDriver.getDyanmicData("invoice");
			String invoicechkbox1 = invchkbox1.replace("#", inv2);
			uiDriver.click_dynamic(invoicechkbox1);
			
			
		uiDriver.executeJavaScript("document.getElementById('submitter').click();");

		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
	}

	/****************************************
	 * Name: ApplyPaymentToInvoice 
	 * Description: ApplyPaymentToInvoice 
	 * Date: 30-Nov-2017
	 ****************************************/

	public void ApplyPaymentToInvoice(DataRow input, DataRow output)
			throws InterruptedException

	{
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Subsidiary");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("SubsidiaryValue");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Customer");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("CustomerValue");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("USD");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("USDValue");
		uiDriver.setValue("Account", "TBD");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("ARAccount");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("ARAccountValue");
		uiDriver.setValue("PaymentAmount", "69333.28");
		uiDriver.click("NextPage");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String InvoiceSize = input.get("InvoiceSize");
		int invsize = Integer.parseInt(InvoiceSize);
		for (i = 1; i < invsize; i++) {
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy ");
			Date date = new Date();
			String date1 = dateFormat.format(date);
			// uiDriver.setValue("FromDate",date1 );
			// uiDriver.setValue("Todate",date1 );
			uiDriver.setValue(
					"MI",
					input.get("invioice" + i).substring(0,
							input.get("invioice" + i).length() - 1));
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("ApplyFilters");
			SleepUtils.sleep(TimeSlab.HIGH);
			String invchk = uiDriver.getDyanmicData("InvoiceChkbox");
			String invoiceChk = invchk.replace("#", Integer.toString(i));
			uiDriver.click_dynamic(invoiceChk);
			SleepUtils.sleep(TimeSlab.LOW);
			/*
			 * uiDriver.sendKey("selectAll"); SleepUtils.sleep(TimeSlab.YIELD);
			 * uiDriver.sendKey("delete"); SleepUtils.sleep(TimeSlab.YIELD);
			 */
			uiDriver.executeJavaScript("document.getElementById('custpage_sublist_payment"
					+ Integer.toString(i) + "_formattedValue').value='';");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.setValue(invoiceChk, "8666.66");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.executeJavaScript("(scroll(0,-400));");

		}
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.executeJavaScript("document.getElementById('submitter').click();");
		SleepUtils.sleep(TimeSlab.MEDIUM);
	}

	/****************************************
	 * Name: ChangeRoleToQA10K
	 * Description: Changing the role from administrator to QA
	 * Date: 30-Nov-2017
	 ****************************************/
	public void ChangeRoleToQA10K(DataRow input, DataRow output)
	{
		SleepUtils.sleep(10);
		uiDriver.mouseOver("Profile");
		SleepUtils.sleep(5);
		uiDriver.click("QA");
		SleepUtils.sleep(5);
		if(uiDriver.checkElementPresent("QARole")){
		//uiDriver.click("Manager1");
				passed("Verify Changing the role to QA",
				"QA Role must be changed Successfully",
				"QA Role is changed Successfully");
		SleepUtils.sleep(5);
		}
	}
		/****************************************
		 * Name: verifymultipleinvoicetype
		 * Description: Changing the role from administrator to ChangeRoleToManager2UAT
		 * Date: 30-Nov-2017
		 ****************************************/
		public void verifymultipleinvoicetype(DataRow input, DataRow output)
		{
			
		}
		
	
	
	/****************************************
	 * Name: ChangeRoleToManager2UAT
	 * Description: Changing the role from administrator to ChangeRoleToManager2UAT
	 * Date: 30-Nov-2017
	 ****************************************/
	public void ChangeRoleToManager2UAT(DataRow input, DataRow output)
	{
		SleepUtils.sleep(10);
		uiDriver.mouseOver("Profile");
		SleepUtils.sleep(5);
		uiDriver.click("Manager2UAT");
		SleepUtils.sleep(5);
		if(uiDriver.checkElementPresent("Manager2UATRole")){
		//uiDriver.click("Manager1");
				passed("Verify Changing the role to Manager2UATRole",
				"Manager2UATRole Role must be changed Successfully",
				"Manager2UATRole Role is changed Successfully");
		SleepUtils.sleep(5);
		}
	}	
	
	
	public void ChangeRoleToManager1UAT(DataRow input, DataRow output)
	{
		SleepUtils.sleep(10);
		uiDriver.mouseOver("Profile");
		SleepUtils.sleep(5);
		uiDriver.click("Manager1UAT");
		SleepUtils.sleep(5);
		if(uiDriver.checkElementPresent("Manager1UATRole")){
		//uiDriver.click("Manager1");
				passed("Verify Changing the role to ChangeRoleToManager1UAT",
				"ChangeRoleToManager1UAT Role must be changed Successfully",
				"ChangeRoleToManager1UAT Role is changed Successfully");
		SleepUtils.sleep(5);
		}
	}	
	
	public void ChangeRoleToQAUAT(DataRow input, DataRow output)
	{
		SleepUtils.sleep(10);
		uiDriver.click("Profile");
		SleepUtils.sleep(5);
		uiDriver.click("QAUATRole");
		SleepUtils.sleep(5);
		if(uiDriver.checkElementPresent("UATRoleVerify")){
		//uiDriver.click("Manager1");
				passed("Verify Changing the role to QAUAT",
				"QAUAT Role must be changed Successfully",
				"QAUAT Role is changed Successfully");
		SleepUtils.sleep(5);
		}
	}	
	
	
	
	public void VerifyTransactionAllocationDetails(DataRow input, DataRow output)
			throws InterruptedException {
		SleepUtils.sleep(5);
		uiDriver.click("Custom");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,800)");
		if(uiDriver.checkElementPresent("//*[@id='recmachcustrecord_nbcu_titleallocpa_contracttxt']"))
		{
		uiDriver.executeJavaScript("document.getElementById('recmachcustrecord_nbcu_titleallocpa_contracttxt').click();");
		//uiDriver.click("TitleAllocationParent");
		SleepUtils.sleep(TimeSlab.LOW);
		}
		else
		{
			uiDriver.executeJavaScript("document.getElementById('recmachcustrecord_nbcu_titleallocpa_paymenttxt').click();");
		}
		uiDriver.executeJavaScript("scroll(0,1200)");
		SleepUtils.sleep(TimeSlab.LOW);
		String s1;
		  int accRows;
		  /****************** If else added *****************/ 
		  if(uiDriver.checkElementPresent_dynamic("//table[@id='recmachcustrecord_nbcu_titleallocpa_contract__tab']/tbody/tr")) {
		  accRows = uiDriver.webDr.findElements(By.xpath("//table[@id='recmachcustrecord_nbcu_titleallocpa_contract__tab']/tbody/tr")).size();
		    s1 = uiDriver.getDyanmicData("DynamicTapid");
		  }
		  else {
		    accRows = uiDriver.webDr.findElements(By.xpath("(//table[@id='recmachcustrecord_nbcu_titleallocpa_payment__tab']/tbody/tr)[2]")).size();
		     s1 = uiDriver.getDyanmicData("DynamicTapidpayment");
		   
		  }
		  
		
		SleepUtils.sleep(TimeSlab.HIGH);
		for (int r = 0; r < accRows; r++) {

			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.executeJavaScript("scroll(0,900)");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			//String s1 = uiDriver.getDyanmicData("DynamicTapid");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			String s2 = s1.replace("#", Integer.toString(r));
			//SleepUtils.sleep(TimeSlab.HIGH);
			if (uiDriver.checkElementPresent_dynamic(s2))
				SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click_dynamic(s2);
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.executeJavaScript("scroll(0,500)");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("AllocationDetail");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("Transactions");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			List<WebElement> Journal = uiDriver.webDr
					.findElements(By
							.xpath("//*[@id='recmachcustbody_nbcu_titleallocation__tab']/tbody//tr"));
			SleepUtils.sleep(TimeSlab.MEDIUM);
			int Journals = Journal.size();
			for (int i = 0; i < Journals; i++) {

				SleepUtils.sleep(TimeSlab.MEDIUM);
				String JournalLink = uiDriver.getDyanmicData("Journal");
				String JournalLinkValue = JournalLink.replace("#",
						Integer.toString(i));
				if(uiDriver.checkElementPresent_dynamic(JournalLinkValue))
				{
				uiDriver.click_dynamic(JournalLinkValue);
				SleepUtils.sleep(TimeSlab.MEDIUM);
				int invoiceRow = 2;
				SleepUtils.sleep(TimeSlab.MEDIUM);
				if (uiDriver.getValue(
						"//*[@id='line_splits']//tbody/tr[" + invoiceRow
								+ "]/td[1]").contains(
						"110051XX Generic Billed AR")
						|| uiDriver
								.getValue(
										"//*[@id='line_splits']//tbody/tr["
												+ invoiceRow + "]/td[1]")
								.contains(
										"TBD - Placeholder (First Run) Cash Account for Syndication")) {

					if (uiDriver.getValue(
							"//*[@id='line_splits']//tbody/tr[" + invoiceRow
									+ "]/td[2]").equals(""))

					{

						failed("Validating Debit Amount",

						"Validating Debit Amount should be successfull",

						"Debit amount is not Deferred Rev -Generic ");
					}

					else

					{

						passed("Debit is Deferred Rev - Generic",

								"Debit is Deferred Rev - Generic",

								"Debit amount is 110051XX Generic Billed AR/ TBD - Placeholder (First Run) Cash Account for Syndication");
					}

				}

				SleepUtils.sleep(TimeSlab.HIGH);
				if (uiDriver.getValue(
						"//*[@id='line_splits']//tbody/tr[" + (invoiceRow + 1)
								+ "]/td[1]").contains(
						"11005104 Billed Dom AR - First Run Cash Syn")
						|| uiDriver
								.getValue(
										"//*[@id='line_splits']//tbody/tr["
												+ (invoiceRow + 1) + "]/td[1]")
								.contains(
										"TBD - Placeholder (First Run) Cash Account for Syndication")) {

					if (uiDriver.getValue(
							"//*[@id='line_splits']//tbody/tr["
									+ (invoiceRow + 1) + "]/td[3]").equals("")) {
						failed("Validating Credit Amount",

						"Validating Credit Amount should be successfull",

						"Credit amount is not Generic billed AR");

					} else

					{

						passed("Credit is generic billed AR",

								"Credit is generic billed AR",

								"Credit amount is 11005104 Billed Dom AR - First Run Cash Syn/TBD - Placeholder (First Run) Cash Account for Syndication");

					}

				}
				
				if (uiDriver.getValue(
						"//*[@id='line_splits']//tbody/tr[" + (invoiceRow + 1)
								+ "]/td[1]").contains(
						"11015052 Canada Cash Clearing")
						|| uiDriver
								.getValue(
										"//*[@id='line_splits']//tbody/tr["
												+ (invoiceRow + 1) + "]/td[1]")
								.contains(
										"11015052 Canada Cash Clearing")) {

					if (uiDriver.getValue(
							"//*[@id='line_splits']//tbody/tr["
									+ (invoiceRow + 1) + "]/td[3]").equals("")) {
						failed("Validating Credit Amount",

						"Validating Credit Amount should be successfull",

						"Credit amount is not Generic billed AR");

					} else

					{

						passed("Credit is generic billed AR",

								"Credit is generic billed AR",

								"Credit amount is 11005104 Billed Dom AR - First Run Cash Syn/TBD - Placeholder (First Run) Cash Account for Syndication");

					}

				}
				}
				SleepUtils.sleep(TimeSlab.MEDIUM);
				uiDriver.click("Back");
				SleepUtils.sleep(TimeSlab.MEDIUM);
				uiDriver.click("AllocationDetail");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.click("Transactions");
				uiDriver.executeJavaScript("scroll(0,1000)");

			}
uiDriver.back();
SleepUtils.sleep(TimeSlab.MEDIUM);
uiDriver.click("Salesnum");
SleepUtils.sleep(TimeSlab.MEDIUM);
uiDriver.click("Custom");
SleepUtils.sleep(TimeSlab.LOW);
uiDriver.executeJavaScript("scroll(0,800)");
uiDriver.click("TitleAllocationParent");
SleepUtils.sleep(TimeSlab.LOW);

		}

	}

	
	/****************************************
	 * Name: VerifyTransactionAllocationDetails 
	 * Description: VerifyTransactionAllocationDetails 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void VerifyTransactionAllocationDetails1(DataRow input, DataRow output)
			  throws InterruptedException {
			 /*SleepUtils.sleep(5);
			    uiDriver.refresh();
			    uiDriver.refresh();
			    uiDriver.refresh();
			    SleepUtils.sleep(10);
			    uiDriver.refresh();
			    SleepUtils.sleep(100);
			    SleepUtils.sleep(500);
			    uiDriver.refresh();
			    uiDriver.refresh();*/
			    uiDriver.refresh();
			    SleepUtils.sleep(10);
			 uiDriver.click("Custom");
			 SleepUtils.sleep(TimeSlab.LOW);
			 SleepUtils.sleep(TimeSlab.LOW);
			 uiDriver.executeJavaScript("scroll(0,800)");
			/******** Try catch*********/
			 try{
			  uiDriver.executeJavaScript("document.getElementById('recmachcustrecord_nbcu_titleallocpa_contracttxt').click();");
			 }
			 catch(Exception e) {
			  SleepUtils.sleep(TimeSlab.LOW);
			  SleepUtils.sleep(TimeSlab.LOW);
			  uiDriver.executeJavaScript("document.getElementById('recmachcustrecord_nbcu_titleallocpa_paymenttxt').click();");
			  
			 }
			 //uiDriver.click("TitleAllocationParent");
			 SleepUtils.sleep(TimeSlab.LOW);
			 SleepUtils.sleep(TimeSlab.LOW);
			 
			 
			 uiDriver.executeJavaScript("scroll(0,1200)");
			   SleepUtils.sleep(TimeSlab.LOW);
			  String s1;
			  int accRows;
			  /****************** If else added *****************/ 
			  if(uiDriver.checkElementPresent_dynamic("//table[@id='recmachcustrecord_nbcu_titleallocpa_contract__tab']/tbody/tr")) {
			  accRows = uiDriver.webDr.findElements(By.xpath("//table[@id='recmachcustrecord_nbcu_titleallocpa_contract__tab']/tbody/tr")).size();
			    s1 = uiDriver.getDyanmicData("DynamicTapid");
			  }
			  else {
			    accRows = uiDriver.webDr.findElements(By.xpath("(//table[@id='recmachcustrecord_nbcu_titleallocpa_payment__tab']/tbody/tr)[2]")).size();
			     s1 = uiDriver.getDyanmicData("DynamicTapidpayment");
			   
			  }
			  
			 
			 SleepUtils.sleep(TimeSlab.HIGH);
			 for (int r = 0; r<=accRows; r++) {

			  SleepUtils.sleep(TimeSlab.MEDIUM);
			  uiDriver.executeJavaScript("scroll(0,900)");
			  SleepUtils.sleep(TimeSlab.MEDIUM);
			  
			  SleepUtils.sleep(TimeSlab.MEDIUM);
			  String s2 = s1.replace("#",Integer.toString(r));
			  //SleepUtils.sleep(TimeSlab.HIGH);
			  for(int x=0;x<50;x++){
			  if (uiDriver.checkElementPresent_dynamic(s2)){
			   break;
			  }
			  else{ 
			   uiDriver.refresh();
			   uiDriver.refresh();
			   uiDriver.refresh();
			   uiDriver.refresh();
			   uiDriver.refresh();
			   uiDriver.refresh();
			   SleepUtils.sleep(10);
			   uiDriver.executeJavaScript("scroll(0,-500)");
			   uiDriver.click("Custom");
			   SleepUtils.sleep(TimeSlab.LOW);
			   uiDriver.executeJavaScript("scroll(0,800)");
			   uiDriver.executeJavaScript("document.getElementById('recmachcustrecord_nbcu_titleallocpa_contracttxt').click();");
			   //uiDriver.click("TitleAllocationParent");
			   SleepUtils.sleep(TimeSlab.LOW);
			    
			  }
			  
			  }
			   SleepUtils.sleep(TimeSlab.MEDIUM);
			  uiDriver.click_dynamic(s2);
			  SleepUtils.sleep(TimeSlab.MEDIUM);
			  uiDriver.executeJavaScript("scroll(0,500)");
			  SleepUtils.sleep(TimeSlab.MEDIUM);
			  uiDriver.click("AllocationDetail");
			  SleepUtils.sleep(TimeSlab.MEDIUM);
			  uiDriver.click("Transactions");
			  SleepUtils.sleep(TimeSlab.MEDIUM);
			  List<WebElement> Journal = uiDriver.webDr.findElements(By.xpath("//*[@id='recmachcustbody_nbcu_titleallocation__tab']/tbody//tr"));
			  SleepUtils.sleep(TimeSlab.MEDIUM);
			  int Journals = Journal.size();
			  for (int i = 1; i <= Journals; i++) {

			   SleepUtils.sleep(TimeSlab.MEDIUM);
			   String JournalLink = uiDriver.getDyanmicData("Journal");
			   String JournalLinkValue = JournalLink.replace("#",
			     Integer.toString(i));
			   if(uiDriver.checkElementPresent_dynamic(JournalLinkValue))
			   {
			   uiDriver.click_dynamic(JournalLinkValue);
			   SleepUtils.sleep(TimeSlab.MEDIUM);
			   int invoiceRow = 2;
			   SleepUtils.sleep(TimeSlab.MEDIUM);
			   if (uiDriver.getValue("//*[@id='line_splits']//tbody/tr[" + invoiceRow+ "]/td[1]").contains("110051XX Generic Billed AR")|| uiDriver.getValue("//*[@id='line_splits']//tbody/tr["+ invoiceRow + "]/td[1]").contains("TBD - Placeholder (First Run) Cash Account for Syndication")) {

			    if (uiDriver.getValue("//*[@id='line_splits']//tbody/tr[" + invoiceRow+ "]/td[2]").equals(""))

			    {

			     failed("Validating Debit Amount",

			     "Validating Debit Amount should be successfull",

			     "Debit amount is not Deferred Rev -Generic ");
			    }

			    else

			    {

			     passed("Debit is Deferred Rev - Generic",

			       "Debit is Deferred Rev - Generic",

			       "Debit amount is 110051XX Generic Billed AR/ TBD - Placeholder (First Run) Cash Account for Syndication");
			    }

			   }

			   SleepUtils.sleep(TimeSlab.HIGH);
			   if (uiDriver.getValue("//*[@id='line_splits']//tbody/tr[" + (invoiceRow + 1)+ "]/td[1]").contains("11005104 Billed Dom AR - First Run Cash Syn")|| uiDriver.getValue("//*[@id='line_splits']//tbody/tr["+ (invoiceRow + 1) + "]/td[1]") .contains("TBD - Placeholder (First Run) Cash Account for Syndication")) {
			    if (uiDriver.getValue("//*[@id='line_splits']//tbody/tr["+ (invoiceRow + 1) + "]/td[3]").equals("")) {
			     failed("Validating Credit Amount",
			       "Validating Credit Amount should be successfull",
			       "Credit amount is not Generic billed AR");

			    } else

			    {

			     passed("Credit is generic billed AR",
			       "Credit is generic billed AR",
			       "Credit amount is 11005104 Billed Dom AR - First Run Cash Syn/TBD - Placeholder (First Run) Cash Account for Syndication");

			    }

			   }
			   
			   if (uiDriver.getValue("//*[@id='line_splits']//tbody/tr[" + (invoiceRow + 1)+ "]/td[1]").contains("11015052 Canada Cash Clearing")|| uiDriver.getValue("//*[@id='line_splits']//tbody/tr["+ (invoiceRow + 1) + "]/td[1]").contains("11015052 Canada Cash Clearing") ||uiDriver.getValue("//*[@id='line_splits']//tbody/tr[" + (invoiceRow + 1)+ "]/td[1]").contains("CBT - Billed AR")) {

			    if (uiDriver.getValue("//*[@id='line_splits']//tbody/tr["+ (invoiceRow + 1) + "]/td[3]").equals("")) {
			     failed("Validating Credit Amount",
			         "Validating Credit Amount should be successfull",
			              "Credit amount is not Generic billed AR");

			    } else

			    {

			     passed("Credit is generic billed AR",
			       "Credit is generic billed AR",
			       "Credit amount is 11005104 Billed Dom AR - First Run Cash Syn/TBD - Placeholder (First Run) Cash Account for Syndication");

			    }

			   }
			   
			   /********MVP2 ADDED FOR STEP TO CHECK IF WHT IS CREATED UNDER TRANSACTIONS *********************************/
			   
			   if(uiDriver.getValue("//*[@id='line_splits']//tbody/tr[" + (invoiceRow + 1)+ "]/td[1]").contains("74300391 WHT Expense")) {
			    if (uiDriver.getValue("//*[@id='line_splits']//tbody/tr["+ (invoiceRow + 1) + "]/td[3]").equals("")) {
			     failed("Validating Credit Amount",
			         "Validating Credit Amount should be successfull",
			              "Credit amount is not Generic CBT WHT");

			    } else

			    {

			     passed("Credit is generic CBT WHT",
			       "Credit is generic CBT WHT",
			       "Credit amount is 302.72");

			    }

			   }
			   }
			   SleepUtils.sleep(TimeSlab.MEDIUM);
			   uiDriver.click("Back");
			   SleepUtils.sleep(TimeSlab.MEDIUM);
			   uiDriver.click("AllocationDetail");
			   SleepUtils.sleep(TimeSlab.LOW);
			   uiDriver.click("Transactions");
			   uiDriver.executeJavaScript("scroll(0,1000)");

			  }
			/*uiDriver.back();
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("Salesnum");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("Custom");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.executeJavaScript("scroll(0,800)");
			uiDriver.click("TitleAllocationParent");
			SleepUtils.sleep(TimeSlab.LOW);
			*/
			 }

			}



	/****************************************
	 * Name: VerifyPaidInFullInvoice 
	 * Description: VerifyPaidInFullInvoice 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void VerifyPaidInFullInvoice(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.executeJavaScript("scroll(0,400)");
		uiDriver.click("Custom");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,1100)");
		uiDriver.click("TitleAllocationParent");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Payment#");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,500)");
		List<WebElement> InvoicesPaid = uiDriver.webDr.findElements(By
				.xpath("//*[@id='apply_splits']//tbody//tr"));
		int InvPaid = InvoicesPaid.size();
		for (int i = 0; i <InvPaid - 1; i++) {
			
			String inv = uiDriver.getDyanmicData("Invoices");
			String invoices = inv.replace("#", Integer.toString(i));
			for(int g=1;g<=10;g++)
			{
			if(uiDriver.checkElementPresent_dynamic(invoices))
			{
			uiDriver.click_dynamic(invoices);
			break;
			}
			else
			{
				uiDriver.refresh();
				SleepUtils.sleep(30);
				uiDriver.refresh();
			}
			}
			SleepUtils.sleep(TimeSlab.MEDIUM);
			String PaidInvoices = uiDriver.getValue_Text("InvPaid");
			SleepUtils.sleep(TimeSlab.LOW);
			if (PaidInvoices.equalsIgnoreCase("Paid In Full") || PaidInvoices.equalsIgnoreCase("OPEN") ) {
				passed("Verify Paid In Full Invoice",
						"Paid In Full should be displayed as" + PaidInvoices
								+ "", "Paid In Full is displayed as"
								+ PaidInvoices + "");
			} else {
				passed("Verify Paid In Full Invoice",
						"Paid In Full should be displayed as" + PaidInvoices
								+ "", "Paid In Full is displayed as"
								+ PaidInvoices + "");
			}
			uiDriver.back();
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.executeJavaScript("scroll(0,500)");
		}

	}

	/****************************************
	 * Name: EditTheAllocationRule 
	 * Description: EditTheAllocationRule 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void EditTheAllocationRule(DataRow input, DataRow output)
			throws InterruptedException {

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("DefaultEdit");
		SleepUtils.sleep(TimeSlab.LOW);
	}

	/****************************************
	 * Name: EditTheAllocationRuleAssigned 
	 * Description: EditTheAllocationRuleAssigned 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void EditTheAllocationRuleAssigned(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.setValue("Name", input.get("Name"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("Note", input.get("Note"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("InvoiceItemCategory");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("InvoiceItemCategoryInput");
		SleepUtils.sleep(TimeSlab.YIELD);
		Boolean Result = uiDriver.webDr.findElement(
				By.id("TerritoriesCheckbox")).isSelected();
		if (Result.equals(false)) {

			uiDriver.click("Territories");
		} else {
			// do nothing
		}

		Boolean RightResult = uiDriver.webDr.findElement(
				By.id("RightsCheckbox")).isSelected();
		if (RightResult.equals(false)) {

			uiDriver.click("Rights");
		} else {
			// do nothing
		}

		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("(scroll(0,1700));");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("document.getElementsByClassName('amount-value weight')[27].value='';");
		Actions action = new Actions(uiDriver.webDr);
		WebElement ele = uiDriver.webDr
				.findElement(By
						.xpath("//*[@id='territoriesGrid']/div[2]/table/tbody/tr[28]/td[4]/div[1]/div/input"));
		action.sendKeys("ele", "").build().perform();
		action.sendKeys(ele, "100.00").build().perform();
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("document.getElementsByClassName('amount-value weight')[29].value='';");
		SleepUtils.sleep(TimeSlab.LOW);
		// uiDriver.executeJavaScript("document.getElementById('line_addedit').value='100';");
		WebElement ele1 = uiDriver.webDr
				.findElement(By
						.xpath("//*[@id='rightsGrid']/div[2]/table/tbody/tr[1]/td[4]/div[1]/div/input"));
		action.sendKeys("ele1", "").build().perform();
		action.sendKeys(ele1, "100.00").build().perform();
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Finish");
		// uiDriver.executeJavaScript("document.getElementById('finish').click();");
		/*
		 * finish=new Actions(uiDriver.webDr); WebElement finishele =
		 * uiDriver.webDr.findElement(By.xpath("//*[@id='finish']"));
		 * action.click(finishele);
		 */
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		output.put("Name", input.get("Name"));
	}
	/****************************************
	 * Name: EditTheAllocationRuleGreece Description:
	 * EditTheAllocationRuleGreece Date: 10-Oct-20178	 ****************************************/
	public void EditTheAllocationRulGreece(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.setValue("Name", input.get("Name"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("Note", input.get("Note"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("InvoiceItemCategory");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("InvoiceItemCategoryInput");
		SleepUtils.sleep(TimeSlab.YIELD);
		Boolean Result = uiDriver.webDr.findElement(
				By.id("TerritoriesCheckbox")).isSelected();
		if (Result.equals(false)) {

			uiDriver.click("Territories");
		} else {
			// do nothing
		}

		Boolean RightResult = uiDriver.webDr.findElement(
				By.id("RightsCheckbox")).isSelected();
		if (RightResult.equals(false)) {

			uiDriver.click("Rights");
		} else {
			// do nothing
		}

		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("(scroll(0,1700));");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("document.getElementsByClassName('amount-value weight')[0].value='';");
		Actions action = new Actions(uiDriver.webDr);
		WebElement ele = uiDriver.webDr
				.findElement(By
						.xpath("//*[@id='territoriesGrid']/div[2]/table/tbody/tr/td[4]/div[1]/div/input"));
		action.sendKeys("ele", "").build().perform();
		action.sendKeys(ele, "100.00").build().perform();
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("document.getElementsByClassName('amount-value weight')[1].value='';");
		SleepUtils.sleep(TimeSlab.LOW);
		// uiDriver.executeJavaScript("document.getElementById('line_addedit').value='100';");
		WebElement ele1 = uiDriver.webDr
				.findElement(By
						.xpath("//*[@id='rightsGrid']/div[2]/table/tbody/tr/td[4]/div[1]/div/input"));
		action.sendKeys("ele1", "").build().perform();
		action.sendKeys(ele1, "100.00").build().perform();
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Finish");
		// uiDriver.executeJavaScript("document.getElementById('finish').click();");
		/*
		 * finish=new Actions(uiDriver.webDr); WebElement finishele =
		 * uiDriver.webDr.findElement(By.xpath("//*[@id='finish']"));
		 * action.click(finishele);
		 */
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		output.put("Name", input.get("Name"));
	}


	/****************************************
	 * Name: AddingSingleAllocationRule 
	 * Description: AddAllocationRules 
	 * Date: 11-July-2018
	 ****************************************/
	public void AddingSingleAllocationRule(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("AddAllocationButton");
		SleepUtils.sleep(TimeSlab.YIELD);

	}

	/****************************************
	 * Name: EditContractWizard
	 * Description: EditContractWizard 
	 * Date: 11-July-2018
	 ****************************************/
	public void EditContractWizard(DataRow input, DataRow output) {
		uiDriver.executeJavaScript("(scroll(0,-300));");
		uiDriver.click("Edit");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("MarketCode");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("MarketCodeValue");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("ApplyFilters");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		List<WebElement> MarketCode = uiDriver.webDr.findElements(By.xpath("//*[@id='contract_lines_splits']//tr"));
		int MC = MarketCode.size();
		for (int i = 0; i < MC - 1; i++) {
			String MarCode = uiDriver.getDyanmicData("MarketCodes");
			String MarCodes = MarCode.replace("#", Integer.toString(i));
			String MarketCodeVal = uiDriver.getValue(MarCodes);
			if (MarketCodeVal.contains("BC")) {
				passed("Verify the MarketCode Value",
						"MarketCode Value should be displayed as "
								+ MarketCodeVal + "",
						"MarketCode Value is displayed as " + MarketCodeVal
								+ "");
			} else {

				failed("Verify the MarketCode Value",
						"MarketCode Value should be displayed as "
								+ MarketCodeVal + "",
						"MarketCode Value is not displayed as " + MarketCodeVal
								+ "");
			}

			String FMV = uiDriver.getDyanmicData("FMV");
			String FMVVal = FMV.replace("#", Integer.toString(i));
			uiDriver.setValue(FMVVal, "L");
			SleepUtils.sleep(TimeSlab.LOW);
		}
		
		uiDriver.executeJavaScript("(scroll(0,-600));");
		for (int j = 1; j < MC; j++) {
			
			String chkboxStatuses = uiDriver.getAttribute("Chkboxes", "class");
			String Chkbox = uiDriver.getDyanmicData("chkbox");
			String ChkboxChk = Chkbox.replace("#", Integer.toString(j));
			String chkboxArr[] = ChkboxChk.split("=");
			String chkboxVal = chkboxArr[1];
			String SelectedChkbox = chkboxVal.replace("\"", "");
			String actualSelectedValue = SelectedChkbox.replace("]", "");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.executeJavaScript("document.getElementById('"+actualSelectedValue+"').click();");
			/*Actions action = new Actions(uiDriver.webDr);
            WebElement ele = uiDriver.webDr.findElement(By.xpath(ChkboxChk));
        	SleepUtils.sleep(TimeSlabLOW);
            action.moveToElement(ele).click().build().perform();*/
            SleepUtils.sleep(TimeSlab.MEDIUM);
		}  
	

		uiDriver.executeJavaScript("(scroll(0,-300));");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("(scroll(0,-1500));");
		uiDriver.click("MoveDown");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Save");
		SleepUtils.sleep(TimeSlab.HIGH);
		}

	/****************************************
	 * Name: RevisionInFT 
	 * Description: RevisionInFT 
	 * Date: 11-July-2018
	 ****************************************/
	public void RevisionInFT(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Action");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Versioning");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("CreateRevision");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("VersionInitiated");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("VersionInitiatedBy");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.setValue("VersionReason", "QA Testing");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("CreateVersion");
		SleepUtils.sleep(TimeSlab.MEDIUM);

	}

	/****************************************
	 * Name: AddTimeLineItems 
	 * Description: AddTimeLineItems 
	 * Date: 12-Sept-2018
	 ****************************************/
	public void AddTimeLineItems(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Dates");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimeLineItems");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("AddTimeLineItem");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setFrame("//*[@id='RadWindowWrapper_ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_TimelineItemWindow']/table/tbody/tr[2]/td[2]/iframe");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimelineItemType");
		// uiDriver.setValue("TimelineItemType",input.get("Type"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimelineItemTypeValue");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("EST");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("Date", input.get("Date"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Notes");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Project");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("WaistDeep");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Add");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("BOWFinger");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Add");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Finish");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.resetFrame();
	}

	/****************************************
	 * Name: AddTimeLineItemsAllproj
	 * Description: AddTimeLineItems by checking all projects
	 * Date: 12-Sept-2018
	 ****************************************/
	public void AddTimeLineItemsAllproj(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Dates");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimeLineItems");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("AddTimeLineItem");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.setFrame("//*[@id='RadWindowWrapper_ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_TimelineItemWindow']/table/tbody/tr[2]/td[2]/iframe");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//*[@id='ctl00_MainContent_ItemInfo_userControl_TimelineItemTypeLocalEdit_Input']");
		// uiDriver.setValue("TimelineItemType",input.get("Type"));
		SleepUtils.sleep(TimeSlab.LOW);
		String Timeline = uiDriver.getDyanmicData("TimelineItemTypeValue");
		String Timeline1 = Timeline.replace("#",input.get("Type"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click(Timeline1);
		SleepUtils.sleep(TimeSlab.LOW);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("EST");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("Date", input.get("Date"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Notes");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Project");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("checkAll");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Add");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Finish");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.resetFrame();
	}
	
	
	
	/****************************************
	 * Name: ChangeRevRecmethod
	 * Description: Change Revrec method from LPSD to Air Date
	 * Date: 12-Sept-2018
	 ****************************************/
	public void ChangeRevRecmethod(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("//a[text()='lated Transactions']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//td[text()='Estimate']/..//td/a");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//*[@id='custpage_edit']");
		SleepUtils.sleep(TimeSlab.HIGH);
		
		uiDriver.click("//*[@id='secondarynext']");
		// uiDriver.setValue("TimelineItemType",input.get("Type"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("action", "Update SO Line");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("Title", input.get("title1"));
		uiDriver.click("ApplyFilters");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("revrecmethod");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("revrecmethod", "Air Date");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.sendKey("enter");
		uiDriver.setValue("RRStartMethod","");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("RRSEndMethod", "");
		/*List<WebElement> chkboxes = uiDriver.webDr.findElements(By.xpath("//*[@id='select1_fs']/img"));
		for(WebElement w:chkboxes)
		{
			w.click();
		}*/
		
		
		
		
		uiDriver.click("(//*[@id='select1_fs']/img)[1]");
		SleepUtils.sleep(TimeSlab.YIELD);
		
		uiDriver.click("movedown");
		uiDriver.setValue("action", "Update SO Line");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("Title", input.get("title2"));
		uiDriver.click("ApplyFilters");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("revrecmethod");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("revrecmethod", "Air Date");
		SleepUtils.sleep(TimeSlab.LOW);

		uiDriver.sendKey("enter");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("RRStartMethod","");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("RRSEndMethod","");
		/*List<WebElement> chkboxes1 = uiDriver.webDr.findElements(By.xpath("//*[@id='select1_fs']/img"));
		for(WebElement w:chkboxes1)
		{
			w.click();
		}*/
		
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("(//*[@id='select1_fs']/img)[1]");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("movedown");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Save");
		SleepUtils.sleep(TimeSlab.HIGH);
		
	}

	
	/****************************************
	 * Name: DeletedefaultXPGBillinggroup
	 * Description: DeletedefaultXPGBillinggroup by checking all projects
	 * Date: 12-Sept-2018
	 ****************************************/
	public void DeletedefaultXPGBillinggroup(DataRow input, DataRow output) {
		uiDriver.click("//ul[@id='ft-context-menu']//li/a[text()='Finance']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//a[text()='Billing']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//a[text()='Billing Groups']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//td[text()='Default-XPG']/..//a[text()='Delete']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.handleAlert("", "OK");
		
		
	}
	
	/****************************************
	 * Name: AddTimeLineItemsspecifiedproj
	 * Description: AddTimeLineItems by checking specified projects
	 * Date: 22-March-2019
	 ****************************************/
	public void AddTimeLineItemsspecifiedproj(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Dates");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimeLineItems");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("AddTimeLineItem");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.setFrame("//*[@id='RadWindowWrapper_ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_TimelineItemWindow']/table/tbody/tr[2]/td[2]/iframe");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimelineItemType");
		// uiDriver.setValue("TimelineItemType",input.get("Type"));
		SleepUtils.sleep(TimeSlab.LOW);
		String Timeline = uiDriver.getDyanmicData("TimelineItemTypeValue");
		String Timeline1 = Timeline.replace("#",input.get("Type"));
		uiDriver.click(Timeline1);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("EST");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("Date", input.get("Date"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Notes");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Project");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("checkAll");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//span[text()='02482|JURASSIC WORLD: FALLEN KINGDOM']/../../..//input");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//span[text()='04115|LITTLE STRANGER, THE']/../../..//input");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//span[text()='09999|CROSS PRODUCT REVENUE-THEATRICAL']/../../..//input");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//*[@id=\"ctl00_MainContent_Project_userControl_ProjectSelectionControlLocal_AddButton\"]");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//*[@id=\"ctl00_MainContent_FinishButton\"]");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("(scroll(0,-500));");
		uiDriver.click("AddTimeLineItem");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.setFrame("//*[@id='RadWindowWrapper_ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_TimelineItemWindow']/table/tbody/tr[2]/td[2]/iframe");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimelineItemType");
		// uiDriver.setValue("TimelineItemType",input.get("Type"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click(Timeline1);
		SleepUtils.sleep(TimeSlab.MEDIUM);
	
		uiDriver.click("EST");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("Date", input.get("Date1"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Notes");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Project");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("//span[text()='02482|JURASSIC WORLD: FALLEN KINGDOM']/../../..//input");
		SleepUtils.sleep(TimeSlab.LOW);
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//*[@id=\"ctl00_MainContent_Project_userControl_ProjectSelectionControlLocal_AddButton\"]");
		SleepUtils.sleep(TimeSlab.LOW);
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//*[@id=\"ctl00_MainContent_FinishButton\"]");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("(scroll(0,-500));");
		uiDriver.click("AddTimeLineItem");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.setFrame("//*[@id='RadWindowWrapper_ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_TimelineItemWindow']/table/tbody/tr[2]/td[2]/iframe");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimelineItemType");
		// uiDriver.setValue("TimelineItemType",input.get("Type"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click(Timeline1);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("EST");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("Date", input.get("Date1"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Notes");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Project");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("//span[text()='04115|LITTLE STRANGER, THE']/../../..//input");
		SleepUtils.sleep(TimeSlab.LOW);
		
		uiDriver.click("//*[@id=\"ctl00_MainContent_Project_userControl_ProjectSelectionControlLocal_AddButton\"]");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("//*[@id=\"ctl00_MainContent_FinishButton\"]");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
	}
	
	
	
	
	
	/****************************************
	 * Name: ValidateFMVAdjustment
	 * Description: ValidateFMVAdjustment 
	 * Date: 12-Sept-2018
	 ****************************************/
	public void ValidateFMVAdjustment(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.executeJavaScript("(scroll(0,300));");
		uiDriver.click("//*[@id='customlnk']/a");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.executeJavaScript("(scroll(0,900));");
		uiDriver.click("//*[@id='recmachcustrecord_nbcu_solnk']/a");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.executeJavaScript("(scroll(0,1500));");
		uiDriver.click("2257BowFinger");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.executeJavaScript("(scroll(0,600));");
		uiDriver.click("ContractBilledRevenue");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String FMVBilledRevenue = uiDriver.getValue_Text("FMVBilledRevenue");
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVBilledRevenue.contains("0")) {
			passed("Verify the FMVBilledRevenue",
					"FMVBilledRevenue  should be displayed Successfully as "
							+ FMVBilledRevenue + "",
					"FMVBilledRevenue is displayed Successfully as "
							+ FMVBilledRevenue + "");

		} else {
			failed("Verify the FMVBilledRevenue",
					"FMVBilledRevenue should be displayed Successfully as "
							+ FMVBilledRevenue + "",
					"FMVBilledRevenue is not displayed Successfully as "
							+ FMVBilledRevenue + "");

		}

		String FMVBilledRevenueAdjustment = uiDriver
				.getValue_Text("FMVBilledRevenueAdjustment");
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVBilledRevenueAdjustment.contains("0")) {
			passed("Verify the FMVBilledRevenueAdjustment",
					"FMVBilledRevenueAdjustment  should be displayed Successfully as "
							+ FMVBilledRevenueAdjustment + "",
					"FMVBilledRevenueAdjustment is displayed Successfully as "
							+ FMVBilledRevenueAdjustment + "");

		} else {
			failed("Verify the FMVBilledRevenueAdjustment",
					"FMVBilledRevenueAdjustment  should be displayed Successfully as "
							+ FMVBilledRevenueAdjustment + "",
					"FMVBilledRevenueAdjustment is not displayed Successfully as "
							+ FMVBilledRevenueAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractUnBilledRevenue");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVUnBilledRevenue = uiDriver
				.getValue_Text("FMVUnBilledRevenue");
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVUnBilledRevenue.contains("0")) {
			passed("Verify the FMVUnBilledRevenue",
					"FMVUnBilledRevenue  should be displayed Successfully as "
							+ FMVUnBilledRevenue + "",
					"FMVUnBilledRevenue is displayed Successfully as "
							+ FMVUnBilledRevenue + "");

		} else {
			failed("Verify the FMVUnBilledRevenue",
					"FMVUnBilledRevenue should be displayed Successfully as "
							+ FMVUnBilledRevenue + "",
					"FMVUnBilledRevenue is not displayed Successfully as "
							+ FMVUnBilledRevenue + "");

		}

		String FMVUnBilledRevenueAdjustment = uiDriver
				.getValue_Text("FMVUnBilledRevenueAdjustment");
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVUnBilledRevenueAdjustment.contains("0")) {
			passed("Verify the FMVUnBilledRevenueAdjustment",
					"FMVUnBilledRevenueAdjustment  should be displayed Successfully as "
							+ FMVUnBilledRevenueAdjustment + "",
					"FMVUnBilledRevenueAdjustment is displayed Successfully as "
							+ FMVUnBilledRevenueAdjustment + "");

		} else {
			failed("Verify the FMVUnBilledRevenueAdjustment",
					"FMVUnBilledRevenueAdjustment  should be displayed Successfully as "
							+ FMVUnBilledRevenueAdjustment + "",
					"FMVUnBilledRevenueAdjustment is not displayed Successfully as "
							+ FMVUnBilledRevenueAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractBilledAR");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVBilledAR = uiDriver.getValue_Text("FMVBilledAR");
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVBilledAR.contains("0")) {
			passed("Verify the FMVBilledAR",
					"FMVBilledAR  should be displayed Successfully as "
							+ FMVBilledAR + "",
					"FMVBilledAR is displayed Successfully as " + FMVBilledAR
							+ "");

		} else {
			failed("Verify the FMVBilledAR",
					"FMVBilledAR should be displayed Successfully as "
							+ FMVBilledAR + "",
					"FMVBilledAR is not displayed Successfully as "
							+ FMVBilledAR + "");

		}

		String FMVBilledARAdjustment = uiDriver
				.getValue_Text("FMVBilledARAdjustment");
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVBilledARAdjustment.contains("0")) {
			passed("Verify the FMVBilledARAdjustment",
					"FMVBilledARAdjustment  should be displayed Successfully as "
							+ FMVBilledARAdjustment + "",
					"FMVBilledARAdjustment is displayed Successfully as "
							+ FMVBilledARAdjustment + "");

		} else {
			failed("Verify the FMVBilledARAdjustment",
					"FMVBilledARAdjustment  should be displayed Successfully as "
							+ FMVBilledARAdjustment + "",
					"FMVBilledARAdjustment is not displayed Successfully as "
							+ FMVBilledARAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractUnBilledAR");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVUnBilledAR = uiDriver.getValue_Text("FMVUnBilledAR");
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVUnBilledAR.contains("0")) {
			passed("Verify the FMVUnBilledAR",
					"FMVUnBilledAR  should be displayed Successfully as "
							+ FMVUnBilledAR + "",
					"FMVUnBilledAR is displayed Successfully as "
							+ FMVUnBilledAR + "");

		} else {
			failed("Verify the FMVUnBilledAR",
					"FMVUnBilledAR should be displayed Successfully as "
							+ FMVUnBilledAR + "",
					"FMVUnBilledAR is not displayed Successfully as "
							+ FMVUnBilledAR + "");

		}

		String FMVUnBilledARAdjustment = uiDriver
				.getValue_Text("FMVUnBilledARAdjustment");
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVUnBilledARAdjustment.contains("0")) {
			passed("Verify the FMVUnBilledARAdjustment",
					"FMVUnBilledARAdjustment  should be displayed Successfully as "
							+ FMVUnBilledARAdjustment + "",
					"FMVUnBilledARAdjustment is displayed Successfully as "
							+ FMVUnBilledARAdjustment + "");

		} else {
			failed("Verify the FMVUnBilledARAdjustment",
					"FMVUnBilledARAdjustment  should be displayed Successfully as "
							+ FMVUnBilledARAdjustment + "",
					"FMVUnBilledARAdjustment is not displayed Successfully as "
							+ FMVUnBilledARAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractUnpaidDeferred");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVUnpaidDeferred = uiDriver.getValue_Text("FMVUnpaidDeferred");
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVUnpaidDeferred.contains("0")) {
			passed("Verify the FMVUnpaidDeferred",
					"FMVUnpaidDeferred  should be displayed Successfully as "
							+ FMVUnpaidDeferred + "",
					"FMVUnpaidDeferred is displayed Successfully as "
							+ FMVUnpaidDeferred + "");

		} else {
			failed("Verify the FMVUnpaidDeferred",
					"FMVUnpaidDeferred should be displayed Successfully as "
							+ FMVUnpaidDeferred + "",
					"FMVUnpaidDeferred is not displayed Successfully as "
							+ FMVUnpaidDeferred + "");

		}

		String FMVUnpaidDeferredAdjustment = uiDriver
				.getValue_Text("FMVUnpaidDeferredAdjustment");
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVUnpaidDeferredAdjustment.contains("0")) {
			passed("Verify the FMVUnpaidDeferredAdjustment",
					"FMVUnpaidDeferredAdjustment  should be displayed Successfully as "
							+ FMVUnpaidDeferredAdjustment + "",
					"FMVUnpaidDeferredAdjustment is displayed Successfully as "
							+ FMVUnpaidDeferredAdjustment + "");

		} else {
			failed("Verify the FMVUnpaidDeferredAdjustment",
					"FMVUnpaidDeferredAdjustment  should be displayed Successfully as "
							+ FMVUnpaidDeferredAdjustment + "",
					"FMVUnpaidDeferredAdjustment is not displayed Successfully as "
							+ FMVUnpaidDeferredAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractPaidDeferred");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVPaidDeferred = uiDriver.getValue_Text("FMVPaidDeferred");
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVPaidDeferred.contains("0")) {
			passed("Verify the FMVPaidDeferred",
					"FMVPaidDeferred  should be displayed Successfully as "
							+ FMVPaidDeferred + "",
					"FMVPaidDeferred is displayed Successfully as "
							+ FMVPaidDeferred + "");

		} else {
			failed("Verify the FMVPaidDeferred",
					"FMVPaidDeferred should be displayed Successfully as "
							+ FMVPaidDeferred + "",
					"FMVPaidDeferred is not displayed Successfully as "
							+ FMVPaidDeferred + "");

		}

		String FMVPaidDeferredAdjustment = uiDriver
				.getValue_Text("FMVPaidDeferredAdjustment");
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVPaidDeferredAdjustment.contains("0")) {
			passed("Verify the FMVPaidDeferredAdjustment",
					"FMVPaidDeferredAdjustment  should be displayed Successfully as "
							+ FMVPaidDeferredAdjustment + "",
					"FMVPaidDeferredAdjustment is displayed Successfully as "
							+ FMVPaidDeferredAdjustment + "");

		} else {
			failed("Verify the FMVPaidDeferredAdjustment",
					"FMVPaidDeferredAdjustment  should be displayed Successfully as "
							+ FMVPaidDeferredAdjustment + "",
					"FMVPaidDeferredAdjustment is not displayed Successfully as "
							+ FMVPaidDeferredAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractFXGainLoss");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVFXGainLoss = uiDriver.getValue_Text("FMVFXGainLoss");
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVFXGainLoss.contains("0")) {
			passed("Verify the FMVFXGainLoss",
					"FMVFXGainLoss  should be displayed Successfully as "
							+ FMVFXGainLoss + "",
					"FMVFXGainLoss is displayed Successfully as "
							+ FMVFXGainLoss + "");

		} else {
			failed("Verify the FMVFXGainLoss",
					"FMVFXGainLoss should be displayed Successfully as "
							+ FMVFXGainLoss + "",
					"FMVFXGainLoss is not displayed Successfully as "
							+ FMVFXGainLoss + "");

		}

		String FMVFXGainLossAdjustment = uiDriver
				.getValue_Text("FMVFXGainLossAdjustment");
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVFXGainLossAdjustment.contains("0")) {
			passed("Verify the FMVFXGainLossAdjustment",
					"FMVFXGainLossAdjustment  should be displayed Successfully as "
							+ FMVFXGainLossAdjustment + "",
					"FMVFXGainLossAdjustment is displayed Successfully as "
							+ FMVFXGainLossAdjustment + "");

		} else {
			failed("Verify the FMVFXGainLossAdjustment",
					"FMVFXGainLossAdjustment  should be displayed Successfully as "
							+ FMVFXGainLossAdjustment + "",
					"FMVFXGainLossAdjustment is not displayed Successfully as "
							+ FMVFXGainLossAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractWHT");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVWHT = uiDriver.getValue_Text("FMVWHT");
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVWHT.contains("0")) {
			passed("Verify the FMVWHT",
					"FMVWHT  should be displayed Successfully as " + FMVWHT
							+ "", "FMVWHT is displayed Successfully as "
							+ FMVWHT + "");

		} else {
			failed("Verify the FMVWHT",
					"FMVWHT should be displayed Successfully as " + FMVWHT + "",
					"FMVWHT is not displayed Successfully as " + FMVWHT + "");

		}

		String FMVWHTAdjustment = uiDriver.getValue_Text("FMVWHTAdjustment");
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVWHTAdjustment.contains("0")) {
			passed("Verify the FMVWHTAdjustment",
					"FMVWHTAdjustment  should be displayed Successfully as "
							+ FMVWHTAdjustment + "",
					"FMVWHTAdjustment is displayed Successfully as "
							+ FMVWHTAdjustment + "");

		} else {
			failed("Verify the FMVWHTAdjustment",
					"FMVWHTAdjustment  should be displayed Successfully as "
							+ FMVWHTAdjustment + "",
					"FMVWHTAdjustment is not displayed Successfully as "
							+ FMVWHTAdjustment + "");

		}

	}

	/****************************************
	 * Name: ValidateFMVForHighlander 
	 * Description: ValidateFMVForHighlander 
	 * Date: 14-November-2018
	 ****************************************/
	public void FMVAdjustmentHighLucy(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.executeJavaScript("(scroll(0,300));");
		uiDriver.click("CustomTab");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.executeJavaScript("(scroll(0,900));");
		uiDriver.click("FMVAdjustment");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Dropdown");		
		List<WebElement> dropdown = uiDriver.webDr.findElements(By.xpath("//div[@class='dropdownDiv']/div"));
		int dropdownsize = dropdown.size();
		highlandersearch:
		for(int k=1;k<=dropdownsize;k++)
		{
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("FMVAdjustment");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Dropdown");
		//	uiDriver.click("//input[@name='inpt_recmachcustrecord_nbcu_sorange']");
			SleepUtils.sleep(TimeSlab.HIGH);
		//	uiDriver.click_dynamic("//div[@class='dropdownDiv']/div["+k+"]");
			String sheets = uiDriver.getDyanmicData("sheets");
			String sheetno = sheets.replace("#", Integer.toString(k));
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click_dynamic(sheetno);
			List<WebElement> titles = uiDriver.webDr.findElements(By.xpath("(//div[text()='Title'])[2]/../../../following-sibling::tbody/tr"));
			int titlesize = titles.size();
			for(int l=0;l<titlesize;l++)
			{
				String random = uiDriver.getDyanmicData("titlenames");
				String randomno = random.replace("#", Integer.toString(l));
				String titlevalue=uiDriver.getValue_Text(randomno);
				String Title = input.get("title");
				SleepUtils.sleep(TimeSlab.YIELD);
				if (Title.equalsIgnoreCase(titlevalue))
				{
					passed("Verify the Title",
							""+ Title +" should be displayed Successfully as "+ titlevalue + "",
							""+ Title +" is displayed Successfully as "+ titlevalue + "");
					SleepUtils.sleep(TimeSlab.HIGH);
					//uiDriver.executeJavaScript("(scroll(0,2500));");
				//	uiDriver.click("HighlanderID");	
					String FMVTitles = uiDriver.getDyanmicData("FMVTitles");
					String FMVActualtitle = FMVTitles.replace("#", input.get("title"));
					uiDriver.click_dynamic(FMVActualtitle);
					
					
					SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("(scroll(0,2500));");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("ContractBilledRevenue");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String ContractBilledRevenue = uiDriver.getValue_Text("Contractual");		
		SleepUtils.sleep(TimeSlab.YIELD);
		if (ContractBilledRevenue.contains(input.get("ContractualBilledRevenue"))) {
			passed("Verify the ContractBilledRevenue",
					"ContractBilledRevenue  should be displayed Successfully as "
							+ ContractBilledRevenue + "",
					"ContractBilledRevenue is displayed Successfully as "
							+ ContractBilledRevenue + "");

		} else {
			failed("Verify the ContractBilledRevenue",
					"ContractBilledRevenue should be displayed Successfully as "
							+ ContractBilledRevenue + "",
					"ContractBilledRevenue is not displayed Successfully as "
							+ ContractBilledRevenue + "");

		}
		
		String FMVBilledRevenueAdjustment = uiDriver.getValue_Text("FMVBilledRevenueAdjustment");		
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVBilledRevenueAdjustment.contains(input.get("BilledRevenueAdjustment"))) {
			passed("Verify the FMVBilledRevenueAdjustment",
					"FMVBilledRevenueAdjustment  should be displayed Successfully as "
							+ FMVBilledRevenueAdjustment + "",
					"FMVBilledRevenueAdjustment is displayed Successfully as "
							+ FMVBilledRevenueAdjustment + "");

		} else {
			failed("Verify the FMVBilledRevenueAdjustment",
					"FMVBilledRevenueAdjustment  should be displayed Successfully as "
							+ FMVBilledRevenueAdjustment + "",
					"FMVBilledRevenueAdjustment is not displayed Successfully as "
							+ FMVBilledRevenueAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractUnBilledRevenue");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVUnBilledRevenue = uiDriver.getValue_Text("FMVUnBilledRevenue");		
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVUnBilledRevenue.contains(input.get("ContractUnbilledRevenue"))){
			passed("Verify the FMVUnBilledRevenue",
					"FMVUnBilledRevenue  should be displayed Successfully as "
							+ FMVUnBilledRevenue + "",
					"FMVUnBilledRevenue is displayed Successfully as "
							+ FMVUnBilledRevenue + "");

		} else {
			failed("Verify the FMVUnBilledRevenue",
					"FMVUnBilledRevenue should be displayed Successfully as "
							+ FMVUnBilledRevenue + "",
					"FMVUnBilledRevenue is not displayed Successfully as "
							+ FMVUnBilledRevenue + "");

		}
		
		String FMVUnBilledRevenueAdjustment = uiDriver.getValue_Text("FMVBilledRevenueAdjustment");		
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVUnBilledRevenueAdjustment.contains(input.get("UnBilledRevenueAdjustment"))) {
			passed("Verify the FMVUnBilledRevenueAdjustment",
					"FMVUnBilledRevenueAdjustment  should be displayed Successfully as "
							+ FMVUnBilledRevenueAdjustment + "",
					"FMVUnBilledRevenueAdjustment is displayed Successfully as "
							+ FMVUnBilledRevenueAdjustment + "");

		} else {
			failed("Verify the FMVUnBilledRevenueAdjustment",
					"FMVUnBilledRevenueAdjustment  should be displayed Successfully as "
							+ FMVUnBilledRevenueAdjustment + "",
					"FMVUnBilledRevenueAdjustment is not displayed Successfully as "
							+ FMVUnBilledRevenueAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractBilledAR");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVBilledAR = uiDriver.getValue_Text("FMVBilledAR");		
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVBilledAR.contains(input.get("BilledAR"))) {
			passed("Verify the FMVBilledAR",
					"FMVBilledAR  should be displayed Successfully as "
							+ FMVBilledAR + "",
					"FMVBilledAR is displayed Successfully as " + FMVBilledAR
							+ "");

		} else {
			failed("Verify the FMVBilledAR",
					"FMVBilledAR should be displayed Successfully as "
							+ FMVBilledAR + "",
					"FMVBilledAR is not displayed Successfully as "
							+ FMVBilledAR + "");

		}

		String FMVBilledARAdjustment = uiDriver.getValue_Text("FMVBilledARAdjustment");		
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVBilledARAdjustment.contains(input.get("BilledARAdjustment"))) {
			passed("Verify the FMVBilledARAdjustment",
					"FMVBilledARAdjustment  should be displayed Successfully as "
							+ FMVBilledARAdjustment + "",
					"FMVBilledARAdjustment is displayed Successfully as "
							+ FMVBilledARAdjustment + "");

		} else {
			failed("Verify the FMVBilledARAdjustment",
					"FMVBilledARAdjustment  should be displayed Successfully as "
							+ FMVBilledARAdjustment + "",
					"FMVBilledARAdjustment is not displayed Successfully as "
							+ FMVBilledARAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractUnBilledAR");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVUnBilledAR = uiDriver.getValue_Text("FMVUnBilledAR");		
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVUnBilledAR.contains("UnBilledAR")) {
			passed("Verify the FMVUnBilledAR",
					"FMVUnBilledAR  should be displayed Successfully as "
							+ FMVUnBilledAR + "",
					"FMVUnBilledAR is displayed Successfully as "
							+ FMVUnBilledAR + "");

		} else {
			failed("Verify the FMVUnBilledAR",
					"FMVUnBilledAR should be displayed Successfully as "
							+ FMVUnBilledAR + "",
					"FMVUnBilledAR is not displayed Successfully as "
							+ FMVUnBilledAR + "");

		}

		String FMVUnBilledARAdjustment = uiDriver.getValue_Text("FMVUnBilledARAdjustment");		
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVUnBilledARAdjustment.contains("UnBilledARAdjustment")) {
			passed("Verify the FMVUnBilledARAdjustment",
					"FMVUnBilledARAdjustment  should be displayed Successfully as "
							+ FMVUnBilledARAdjustment + "",
					"FMVUnBilledARAdjustment is displayed Successfully as "
							+ FMVUnBilledARAdjustment + "");

		} else {
			failed("Verify the FMVUnBilledARAdjustment",
					"FMVUnBilledARAdjustment  should be displayed Successfully as "
							+ FMVUnBilledARAdjustment + "",
					"FMVUnBilledARAdjustment is not displayed Successfully as "
							+ FMVUnBilledARAdjustment + "");
//-------
		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractUnpaidDeferred");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVUnpaidDeferred = uiDriver.getValue_Text("FMVUnpaidDeferred");		
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVUnpaidDeferred.contains("UnpaidDeferred")) {
			passed("Verify the FMVUnpaidDeferred",
					"FMVUnpaidDeferred  should be displayed Successfully as "
							+ FMVUnpaidDeferred + "",
					"FMVUnpaidDeferred is displayed Successfully as "
							+ FMVUnpaidDeferred + "");

		} else {
			failed("Verify the FMVUnpaidDeferred",
					"FMVUnpaidDeferred should be displayed Successfully as "
							+ FMVUnpaidDeferred + "",
					"FMVUnpaidDeferred is not displayed Successfully as "
							+ FMVUnpaidDeferred + "");

		}															

		String FMVUnpaidDeferredAdjustment = uiDriver.getValue_Text("FMVUnpaidDeferredAdjustment");		
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVUnpaidDeferredAdjustment.contains("UnpaidDeferredAdjustment")) {
			passed("Verify the FMVUnpaidDeferredAdjustment",
					"FMVUnpaidDeferredAdjustment  should be displayed Successfully as "
							+ FMVUnpaidDeferredAdjustment + "",
					"FMVUnpaidDeferredAdjustment is displayed Successfully as "
							+ FMVUnpaidDeferredAdjustment + "");

		} else {
			failed("Verify the FMVUnpaidDeferredAdjustment",
					"FMVUnpaidDeferredAdjustment  should be displayed Successfully as "
							+ FMVUnpaidDeferredAdjustment + "",
					"FMVUnpaidDeferredAdjustment is not displayed Successfully as "
							+ FMVUnpaidDeferredAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractPaidDeferred");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVPaidDeferred = uiDriver.getValue_Text("FMVPaidDeferred");		
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVPaidDeferred.contains("PaidDeferred")) {
			passed("Verify the FMVPaidDeferred",
					"FMVPaidDeferred  should be displayed Successfully as "
							+ FMVPaidDeferred + "",
					"FMVPaidDeferred is displayed Successfully as "
							+ FMVPaidDeferred + "");

		} else {
			failed("Verify the FMVPaidDeferred",
					"FMVPaidDeferred should be displayed Successfully as "
							+ FMVPaidDeferred + "",
					"FMVPaidDeferred is not displayed Successfully as "
							+ FMVPaidDeferred + "");

		}

		String FMVPaidDeferredAdjustment = uiDriver.getValue_Text("FMVPaidDeferredAdjustment");		
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVPaidDeferredAdjustment.contains("PaidDeferredAdjustment")) {
			passed("Verify the FMVPaidDeferredAdjustment",
					"FMVPaidDeferredAdjustment  should be displayed Successfully as "
							+ FMVPaidDeferredAdjustment + "",
					"FMVPaidDeferredAdjustment is displayed Successfully as "
							+ FMVPaidDeferredAdjustment + "");

		} else {
			failed("Verify the FMVPaidDeferredAdjustment",
					"FMVPaidDeferredAdjustment  should be displayed Successfully as "
							+ FMVPaidDeferredAdjustment + "",
					"FMVPaidDeferredAdjustment is not displayed Successfully as "
							+ FMVPaidDeferredAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractFXGainLoss");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVFXGainLoss = uiDriver.getValue_Text("FMVFXGainLoss");		
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVFXGainLoss.contains("FXGainLoss")) {
			passed("Verify the FMVFXGainLoss",
					"FMVFXGainLoss  should be displayed Successfully as "
							+ FMVFXGainLoss + "",
					"FMVFXGainLoss is displayed Successfully as "
							+ FMVFXGainLoss + "");

		} else {
			failed("Verify the FMVFXGainLoss",
					"FMVFXGainLoss should be displayed Successfully as "
							+ FMVFXGainLoss + "",
					"FMVFXGainLoss is not displayed Successfully as "
							+ FMVFXGainLoss + "");

		}

		String FMVFXGainLossAdjustment = uiDriver.getValue_Text("FMVFXGainLossAdjustment");		
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVFXGainLossAdjustment.contains("FXGainLossAdjustment")) {
			passed("Verify the FMVFXGainLossAdjustment",
					"FMVFXGainLossAdjustment  should be displayed Successfully as "
							+ FMVFXGainLossAdjustment + "",
					"FMVFXGainLossAdjustment is displayed Successfully as "
							+ FMVFXGainLossAdjustment + "");

		} else {
			failed("Verify the FMVFXGainLossAdjustment",
					"FMVFXGainLossAdjustment  should be displayed Successfully as "
							+ FMVFXGainLossAdjustment + "",
					"FMVFXGainLossAdjustment is not displayed Successfully as "
							+ FMVFXGainLossAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractWHT");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVWHT = uiDriver.getValue_Text("FMVWHT");		
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVWHT.contains("WHT")) {
			passed("Verify the FMVWHT",
					"FMVWHT  should be displayed Successfully as " + FMVWHT
							+ "", "FMVWHT is displayed Successfully as "
							+ FMVWHT + "");

		} else {
			failed("Verify the FMVWHT",
					"FMVWHT should be displayed Successfully as " + FMVWHT + "",
					"FMVWHT is not displayed Successfully as " + FMVWHT + "");

		}

		String FMVWHTAdjustment = uiDriver.getValue_Text("FMVWHTAdjustment");		
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVWHTAdjustment.contains("WHTAdjustment")) {
			passed("Verify the FMVWHTAdjustment",
					"FMVWHTAdjustment  should be displayed Successfully as "
							+ FMVWHTAdjustment + "",
					"FMVWHTAdjustment is displayed Successfully as "
							+ FMVWHTAdjustment + "");

		} else {
			failed("Verify the FMVWHTAdjustment",
					"FMVWHTAdjustment  should be displayed Successfully as "
							+ FMVWHTAdjustment + "",
					"FMVWHTAdjustment is not displayed Successfully as "
							+ FMVWHTAdjustment + "");

		}
					break highlandersearch;
				}

	}
	
		}
		
//		uiDriver.executeJavaScript("(scroll(0,1500));");
//		SleepUtils.sleep(TimeSlab.MEDIUM);
//		uiDriver.click("HighlanderID");
		

	}
	
	/****************************************
	 * Name: VerifyEstimateReason 
	 * Description: VerifyEstimateReason 
	 * Date: 12-Sept-2018
	 ****************************************/
	public void VerifyEstimateReason(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("(scroll(0,500));");
		uiDriver.click("RelatedTransactions");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("DocumentNumber");
		SleepUtils.sleep(TimeSlab.LOW);
		String Action = uiDriver.getValue_Text("Action");
		if (Action.contains("Update SO Line")) {
			passed("Verify the Action",
					"Action  should be displayed Successfully as " + Action
							+ "", "Action is displayed Successfully as "
							+ Action + "");

		} else {
			failed("Verify the Action",
					"Action  should be displayed Successfully as " + Action
							+ "", "Action is not displayed Successfully as "
							+ Action + "");

		}

		String RevrecMethod = uiDriver.getValue_Text("RevrecMethod");
		if (RevrecMethod.contains("License Period Start Date")) {
			passed("Verify the RevrecMethod",
					"RevrecMethod  should be displayed Successfully as "
							+ RevrecMethod + "",
					"RevrecMethod is displayed Successfully as " + RevrecMethod
							+ "");

		} else {
			failed("Verify the RevrecMethod",
					"RevrecMethod  should be displayed Successfully as "
							+ RevrecMethod + "",
					"RevrecMethod is not displayed Successfully as "
							+ RevrecMethod + "");

		}
		String LicensePeriodStartDate = uiDriver
				.getValue_Text("LicensePeriodStartDate");
		if (LicensePeriodStartDate.contains("12/31/2017")) {
			passed("Verify the LicensePeriodStartDate",
					"LicensePeriodStartDate  should be displayed Successfully as "
							+ LicensePeriodStartDate + "",
					"LicensePeriodStartDate is displayed Successfully as "
							+ LicensePeriodStartDate + "");

		} else {
			failed("Verify the LicensePeriodStartDate",
					"LicensePeriodStartDate  should be displayed Successfully as "
							+ LicensePeriodStartDate + "",
					"LicensePeriodStartDate is not displayed Successfully as "
							+ LicensePeriodStartDate + "");

		}

		String LicensePeriodEndDate = uiDriver
				.getValue_Text("LicensePeriodEndDate");
		if (LicensePeriodEndDate.contains("12/1/2017")) {
			passed("Verify the LicensePeriodEndDate",
					"LicensePeriodEndDate  should be displayed Successfully as "
							+ LicensePeriodEndDate + "",
					"LicensePeriodEndDate is displayed Successfully as "
							+ LicensePeriodEndDate + "");

		} else {
			failed("Verify the LicensePeriodEndDate",
					"LicensePeriodEndDate  should be displayed Successfully as "
							+ LicensePeriodEndDate + "",
					"LicensePeriodEndDate is not displayed Successfully as "
							+ LicensePeriodEndDate + "");

		}
		String DeliveryDate = uiDriver.getValue_Text("DeliveryDate");
		if (DeliveryDate.contains("1/8/2018")) {
			passed("Verify the DeliveryDate",
					"DeliveryDate  should be displayed Successfully as "
							+ DeliveryDate + "",
					"DeliveryDate is displayed Successfully as " + DeliveryDate
							+ "");

		} else {
			failed("Verify the DeliveryDate",
					"DeliveryDate  should be displayed Successfully as "
							+ DeliveryDate + "",
					"DeliveryDate is not displayed Successfully as "
							+ DeliveryDate + "");

		}

		String RevRecStartDate = uiDriver.getValue_Text("RevRecStartDate");
		if (RevRecStartDate.contains("1/8/2018")) {
			passed("Verify the RevRecStartDate",
					"RevRecStartDate  should be displayed Successfully as "
							+ RevRecStartDate + "",
					"RevRecStartDate is displayed Successfully as "
							+ RevRecStartDate + "");

		} else {
			failed("Verify the RevRecStartDate",
					"RevRecStartDate  should be displayed Successfully as "
							+ RevRecStartDate + "",
					"RevRecStartDate is not displayed Successfully as "
							+ RevRecStartDate + "");

		}

		String RevRecEndDate = uiDriver.getValue_Text("RevRecEndDate");
		if (RevRecEndDate.contains("1/8/2018")) {
			passed("Verify the RevRecEndDate",
					"RevRecEndDate  should be displayed Successfully as "
							+ RevRecEndDate + "",
					"RevRecEndDate is displayed Successfully as "
							+ RevRecEndDate + "");

		} else {
			failed("Verify the RevRecEndDate",
					"RevRecEndDate  should be displayed Successfully as "
							+ RevRecEndDate + "",
					"RevRecEndDate is not displayed Successfully as "
							+ RevRecEndDate + "");

		}
	}

	
	/****************************************
	 * Name: VerifyEstimateReasonRemoveSO 
	 * Description: VerifyEstimateReasonRemoveSO 
	 * Date: 31-October-2018
	 ****************************************/
	public void VerifyEstimateReasonRemoveSO(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("(scroll(0,500));");
		uiDriver.click("RelatedTransactions");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("DocumentNumber");
		SleepUtils.sleep(TimeSlab.LOW);
		String RemoveSoLine = uiDriver.getValue_Text("RemoveSoLine");
		if (RemoveSoLine.contains("Remove SO Line")) {
			passed("Verify the RemoveSoLine",
					"RemoveSoLine  should be displayed Successfully as " + RemoveSoLine
							+ "", "RemoveSoLine is displayed Successfully as "
							+ RemoveSoLine + "");

		} else {
			failed("Verify the RemoveSoLine",
					"RemoveSoLine  should be displayed Successfully as " + RemoveSoLine
							+ "", "RemoveSoLine is not displayed Successfully as "
							+ RemoveSoLine + "");

		}

		String Title = uiDriver.getValue_Text("Title");
		if (Title.contains("BNI-05|I3522|JAKE & AMY")) {
			passed("Verify the Title",
					"Title  should be displayed Successfully as "
							+ Title + "",
					"Title is displayed Successfully as " + Title
							+ "");

		} else {
			failed("Verify the Title",
					"Title  should be displayed Successfully as "
							+ Title + "",
					"Title is not displayed Successfully as "
							+ Title + "");

		}
		
		
	}

	
	/****************************************
	 * Name: ValidateRevision 
	 * Description: ValidateRevision 
	 * Date: 31-October-2018
	 ****************************************/
	public void ValidateRevision(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("(scroll(0,-1500));");
		uiDriver.click("ValidateRevision");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.handleAlert("", "OK");
		SleepUtils.sleep(TimeSlab.LOW);
		
	}
	
	/****************************************
	 * Name: VerifyEstimateReason 
	 * Description: VerifyEstimateReason 
	 * Date: 12-Sept-2018
	 ****************************************/
	public void VerifyMasterRevisionEstimateStatus(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.executeJavaScript("(scroll(0,500));");
		uiDriver.click("RelatedTransactions");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("DocumentNumber");
		SleepUtils.sleep(TimeSlab.LOW);
		String CommittedChk = uiDriver.getAttribute("CommittedChk", "class");
		if (CommittedChk.contains("checkbox_read_ck")) {
			passed("Verify the Committed Check box",
					"Committed check box should be Checked Successfully",
					"Committed check box is Checked Successfully");

		} else {
			failed("Verify the Committed Check box",
					"Committed check box should be Checked Successfully",
					"Committed check box is not Checked Successfully");

		}
	}
	/****************************************
	 * Name: AllocationRuleAssignedToMultipleBillingSchedule 
	 * Description: AllocationRuleAssignedToMultipleBillingSchedule
	 * Date: 12-Sept-2018
	 ****************************************/
	public void AllocationRuleAssignedToMultipleBillingSchedule(DataRow input,
			DataRow output) {
		SleepUtils.sleep(TimeSlab.HIGH);

		List<WebElement> Billing = uiDriver.webDr.findElements(By.xpath("//*[@id='contract-billing-schedules-grid']/div[3]/table//tr"));
		int size = Billing.size();
		for(i=1;i<size;i++)
		{
			String Edit = uiDriver.getDyanmicData("Edit");
			String EditField = Edit.replace("#", Integer.toString(i));
			uiDriver.click_dynamic(EditField);
			uiDriver.executeJavaScript("scroll(900,0)");
			uiDriver.setValue("AllocationRule", input.get("AllocationRule"));
			uiDriver.click("//*[@id='AllocationRuleNote']");
			Boolean Result = uiDriver.webDr.findElement(By.id("TerritoriesCheckbox")).isSelected();
			if (Result.equals(false)) {

				uiDriver.click("Territories");
			} else {
				// do nothing
			}

			Boolean RightResult = uiDriver.webDr.findElement(By.id("RightsCheckbox")).isSelected();
			if (RightResult.equals(false)) {

				uiDriver.click("Rights");
			} else {
				// do nothing
			}
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Next");
			Boolean Result1 = uiDriver.webDr.findElement(
					By.id("TerritoriesCheckbox")).isSelected();
			if (Result1.equals(false)) {

				uiDriver.click("Territories");
			} else {
				// do nothing
			}

			Boolean RightResult1 = uiDriver.webDr.findElement(
					By.id("RightsCheckbox")).isSelected();
			if (RightResult1.equals(false)) {

				uiDriver.click("Rights");
			} else {
				// do nothing
			}
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Next");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Next");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.executeJavaScript("scroll(0,600)");
			uiDriver.click("Next");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Finish");
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);	}
	}	
	
	/****************************************
	 * Name: GenerateMultipleInvoices
	 * Description: GenerateMultipleInvoices
	 * Date: 12-Sept-2018
	 ****************************************/
	public void GenerateMultipleInvoices3(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Invoices");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("BulkOperations");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("GenerateInvoices");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Filter");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("searchinput");
		String ContractId = input.get("ContractId");
		uiDriver.setValue("searchinput", input.get("ContractId"));
		// uiDriver.setValue("searchinput", "123178");
		if(input.get("Title").equals("Y"))
		{
			uiDriver.click("TitleAll");
			uiDriver.setValue("TitleAllGetText",input.get("Titlename"));
			SleepUtils.sleep(TimeSlab.MEDIUM);
				
		}
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Search");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("//*[@id='CriteriaDropdown']/button[1]");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("//*[@id='FilterSelector']/li[30]/label/input");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("//*[@id='CriteriaContainer']/div[4]/div/span[2]");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.setValue("//*[@id='CriteriaContainer']/div[4]/ul/li[4]/span[1]/span/input",input.get("StartDate"));
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.setValue("//*[@id='CriteriaContainer']/div[4]/ul/li[4]/span[2]/span/input",input.get("EndDate"));
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Search");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		if(input.get("Pagination").equals("Y")){
			uiDriver.executeJavaScript("scroll(0,2000)");
			String pages = uiDriver.getValue_Text("No.of.pages");
			String PageArr[] = pages.split(" ");
			String SetPage = PageArr[4];
			Integer page = Integer.parseInt(SetPage)- 50;
			SleepUtils.sleep(TimeSlab.LOW);
			for(int n=0;n<page;n++){
				uiDriver.click("//*[@id='AdvancedSearchResultsGrid']/div[4]/span[1]/span/span/span[2]/span[1]/span");
				SleepUtils.sleep(3);	
			}
			SleepUtils.sleep(TimeSlab.HIGH);	
			uiDriver.executeJavaScript("scroll(0,-2500)");
			uiDriver.click("Search");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("CheckAllRows");
			//uiDriver.webDr.findElement(By.xpath("//*[@id='AdvancedSearchResultsGrid']/div[4]/span[1]/span/span/input[1]")).sendKeys(Keys.ENTER);
			SleepUtils.sleep(TimeSlab.LOW);
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("Createinvoice");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			String invoicenum = uiDriver.getValue("InvoiceID");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("InvoiceID");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			passed("Verify the Invoice",
					"Invoice should be displayed successfully",
					"Invoice is displayed successfully");
			output.put("Invoice", invoicenum);
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("Invoices");
			SleepUtils.sleep(TimeSlab.YIELD);
			output.put("Invoice", invoicenum);
							
		}
		else{

		uiDriver.click("CheckAllRows");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Createinvoice");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String invoicenum = uiDriver.getValue("InvoiceID");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("InvoiceID");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		passed("Verify the Invoice",
				"Invoice should be displayed successfully",
				"Invoice is displayed successfully");
		output.put("Invoice", invoicenum);
		SleepUtils.sleep(TimeSlab.LOW);
		//uiDriver.click("Invoices");
		//SleepUtils.sleep(TimeSlab.YIELD);
		output.put("Invoice", invoicenum);
		}	
	}

	public void GenerateMultipleInvoices(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Invoices");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("BulkOperations");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("GenerateInvoices");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Filter");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("searchinput");
		String ContractId = input.get("ContractId");
		uiDriver.setValue("searchinput", input.get("ContractId"));
		// uiDriver.setValue("searchinput", "123178");
		if(input.get("Title").equals("Y"))
		{
		uiDriver.click("TitleAll");
		uiDriver.setValue("TitleAllGetText",input.get("Titlename"));
		SleepUtils.sleep(TimeSlab.MEDIUM);
		}
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Search");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		//uiDriver.click("//*[@id='CriteriaDropdown']/button[1]");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		//uiDriver.click("//*[@id='FilterSelector']/li[30]/label/input");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		//uiDriver.click("//*[@id='CriteriaContainer']/div[4]/div/span[2]");
		uiDriver.click("//span[text()='Effective Due Date: All']");
		//label[text()='On or after']/following-sibling::span[1]
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.setValue("//label[text()='On or after']/following-sibling::span[1]/span/input",input.get("StartDate"));
		//uiDriver.setValue("//*[@id='CriteriaContainer']/div[4]/ul/li[4]/span[1]/span/input",input.get("StartDate"));
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.setValue("//label[text()='Before']/following-sibling::span[1]/span/input",input.get("EndDate"));
		//uiDriver.setValue("//*[@id='CriteriaContainer']/div[4]/ul/li[4]/span[2]/span/input",input.get("EndDate"));
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Search");
		SleepUtils.sleep(TimeSlab.HIGH);
		if(input.get("Pagination").equals("Y")){
		uiDriver.executeJavaScript("scroll(0,2000)");
		String pages = uiDriver.getValue_Text("No.of.pages");
		String PageArr[] = pages.split(" ");
		String SetPage = PageArr[4];
		Integer page = Integer.parseInt(SetPage)- 50;
		SleepUtils.sleep(TimeSlab.LOW);
		for(int n=0;n<page;n++){
		uiDriver.click("//*[@id='AdvancedSearchResultsGrid']/div[4]/span[1]/span/span/span[2]/span[1]/span");
		SleepUtils.sleep(3);
		 
		}
		SleepUtils.sleep(TimeSlab.HIGH);
		 
		uiDriver.executeJavaScript("scroll(0,-2500)");
		uiDriver.click("Search");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("//*[@id='AdvancedSearchResultsGrid']/div[1]/a");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Createinvoicebutton");
		//uiDriver.click("CheckAllRows");
		//uiDriver.webDr.findElement(By.xpath("//*[@id='AdvancedSearchResultsGrid']/div[4]/span[1]/span/span/input[1]")).sendKeys(Keys.ENTER);
		SleepUtils.sleep(TimeSlab.LOW);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Createinvoice");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String invoicenum = uiDriver.getValue("InvoiceID");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("InvoiceID");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		passed("Verify the Invoice",
		"Invoice should be displayed successfully",
		"Invoice is displayed successfully");
		output.put("Invoice", invoicenum);
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Invoices");
		SleepUtils.sleep(TimeSlab.YIELD);
		output.put("Invoice", invoicenum);
		}
		else{
		uiDriver.click("//*[@id='AdvancedSearchResultsGrid']/div[1]/a");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("//*[@id='generateAll']/div/div[2]/button[2]");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("(//a[text()='Invoice Queue'])[2]");
		//uiDriver.click("CheckAllRows");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		//uiDriver.click("Createinvoice");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String invoicenum = uiDriver.getValue("//a[text()='Invoice #']/../../../following-sibling::tbody/tr[1]/td[4]");
		//String invoicenum = uiDriver.getValue("InvoiceID");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		//uiDriver.click("InvoiceID");
		uiDriver.click("//a[text()='Invoice #']/../../../following-sibling::tbody/tr[1]/td[4]");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		passed("Verify the Invoice",
		"Invoice should be displayed successfully",
		"Invoice is displayed successfully");
		output.put("Invoice", invoicenum);
		SleepUtils.sleep(TimeSlab.LOW);
		//uiDriver.click("Invoices");
		//SleepUtils.sleep(TimeSlab.YIELD);
		output.put("Invoice", invoicenum);
		}  
		}
	
	/****************************************
	* Name: NavigatetoFeeCalcStatements
	* Description: NavigatetoFeeCalcStatements
	* Date: 29-April-2019
	****************************************/
	public void NavigatetoFeeCalcStatements(DataRow input, DataRow output) 
	{
		uiDriver.click("(//a[text()='Finance'])[2]");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("(//a[text()='Fee Calculation'])[2]");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//a[text()='Statements']");
	}
	
	/****************************************
	* Name: AddFeecalcStatement
	* Description: AddFeecalcStatement
	* Date: 29-April-2019
	****************************************/
	public void AddFeecalcStatement(DataRow input, DataRow output) 
	{
		uiDriver.click("//input[@id='feeCalcStatementMonth']/..");
		SleepUtils.sleep(TimeSlab.LOW);
		String month=uiDriver.getDyanmicData("Month");
		String month1 = month.replace("#", input.get("Month"));
		uiDriver.click_dynamic(month1);
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//input[@id='feeCalcStatementYear']/..");
		SleepUtils.sleep(TimeSlab.LOW);
		String Year=uiDriver.getDyanmicData("Year");
		String Year1 = Year.replace("#", input.get("Year"));
		uiDriver.click_dynamic(Year1);
		uiDriver.click("//*[@id='feeCalcStatementType']/..");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//li[text()='Actual']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("paytv1");
		SleepUtils.sleep(TimeSlab.LOW);
		//uiDriver.setValue("paytv", "hi");
		SleepUtils.sleep(TimeSlab.LOW);
		WebElement w = uiDriver.webDr.findElement(By.xpath("//*[@id='templateInputs']/div[2]/div[2]/span[1]/span/input[2]"));
		String paytv = input.get("paytv");
		((JavascriptExecutor)uiDriver.webDr).executeScript("arguments[0].value='"+paytv+"'", w);
		SleepUtils.sleep(TimeSlab.LOW);
		((JavascriptExecutor)uiDriver.webDr).executeScript("arguments[0].click()", w);
		//new Actions(uiDriver.webDr).sendKeys(w, paytv);
		SleepUtils.sleep(TimeSlab.LOW);
		//w.click();
		new Actions(uiDriver.webDr).click(w);
		SleepUtils.sleep(TimeSlab.LOW);
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("neon1");
		WebElement w1 = uiDriver.webDr.findElement(By.xpath("//*[@id='templateInputs']/div[3]/div[2]/span[1]/span/input[2]"));
		
		String neon = input.get("neon");
		((JavascriptExecutor)uiDriver.webDr).executeScript("arguments[0].value='"+neon+"'", w1);
		SleepUtils.sleep(TimeSlab.LOW);
		((JavascriptExecutor)uiDriver.webDr).executeScript("arguments[0].click()", w1);
		SleepUtils.sleep(TimeSlab.LOW);
		new Actions(uiDriver.webDr).click(w1);
		SleepUtils.sleep(TimeSlab.LOW);
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("replacement1");
		WebElement w2 = uiDriver.webDr.findElement(By.xpath("//*[@id='templateInputs']/div[4]/div[2]/span[1]/span/input[2]"));
		String replacement = input.get("replacement");
		((JavascriptExecutor)uiDriver.webDr).executeScript("arguments[0].value='"+replacement+"'", w2);
		SleepUtils.sleep(TimeSlab.LOW);
		((JavascriptExecutor)uiDriver.webDr).executeScript("arguments[0].click()", w2);
		SleepUtils.sleep(TimeSlab.LOW);
		new Actions(uiDriver.webDr).click(w2);
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//*[@id='Save']");
		SleepUtils.sleep(TimeSlab.HIGH);
		
	}
	
	
	/****************************************
	* Name: Approveeachstatement
	* Description: Approve each statement
	* Date: 29-April-2019
	****************************************/
	public void Approveeachstatement(DataRow input, DataRow output) 
	{
		SleepUtils.sleep(TimeSlab.YIELD);
		List<WebElement> lst = uiDriver.webDr.findElements(By.xpath("//a[text()='Calculate']"));
		for(int i=1;i<=lst.size();i++)
		{
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String calculatebutton="(//a[text()='Calculate'])["+i+"]";
		uiDriver.click(calculatebutton);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("scroll(0,1000)");
		}
		
		List<WebElement> lst1 = uiDriver.webDr.findElements(By.xpath("//button[text()='Send to NS']"));
		for(int i=1;i<=lst1.size();i++)
		{
			String month=uiDriver.getDyanmicData("Month");
			String s = input.get("Month"+i);
			String month1 = month.replace("#", input.get("Month"+i));
			uiDriver.click_dynamic(month1);
		}
		
		passed("Approve each statement", "Each statement should be Approved",
				"Each statement is Approved");
	}
	


	/****************************************
	 * Name: ChangeWFStatusToMultipleInvoices 
	 * Description:ChangeWFStatusToMultipleInvoices
	 * Date: 11-July-2018
	 ****************************************/
	public void contractsearchfrominvoice (DataRow input, DataRow output) {
	uiDriver.click("//a[text()='Contracts']");
	SleepUtils.sleep(TimeSlab.MEDIUM);
	if(uiDriver.checkElementPresent_dynamic("//a[text()='Contract Search']"))
	{
	uiDriver.click("//a[text()='Contract Search']");
	}
	//SleepUtils.sleep(TimeSlab.MEDIUM);
	//uiDriver.click("//a[text()='Contract Search']");
	SleepUtils.sleep(TimeSlab.MEDIUM);
	}
	/****************************************
	 * Name: ChangeWFStatusToMultipleInvoices 
	 * Description:ChangeWFStatusToMultipleInvoices
	 * Date: 11-July-2018
	 ****************************************/
	public void ChangeWFStatusToMultipleInvoices(DataRow input, DataRow output) {
		uiDriver.click("Invoices");
		uiDriver.click("BulkOperations");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("ChangeWFStates");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Filter");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("searchinput");
		uiDriver.setValue("searchinput", input.get("ContractId"));
		SleepUtils.sleep(TimeSlab.MEDIUM);
		/*
		 * uiDriver.sendKey("enter"); uiDriver.sendKey("enter");
		 */
		uiDriver.click("Search");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("CheckAllRows");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("scroll(0,-1000)");
		uiDriver.click("Invoicedropdown");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SendforInvoice");
		uiDriver.click("SendforInvoice");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Transitiontoworkflow");
		SleepUtils.sleep(TimeSlab.HIGH);
		passed("Verify the Invoice is posted", "Invoice posted successfully",
				"Invoice posted successfully");

	}

	/****************************************
	 * Name: NavigateToFinancialSummary 
	 * Description: NavigateToFinancialSummary
	 * Date: 11-July-2018
	 ****************************************/
	public void NavigateToFinancialSummary(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("FinancialSummary");
		SleepUtils.sleep(TimeSlab.LOW);
		String Difference = uiDriver.getValue_Text("Difference");
		if (Difference != "0.00") {

			uiDriver.click("UpdateContractTotal");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("Yes");
			SleepUtils.sleep(TimeSlab.HIGH);
		} else {
			// do nothing
		}

	}

	/****************************************
	 * Name: AddTimeLineItemsForMultipledate Description: AddTimeLineItemsForMultipledate Date: 11-October-2018
	 ****************************************/
	public void AddTimeLineItemsForMultipledate(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Dates");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimeLineItems");
		SleepUtils.sleep(TimeSlab.LOW);
		
		for(int i = 1;i<=3;i++)
		{
		uiDriver.click("AddTimeLineItem");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setFrame("//*[@id='RadWindowWrapper_ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_TimelineItemWindow']/table/tbody/tr[2]/td[2]/iframe");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimelineItemType");
		// uiDriver.setValue("TimelineItemType",input.get("Type"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimelineItemTypeValue"+i);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("EST");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("Date", input.get("Date"+i));		
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Notes");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Project");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("WaistDeep");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("AddAll");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Finish");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.resetFrame();
		}
	}
	
	
	/****************************************
	 * Name: NavigateToFinancialSummary 
	 * Description: NavigateToFinancialSummary
	 * Date: 11-July-2018
	 ****************************************/
	public void VerifyNoLaterThanDate(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billing");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billingschedules");
		SleepUtils.sleep(TimeSlab.YIELD);
		List<WebElement> rows=uiDriver.webDr.findElements(By.xpath("//*[@id='contract-billing-schedules-grid']/div[3]/table/tbody/tr"));
		int rowSize=rows.size();
		for(int rown=2;rown<rowSize+1;rown++)
		{
			String Date = uiDriver.getDyanmicData("NoLaterThanDate");
			String Date1 = Date.replace("#",Integer.toString(rown));
			String nolaterdate=uiDriver.getValue(Date1);
			if(nolaterdate.isEmpty())
			{
				failed("Verify the NoLaterThanDate displayed",
						"NoLaterThanDate should be displayed successfully",
						"NoLaterThanDate is not displayed successfully");

			}
			
			else
			{
				passed("Verify the NoLaterThanDate displayed",
						"NoLaterThanDate should be displayed successfully",
						"NoLaterThanDate is not displayed successfully");

			}
			
			
		}
		
		/*WebElement tcst = uiDriver.webDr.findElement(By.xpath("//*[@id='contract-billing-schedules-grid']/div[3]/table/tbody/tr[2]/td[14]/div/a"));
		 String tooltip=tcst.getAttribute("title");
		
		if(tooltip.contains("TCST1"))
		{
			passed("Verify the Tooltip",
					"Tooltip should contain TCST1",
					"Tooltip does contain TCST1");

		}
		
		else
		{
			failed("Verify the Tooltip",
					"Tooltip should contain TCST1",
					"Tooltip does not  contain TCST1");
		}*/
		

	}

	 /****************************************
	 * Name: VerifyPayShipValue
	 * Description: VerifyPayShipValue
	 * Date: 02-Oct-2018
	 ****************************************/
	public void VerifyPayShipValue(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.click("//a[text()=\"Information\"]");
		uiDriver.click("//a[text()=\"Additional Info\"]");
		String Payship = uiDriver.getValue_Text("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_OtherDataAttributeValueGrid_ctl00_ctl10_ValueLabel']");
		if(input.get("Payship").equals("Y")){
		if (Payship.contains(input.get("Payshipvalue"))) {
			passed("Verify the Payship displayed",
					"Payship should be Checked successfully as " + Payship + "",
					"Payship is Checked successfully as" + Payship + "");

		} else {

			failed("Verify the Payship displayed",
					"Payship should be checked successfully as " + Payship + "",
					"Payship is not checked successfully as" + Payship + "");

		}
		}
		if(input.get("XPG-PTMG").equals("Y")){
		
		String PTMG = uiDriver.getValue_Text("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_OtherDataAttributeValueGrid_ctl00_ctl12_ValueLabel']");
		
		SleepUtils.sleep(5);
		String XPG = uiDriver.getValue_Text("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_OtherDataAttributeValueGrid_ctl00_ctl18_ValueLabel']");
		if (XPG.contains(input.get("XPG"))) {
			passed("Verify the XPG displayed",
					"XPG should be Checked successfully as " + XPG + "",
					"XPG is Checked successfully as" + XPG + "");

		} else {

			failed("Verify the XPG displayed",
					"XPG should be checked successfully as " + XPG + "",
					"XPG is not checked successfully as" + XPG + "");

		}	
		
		if (PTMG.contains(input.get("PTMG"))) {
			passed("Verify the PTMG displayed",
					"PTMG should be Checked successfully as " + PTMG + "",
					"PTMG is Checked successfully as" + PTMG + "");

		} else {

			failed("Verify the PTMG displayed",
					"PTMG should be checked successfully as " + PTMG + "",
					"PTMG is not checked successfully as" + PTMG + "");

		}	
		
			
			
		}
	}

	
	 /****************************************
	 * Name: AssignAllocationBASvalue
	 * Description: VerifyPayShipValue
	 *  Date: 02-Oct-2018
	 ****************************************/
	public void AssignAllocationBAS(DataRow input, DataRow output)
			throws InterruptedException {

uiDriver.click("projectdetails");
SleepUtils.sleep(TimeSlab.MEDIUM);
		
		 uiDriver.executeJavaScript("(scroll(0,25000));");
		String numofpages = uiDriver.getValue("lastpagenum");
		int pagenum = Integer.parseInt(numofpages);
		 uiDriver.executeJavaScript("(scroll(0,-25000));");
		 SleepUtils.sleep(TimeSlab.LOW);
		for (int i=1; i <= pagenum; i++) 
		{
			List<WebElement> rows=uiDriver.webDr.findElements(By.xpath("//table[@role='grid']//tr"));
			for( int rownum=1;rownum<=rows.size();rownum=rownum+2)
			{
				String Allocation = uiDriver.getDyanmicData("Allocation");
				String Allocation1 = Allocation.replace("#",Integer.toString(rownum));
				SleepUtils.sleep(TimeSlab.LOW);
				if(uiDriver.checkElementPresent_dynamic(Allocation1))
				{
		uiDriver.click(Allocation1);
				}
				else
				{
					break;
				}
		
					
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("Allocationdropdown");
			  SleepUtils.sleep(TimeSlab.LOW);
			  String Rights = uiDriver.getDyanmicData("Allocationvalue");
				String rights1 = Rights.replace("#",input.get("Rights"));
				if(uiDriver.checkElementPresent_dynamic(rights1))
						{
				uiDriver.click(rights1);
						}
				  SleepUtils.sleep(TimeSlab.LOW);
				  uiDriver.executeJavaScript("(scroll(0,-1000));");
				uiDriver.click("Save");
				SleepUtils.sleep(TimeSlab.MEDIUM);
				if(rownum>9)
				{
					uiDriver.executeJavaScript("(scroll(0,800));");
				}		
				
				
				
						
			
		}
			 uiDriver.executeJavaScript("(scroll(0,-1000));");
			 SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("recalculate");
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.executeJavaScript("(scroll(0,1000));");
			if(uiDriver.checkElementPresent("nextpage"))
			{
				if(i==2)
				{
					uiDriver.click("nextpage");
					SleepUtils.sleep(TimeSlab.MEDIUM);
					uiDriver.click("nextpage");
					SleepUtils.sleep(TimeSlab.MEDIUM);
					uiDriver.executeJavaScript("(scroll(0,-1000));");
					SleepUtils.sleep(TimeSlab.MEDIUM);
				}
				
				 SleepUtils.sleep(TimeSlab.MEDIUM);
				 uiDriver.click("nextpage");
				 SleepUtils.sleep(TimeSlab.MEDIUM);
				 uiDriver.executeJavaScript("(scroll(0,-1000));");
				 SleepUtils.sleep(TimeSlab.MEDIUM);
			
			}
			else
			{
				break;	
		}
		
		
		
		
	}
		uiDriver.click("Nextbutton");
		
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Lastrecalculate");
		}
	
			
	 /****************************************
	 * Name: ValidatingBillingScheduleDetails
	 * Description:NaviagteToBillingSchedule 
	 * Date: 11-July-2018
	 ****************************************/
	public void ValidatingBillingSchedules(DataRow input, DataRow output) {
		List<WebElement> billingValues = uiDriver.webDr.findElements(By.xpath("//*[@id=\'contract-billing-schedules-grid\']/div[3]/table/tbody/tr"));
		int billingValuedetails = billingValues.size();
		for (i = 0; i < billingValuedetails; i++) {
			String Amount = uiDriver.getValue_Text("//*[@id=\"contract-billing-schedules-grid\"]/div[3]/table/tbody/tr[i]/td[10]/p");
			String Projects = uiDriver.getValue_Text("//*[@id=\"contract-billing-schedules-grid\"]/div[3]/table/tbody/tr[i]/td[7]/p");
			String duedate = uiDriver.getValue_Text("//*[@id=\\\"contract-billing-schedules-grid\\\"]/div[3]/table/tbody/tr[i]/td[12]/p");
			if (Amount.contains(input.get("Amount"))) {
				passed("Verify the Amount displayed",
						"Amount should be displayed successfully as " + Amount
								+ "", "Amount is displayed successfully as"
								+ Amount + "");

			}

			else {
				failed("Verify the Amount displayed",
						"Amount should be displayed successfully as " + Amount
								+ "", "Amount is not displayed successfully as"
								+ Amount + "");

			}

			if (Projects.contains(input.get("Projects"))) {
				passed("Verify the Projects displayed",
						"Projects should be displayed successfully as "
								+ Projects + "",
						"Projects is displayed successfully as" + Projects + "");

			} else {

				failed("Verify the Projects displayed",
						"Projects should be displayed successfully as "
								+ Projects + "",
						"Projects is not displayed successfully as" + Projects
								+ "");

			}

			if (duedate.contains(input.get("duedate"))) {
				passed("Verify the duedate displayed",
						"duedate should be displayed successfully as "
								+ duedate + "",
						"duedate is displayed successfully as" + duedate + "");

			} else {

				failed("Verify the duedate displayed",
						"duedate should be displayed successfully as "
								+ duedate + "",
						"duedate is not displayed successfully as" + duedate
								+ "");

			}
		}

	}
	
	/****************************************
	 * Name: AddMultipleTerritoriess
	 * Description: AddMultipleTerritoriess
	 * Date: 11-July-2018
	 ****************************************/
	public  void AddMultipleTerritories(DataRow input, DataRow output)
            throws InterruptedException {
      
      SleepUtils.sleep(TimeSlab.LOW);
      uiDriver.setValue("Name", input.get("Name"));
      SleepUtils.sleep(TimeSlab.LOW);
      uiDriver.setValue("Note", input.get("Note"));
      SleepUtils.sleep(TimeSlab.LOW);
      uiDriver.click("InvoiceItemCategory");
      SleepUtils.sleep(TimeSlab.LOW);
      uiDriver.click("InvoiceItemCategoryInput");
      SleepUtils.sleep(TimeSlab.LOW);
      Boolean Result = uiDriver.webDr.findElement(By.id("TerritoriesCheckbox")).isSelected();
      if(Result.equals(false)){
            
            uiDriver.click("Territories");
            SleepUtils.sleep(TimeSlab.LOW);
      }
      else{
            //do nothing 
      }
      
      Boolean RightResult = uiDriver.webDr.findElement(By.id("RightsCheckbox")).isSelected();
      if(RightResult.equals(false)){
            
            uiDriver.click("Rights");
            SleepUtils.sleep(TimeSlab.LOW);
      }
      else{
            //do nothing 
      }
      
      uiDriver.click("Next");
      SleepUtils.sleep(TimeSlab.HIGH);
      SleepUtils.sleep(TimeSlab.HIGH);
      SleepUtils.sleep(TimeSlab.HIGH);
      uiDriver.executeJavaScript("document.getElementsByClassName('amount-value weight')[0].value='';");
      SleepUtils.sleep(TimeSlab.LOW);
      Actions action=new Actions(uiDriver.webDr);
      WebElement ele = uiDriver.webDr.findElement(By.xpath("//*[@id='territoriesGrid']/div[2]/table/tbody/tr[1]/td[4]/div[1]/div/input"));
      action.sendKeys("ele","").build().perform();
      action.sendKeys(ele ,"50.00").build().perform();
	  SleepUtils.sleep(TimeSlab.LOW);
	  uiDriver.executeJavaScript("(scroll(0,300));");
	 uiDriver.executeJavaScript("document.getElementsByClassName('amount-value weight')[8].value='';");
      SleepUtils.sleep(TimeSlab.LOW);
      Actions action1=new Actions(uiDriver.webDr);
      WebElement ele1 = uiDriver.webDr.findElement(By.xpath("//*[@id='territoriesGrid']/div[2]/table/tbody/tr[9]/td[4]/div[1]/div/input"));
      action.sendKeys("ele1","").build().perform();
      action.sendKeys(ele1 ,"50.00").build().perform();
      uiDriver.click("Next");
      SleepUtils.sleep(TimeSlab.HIGH);
      SleepUtils.sleep(TimeSlab.HIGH);
      SleepUtils.sleep(TimeSlab.HIGH);
      uiDriver.executeJavaScript("document.getElementsByClassName('amount-value weight')[27].value='';");
      SleepUtils.sleep(TimeSlab.LOW);
      WebElement ele2 = uiDriver.webDr.findElement(By.xpath("//*[@id='rightsGrid']/div[2]/table/tbody/tr[1]/td[4]/div[1]/div/input"));
      action.sendKeys("ele2","").build().perform();
      action.sendKeys(ele2 ,"50.00").build().perform();
      SleepUtils.sleep(TimeSlab.HIGH);
      uiDriver.executeJavaScript("document.getElementsByClassName('amount-value weight')[28].value='';");
      SleepUtils.sleep(TimeSlab.LOW);
      WebElement ele3 = uiDriver.webDr.findElement(By.xpath("//*[@id='rightsGrid']/div[2]/table/tbody/tr[2]/td[4]/div[1]/div/input"));
      action.sendKeys("ele3","").build().perform();
      action.sendKeys(ele3 ,"50.00").build().perform();
      SleepUtils.sleep(TimeSlab.HIGH);
      uiDriver.click("Finish");
      SleepUtils.sleep(TimeSlab.HIGH);
      SleepUtils.sleep(TimeSlab.HIGH);
      SleepUtils.sleep(TimeSlab.HIGH);
      output.put("Name", input.get("Name"));
}      

	/****************************************
	 * Name: VerifyWht
	 * Description: VerifyWht 
	 * Date: 10-Oct-2018
	 ****************************************/
	public void VerifyWht(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("//a[text()='Cas']");
		SleepUtils.sleep(TimeSlab.LOW);
		String cashadj=uiDriver.getValue_Text("//*[@id='custom60_form']/table/tbody/tr[1]/td/table/tbody/tr/td[2]/table/tbody/tr[1]/td/div/span[2]");
		if(cashadj.equals(input.get("amount")))
		{
			 passed("Verify Cash Adj ",
				     "Wht amount  should  be " +cashadj , 
				     "Wht amount  is  "+input.get("amount"));
		}
		else
		{
			failed("Verify Cash Adj ",
				     "Wht amount  should  be " +cashadj , 
				     "Wht amount  is not "+input.get("amount"));
		}
	
		
	}

/****************************************
	 * Name: copyContractNum 
	 * Description: copyContractNum 
	 * Date: 10-Oct-2018
	 ****************************************/
	public void copyContractNum(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Copy");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.handleAlert("", "OK");
		SleepUtils.sleep(TimeSlab.LOW);
		
	}
	
	 public void CalculateWhtAmount(DataRow input, DataRow output) {
		  
		  SleepUtils.sleep(TimeSlab.MEDIUM);
		     String Num = input.get("conf");
		  uiDriver.setValue("SearchSO", Num);
		  SleepUtils.sleep(TimeSlab.MEDIUM);
		  uiDriver.click("SalesOrder");
		  passed("SalesOrder", "SalesOrder Should be displayed Successfully",
		    "SalesOrder is displayed Successfully");
		  uiDriver.executeJavaScript("scroll(0,500)"); 
		  uiDriver.click("relatedRecord");
		  String Invoices = uiDriver.getDyanmicData("InvoiceLinks");
		  String InvoiceLink = Invoices.replace("#",input.get("Amount"));
		  uiDriver.click_dynamic(InvoiceLink);
		  
		  SleepUtils.sleep(TimeSlab.MEDIUM);
		  uiDriver.executeJavaScript("scroll(0,500)");
		  String Actualmasterinvoice=uiDriver.getValue_Text("actualmasterinvoice");
		  
		  
		  
		  
		  SleepUtils.sleep(TimeSlab.MEDIUM);
		  uiDriver.executeJavaScript("scroll(0,500)");
		  uiDriver.click("relatedRecord");
		  uiDriver.click("payment");
		  SleepUtils.sleep(TimeSlab.MEDIUM);
		        SleepUtils.sleep(TimeSlab.MEDIUM);
		        uiDriver.executeJavaScript("scroll(0,500)"); 
		        uiDriver.click("Cashadj");
		        uiDriver.executeJavaScript("scroll(0,500)");
		        String Whtamount = uiDriver.getValue_Text("Whtamount");
		        if(input.get("whtamount").contains(Whtamount)) {
		         passed("Wht amount ",
		     "Wht amount  should  be " +input.get("whtamount") , 
		     "Wht amount  is  "+Whtamount);
		  
		         
		        }
		        else {
		         failed("Wht amount ",
		     "Wht amount  should  be " +input.get("whtamount") , 
		     "Wht amount  is  "+Whtamount);
		  
		   
		        }
		        
		        if(uiDriver.getValue_Text("Masterinvoice").contains(Actualmasterinvoice)) {
		         passed("Masterinvoice",
		     "Masterinvoice  should  be " +uiDriver.getValue_Text("Masterinvoice") , 
		     "Masterinvoice  is  "+Actualmasterinvoice);
		  
		         
		        }
		        else {
		         passed("Masterinvoice",
		     "Masterinvoice  should  be " +input.get("Masterinvoice") , 
		     "Masterinvoice  is  "+Actualmasterinvoice);
		  
		        }
		        
		     uiDriver.executeJavaScript("scroll(0,0)"); 
		  
		  
		 }
		 

	

	/****************************************
	 * Name: uploadingFilesViaFTP
	 * Description: uploadingFilesViaFTP
	 * Date: 11-July-2018
	 * @throws Exception 
	 ****************************************/
	public  void uploadingFilesViaFTP(DataRow input, DataRow output)
            throws Exception {
	
		String filePath = input.get("filePath");
		String fileName = input.get("fileName");
		uiDriver.FTPUploader("ftp.universalstudios.com", "webcollect-test", "Ln3D*54q");
        uiDriver.uploadFile(filePath,fileName);
       uiDriver.disconnect();
    }
	
	/****************************************
	 * Name: viewRevPlanupdated
	 * Description: viewRevPlanupdated
	 * Date: 11-July-2018
	 * @throws Exception 
	 ****************************************/
	
	public void viewRevPlanupdated(DataRow input, DataRow output) {

		SleepUtils.sleep(10);
          // add view plan step here
        uiDriver.click("viewRevplanBtn");
        SleepUtils.sleep(TimeSlab.YIELD);
        // validation pendlin
        SleepUtils.sleep(TimeSlab.YIELD);
        uiDriver.setFrame("IframeWindow");
        uiDriver.setValue("Action", input.get("Action"));
       List<WebElement> lst = uiDriver.webDr.findElements(By.xpath("//table[@id='revenueplan_splits']//tr[contains(@id,'revenueplan') and not(contains(@id,'revenueplanheader'))]"));
       
       
      String revrecstartdate= uiDriver.getValueByText("//table[@id='revenueplan_splits']//tr[contains(@id,'revenueplan') and not(contains(@id,'revenueplanheader'))]//td[6]");
      String revrecenddate= uiDriver.getValueByText("//table[@id='revenueplan_splits']//tr[contains(@id,'revenueplan') and not(contains(@id,'revenueplanheader'))]//td[7]");
      
      
      
       
        
	}
	/****************************************
	 * Name: initializeRow Description:Method to validate Debit and Credit
	 * Amount Date: 22-May-2018
	 ****************************************/

	public void initializeRow(DataRow input, DataRow output) {
		nextRow = 2;
		firstRow = 2;
		ItemCol = 2;

	}


	/****************************************
	 * Name: AddTimeLineItemsForMultidate1 
	*  Description: AddTimeLineItemsForMultidate1 
	*  Date: 12-November-2018
	 ****************************************/
	public void AddTimeLineItemsForMultidate1(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Dates");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimeLineItems");
		SleepUtils.sleep(TimeSlab.LOW);
		
		for(int i = 1;i<=2;i++)
		{
		uiDriver.click("AddTimeLineItem");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setFrame("//*[@id='RadWindowWrapper_ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_TimelineItemWindow']/table/tbody/tr[2]/td[2]/iframe");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimelineItemType");
		// uiDriver.setValue("TimelineItemType",input.get("Type"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("TimelineItemTypeValue"+i);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("EST");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("Date", input.get("Date"+i));		
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Notes");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Project");
//		SleepUtils.sleep(TimeSlab.MEDIUM);
//		uiDriver.click("WaistDeep");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		if(input.get("addall").equals("Y"))
		{
		uiDriver.click("AddAll");
		}
		if(input.get("project").equals("Y"))
		{
		//uiDriver.click("OnScreen");
		//uiDriver.executeJavaScript("scroll(0,2000)");
		uiDriver.click("PitchPerfect");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Add");
		}
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Finish");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.resetFrame();
		}
	}
	/****************************************
	 * Name: verifycontracttotaliszeroinFS 
	*  Description: verifycontracttotaliszeroinFS
	 * Date: 31-October-2018
	 ****************************************/
	public void verifycontracttotaliszeroinFS(DataRow input, DataRow output) 
	{
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("FinancialSummary");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		SleepUtils.sleep(TimeSlab.LOW);
		String ContractTotal=uiDriver.getValue_Text("ContractTotal");
			if(ContractTotal.contains("0.00"))
		{
			
			passed("Verify Contract total is zero",
					"The contract total should be zero",
					"The contract total is zero");
		
		}
		else
		{
			failed("Verify Contract total is zero",
					"The contract total should be zero",
					"The contract total is not zero");
		}
	}
	/****************************************
	 * Name: ValidateFinancialSummary 
	*  Description: ValidateFinancialSummary
	 * Date: 31-October-2018
	 ****************************************/
	public void ValidateFinancialSummary(DataRow input, DataRow output) 
	{
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("FinancialSummary");
		SleepUtils.sleep(TimeSlab.LOW);
		String ContractTotal=uiDriver.getValue_Text("ContractTotal");
		SleepUtils.sleep(TimeSlab.LOW);
		String AllocTotal=uiDriver.getValue_Text("AllocTotal");
		SleepUtils.sleep(TimeSlab.LOW);
		String difference=uiDriver.getValue_Text("difference");
		if(input.get("ContractTotal").contains(ContractTotal)&&input.get("AllocTotal").contains(AllocTotal)&&input.get("difference").contains(difference))
		{
			
			passed("Verify the Record is displayed",
					"The  " + ContractTotal + AllocTotal+difference+"is displayed",
					"The records are matching");
		
		}
		else
		{
			failed("Verify the Record is displayed",
					"The  " + ContractTotal + AllocTotal+difference+"is displayed",
					"The record are not matching");
		}
		String JAKandAME="BNI-05|I3501|BIG HOUSE PT. 1, THE";
		String NoOfRecords=uiDriver.getValue_Text("TotalRecords");
		NoOfRecords.substring(0, NoOfRecords.length()-9);
		System.out.println(NoOfRecords);
		int m = Integer.parseInt(NoOfRecords); 
		for(int i=0; i<m+1;i++)
		{
			if(m==22)
			{
				passed("Verify the Record is not displayed",
						"The  Record is not displayed",
						"The record Record has been removed");
			}
			String inv = uiDriver.getDyanmicData("records");
			String Records = inv.replace("#", Integer.toString(i));
			SleepUtils.sleep(TimeSlab.MEDIUM);
			if(Records.contains(JAKandAME))
			{
				
				failed("Verify the Record is displayed",
						"The  " + Records + "is displayed",
						"The record " + Records + "should have been removed");

			}
			else
			{
				continue;
			}
			
		}
		

	}



	/****************************************
	 * Name: VerifyPIFandOpenInvoices 
	 * Description: VerifyPIFandOpenInvoices Date:
	 * 29-Oct-2018
	 ****************************************/
	public void VerifyPIFandOpenInvoices(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.refresh();
		uiDriver.executeJavaScript("scroll(0,400)");
		uiDriver.click("Custom");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,1600)");
		uiDriver.click("TitleAllocationParent");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Payment#");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,500)");
		List<WebElement> InvoicesPaid = uiDriver.webDr.findElements(By
				.xpath("//*[@id='apply_splits']//tbody//tr"));
		int InvPaid = InvoicesPaid.size();
		for (int i = 0; i < InvPaid - 1; i++) {

			String inv = uiDriver.getDyanmicData("Invoices");
			String invoices = inv.replace("#", Integer.toString(i));
			uiDriver.click_dynamic(invoices);
			SleepUtils.sleep(TimeSlab.MEDIUM);
			
//			String PaidInvoices = uiDriver.getValue_Text("InvPaid");
//			String PaidInvoicesopen = uiDriver.getValue_Text("InvPaidopen");
			if(i==0)
			{
				String PaidInvoicesopen = uiDriver.getValue_Text("InvPaidopen");
				SleepUtils.sleep(TimeSlab.LOW);
				if (PaidInvoicesopen.equalsIgnoreCase("Open"))
					
				{
					passed("Verify Paid In Full Invoice",
							"Paid In Full should be displayed as" + PaidInvoicesopen
									+ "", "Paid In Full is displayed as"
									+ PaidInvoicesopen + "");
				} else {
					passed("Verify Paid In Full Invoice",
							"Paid In Full should be displayed as" + PaidInvoicesopen
									+ "", "Paid In Full is displayed as"
									+ PaidInvoicesopen + "");
				}
			}
			else if(i==1)
			{
				String PaidInvoices = uiDriver.getValue_Text("InvPaid");
				SleepUtils.sleep(TimeSlab.LOW);
				if (PaidInvoices.equalsIgnoreCase("Paid In Full"))
					
				{
					passed("Verify Paid In Full Invoice",
							"Paid In Full should be displayed as" + PaidInvoices
									+ "", "Paid In Full is displayed as"
									+ PaidInvoices + "");
				} else {
					passed("Verify Paid In Full Invoice",
							"Paid In Full should be displayed as" + PaidInvoices
									+ "", "Paid In Full is displayed as"
									+ PaidInvoices + "");
				}
			}

						
			uiDriver.back();
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.executeJavaScript("scroll(0,500)");
		}

	}
	
	/****************************************
	 * Name: VerifyPrjandRecalculate 
	 * Description: VerifyPrjandRecalculate
	 * Date: 16-November-2018
	 ****************************************/
	public void VerifyPrjandRecalculate(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Finance");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billing");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Billingschedules");
		SleepUtils.sleep(TimeSlab.HIGH);
		//uiDriver.click("RecalculateAll");
		//SleepUtils.sleep(TimeSlab.LOW);
		SleepUtils.sleep(TimeSlab.HIGH);

		List<WebElement> Billing = uiDriver.webDr.findElements(By.xpath("//*[@id='contract-billing-schedules-grid']/div[3]/table//tr"));
		int size = Billing.size();
		for(i=2;i<=size;i++)
		{
			String Edit = uiDriver.getDyanmicData("Edit");
			String EditField = Edit.replace("#", Integer.toString(i));
			uiDriver.click_dynamic(EditField);
			uiDriver.executeJavaScript("scroll(900,0)");
			uiDriver.click("Next");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Next");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.executeJavaScript("scroll(-2200,0)");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.executeJavaScript("scroll(2200,0)");
			String Project=uiDriver.getValue_Text("Project");
			if (Project.contains("ProjectName")) 
			{
				passed("Verify the PITCH PERFECT Project Name",
						"PITCH PERFECT Project Name should be displayed Successfully",
						"PITCH PERFECT Project Name is displayed Successfully");

			}
			else {
				failed("Verify the PITCH PERFECT Project Name",
						"PITCH PERFECT Project Name is not displayed Successfully",
						"PITCH PERFECT Project Name is not displayed Successfully");

			}
			uiDriver.executeJavaScript("scroll(-2000,0)");
			uiDriver.click("Next");
			String Territory=uiDriver.getValue_Text("TerritoryGBR");
			if (Territory.contains("Weight")) 
			{
				passed("Verify the Weight of Territory GBR",
						"Weight of Territory GBR is displayed Successfully as expected",
						"Weight of Territory GBR is displayed Successfully");

			}
			else {
				failed("Verify the Weight of Territory GBR",
						"Weight of Territory GBR is not displayed Successfully as expected",
						"Weight of Territory GBR is not displayed Successfully");

			}
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Next");
			String TitleBasicCable=uiDriver.getValue_Text("TitleBasicCable");
			String TitleFreeTV=uiDriver.getValue_Text("TitleFreeTV");
			if (TitleBasicCable.contains("BasicCable")&&TitleFreeTV.contains("FreeTV")) 
			{
				passed("Verify the added title has been assigned",
						"Weight of Free TV and Basic Cable is displayed Successfully as expected",
						"Weight of Free TV and Basic Cable is displayed Successfully");

			}
			else {
				failed("Verify the added title has been assigned",
						"Weight of Free TV and Basic Cable is not displayed Successfully as expected",
						"Weight of Free TV and Basic Cable is not displayed Successfully");

			}
			
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("Finish");
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.LOW);
		}
	}


	/****************************************
	 * Name: ValidateFMVAdjustmentLucy Description: ValidateFMVAdjustmentLucy Date:
	 * 13-Nov-2018
	 ****************************************/
	public void ValidateFMVAdjustmentLucy(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.executeJavaScript("(scroll(0,300));");
		uiDriver.click("//*[@id='customlnk']/a");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.executeJavaScript("(scroll(0,900));");
		uiDriver.click("//*[@id='recmachcustrecord_nbcu_solnk']/a");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Dropdown");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Thirdvalue");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.executeJavaScript("(scroll(0,2500));");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Valueedit");
		uiDriver.executeJavaScript("(scroll(0,2500));");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("ContractBilledRevenue");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String ContractBilledRevenue=uiDriver.getAttribute("//input[@value='2,500.92']", "value");
		
		SleepUtils.sleep(TimeSlab.YIELD);
		if (ContractBilledRevenue.contains(input.get("ContractualBilledRevenue"))) {
			passed("Verify the ContractBilledRevenue",
					"ContractBilledRevenue  should be displayed Successfully as "
							+ ContractBilledRevenue + "",
					"ContractBilledRevenue is displayed Successfully as "
							+ ContractBilledRevenue + "");

		} else {
			failed("Verify the ContractBilledRevenue",
					"ContractBilledRevenue should be displayed Successfully as "
							+ ContractBilledRevenue + "",
					"ContractBilledRevenue is not displayed Successfully as "
							+ ContractBilledRevenue + "");

		}
		
		String FMVBilledRevenueAdjustment = uiDriver.getAttribute("//input[@id='custrecord_nbcu_fmv_billed_revenue_adjus_formattedValue']", "value");
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVBilledRevenueAdjustment.contains(input.get("BilledRevenueAdjustment"))) {
			passed("Verify the FMVBilledRevenueAdjustment",
					"FMVBilledRevenueAdjustment  should be displayed Successfully as "
							+ FMVBilledRevenueAdjustment + "",
					"FMVBilledRevenueAdjustment is displayed Successfully as "
							+ FMVBilledRevenueAdjustment + "");

		} else {
			failed("Verify the FMVBilledRevenueAdjustment",
					"FMVBilledRevenueAdjustment  should be displayed Successfully as "
							+ FMVBilledRevenueAdjustment + "",
					"FMVBilledRevenueAdjustment is not displayed Successfully as "
							+ FMVBilledRevenueAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractUnBilledRevenue");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVUnBilledRevenue =uiDriver.getAttribute("//input[@id='custrecord_nbcu_fmv_unbilled_revenue_formattedValue']", "value");
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVUnBilledRevenue.contains(input.get("ContractUnbilledRevenue"))){
			passed("Verify the FMVUnBilledRevenue",
					"FMVUnBilledRevenue  should be displayed Successfully as "
							+ FMVUnBilledRevenue + "",
					"FMVUnBilledRevenue is displayed Successfully as "
							+ FMVUnBilledRevenue + "");

		} else {
			failed("Verify the FMVUnBilledRevenue",
					"FMVUnBilledRevenue should be displayed Successfully as "
							+ FMVUnBilledRevenue + "",
					"FMVUnBilledRevenue is not displayed Successfully as "
							+ FMVUnBilledRevenue + "");

		}
		
		String FMVUnBilledRevenueAdjustment = uiDriver.getAttribute("//input[@id='custrecord_nbcu_fmv_unbilled_revenue_adj_formattedValue']", "value");
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVUnBilledRevenueAdjustment.contains(input.get("UnBilledRevenueAdjustment"))) {
			passed("Verify the FMVUnBilledRevenueAdjustment",
					"FMVUnBilledRevenueAdjustment  should be displayed Successfully as "
							+ FMVUnBilledRevenueAdjustment + "",
					"FMVUnBilledRevenueAdjustment is displayed Successfully as "
							+ FMVUnBilledRevenueAdjustment + "");

		} else {
			failed("Verify the FMVUnBilledRevenueAdjustment",
					"FMVUnBilledRevenueAdjustment  should be displayed Successfully as "
							+ FMVUnBilledRevenueAdjustment + "",
					"FMVUnBilledRevenueAdjustment is not displayed Successfully as "
							+ FMVUnBilledRevenueAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractBilledAR");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVBilledAR =uiDriver.getAttribute("//input[@id='custrecord_nbcu_fmv_billed_ar_formattedValue']", "value");
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVBilledAR.contains(input.get("BilledAR"))) {
			passed("Verify the FMVBilledAR",
					"FMVBilledAR  should be displayed Successfully as "
							+ FMVBilledAR + "",
					"FMVBilledAR is displayed Successfully as " + FMVBilledAR
							+ "");

		} else {
			failed("Verify the FMVBilledAR",
					"FMVBilledAR should be displayed Successfully as "
							+ FMVBilledAR + "",
					"FMVBilledAR is not displayed Successfully as "
							+ FMVBilledAR + "");

		}

		String FMVBilledARAdjustment = uiDriver.getAttribute("//input[@id='custrecord_nbcu_fmv_billed_ar_adjustmen_formattedValue']", "value");
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVBilledARAdjustment.contains(input.get("BilledARAdjustment"))) {
			passed("Verify the FMVBilledARAdjustment",
					"FMVBilledARAdjustment  should be displayed Successfully as "
							+ FMVBilledARAdjustment + "",
					"FMVBilledARAdjustment is displayed Successfully as "
							+ FMVBilledARAdjustment + "");

		} else {
			failed("Verify the FMVBilledARAdjustment",
					"FMVBilledARAdjustment  should be displayed Successfully as "
							+ FMVBilledARAdjustment + "",
					"FMVBilledARAdjustment is not displayed Successfully as "
							+ FMVBilledARAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractUnBilledAR");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVUnBilledAR = uiDriver.getAttribute("//input[@id='custrecord_nbcu_fmv_unbilled_ar_formattedValue']", "value");
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVUnBilledAR.contains("UnBilledAR")) {
			passed("Verify the FMVUnBilledAR",
					"FMVUnBilledAR  should be displayed Successfully as "
							+ FMVUnBilledAR + "",
					"FMVUnBilledAR is displayed Successfully as "
							+ FMVUnBilledAR + "");

		} else {
			failed("Verify the FMVUnBilledAR",
					"FMVUnBilledAR should be displayed Successfully as "
							+ FMVUnBilledAR + "",
					"FMVUnBilledAR is not displayed Successfully as "
							+ FMVUnBilledAR + "");

		}

		String FMVUnBilledARAdjustment = uiDriver.getAttribute("//input[@id='custrecord_nbcu_fmv_unbilled_ar_adjustme_formattedValue']", "value");
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVUnBilledARAdjustment.contains("UnBilledARAdjustment")) {
			passed("Verify the FMVUnBilledARAdjustment",
					"FMVUnBilledARAdjustment  should be displayed Successfully as "
							+ FMVUnBilledARAdjustment + "",
					"FMVUnBilledARAdjustment is displayed Successfully as "
							+ FMVUnBilledARAdjustment + "");

		} else {
			failed("Verify the FMVUnBilledARAdjustment",
					"FMVUnBilledARAdjustment  should be displayed Successfully as "
							+ FMVUnBilledARAdjustment + "",
					"FMVUnBilledARAdjustment is not displayed Successfully as "
							+ FMVUnBilledARAdjustment + "");
//-------
		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractUnpaidDeferred");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVUnpaidDeferred =uiDriver.getAttribute("//input[@id='custrecord_nbcu_fmv_unpaid_deferred_formattedValue']", "value");
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVUnpaidDeferred.contains("UnpaidDeferred")) {
			passed("Verify the FMVUnpaidDeferred",
					"FMVUnpaidDeferred  should be displayed Successfully as "
							+ FMVUnpaidDeferred + "",
					"FMVUnpaidDeferred is displayed Successfully as "
							+ FMVUnpaidDeferred + "");

		} else {
			failed("Verify the FMVUnpaidDeferred",
					"FMVUnpaidDeferred should be displayed Successfully as "
							+ FMVUnpaidDeferred + "",
					"FMVUnpaidDeferred is not displayed Successfully as "
							+ FMVUnpaidDeferred + "");

		}															

		String FMVUnpaidDeferredAdjustment = uiDriver.getAttribute("//input[@id='custrecord_nbcu_fmv_unpaid_deferred_adju_formattedValue']", "value");
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVUnpaidDeferredAdjustment.contains("UnpaidDeferredAdjustment")) {
			passed("Verify the FMVUnpaidDeferredAdjustment",
					"FMVUnpaidDeferredAdjustment  should be displayed Successfully as "
							+ FMVUnpaidDeferredAdjustment + "",
					"FMVUnpaidDeferredAdjustment is displayed Successfully as "
							+ FMVUnpaidDeferredAdjustment + "");

		} else {
			failed("Verify the FMVUnpaidDeferredAdjustment",
					"FMVUnpaidDeferredAdjustment  should be displayed Successfully as "
							+ FMVUnpaidDeferredAdjustment + "",
					"FMVUnpaidDeferredAdjustment is not displayed Successfully as "
							+ FMVUnpaidDeferredAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractPaidDeferred");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVPaidDeferred =uiDriver.getAttribute("//input[@id='custrecord_nbcu_fmv_paid_deferred_formattedValue]", "value");
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVPaidDeferred.contains("PaidDeferred")) {
			passed("Verify the FMVPaidDeferred",
					"FMVPaidDeferred  should be displayed Successfully as "
							+ FMVPaidDeferred + "",
					"FMVPaidDeferred is displayed Successfully as "
							+ FMVPaidDeferred + "");

		} else {
			failed("Verify the FMVPaidDeferred",
					"FMVPaidDeferred should be displayed Successfully as "
							+ FMVPaidDeferred + "",
					"FMVPaidDeferred is not displayed Successfully as "
							+ FMVPaidDeferred + "");

		}

		String FMVPaidDeferredAdjustment = uiDriver.getAttribute("//input[@id='custrecord_nbcu_fmv_paid_deferred_adjust_formattedValue]", "value");
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVPaidDeferredAdjustment.contains("PaidDeferredAdjustment")) {
			passed("Verify the FMVPaidDeferredAdjustment",
					"FMVPaidDeferredAdjustment  should be displayed Successfully as "
							+ FMVPaidDeferredAdjustment + "",
					"FMVPaidDeferredAdjustment is displayed Successfully as "
							+ FMVPaidDeferredAdjustment + "");

		} else {
			failed("Verify the FMVPaidDeferredAdjustment",
					"FMVPaidDeferredAdjustment  should be displayed Successfully as "
							+ FMVPaidDeferredAdjustment + "",
					"FMVPaidDeferredAdjustment is not displayed Successfully as "
							+ FMVPaidDeferredAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractFXGainLoss");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVFXGainLoss =uiDriver.getAttribute("//input[@id='custrecord_nbcu_fmv_fx_gain_loss_formattedValue']", "value");
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVFXGainLoss.contains("FXGainLoss")) {
			passed("Verify the FMVFXGainLoss",
					"FMVFXGainLoss  should be displayed Successfully as "
							+ FMVFXGainLoss + "",
					"FMVFXGainLoss is displayed Successfully as "
							+ FMVFXGainLoss + "");

		} else {
			failed("Verify the FMVFXGainLoss",
					"FMVFXGainLoss should be displayed Successfully as "
							+ FMVFXGainLoss + "",
					"FMVFXGainLoss is not displayed Successfully as "
							+ FMVFXGainLoss + "");

		}

		String FMVFXGainLossAdjustment = uiDriver.getAttribute("//input[@id='custrecord_nbcu_fmv_fx_gain_loss_adjustm_formattedValue']", "value");
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVFXGainLossAdjustment.contains("FXGainLossAdjustment")) {
			passed("Verify the FMVFXGainLossAdjustment",
					"FMVFXGainLossAdjustment  should be displayed Successfully as "
							+ FMVFXGainLossAdjustment + "",
					"FMVFXGainLossAdjustment is displayed Successfully as "
							+ FMVFXGainLossAdjustment + "");

		} else {
			failed("Verify the FMVFXGainLossAdjustment",
					"FMVFXGainLossAdjustment  should be displayed Successfully as "
							+ FMVFXGainLossAdjustment + "",
					"FMVFXGainLossAdjustment is not displayed Successfully as "
							+ FMVFXGainLossAdjustment + "");

		}

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ContractWHT");
		SleepUtils.sleep(TimeSlab.LOW);
		String FMVWHT = uiDriver.getAttribute("//input[@id='custrecord_nbcu_fmv_withholding_tax_formattedValue']", "value");
		SleepUtils.sleep(TimeSlab.LOW);
		if (FMVWHT.contains("WHT")) {
			passed("Verify the FMVWHT",
					"FMVWHT  should be displayed Successfully as " + FMVWHT
							+ "", "FMVWHT is displayed Successfully as "
							+ FMVWHT + "");

		} else {
			failed("Verify the FMVWHT",
					"FMVWHT should be displayed Successfully as " + FMVWHT + "",
					"FMVWHT is not displayed Successfully as " + FMVWHT + "");

		}

		String FMVWHTAdjustment = uiDriver.getAttribute("//input[@id='custrecord_nbcu_fmv_withholding_tax_adju_formattedValue']", "value");
		SleepUtils.sleep(TimeSlab.YIELD);
		if (FMVWHTAdjustment.contains("WHTAdjustment")) {
			passed("Verify the FMVWHTAdjustment",
					"FMVWHTAdjustment  should be displayed Successfully as "
							+ FMVWHTAdjustment + "",
					"FMVWHTAdjustment is displayed Successfully as "
							+ FMVWHTAdjustment + "");

		} else {
			failed("Verify the FMVWHTAdjustment",
					"FMVWHTAdjustment  should be displayed Successfully as "
							+ FMVWHTAdjustment + "",
					"FMVWHTAdjustment is not displayed Successfully as "
							+ FMVWHTAdjustment + "");

		}

	}



	/****************************************
	 * Name: GenerateMultipleInvoices2
	 *  Description: GenerateMultipleInvoices2
	 * Date: 25OCT2018
	 ****************************************/
	public void GenerateMultipleInvoices2(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Invoices");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("BulkOperations");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("GenerateInvoices");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Filter");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("searchinput");
		String ContractId = input.get("ContractId");
		uiDriver.setValue("searchinput", input.get("ContractId"));
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		// uiDriver.setValue("searchinput", "123178");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Search");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		
		
		uiDriver.click("//*[@id='CriteriaDropdown']/button[1]");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("(//input[@data-data-type='Date'])[2]");
		//uiDriver.click("//*[@id='FilterSelector']/li[30]/label/input");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("//*[@id='CriteriaContainer']/div[4]/div/span[2]");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.setValue("//*[@id='CriteriaContainer']/div[4]/ul/li[4]/span[1]/span/input",input.get("StartDate"));
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.setValue("//*[@id='CriteriaContainer']/div[4]/ul/li[4]/span[2]/span/input",input.get("EndDate"));
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Search");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		if(input.get("Pagination").equals("Y")){
			uiDriver.executeJavaScript("scroll(0,2000)");
			String pages = uiDriver.getValue_Text("No.of.pages");
			String PageArr[] = pages.split(" ");
			String SetPage = PageArr[4];
			SleepUtils.sleep(TimeSlab.LOW);
			for(i=0;i<=53;i++){
				uiDriver.click("//*[@id='AdvancedSearchResultsGrid']/div[4]/span[1]/span/span/span[2]/span[1]/span");
				SleepUtils.sleep(3);	
			}
			/*List<String> invoicelist=new ArrayList();
			invoicelist.add(input.get("invoice1"));
			
			for(String s:invoicelist)
			{
				String Rights = uiDriver.getDyanmicData("Invoicenum");
				String rights1 = Rights.replace("#",s);
				uiDriver.click(rights1);
			}*/
	
			SleepUtils.sleep(TimeSlab.HIGH);	
			uiDriver.executeJavaScript("scroll(0,-2500)");
			uiDriver.click("Search");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("//td[text()='81.63']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='423.85']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='60.19']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='320.38']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='643.27']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='567.67']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='96.95']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			//uiDriver.executeJavaScript("scroll(0,2500)");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='108.84']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='414.99']/..//input");  
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='170.46']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='314.63']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='397.63']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			//uiDriver.executeJavaScript("scroll(0,2500)");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='235.50']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='122.33']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='367.50']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='459.12']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='259.68']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='602.85']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='1,199.49']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='1,219.02']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='1,724.89']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='1,980.86']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			
			uiDriver.click("//td[text()='1,727.61']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='641.26']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='854.32']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='175.71']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='126.11']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='309.20']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='231.82']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='146.61']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='84.96']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='2,500.92']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='277.33']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='535.13']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='813.73']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='1,849.24']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='176.84']/..//input");
			
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='242.24']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			
			uiDriver.click("//td[text()='44.22']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='40.32']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='30.41']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='85.40']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='553.71']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='373.73']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='86.15']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='149.03']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='300.11']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='257.77']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='136.06']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='43.78']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='74.84']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//td[text()='359.71']/..//input");
			SleepUtils.sleep(TimeSlab.LOW);
			
			
			
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.executeJavaScript("scroll(0,-2500)");
			//uiDriver.click("Createinvoice");
			SleepUtils.sleep(TimeSlab.LOW);
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("Createinvoice");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			String invoicenum = uiDriver.getValue("InvoiceID");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("InvoiceID");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			passed("Verify the Invoice",
					"Invoice should be displayed successfully",
					"Invoice is displayed successfully");
			output.put("Invoice", invoicenum);
			SleepUtils.sleep(TimeSlab.LOW);
			//uiDriver.click("Invoices");
			SleepUtils.sleep(TimeSlab.YIELD);
			output.put("Invoice", invoicenum);
							
		}
			
			
			
			
			SleepUtils.sleep(TimeSlab.HIGH);
			
		}

/****************************************
	 * Name: Verifycreditmemo
	 * Description:Method to Navigate To Invoice Screen
	 *  Date:30-Nov-2017 
	 * @throws IOException 
	 * @throws InvalidPasswordException 
	 ****************************************/
    public void Verifycreditmemo(DataRow input, DataRow output) throws InterruptedException, InvalidPasswordException, IOException 
    {
    	uiDriver.click("relatedrecord");
    	
    	//uiDriver.click("//*[text()='lated Transactions']");
    	SleepUtils.sleep(TimeSlab.MEDIUM);
    	uiDriver.click("creditmemo");
    	SleepUtils.sleep(TimeSlab.MEDIUM);
    	String taxcode=uiDriver.getValue("taxcode");
    	String exptaxcode=input.get("taxcode");
    	if(taxcode.equals(exptaxcode)|taxcode.contains(exptaxcode)|taxcode.startsWith("Canada"))
    	{
    		passed("Verify tax code", " tax code should be"+taxcode+"",
    				" tax code should be"+exptaxcode+"");
    	}
    	else
    	{
    		failed("Verify tax code", " tax code should be"+taxcode+"",
    				" tax code should be"+exptaxcode+"");
    	}
    	
    	String creditmemo=uiDriver.getValue("creditmemovalue");
    	String mastercredit=uiDriver.getValue("mastercredit")+"A";
    	if(creditmemo.equalsIgnoreCase(mastercredit))
    	{
    		passed("Creditmemo", " native credit memo number should be master credit memo number with an 'A' appended on the end",
    				" native credit memo number is the master credit memo number with an 'A' appended on the end");
    	}
    	
    	else
    	{
    		failed("Creditmemo", " native credit memo number should be master credit memo number with an 'A' appended on the end",
    				" native credit memo number is not the master credit memo number with an 'A' appended on the end");
    	}
    	uiDriver.click("mastercredit");
    	passed("Verify master credit ", " master credit should be displayed",
				"master credit  is displayed");
    	
    	/*String contractkey=uiDriver.getValue_Text("contractkey");
    	String orderid=input.get("conf");
    	orderid=orderid.substring(0, orderid.length()-1);
    	if(contractkey.contains(orderid))
    	{
    		passed("Contract key validation", " Contract key should be displayed",
    				"  Contract key is displayed");
    	}
    	String presentwindow = uiDriver.webDr.getWindowHandle();
		// boolean flag = false;*/
    	/*String presentwindow = uiDriver.webDr.getWindowHandle();
		uiDriver.click("viewPDF");
		SleepUtils.sleep(TimeSlab.HIGH);


		Set<String> whandles = uiDriver.webDr.getWindowHandles();
		for (String w : whandles) {
			if (!w.equals(presentwindow)) {
				uiDriver.webDr.switchTo().window(w);
				String PDFWindowURL = uiDriver.webDr.getCurrentUrl();
				URL url = new URL(PDFWindowURL);
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.sendKey("save");
				SleepUtils.sleep(TimeSlab.LOW);

				Random random = new Random();
				int limit = random.nextInt(1000);
				String inv = Integer.toString(limit);
				String text = "credit" + inv;
				StringSelection stringSelection = new StringSelection(text);
				Clipboard clipboard = Toolkit.getDefaultToolkit()
						.getSystemClipboard();
				clipboard.setContents(stringSelection, stringSelection);
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.sendKey("paste");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.sendKey("enter");

				SleepUtils.sleep(TimeSlab.LOW);
				String path = System.getProperty("user.home");
				// try(PDDocument document = PDDocument.load(new
				// File(path+"/Downloads/"+FileName+".pdf"))){
				PDDocument document = PDDocument.load(new File(path
						+ "/Downloads/" + text + ".pdf"));

				document.getClass();

				if (!document.isEncrypted()) {

					PDFTextStripperByArea stripper = new PDFTextStripperByArea();
					stripper.setSortByPosition(true);

					PDFTextStripper tStripper = new PDFTextStripper();

					String pdfFileInText = tStripper.getText(document);
					// System.out.println("Text:" + st);

					// split by whitespace
					String lines[] = pdfFileInText.split("\\r?\\n");
					for (String line : lines) {
						System.out.println(line);
						if (input.get("BilledBy").contains(line)) {
							passed("Verifying the BilledBy info in pdf",
									"BilledBy info should be displayed as "
											+ input.get("BilledBy") + " ",
									"BilledBy info is displayed as "
											+ input.get("BilledBy") + " ");
						} else if ((input.get("Remit").contains(line))) {
							passed("Verifying the Remit info in pdf",
									"Remit info should be displayed as "
											+ input.get("Remit") + " ",
									"Remit info is displayed as "
											+ input.get("Remit") + " ");

						} else if (input.get("BillTo").contains(line)) {
							passed("Verifying the BillTo info in pdf",
									"BillTo info should be displayed as "
											+ input.get("BillTo") + " ",
									"BillTo info is displayed as "
											+ input.get("BillTo") + " ");
							;

						}

						else if (input.get("SendTo").contains(line)) {
							passed("Verifying the SendTo info in pdf",
									"SendTo info should be displayed as "
											+ input.get("SendTo") + " ",
									"SendTo info is displayed as "
											+ input.get("SendTo") + " ");
							;

						} else if (input.get("TotalAmount").contains(line)) {
							passed("Verifying the TotalAmount in pdf",
									"TotalAmount should be displayed as "
											+ input.get("TotalAmount") + " ",
									"TotalAmount is displayed as "
											+ input.get("TotalAmount") + " ");
							;

						} else if (input.get("RemitInformation").contains(line)) {
							passed("Verifying the RemitInformation in pdf",
									"RemitInformation should be displayed as "
											+ input.get("RemitInformation")
											+ " ",
									"RemitInformation is displayed as "
											+ input.get("RemitInformation")
											+ " ");
							;

						}

					}
				}

				uiDriver.webDr.close();

			}
			uiDriver.webDr.switchTo().window(presentwindow);
			uiDriver.executeJavaScript("scroll(0,-1000)");
			// uiDriver.switchToWindow("Invoice - NetSuite (NBCUniversal Media, LLC 10K QA)");

		}*/
		
			uiDriver.click("docnum");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("customercredit");
			String status=uiDriver.getValue("customercreditstatus");
			if(status.equalsIgnoreCase("refunded"))
			{
	    		passed("Verify customer credit status", " Customer credit status should be refunded",
	    				" Customer credit status should be refunded");
	    	}
	    	
	    	else
	    	{
	    		failed("Verify customer credit status", " Customer credit status should be refunded",
	    				" Customer credit status is not refunded");
	    	}
			
			
			uiDriver.back();
			SleepUtils.sleep(TimeSlab.HIGH);
		}
		
		 
    
	
    /****************************************
	 * Name: verifycreditmemowithamount
	 * Description: verifycreditmemowithamount
	 * Date: 13-April-2019
	 * @throws Exception 
	 ****************************************/
	public  void verifycreditmemowithamount(DataRow input, DataRow output)
            throws Exception {
		
		uiDriver.click("//*[text()='lated Transactions']");
    	SleepUtils.sleep(TimeSlab.MEDIUM);
    	uiDriver.click("(//td[text()='Credit Memo']/..//td[1]/a)[2]");
    	SleepUtils.sleep(TimeSlab.MEDIUM);
    	String amt = uiDriver.getValue("//a[text()='Total']/../../../span[2]");
    	if(amt.equalsIgnoreCase(input.get("amount")))
		{
    		passed("Verify credit memo amount", " credit amount should be"+amt,
    				 " credit amount is"+amt);
    	}
    	
    	else
    	{
    		failed("Verify credit memo amount", " credit amount should be"+amt,
   				 " credit amount is not "+amt);
    	}
    	
    	String creditmemo=uiDriver.getValue("//*[@id='main_form']/table/tbody/tr[1]/td/div[1]/div[4]/div[1]");
    	String mastercredit=uiDriver.getValue("//a[text()='Master Credit Memo Parent']/../../../span[2]")+"A";
    	if(creditmemo.equalsIgnoreCase(mastercredit))
    	{
    		passed("Creditmemo", " native credit memo number should be master credit memo number with an 'A' appended on the end",
    				" native credit memo number is the master credit memo number with an 'A' appended on the end");
    	}
    	
    	else
    	{
    		failed("Creditmemo", " native credit memo number should be master credit memo number with an 'A' appended on the end",
    				" native credit memo number is not the master credit memo number with an 'A' appended on the end");
    	}
    	uiDriver.click("//a[text()='Master Credit Memo Parent']/../../../span[2]");
    	passed("Verify master credit ", " master credit should be displayed",
				"master credit  is displayed");
    	
    	
    	uiDriver.click("//a[text()='download']");
		String invoicevalue=uiDriver.getValue("//*[@id=\"main_form\"]/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[3]/td/div/span[2]/a[1]");
		int val=invoicevalue.indexOf("NBCU");
		String pdfvalue=invoicevalue.substring(val,invoicevalue.length()-4);

				String presentwindow = uiDriver.webDr.getWindowHandle();
			
						String path = System.getProperty("user.home");
						
						PDDocument document = PDDocument.load(new File(path
								+ "/Downloads/" + pdfvalue + ".pdf"));

						document.getClass();

						if (!document.isEncrypted()) {

							PDFTextStripperByArea stripper = new PDFTextStripperByArea();
							stripper.setSortByPosition(true);

							PDFTextStripper tStripper = new PDFTextStripper();

							String pdfFileInText = tStripper.getText(document);
							// System.out.println("Text:" + st);

							// split by whitespace
							String lines[] = pdfFileInText.split("\\r?\\n");
							for (String line : lines) {
								System.out.println(line);
								if (input.get("BilledBy").contains(line)) {
									passed("Verifying the BilledBy info in pdf",
											"BilledBy info should be displayed as "
													+ input.get("BilledBy") + " ",
											"BilledBy info is displayed as "
													+ input.get("BilledBy") + " ");
								} else if ((input.get("Remit").contains(line))) {
									passed("Verifying the Remit info in pdf",
											"Remit info should be displayed as "
													+ input.get("Remit") + " ",
											"Remit info is displayed as "
													+ input.get("Remit") + " ");

								} else if (input.get("BillTo").contains(line)) {
									passed("Verifying the BillTo info in pdf",
											"BillTo info should be displayed as "
													+ input.get("BillTo") + " ",
											"BillTo info is displayed as "
													+ input.get("BillTo") + " ");
									;

								}

								else if (input.get("SendTo").contains(line)) {
									passed("Verifying the SendTo info in pdf",
											"SendTo info should be displayed as "
													+ input.get("SendTo") + " ",
											"SendTo info is displayed as "
													+ input.get("SendTo") + " ");
									;

								} else if (input.get("TotalAmount").contains(line)) {
									passed("Verifying the TotalAmount in pdf",
											"TotalAmount should be displayed as "
													+ input.get("TotalAmount") + " ",
											"TotalAmount is displayed as "
													+ input.get("TotalAmount") + " ");
									;

								} else if (input.get("RemitInformation").contains(line)) {
									passed("Verifying the RemitInformation in pdf",
											"RemitInformation should be displayed as "
													+ input.get("RemitInformation")
													+ " ",
											"RemitInformation is displayed as "
													+ input.get("RemitInformation")
													+ " ");
									;

								}

							}
						}
		

		
    	uiDriver.click("//table[@id='recmachcustbody_nbcu_cm_master__tab']//tbody//td[3]/a");
    	
    	
		
	}
	/****************************************
	 * Name: EditInvoicefile
	 * Description: EditInvoicefile
	 * Date: 11-July-2018
	 * @throws Exception 
	 ****************************************/
    /****************************************
	 * Name: EditInvoicefile
	 * Description: EditInvoicefile
	 * Date: 11-July-2018
	 * @throws Exception 
	 ****************************************/
	public  void EditInvoicefile(DataRow input, DataRow output)
            throws Exception {
	
		String filePath = input.get("filePath");
		String OldInvoice = input.get("OldInvoice");
		String InvoiceSize = input.get("InvoiceSize");
		int invsize = Integer.parseInt(InvoiceSize);
		for (int r = 1; r < invsize; r++) {
		String invoice = input.get("invioice" + r);
		String newInvoice = invoice.substring(0, invoice.length()-1);
		uiDriver.modifyFile(filePath,OldInvoice,newInvoice);
		
		}
	
	}
	/********************************************
	 * Name: VerifyAllInvoiceStatus 
	 * Description: VerifyAllInvoiceStatus Date: 09-April-2019
	 ****************************************/
	public void VerifyAllInvoiceStatus(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Invoices");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("InvoicesSearch");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("searchinput");
		String ContractId = input.get("conf");	
		uiDriver.setValue("searchinput", ContractId+"-0");
		//uiDriver.setValue("searchinput", input.get("ContractId")+"-0");
		SleepUtils.sleep(TimeSlab.MEDIUM);	
		uiDriver.click("searchInvoice");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		List<WebElement>inv=uiDriver.webDr.findElements(By.xpath("//*[@title='View this invoice']"));
		int invsize=inv.size();
		for(int i=1;i<=invsize;i++){
			uiDriver.click("(//*[@title='View this invoice'])["+i+"]");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.refresh();
			SleepUtils.sleep(30);
			uiDriver.refresh();
			/*uiDriver.refresh();
			uiDriver.refresh();
			uiDriver.refresh();
			uiDriver.refresh();*/
			for(int j=1;j<=50;j++)
			{
				String ContractStatus = uiDriver.getValue("ContractStatus");
				if (ContractStatus.equalsIgnoreCase("Posted Successfully")) {

					passed("Verifying the  Invoice Status",
							"Invoice Status should be displayed as '"
									+ input.get("Status") + "' Successfully",
							"Invoice Status " + ContractStatus
									+ " is displayed Successfully");
					break;
				}
					else if(ContractStatus.contains("Error")){
						failed("Verifying the  Invoice Status",
								"Invoice Status should be displayed as '"
										+ input.get("Status") + "' Successfully",
								"Invoice Status " + ContractStatus
										+ " is not displayed Successfully");
						break;
					}
				 else {
					uiDriver.refresh();
					SleepUtils.sleep(60);
					/*SleepUtils.sleep(TimeSlab.MEDIUM);
					uiDriver.refresh();*/
					SleepUtils.sleep(5);
				}
			}
			uiDriver.back();
			SleepUtils.sleep(TimeSlab.HIGH);
			
				}
		
	}



	/****************************************
	 * Name: ReadPaymentNumber
	 * Description: ReadPaymentNumber
	 * Date: 23-Nov-2018
	 ****************************************/
	public void ReadPaymentNumber(DataRow input, DataRow output)
			throws InterruptedException 
	{
		SleepUtils.sleep(TimeSlab.MEDIUM);
    	String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("relatedRecord");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click_dynamic("InvoiceLinks");
		passed("InvoiceNo", "InvoiceNo Should be Clicked Successfully",
				"InvoiceNo is Clicked Successfully");
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("CustomTab");
		uiDriver.executeJavaScript("scroll(0,2500)");
		String paymentnumber=uiDriver.getValue("paymentrecord");
		paymentnumber=paymentnumber.substring(9, paymentnumber.length());
		output.put("paynumber", paymentnumber);
        }				
	
	

	/**
	 * Overriding toString() method of object class to print SJMDriver format
	 * string
	 */
	public String toString() {
		return "NBCUDriver()";
	}
	
	

	public static int i = 4, j = 2;
	int nextRow = 2, firstRow = 2, ItemCol = 4;
	String orderId, FMVDimention, SONum;
	List<WebElement> fmvValue = new ArrayList<WebElement>();
	List<String> fmvVal = new ArrayList<String>();
	private static final int BUFFER_SIZE = 4096;
}

