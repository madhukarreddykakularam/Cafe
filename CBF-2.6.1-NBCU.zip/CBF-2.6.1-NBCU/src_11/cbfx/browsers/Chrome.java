/******************************************************************************
$Id : Chrome.java 12/23/2016 4:08:50 PM
Copyright � 2016 Capgemini Group of companies. All rights reserved
(Subject to Limited Distribution and Restricted Disclosure Only.)
THIS SOURCE FILE MAY CONTAIN INFORMATION WHICH IS THE PROPRIETARY
INFORMATION OF CAPGEMINI GROUP OF COMPANIES AND IS INTENDED FOR USE
ONLY BY THE ENTITY WHO IS ENTITLED TO AND MAY CONTAIN
INFORMATION THAT IS PRIVILEGED, CONFIDENTIAL, OR EXEMPT FROM
DISCLOSURE UNDER APPLICABLE LAW.
YOUR ACCESS TO THIS SOURCE FILE IS GOVERNED BY THE TERMS AND
CONDITIONS OF AN AGREEMENT BETWEEN YOU AND CAPGEMINI GROUP OF COMPANIES.
The USE, DISCLOSURE REPRODUCTION OR TRANSFER OF THIS PROGRAM IS
RESTRICTED AS SET FORTH THEREIN.
******************************************************************************/

package cbfx.browsers;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;

import cbf.utils.LogUtils;
import cbf.utils.StringUtils;

public class Chrome implements Browser {

	/**
	 * Constructor to initialize browser related parameters
	 * 
	 * @param parameters
	 *            browser related parameters
	 * 
	 */

	public Chrome(Map parameters) {

		this.params = parameters;
	}

	/**
	 * Loads chrome driver
	 * 
	 * @return chrome driver instance
	 */

	public WebDriver openDriver() {
		System.setProperty("webdriver.chrome.driver",
				(String) params.get("browserdriver") + "chromedriver.exe");
		/*String userProfile= "C:\\Users\\user_name\\AppData\\Local\\Google\\Chrome\\User Data\\Default\\";
		ChromeOptions options = new ChromeOptions();
		options.addArguments("user-data-dir="+userProfile);
		options.addArguments("--start-maximized");
		WebDriver driver = new ChromeDriver(options);
		driver.get("http://www.google.com");*/
		
		
		System.setProperty("webdriver.chrome.driver",
				(String) params.get("browserdriver") + "chromedriver.exe");
		try {
			chromeDriver = new ChromeDriver();
		} catch (Exception e) {
			logger.handleError("Failed to read browser details ", e);
		}
		return chromeDriver;
	}

	/**
	 * Quits chrome driver
	 * 
	 */

	public void closeDriver() {
		chromeDriver.quit();
	}

	/**
	 * Overriding toString() method to return Chrome format string
	 */
	public String toString() {
		return StringUtils.mapString(this);
	}

	private Map params;
	private WebDriver chromeDriver;
	private static LogUtils logger = new LogUtils();
}
