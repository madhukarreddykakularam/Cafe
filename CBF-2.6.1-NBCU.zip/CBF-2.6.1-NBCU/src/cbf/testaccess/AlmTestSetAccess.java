/******************************************************************************
$Id : AlmTestSetAccess.java 12/23/2016 4:08:33 PM
Copyright � 2016 Capgemini Group of companies. All rights reserved
(Subject to Limited Distribution and Restricted Disclosure Only.)
THIS SOURCE FILE MAY CONTAIN INFORMATION WHICH IS THE PROPRIETARY
INFORMATION OF CAPGEMINI GROUP OF COMPANIES AND IS INTENDED FOR USE
ONLY BY THE ENTITY WHO IS ENTITLED TO AND MAY CONTAIN
INFORMATION THAT IS PRIVILEGED, CONFIDENTIAL, OR EXEMPT FROM
DISCLOSURE UNDER APPLICABLE LAW.
YOUR ACCESS TO THIS SOURCE FILE IS GOVERNED BY THE TERMS AND
CONDITIONS OF AN AGREEMENT BETWEEN YOU AND CAPGEMINI GROUP OF COMPANIES.
The USE, DISCLOSURE REPRODUCTION OR TRANSFER OF THIS PROGRAM IS
RESTRICTED AS SET FORTH THEREIN.
******************************************************************************/

package cbf.testaccess;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import cbf.model.TestCase;
import cbf.model.TestInstance;
import cbf.model.TestIteration;
import cbf.model.TestSet;
import cbf.utils.AlmAccess;
import cbf.utils.LogUtils;
import cbf.utils.StringUtils;

import com.mercury.qualitycenter.otaclient.IList;
import com.mercury.qualitycenter.otaclient.ITSTest;
import com4j.Com4jObject;

/**
 * 
 * Implements TestSet interface and makes TestInstance
 * 
 */
public class AlmTestSetAccess implements TestSet {

	/**
	 * Constructor which makes a list map for instances as per the user
	 * selection
	 */

	public AlmTestSetAccess(Map params) {
		this.params = params;
		AlmAccess almaccess = new AlmAccess(params);
		almaccess.connect();
		logger.trace("Reading the test instances from alm...........");
		IList instanceInfo = almaccess.getTestCaseInstance(params);
		Iterator testCaseIterator = instanceInfo.iterator();
		int index = 0;
		try {
			while (testCaseIterator.hasNext()) {
				Com4jObject comOb = (Com4jObject) testCaseIterator.next();
				ITSTest testCase = comOb.queryInterface(ITSTest.class);
				String testCaseName = testCase.name().substring(3);
				ArrayList<String> instanceList = new ArrayList<String>();
				instanceList.add(testCaseName);
				testInstanceInfo.put(index, instanceList);
				index++;
			}
		} catch (Exception e) {
			logger.handleError("Failed to get instances", params, e);

		}

	}

	/**
	 * Returns test instance object specified at the given index in instance
	 * array
	 * 
	 * @param ix
	 *            index of TestInstance
	 * @return testInstance
	 */

	public TestInstance testInstance(final int ix) {
		final ArrayList<String> params = testInstanceInfo.get(ix);
		return new TestInstance() {

			public TestCase testCase() {
				return null;
			}

			public String description() {
				return null;
			}

			public String instanceName() {
				return params.get(0);
			}

			public TestIteration[] iterations() {
				return null;
			}

			public String folderPath() {
				return "";
			}
		};
	}

	/**
	 * Returns number of TestInstances
	 * 
	 * @return TestInsances count
	 */
	public int testInstanceCount() {
		return testInstanceInfo.size();
	}

	/**
	 * Returns AlmTestSetAccess format string
	 */
	public String toString() {
		return StringUtils.mapString(this, params);
	}

	private static Map<Integer, ArrayList<String>> testInstanceInfo = new HashMap<Integer, ArrayList<String>>();
	private Map params;
	private LogUtils logger = new LogUtils(this);
}
