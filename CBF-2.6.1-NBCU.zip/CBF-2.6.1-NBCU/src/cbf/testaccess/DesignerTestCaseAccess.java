/******************************************************************************
$Id : DesignerTestCaseAccess.java 12/23/2016 4:08:34 PM
Copyright � 2016 Capgemini Group of companies. All rights reserved
(Subject to Limited Distribution and Restricted Disclosure Only.)
THIS SOURCE FILE MAY CONTAIN INFORMATION WHICH IS THE PROPRIETARY
INFORMATION OF CAPGEMINI GROUP OF COMPANIES AND IS INTENDED FOR USE
ONLY BY THE ENTITY WHO IS ENTITLED TO AND MAY CONTAIN
INFORMATION THAT IS PRIVILEGED, CONFIDENTIAL, OR EXEMPT FROM
DISCLOSURE UNDER APPLICABLE LAW.
YOUR ACCESS TO THIS SOURCE FILE IS GOVERNED BY THE TERMS AND
CONDITIONS OF AN AGREEMENT BETWEEN YOU AND CAPGEMINI GROUP OF COMPANIES.
The USE, DISCLOSURE REPRODUCTION OR TRANSFER OF THIS PROGRAM IS
RESTRICTED AS SET FORTH THEREIN.
******************************************************************************/

package cbf.testaccess;

import java.util.Map;

import cbf.model.TestCase;
import cbf.model.TestCaseAccess;
import cbf.utils.FrameworkException;
import cbf.utils.LogUtils;
import cbf.utils.StringUtils;

/**
 * 
 * Implements TestCaseAccess interface and makes TestCase from designer
 * 
 */
public class DesignerTestCaseAccess implements TestCaseAccess {

	/**
	 * Constructor to initialize CONFIG parameter
	 * 
	 * @param params
	 *            map containing parameters
	 */
	public DesignerTestCaseAccess(Map params) {
		this.params = params;
	}

	/**
	 * Deserializes test file, resolves references and returns TestCase object
	 * 
	 * @param info
	 *            Map having info related to TestCase like test name
	 * @return object of TestCase
	 * 
	 */
	public TestCase getTestCase(Map info) {
		logger.trace("getTestCase()");
		String testName = (String) info.get("instanceName");
		String folderPath = (String) info.get("folderPath");
		if (testName == null || folderPath == null) {
			logger.handleError("Invalid testcase attributes", info);
		}

		TestCase oTestCase = null;
		try {
			oTestCase = deserializeTest(testName, folderPath);
		} catch (FrameworkException e) {
			logger.handleError("Error in deserializing test step file:" + folderPath);
		}

		return oTestCase;
	}

	private LogUtils logger = new LogUtils(this);
	private Map params;

	private TestCase deserializeTest(String testName, String folderPath) {
		logger.trace("DeserializeTest(" + testName + ";" + folderPath + ")");
		return DesignerDeserializer.deserialize(params, testName, folderPath);
	}

	/**
	 * Returns DesignerAccess format string
	 */
	public String toString() {
		return StringUtils.mapString(this, params);
	}
}
