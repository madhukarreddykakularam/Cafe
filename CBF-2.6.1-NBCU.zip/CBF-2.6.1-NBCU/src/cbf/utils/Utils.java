/******************************************************************************
$Id : Utils.java 12/23/2016 4:08:45 PM
Copyright � 2016 Capgemini Group of companies. All rights reserved
(Subject to Limited Distribution and Restricted Disclosure Only.)
THIS SOURCE FILE MAY CONTAIN INFORMATION WHICH IS THE PROPRIETARY
INFORMATION OF CAPGEMINI GROUP OF COMPANIES AND IS INTENDED FOR USE
ONLY BY THE ENTITY WHO IS ENTITLED TO AND MAY CONTAIN
INFORMATION THAT IS PRIVILEGED, CONFIDENTIAL, OR EXEMPT FROM
DISCLOSURE UNDER APPLICABLE LAW.
YOUR ACCESS TO THIS SOURCE FILE IS GOVERNED BY THE TERMS AND
CONDITIONS OF AN AGREEMENT BETWEEN YOU AND CAPGEMINI GROUP OF COMPANIES.
The USE, DISCLOSURE REPRODUCTION OR TRANSFER OF THIS PROGRAM IS
RESTRICTED AS SET FORTH THEREIN.
 ******************************************************************************/

package cbf.utils;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.GnuParser;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;

/**
 * 
 * Generic utility functions.
 * 
 */
public class Utils {

	/**
	 * Converts passed object array to map
	 * 
	 * @param array
	 *            of object to be converted
	 * @return Map of objects
	 */
	public static Map<Object, Object> toMap(Object[] array) {
		Map<Object, Object> map = new HashMap<Object, Object>();
		for (int i = 0; i < array.length; i = i + 2) {
			map.put(array[i], array[i + 1]);
		}
		return map;
	}

	/**
	 * Converts passed object to string
	 * 
	 * @param object
	 *            to be converted
	 * @return string format of object
	 */
	public static String toString(Object object) {
		return object.toString();
	}

	/**
	 * Converts given string to boolean value
	 * 
	 * @param value
	 *            string to be converted
	 * @return boolean value of string
	 */
	public static boolean string2Bool(String value) {
		boolean result = false;
		if (StringUtils.match(value, StringUtils.pattern(
				"(Pass|True|Yes|Y|true|yes|YES)", false, true))) {
			result = true;
		}
		if (StringUtils.match(value, StringUtils.pattern(
				"(Fail|False|No|N|false|no|NO)", false, true))) {
			result = false;
		}
		return result;
	}

	/*
	 * Public Function Array2Dictionary(ByRef Arr) Dim dict Set dict =
	 * CreateObject("Scripting.Dictionary") Dim i For i = LBound(Arr) to
	 * UBound(Arr)-1 Step 2 Dim Nam, Val Nam = Arr(i) if VarType(Arr(i+1)) =
	 * vbObject then set Val = Arr(i+1) else Val = Arr(i+1) end if dict.add Nam,
	 * Val Next
	 * 
	 * Set Array2Dictionary = dict End Function
	 */
	/**
	 * Converts array to map
	 * 
	 * @param arr
	 *            array to be converted
	 * @return converted map
	 */
	public Map<String, String> arrayToMap(String[] arr) {
		Map<String, String> dataMap = new HashMap();

		int len = arr.length;
		String key, val;
		for (int i = 0; i <= len - 1; i += 2) {
			key = arr[i];
			val = arr[i + 1];
			dataMap.put(key, val);
		}

		return dataMap;
	}

	public static String getHostName() {
		String hostName = "";
		try {
			java.net.InetAddress addr = InetAddress.getLocalHost();
			hostName = addr.getHostName();

		} catch (UnknownHostException e) {

			logger.handleError("Hostname can not be resolved ", e);

		}
		return hostName;
	}

	public LinkedHashMap<String, String> parseCommandLineArgs(String[] args) {
		Options options = makeCommandLineArgs(args);		
		LinkedHashMap<String, String> runMap = new LinkedHashMap<String, String>();
		try {
			CommandLine commandLine = new GnuParser().parse(options, args);
			for (Option option : commandLine.getOptions()) {
				
				runMap.put(option.getArgName(), option.getValue());
			}
		} catch (Exception e) {
			System.out.println("Error:Error in parsing arguments   " + e);
			System.out.println("Error: Run Configuration paths are not proper:    " + e);
			
		}
		return runMap;
	}

	public Options makeCommandLineArgs(String[] args) {
		Options options = new Options();
		try {
			for (String arg : args) {
				if (arg.startsWith("-")) {
					options.addOption(OptionBuilder
							.withArgName(arg.replace("-", "")).hasArg()
							.create(arg.replace("-", "")));
				}
			}
		} catch (Exception e) {
			System.out.println("Error:Error in making arguments" + e);
		}
		return options;
	}

	/**
	 * Converts passed map to DataRow object
	 * 
	 * @param map
	 *            to be converted
	 * @return object of DataRow
	 */
	public static DataRow Map2DataRow(Map map) {
		return new DataRow(map);
	}

	private static LogUtils logger = new LogUtils();
}
