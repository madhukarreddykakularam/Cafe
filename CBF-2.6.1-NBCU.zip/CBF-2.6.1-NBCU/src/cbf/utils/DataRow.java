/******************************************************************************
$Id : DataRow.java 12/23/2016 4:08:38 PM
Copyright � 2016 Capgemini Group of companies. All rights reserved
(Subject to Limited Distribution and Restricted Disclosure Only.)
THIS SOURCE FILE MAY CONTAIN INFORMATION WHICH IS THE PROPRIETARY
INFORMATION OF CAPGEMINI GROUP OF COMPANIES AND IS INTENDED FOR USE
ONLY BY THE ENTITY WHO IS ENTITLED TO AND MAY CONTAIN
INFORMATION THAT IS PRIVILEGED, CONFIDENTIAL, OR EXEMPT FROM
DISCLOSURE UNDER APPLICABLE LAW.
YOUR ACCESS TO THIS SOURCE FILE IS GOVERNED BY THE TERMS AND
CONDITIONS OF AN AGREEMENT BETWEEN YOU AND CAPGEMINI GROUP OF COMPANIES.
The USE, DISCLOSURE REPRODUCTION OR TRANSFER OF THIS PROGRAM IS
RESTRICTED AS SET FORTH THEREIN.
******************************************************************************/

package cbf.utils;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 * Wrapper class on DataRow
 * 
 */
public class DataRow extends HashMap<String, String> {

	/**
	 * Overloaded constructor to generate Map
	 * 
	 * @param data
	 *            Map containing details
	 */
	public DataRow(Map<String, String> data) {
		this.putAll(data);
	}

	public DataRow() {
	}

	/**
	 * Returns map values in string format
	 */
	public String toString() {
		String mapValues = "";
		Iterable<String> keys = this.keySet();
		for (String key : keys) {
			mapValues = mapValues + key + " = " + this.get(key) + ";";

		}
		return StringUtils.mapString(this,mapValues);
	}

}
