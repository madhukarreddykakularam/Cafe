/******************************************************************************
$Id : Summary.java 12/23/2016 4:08:32 PM
Copyright � 2016 Capgemini Group of companies. All rights reserved
(Subject to Limited Distribution and Restricted Disclosure Only.)
THIS SOURCE FILE MAY CONTAIN INFORMATION WHICH IS THE PROPRIETARY
INFORMATION OF CAPGEMINI GROUP OF COMPANIES AND IS INTENDED FOR USE
ONLY BY THE ENTITY WHO IS ENTITLED TO AND MAY CONTAIN
INFORMATION THAT IS PRIVILEGED, CONFIDENTIAL, OR EXEMPT FROM
DISCLOSURE UNDER APPLICABLE LAW.
YOUR ACCESS TO THIS SOURCE FILE IS GOVERNED BY THE TERMS AND
CONDITIONS OF AN AGREEMENT BETWEEN YOU AND CAPGEMINI GROUP OF COMPANIES.
The USE, DISCLOSURE REPRODUCTION OR TRANSFER OF THIS PROGRAM IS
RESTRICTED AS SET FORTH THEREIN.
******************************************************************************/

package cbf.reporting;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import cbf.engine.TestResult;
import cbf.engine.TestResult.ResultType;
import cbf.harness.ResourcePaths;
import cbf.model.ResultReporter;
import cbf.utils.LogUtils;
import cbf.utils.StringUtils;
import cbf.utils.Utils;

public class Summary implements ResultReporter {

	public Summary(Map params) {
		filePath = (String) params.get("filepath");
		if (filePath.equals("")) {
			filePath = ResourcePaths.getInstance().getRunResource(
					"Summary" + ".json", "");
		}
		templatePath = ResourcePaths.getInstance().getFrameworkResource(
				"Resources", "SummaryTemplate.json");
	}

	/*
	 * * Function: open(public) Goal: Makes the engine ready for use Out Params:
	 * Boolean - Didn't the engine manage to start?
	 */
	/**
	 * Copies and loads the excel reporter template in logs
	 * 
	 * @param headers
	 *            contains header info, like run name, config details etc
	 */

	public void open(Map headers) {
		logger.trace("Report: open");
		File srcFile = new File(templatePath);
		targetFile = new File(filePath);
		boolean isExists = targetFile.exists();
		if (!isExists) {
			try {
				FileUtils.copyFile(srcFile, targetFile);
			} catch (Exception e) { // FIXME: specific exception
				logger.handleError(
						"Error in making a new Jsonreport file from template",
						e, srcFile, targetFile);
			}
		}
		openFile(targetFile);
	}

	private void openFile(File targetFile) {
		try {
			//
			inputStream = new FileInputStream(targetFile);
		} catch (IOException e) {
			logger.handleError("Error while accessing workbook ", e);
		}
	}

	/*
	 * * Function: close(public) Goal: Stops the engine In Params: None Out
	 * Params: None
	 */

	/**
	 * Reports execution details along with result counts
	 * 
	 * @param result
	 *            execution details
	 * @param rsType
	 *            result type of the current executed entity
	 * @param details
	 *            execution details of the current executed entity
	 */
	public void finish(TestResult result, ResultType rsType, Object details) {
		report("FINISH", result, details);
	}

	private FileInputStream inputStream;
	private FileOutputStream outputStream;

	/**
	 * Function: report(public) Goal:Reports an event
	 * 
	 * @return
	 */

	private void report(String eventType, TestResult result, Object eventData) {
		logger.trace("Report:" + eventType + ":" + StringUtils.toString(result)
				+ ":" + StringUtils.toString(eventData));

		try {
			switch (result.entityType) {
			case ITERATION:
				if (eventType.equals("FINISH")) {
					testCases++;

					if (result.msRsType.isPassed()) {

						passed++;

					} else {

						failed++;

					}
				}
			case TESTCASE:
				if (eventType.equals("FINISH")) {
					WritetoJson(result);
				}
				break;
			}
		} catch (Exception e) {
			logger.handleError("Error in Json reporting", e);
		}

	}

	private void WritetoJson(TestResult result) throws Exception {
		
		JSONObject testcaseObj = new JSONObject();
		testcaseObj.put("Executed", testCases);
		testcaseObj.put("Passed", passed);
		testcaseObj.put("Failed", failed);
		
		System.out.println(testcaseObj);
		
		FileWriter FR = new FileWriter(filePath);
		FR.write(testcaseObj.toJSONString());
		FR.close();
	}

	private Map toMap(Object[] arr) {
		return Utils.toMap(arr);
	}

	/**
	 * Overrides toString() method of Object class to return ExcelReporter
	 * format string
	 */
	public String toString() {

		return StringUtils.mapString(this, filePath);
	}

	private String filePath, templatePath;
	File targetFile;
	Object obj = null;
	private LogUtils logger = new LogUtils(this);

	public void close() {
		logger.trace("Report: Close");

	}

	@Override
	public void start(TestResult result) {
		// TODO Auto-generated method stub

	}

	@Override
	public void log(TestResult result, ResultType rsType, Map details) {
		// TODO Auto-generated method stub

	}

	private int failed = 0, testCases = 0, passed = 0;

}
