/******************************************************************************
$Id : TestLinkReporter.java 12/23/2016 4:08:32 PM
Copyright � 2016 Capgemini Group of companies. All rights reserved
(Subject to Limited Distribution and Restricted Disclosure Only.)
THIS SOURCE FILE MAY CONTAIN INFORMATION WHICH IS THE PROPRIETARY
INFORMATION OF CAPGEMINI GROUP OF COMPANIES AND IS INTENDED FOR USE
ONLY BY THE ENTITY WHO IS ENTITLED TO AND MAY CONTAIN
INFORMATION THAT IS PRIVILEGED, CONFIDENTIAL, OR EXEMPT FROM
DISCLOSURE UNDER APPLICABLE LAW.
YOUR ACCESS TO THIS SOURCE FILE IS GOVERNED BY THE TERMS AND
CONDITIONS OF AN AGREEMENT BETWEEN YOU AND CAPGEMINI GROUP OF COMPANIES.
The USE, DISCLOSURE REPRODUCTION OR TRANSFER OF THIS PROGRAM IS
RESTRICTED AS SET FORTH THEREIN.
******************************************************************************/

package cbf.reporting;

import java.util.Map;

import testlink.api.java.client.TestLinkAPIClient;
import testlink.api.java.client.TestLinkAPIException;
import testlink.api.java.client.TestLinkAPIResults;
import cbf.engine.TestResult;
import cbf.engine.TestResult.EntityType;
import cbf.engine.TestResult.ResultType;
import cbf.model.ResultReporter;
import cbf.utils.LogUtils;
import cbf.utils.StringUtils;

/**
 * 
 * Implements ResultReporter and generates test link reports
 * 
 *
 */
public class TestLinkReporter implements ResultReporter {

	private void reportResult(String testProject, String testPlan,
			String testCase, String build, String notes, String result)
			throws TestLinkAPIException {
		TestLinkAPIClient apic = new TestLinkAPIClient(devkey, url);
		apic.reportTestCaseResult(testProject, testPlan, testCase, build,
				notes, result);
	}

	/**
	 * Constructor to initialize test link reporter related parameters
	 * 
	 * @param params
	 *            map containing parameters
	 */
	public TestLinkReporter(Map params) {
		testProject = (String) params.get("project");
		build = (String) params.get("build");
		testPlan = (String) params.get("plan");
		// testCase= (String) params.get("testcase");
		url = (String) params.get("url");
		devkey = (String) params.get("devkey");
	}

	/**
	 * Reporter open method *
	 * 
	 * @param headers
	 *            contains header info, like run name, config details etc
	 */
	public void open(Map headers) {
		logger.trace("Report: Open");
	}

	/**
	 * Reporter close method *
	 */

	public void close() {
		logger.trace("Report: Close");
	}

	/**
	 * Reports entity execution start details
	 * 
	 * @param result
	 *            entity object
	 */
	public void start(TestResult result) {
		report("START", result, result.entityDetails);
	}

	/**
	 * Logs execution details in report
	 * 
	 * @param result
	 *            entity details
	 * @param rsType
	 *            result type of the current executed entity
	 * @param details
	 *            execution details of the current executed entity
	 */
	public void log(TestResult result, ResultType rsType, Map details) {
		report("DETAILS", result, details);
	}

	/**
	 * Reports execution details along with result counts
	 * 
	 * @param result
	 *            execution details
	 * @param rsType
	 *            result type of the current executed entity
	 * @param details
	 *            execution details of the current executed entity
	 */
	public void finish(TestResult result, ResultType rsType, Object details) {
		report("FINISH", result, details);
	}

	private void report(String eventType, TestResult result, Object eventData) {
		if (result.entityType.equals(EntityType.ITERATION)) {
			if (eventType.equals("START")) {
				testCase = result.parent.entityName;
			}
		}
		try {
			switch (result.entityType) {
			case ITERATION:
				if (eventType.equals("FINISH")) {
					System.out.println(result.msRsType);
					if (result.msRsType.equals(ResultType.PASSED)) {
						testResult = TestLinkAPIResults.TEST_PASSED;
						notes = "Successfully Executed";
						reportResult(testProject, testPlan, testCase, build,
								notes, testResult);
					} else if (result.msRsType.equals(ResultType.FAILED)
							|| result.msRsType.equals(ResultType.ERROR)) {
						testResult = TestLinkAPIResults.TEST_FAILED;
						notes = "Execution failed";
						reportResult(testProject, testPlan, testCase, build,
								notes, testResult);
					}
				}
				break;
			}
		} catch (Exception e) {
			logger.handleError("Error while updating result ", e);
		}
	}

	/**
	 * Returns TestLinkReporter format string
	 */
	public String toString() {
		return StringUtils.mapString(this, testProject, build, testPlan, url,
				devkey);
	}

	private String testProject, testPlan, testCase, build, devkey, url;
	String notes = null;
	String testResult = null;
	private LogUtils logger = new LogUtils(this);
}
