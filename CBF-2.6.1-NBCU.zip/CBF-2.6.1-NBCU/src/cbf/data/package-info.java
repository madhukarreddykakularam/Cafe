/**
 * Provides classes necessary to fetch the component data from different data sources like database, excel etc
 * @author rashnaga
 *
 */
package cbf.data;