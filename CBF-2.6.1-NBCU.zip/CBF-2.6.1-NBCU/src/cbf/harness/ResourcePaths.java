/******************************************************************************
$Id : ResourcePaths.java 12/23/2016 4:08:21 PM
Copyright � 2016 Capgemini Group of companies. All rights reserved
(Subject to Limited Distribution and Restricted Disclosure Only.)
THIS SOURCE FILE MAY CONTAIN INFORMATION WHICH IS THE PROPRIETARY
INFORMATION OF CAPGEMINI GROUP OF COMPANIES AND IS INTENDED FOR USE
ONLY BY THE ENTITY WHO IS ENTITLED TO AND MAY CONTAIN
INFORMATION THAT IS PRIVILEGED, CONFIDENTIAL, OR EXEMPT FROM
DISCLOSURE UNDER APPLICABLE LAW.
YOUR ACCESS TO THIS SOURCE FILE IS GOVERNED BY THE TERMS AND
CONDITIONS OF AN AGREEMENT BETWEEN YOU AND CAPGEMINI GROUP OF COMPANIES.
The USE, DISCLOSURE REPRODUCTION OR TRANSFER OF THIS PROGRAM IS
RESTRICTED AS SET FORTH THEREIN.
******************************************************************************/

package cbf.harness;

import cbf.utils.StringUtils;

/**
 * Initializes all paths like automation home, work home, and the logs folder
 * path
 * 
 */
public class ResourcePaths {
	

	/**
	 * Returns file paths by using auto home
	 * 
	 * @param relPath
	 *            Relative paths to folder
	 * @param relName
	 *            name of the file in the relPath
	 * @return path of the folder
	 */
	public String getSuiteResource(String relPath, String relName) {

		return createPath(autoHome, relPath, relName);
	}

	/**
	 * Returns file paths by using work home
	 * 
	 * @param relPath
	 *            Relative paths to folder
	 * @param relName
	 *            name of the file in the relPath
	 * @return path of the folder
	 */
	public String getFrameworkResource(String relPath, String relName) {
		return createPath(workHome, relPath, relName);
	}

	/**
	 * Initializes log sfile paths by using run home
	 * 
	 * @param relPath
	 *            Relative paths to folder
	 * @param relName
	 *            name of the file in the relPath
	 * @return path of the folder
	 */
	public String getRunResource(String relPath, String relName) {
		return createPath(runHome, relPath, relName);
	}

	public static ResourcePaths getInstance(String autoHome, String workHome,
			String runHome) {
		if (singleton == null)
			singleton = new ResourcePaths(autoHome, workHome, runHome);
		return singleton;
	}

	private ResourcePaths(String autoHome, String workHome, String runHome) {
		ResourcePaths.autoHome = autoHome;
		ResourcePaths.workHome = workHome;
		ResourcePaths.runHome = runHome;
	}

	private static ResourcePaths singleton = null;

	public static ResourcePaths getInstance() {
		return getInstance(autoHome, workHome, runHome);

	}

	private String createPath(String home, String relPath, String relName) {
		if (!relPath.equals(""))
			home = home + "/" + relPath;
		if (!relName.equals(""))
			home = home + "/" + relName;
		return home;
	}

	/**
	 * Returns ResourcePaths format string
	 */
	public String toString() {
		return StringUtils.mapString(this, autoHome, workHome, runHome);
	}
	static String autoHome, workHome, runHome;
}
