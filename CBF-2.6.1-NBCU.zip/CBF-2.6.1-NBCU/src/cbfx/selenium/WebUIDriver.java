/******************************************************************************
$Id : WebUIDriver.java 12/23/2016 4:09:02 PM
Copyright � 2016 Capgemini Group of companies. All rights reserved
(Subject to Limited Distribution and Restricted Disclosure Only.)
THIS SOURCE FILE MAY CONTAIN INFORMATION WHICH IS THE PROPRIETARY
INFORMATION OF CAPGEMINI GROUP OF COMPANIES AND IS INTENDED FOR USE
ONLY BY THE ENTITY WHO IS ENTITLED TO AND MAY CONTAIN
INFORMATION THAT IS PRIVILEGED, CONFIDENTIAL, OR EXEMPT FROM
DISCLOSURE UNDER APPLICABLE LAW.
YOUR ACCESS TO THIS SOURCE FILE IS GOVERNED BY THE TERMS AND
CONDITIONS OF AN AGREEMENT BETWEEN YOU AND CAPGEMINI GROUP OF COMPANIES.
The USE, DISCLOSURE REPRODUCTION OR TRANSFER OF THIS PROGRAM IS
RESTRICTED AS SET FORTH THEREIN.
 ******************************************************************************/

package cbfx.selenium;

import static cbf.engine.TestResultLogger.failed;
import static cbf.engine.TestResultLogger.passed;
import static java.awt.event.KeyEvent.*;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.HasInputDevices;
import org.openqa.selenium.interactions.Mouse;
import org.openqa.selenium.internal.Locatable;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import cbf.harness.Harness;
import cbf.plugin.PluginManager;
import cbf.utils.DataRow;
import cbf.utils.LogUtils;
import cbf.utils.StringUtils;
import cbfx.browsers.Browser;
import cbfx.objectmaps.ObjectMap;

import org.apache.commons.net.PrintCommandListener;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
/**
 * 
 * Extends BaseWebAppDriver and handles all the common functionalities for
 * webControls like setting the TextBox,Selecting an option in Dropdown ,etc..
 * 
 */

public class WebUIDriver {
	FTPClient ftp = null;

	/**
	 * Overloaded Constructor to initialize webdriver and selenium
	 * 
	 * @param parameters
	 *            webDriver: object of WebDriver selenium: object of
	 *            WebDriverBackedSelenium
	 */
	public WebUIDriver(Map parameters) {

		
		Map obj = (Map<String, Object>) Harness.GCONFIG.get("ObjectMap");
		objMap = (ObjectMap) PluginManager.getPlugin((String) obj.get("plugin"),
				(Map<String, Object>) obj.get("parameters"));

		browser = (Browser) PluginManager.getPlugin((String) parameters.get("plugin"),
				(Map<String, Object>) parameters.get("parameters"));
		this.th = new TableHandler(this);
		
	}

	private void openBrowser() {
		
		this.webDr = browser.openDriver();
		webDr.manage().window().maximize();
		
		
	}

	/**
	 * Launches the Application in the Browser
	 * 
	 * @param url
	 *            URL of the page to be opened.
	 */
	public void launchApplication(String url) {
		closeBrowsers();
		openBrowser();
		try{
		webDr.get(url);
		}
		catch(Exception e)
		{
			logger.handleError("", e);
		}
	}

	/**
	 * Checks whether page title matches or not
	 * 
	 * @param pageTitle
	 *            title of page opened
	 * @return true or false result
	 */
	public boolean checkPage(String pageTitle) {
		try {
			if (pageTitle.equals(webDr.getTitle())) {
				return true;
			}
		} catch (Exception e) {
			logger.handleError("Error in checking the page title: " + pageTitle, e);
		}
		
		
		
		return false;
	}

	/**
	 * Identifies the locator as needed by webDriver object
	 * 
	 * @param elementName
	 *            Name of the element whose locator is required
	 * @return Identified locator as Web Element
	 */

	public WebElement getControl(String elementName) {
		String actualLocator="";
		if(elementName.contains("/")){
			actualLocator=elementName;
		}else{
		actualLocator = (String) objMap.properties(elementName).get("locator");
		}
		WebElement element = null;
		int index = 1;
		final By[] byCollection = { By.id(actualLocator), By.name(actualLocator), By.xpath(actualLocator),
				By.className(actualLocator), By.cssSelector(actualLocator), By.tagName(actualLocator),
				By.linkText(actualLocator), By.partialLinkText(actualLocator) };

		for (By by : byCollection) {
			try {
				element = webDr.findElement(by);
				if (!element.equals(null)) {
					break;
				}
			} catch (NoSuchElementException e) {
				if (index == byCollection.length) {
					//logger.error("Unable to find element ", elementName, e);
				} else {
					index++;
					continue;
				}
			}
		}
		
		return element;
	}

	
	/**
	 * Checks the presence of element till timeout
	 * 
	 * @param elementName
	 *            name of the element
	 * @param timeInSec
	 *            time limit
	 * @return boolean result
	 */
	public boolean checkElementPresent(final String elementName) {

		boolean result = false;
		String time = (String) Harness.GCONFIG.get("TimeOutInSec");
		int timeInSec = Integer.parseInt(time);

		try {
			ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver webDriver) {
					WebElement element = getControl(elementName);
					if (element != null) {
						logger.trace("Element found ", elementName);
						return true;

					} else {
						logger.trace("Unable to find Element", elementName);
						return false;

					}
				}
			};

			Wait<WebDriver> wait = new WebDriverWait(webDr, timeInSec);
			try {
				result = wait.until(expectation);
			} catch (TimeoutException e) {
				logger.error("Unable to find element ", elementName,e.getMessage());
			}
		} catch (ElementNotVisibleException e) {

			logger.handleError("", e);
			
		}
		return result;
	}

	/**
	 * Sets the value to the specified UI Element
	 * 
	 * @param elementName
	 *            name of element
	 * @param value
	 *            value to be set on element
	 */
	public void setValue(String elementName, String value) {
		WebElement element = null;
		if (checkElementPresent(elementName)) {
			element = getControl(elementName);
		} else {
			logger.error("Failed to get element by element name   " + elementName);
		}
		try {
			String type = element.getAttribute("type");
			
			if(type.equals("")||type==null){
				element.clear();
				element.sendKeys(value);
				logger.trace("Typed text '" + value + "' in the input element '" + elementName + "'");
				return;
			}
			if ((type.equals("text")) || type.equals("password")|| type.equals("email") ||type.equals("textarea")) {
				element.clear();
				element.sendKeys(value);
				logger.trace("Typed text '" + value + "' in the input element '" + elementName + "'");
				return;

			}
			

			if (type.equals("select-one")) {
				Select selectOption = new Select(element);
				selectOption.selectByVisibleText(value);
				logger.trace("Selected  " + value + "' in " + elementName + "'");
				return;

			}

			if (type.equalsIgnoreCase("Calendar")) {
				setCalendar(element, value);
				return;
			}

		} 
		
		catch (Exception e) {
			logger.handleError("Error while setting value ," + value + " on element " + elementName, e);
		}
	}

	/**
	 * Sets the value to the specified UI Element
	 * 
	 * @param elementName
	 *            name of element
	 * @param input
	 *            input datarow with UI properties
	 */
	public void setValue(String elementName, DataRow input) {
		setValue(elementName, input.get("elementName"));
	}

	// TODO:Should be made as a plugin
	private void setCalendar(WebElement element, String value) {
		element.click();
		webDr.findElement(By.linkText(value.substring(0, value.indexOf("/")).toString())).click();
	}

	/**
	 * Sets the value to all the locators on the specified page.
	 * 
	 * @param pageName
	 *            name of the page
	 * @param data
	 *            value to be set on page
	 */
	public void setValues(String pageName, Map data) {
		List<Map> resultMap = new ArrayList();
		resultMap = objMap.ObjectMaps(pageName);
		setValues(data, resultMap);
	}

	private void setValues(Map data, List<Map> uiElements) {
		String elementName = "";
		for (Map uiElement : uiElements) {
			elementName = ((String) uiElement.get("elementName"));

			if (data.containsKey(elementName)) {
				setValue(elementName, (String) data.get(elementName));
			}
		}
	}

	/**
	 * Gets the value of the specified element
	 * 
	 * @param elementName
	 *            whose value has to be obtained
	 */
	public String getValue(String elementName) {

		WebElement element = null;
		if (checkElementPresent(elementName)) {
			element = getControl(elementName);
		} else {
			logger.error("Failed to get element by element name" + elementName);
		}
		try {
			String type = element.getAttribute("type");
			if (type==null){
				return element.getText();
			}
			
			if (type.equals("text") || type.equals("password")||type==null) {

				if (element.getText().equals(""))
					return getAttribute(elementName, "value");
				return element.getText();

			}
			if (type.equals("select-one")) {

				Select selectOption = new Select(element);
				return selectOption.getFirstSelectedOption().getText();

			}
			if (type.equals("checkbox") || type.equals("radio")) {

				if (element.isSelected()) {
					return "Yes";
				} else {
					return "No";
				}

			}
			if (type.equals("") || type==null)
			{
				return element.getText();
			}
			
		} catch (Exception e) {
			logger.handleError("Error while getting value of element " + elementName, e);
		}

		return null;
	}

	/**
	 * Clears the value of specified element
	 * 
	 * @param elementName
	 *            element to be cleared
	 */
	public void clear(String elementName) {
		try {
			getControl(elementName).clear();

		} catch (Exception e) {
			logger.handleError("Failed to clear  " + elementName, e);

		}

	}

	/**
	 * Navigates to the Menu
	 * 
	 * @param menuList
	 *            list of menu items
	 */
	public void navigateMenu(String menuList) {
		String[] aMenu;
		aMenu = menuList.split(",");
		try {
			for (int i = 0; i < aMenu.length; i++) {
				if (!(aMenu[i].matches(""))) {
					getControl(aMenu[i]).click();
					logger.trace("Clicked on menu: " + aMenu[i] + ".");
					waitForBrowserStability("1000");
				}
			}
		} catch (Exception e) {
			if (menuList.contains(","))
				menuList = menuList.replaceAll(",", "-->");
			logger.handleError("Failed while Navigating to  " + menuList);
		}
	}

	
	/**
	 * Check for the presence of the specified text on page till timeout
	 * 
	 * @param text
	 *            text to be verified
	 * @param timeInSec
	 *            time-limit(in seconds)
	 * @return boolean Result
	 */
	public boolean checkTextOnPage(String text, int timeInSec) {
		boolean result = false;
		WebDriverWait waitForPage = new WebDriverWait(webDr, TimeUnit.MILLISECONDS.toSeconds(500));

		try {
			for (int second = 0;; second++) {
				if (second >= timeInSec * 10) {
					logger.trace("TimeOut for " + second);
					break;
				}
				if (webDr.findElement(By.tagName("body")).getText().contains(text)) {
					result = true;
					break;
				}
				waitForPage.until(ExpectedConditions.visibilityOf(webDr.findElement(By.tagName("body"))));
			}
		} catch (Exception e) {
			logger.handleError("Error: Caused while Verifying the Presence of Text \" " + text + " \"", e);
		}
		return result;
	}

	/**
	 * Clicks on the specified element
	 * 
	 * @param elementName
	 *            element to be clicked
	 */

	public void click(String elementName) {
		try {

			if (checkElementPresent(elementName)) {
				
				getControl(elementName).click();
				logger.trace("Clicked on element ",elementName);
			} else {
				logger.error("Failed to get element by element name   " + elementName);
			}
		} catch (Exception e) {
			logger.handleError("Failed to click on the element ", elementName, " ", e);
		}

	}
	
		/**
	 * Mouse overs on the specified menu and clicks on the sub menu.
	 * 
	 * @param menu
	 *            menu of the elements
	 * @param subMenu
	 *            element to be clicked
	 */

	public void mouseOverAndClick(String menu, String subMenu) {
		try {
			Mouse mouse = mouseOver(menu);
			Locatable hoverSubItem = (Locatable) getControl(subMenu);
			mouse = ((HasInputDevices) webDr).getMouse();
			mouse.click(hoverSubItem.getCoordinates());
		} catch (Exception e) {
			logger.handleError("Falied to click ", subMenu, " on", menu, " ", e);
		}
	}

	/**
	 * Mouse overs on the specified element
	 * 
	 * @param elementName
	 *            name of element
	 */

	public Mouse mouseOver(String elementName) {
		try {
			WebElement link = getControl(elementName);
			Locatable hoverItem = (Locatable) link;
			Mouse mouse = ((HasInputDevices) webDr).getMouse();
			mouse.mouseMove(hoverItem.getCoordinates());
			return mouse;
		} catch (Exception e) {
			logger.handleError("Falied to hover on ", elementName, e);
			return null;
		}

	}

	/**
	 * Performs the drag and drop operation
	 * 
	 * @param fromLocator
	 *            Contains the locator of source element
	 * @param toLocator
	 *            Contains the locator of destination element
	 */
	public void dragAndDrop(String fromLocator, String toLocator) {
		try {
			WebElement from = getControl(fromLocator);
			WebElement to = getControl(toLocator);
			Actions builder = new Actions(webDr);
			Action dragAndDrop = builder.clickAndHold(from).moveToElement(to).release(to).build();
			dragAndDrop.perform();
		} catch (StaleElementReferenceException e) {
			logger.handleError("Failed to drag drop elements ", fromLocator, " , ", toLocator, " ", e);
		}
	}

	/**
	 * Switch to another window
	 * 
	 * @param title
	 *            Contains title of the new window
	 * @return true or false
	 */
	public boolean switchToWindow(String title) {
		Set<String> availableWindows = webDr.getWindowHandles();
		if (availableWindows.size() > 1) {
			try {
				for (String windowId : availableWindows) {
					if (webDr.switchTo().window(windowId).getTitle().equals(title))
						return true;
				}
			} catch (NoSuchWindowException e) {
				logger.handleError("No child window is available to switch ", e);
			}
		}

		return false;
	}

	/**
	 * Uploads a file
	 * 
	 * @param filePath
	 *            Contains path of the file to be uploaded
	 * @param browse
	 *            Contains locator of the browse button
	 * @param upload
	 *            locator of the upload button
	 */
	public void fileUpload(String filePath, String browse, String upload) {
		WebElement element = getControl(browse);
		try {
			element.sendKeys(filePath);
			if (upload != null) {
				click("upload");
			}
		} catch (Exception e) {
			logger.handleError("Invalid File Path: ", filePath, e);
		}

	}

	/**
	 * Invokes enter/tab/F5/home/delete key
	 * 
	 * @param keyEvent
	 *            key to be invoked
	 * 
	 */
	// TODO:Check for other useful key events
	public void sendKey(String keyEvent) {
		try {
			Robot key = new Robot();
			if (keyEvent.equalsIgnoreCase("enter")) {
				key.keyPress(KeyEvent.VK_ENTER);
				key.keyRelease(KeyEvent.VK_ENTER);
				waitForBrowserStability("1000");
				return;
			}
			if (keyEvent.equalsIgnoreCase("tab")) {
				key.keyPress(KeyEvent.VK_TAB);
				key.keyRelease(KeyEvent.VK_TAB);
				waitForBrowserStability("5000");
				return;
			}
			
			if (keyEvent.equalsIgnoreCase("backspace")) {
				key.keyPress(KeyEvent.VK_BACK_SPACE);
				key.keyRelease(KeyEvent.VK_BACK_SPACE);
				waitForBrowserStability("5000");
				return;
			}
			
			if (keyEvent.equalsIgnoreCase("F5")) {
				key.keyPress(KeyEvent.VK_F5);
				key.keyRelease(KeyEvent.VK_F5);
				waitForBrowserStability("1000");
				return;
			}

			if (keyEvent.equalsIgnoreCase("home")) {
				key.keyPress(KeyEvent.VK_HOME);
				key.keyRelease(KeyEvent.VK_HOME);
				waitForBrowserStability("1000");
				return;
			}

			if (keyEvent.equalsIgnoreCase("delete")) {
				key.keyPress(KeyEvent.VK_DELETE);
				key.keyRelease(KeyEvent.VK_DELETE);
				waitForBrowserStability("1000");
				return;
			}
			if (keyEvent.equalsIgnoreCase("save")) {
				key.keyPress(KeyEvent.VK_CONTROL);
				key.keyPress(KeyEvent.VK_S);
				key.keyRelease(KeyEvent.VK_S);
				key.keyRelease(KeyEvent.VK_CONTROL);
				waitForBrowserStability("1000");
				return;
			}
			
			if (keyEvent.equalsIgnoreCase("selectAll")) {
				key.keyPress(KeyEvent.VK_CONTROL);
				key.keyPress(KeyEvent.VK_A);
				key.keyRelease(KeyEvent.VK_A);
				key.keyRelease(KeyEvent.VK_CONTROL);
				waitForBrowserStability("1000");
				return;
			}
			
			
			if (keyEvent.equalsIgnoreCase("paste")) {
				key.keyPress(KeyEvent.VK_CONTROL);
				key.keyPress(KeyEvent.VK_V);
				key.keyRelease(KeyEvent.VK_V);
				key.keyRelease(KeyEvent.VK_CONTROL);
				waitForBrowserStability("1000");
				return;
			}
			
			
			
			
			if(keyEvent.equalsIgnoreCase("rightClick")){
				key.mousePress(InputEvent.BUTTON1_DOWN_MASK); // press left click	
				key.mouseRelease(InputEvent.BUTTON1_DOWN_MASK); // release left click
			}
		} catch (AWTException e) {
			logger.handleError("Error caused while clicking on '", keyEvent, e);
		}
	}

	/**
	 * Send string as keyboard keystrokes
	 * 
	 * @param text
	 *            String to be entered
	 */
	public void setText(String text) {
		for (int i = 0; i < text.length(); i++) {
			char c = text.charAt(i);
			Robot robot;
			try {
				robot = new Robot();
				robot.keyPress(VK_ALT);
				robot.keyPress(VK_NUMPAD0);
				robot.keyRelease(VK_NUMPAD0);
				String altCode = Integer.toString(c);
				for (int j = 0; j < altCode.length(); j++) {
					c = (char) (altCode.charAt(j) + '0');
					robot.keyPress(c);
					robot.keyRelease(c);
				}
				robot.keyRelease(VK_ALT);
			} catch (AWTException e) {
				logger.error("Unable to type string " + text);
			}
		}

	}

	/**
	 * Compares actual and expected text from the application
	 * 
	 * @param elementName
	 *            element for which text is to be checked
	 * @param expectedText
	 *            expected text
	 * @return boolean result
	 */
	public boolean verifyText(String elementName, String expectedText) {
		String actualText = getValue(elementName);
		if (actualText.equalsIgnoreCase(expectedText)) {
			return true;
		}
		return false;
	}

	/**
	 * Verify Tooltip's text
	 * 
	 * @param elementName
	 *            Give element for which tooltip is visible
	 * @param expected
	 *            expected tooltip text
	 */

	public void verifyTooltip(String elementName, String expected) {
		WebElement element = null;
		if (checkElementPresent(elementName)) {
			element = getControl(elementName);
		} else {
			logger.error("Failed to get element by element name" + elementName);
		}
		String str = null;
		try {
			if (!element.getAttribute("title").isEmpty()) {
				str = element.getAttribute("title");
				if (str.contains(expected)) {
					passed("verify tooltip: " + str + "for " + element,
							"Tooltip's text should match with " + str + "for " + element,
							"Tooltip's text matches with " + str + "for " + element);
				} else {
					failed("verify tooltip: " + str, "Tooltip's text should match with " + str,
							"Tooltip's text doesn't match with " + str);
				}
			} else {
				failed("verify tooltip: " + str + "for " + element, str + " not Visible",
						"Tooltip" + str + " is not visible for " + element);
			}
		} catch (Exception e) {
			logger.handleError("Error while verifying tool tip", e);
		}

	}

	/**
	 * Verifies text in alert and clicks on either OK or cancel.
	 * 
	 * @param text
	 *            expected text
	 * @param button
	 *            "OK" or "Cancel" button
	 */

	public void handleAlert(String text, String button) {
		try {
			Alert alert = webDr.switchTo().alert();
			if (!text.equals("")) {
				String alerttext = alert.getText();
				if (alerttext.matches(text)) {
					passed("verify " + text + " in alert", text + " should present in alert",
							text + " is present in  alert");
				} else {
					//failed("verify " + text + " in alert", text + " should present in alert",
					//		text + " is not present in  alert");
				}
			}
			if (button.equalsIgnoreCase("yes") || button.equalsIgnoreCase("ok")|| button.equalsIgnoreCase("Stay")) {
				alert.accept();
			} else {
				alert.dismiss();
			}
		} 
		
		catch (NoAlertPresentException e) {
		//	logger.handleError("Error while verifying text:" + text + " in alert with button", button, e);
		}
		/*catch (Exception e) {
			logger.handleError("Error while verifying text:" + text + " in alert with button", button, e);
		}*/

	}

	/**
	 * Sets the text in the alert box
	 * 
	 * @param value
	 *            text to be set in alert box
	 */

	public void setTextInAlert(String value) {
		try {
			Alert alt = webDr.switchTo().alert();
			alt.sendKeys(value);
			alt.accept();
		} 
		catch (NoAlertPresentException e) {
			logger.handleError("Failed to set text:" + value + " in alert", e);
		}
		catch (Exception e) {
			logger.handleError("Failed to set text:" + value + " in alert", e);
		}

	}

	/**
	 * Gets the text from the alert box
	 * 
	 * @return String
	 */

	public String getAlertText() {
		try {
			Alert alt = webDr.switchTo().alert();
			return alt.getText();
		}
		catch (NoAlertPresentException e) {
			logger.handleError("Failed to get text from alert box", e);
			return null;
		}
		catch (Exception e) {
			logger.handleError("Failed to get text from alert box", e);
			return null;
		}
		
	}

	/**
	 * Verify the presence of alert till timeout
	 * 
	 * @param TimeOutinSeconds
	 *            Give max time limit
	 * @return boolean
	 */

	/*public boolean isAlertPresent(int TimeOutinSeconds) {
		for (int i = 0; i < TimeOutinSeconds; i++) {
		try {
			    Thread.sleep(500);
				webDr.switchTo().alert();
				return true;
				 
			}catch (InterruptedException e) {
				e.printStackTrace();
			}
			catch (NoAlertPresentException e) {
				logger.handleError("Failed to verify presence of alert", e);
			}
			
			
		}
		return false;
	}*/
	
	public boolean isAlertPresent(){
	    boolean foundAlert = false;
	    WebDriverWait wait = new WebDriverWait(webDr, 0);
	    try {
	        wait.until(ExpectedConditions.alertIsPresent());
	        foundAlert = true;
	    } catch (TimeoutException eTO) {
	        foundAlert = false;
	    }
	    return foundAlert;
	}

	

	/**
	 * For highlighting an element
	 * 
	 * @param elementName
	 *            Locator
	 */

	public void drawHighlight(String elementName) {
		WebElement element = null;
		if (checkElementPresent(elementName)) {
			element = getControl(elementName);
		} else {
			logger.error("Failed to get element by element name" + elementName);
		}
		try {
			JavascriptExecutor js = ((JavascriptExecutor) webDr);
			js.executeScript("arguments[0].style.border='2px groove red'", element);
		} catch (Exception e) {
			logger.handleError("Failed to highlight element", elementName, " ", e);
		}

	}

	/**
	 * Retrieve drop down options
	 * 
	 * @param elementName
	 *            name of dropdown
	 * 
	 */
	public List<String> getDropDownOptions(String elementName) {
		List<String> optionsStr = new ArrayList<String>();
		WebElement element = null;
		if (checkElementPresent(elementName)) {
			element = getControl(elementName);
		} else {
			logger.error("Failed to get element by element name" + elementName);
		}
		try {
			List<WebElement> options = element.findElements(By.tagName("option"));

			for (WebElement option : options) {
				optionsStr.add(option.getText());

			}

		} catch (Exception e) {
			logger.handleError("Failed to get dropdown list for: ", elementName, " ", e);
		}

		return optionsStr;
	}

	/**
	 * checks the presence of specified options in the dropdown
	 * 
	 * @param elementName
	 *            name of element
	 * @param optionsStr
	 *            options to be checked with comma separated values
	 * 
	 * 
	 */
	public boolean checkDropDownOptions(String elementName, String optionsStr) {
		List<Object> flag = new ArrayList<Object>();
		List<String> dropDownOptions = getDropDownOptions(elementName);
		List<String> dropDownOptionsLowerCase = new ArrayList<String>();
		for (String temp : dropDownOptions) {
			dropDownOptionsLowerCase.add(temp.trim().toLowerCase());
		}
		String[] dropDownOptionsActList = optionsStr.split(",");
		try {
			for (int i = 0; i < dropDownOptionsActList.length; i++) {
				if (dropDownOptionsLowerCase.contains(dropDownOptionsActList[i].trim().toLowerCase())) {
					flag.add(true);
				} else {
					flag.add(false);
				}
			}

		} catch (Exception e) {
			logger.handleError("Failed to verify option: ", optionsStr, "for ", elementName, " ", e);
		}
		if (flag.contains(false)) {
			return false;
		} else {

			return true;
		}
	}

	/**
	 * Checks the attribute value
	 * 
	 * @param elementName
	 *            name of element
	 * 
	 * @param attribute
	 *            attribute to be set
	 * @param value
	 *            value of the attribute
	 */

	public boolean checkAtttribute(String elementName, String attribute, String value) {
		String actualValue = getAttribute(elementName, attribute);
		if (value.equals(actualValue))
			return true;
		return false;
	}

	/**
	 * Sets the attribute value
	 * 
	 * @param elementName
	 *            name of element
	 * 
	 * @param attribute
	 *            attribute to be set
	 * @param value
	 *            value of the attribute
	 */
	public void setAttribute(String elementName, String attribute, String value) {
		try {
			WebElement element = null;
			if (checkElementPresent(elementName)) {
				element = getControl(elementName);
			} else {
				logger.error("Failed to get element by element name" + elementName);
			}
			JavascriptExecutor js = (JavascriptExecutor) webDr;
			js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2])", element, attribute, value);

		} catch (Exception e) {
			logger.handleError("Failed to set ", value, " for attribute ", attribute, " for the element ", elementName,
					" ", e);
		}
	}

	/**
	 * Gets the attribute value
	 * 
	 * @param elementName
	 *            name of element
	 * 
	 * @param attribute
	 *            attribute name
	 */
	public String getAttribute(String elementName, String attribute) {
		WebElement element = null;
		if (checkElementPresent(elementName)) {
			element = getControl(elementName);
		} else {
			logger.error("Failed to get element by element name" + elementName);
		}
		try {
			String value = element.getAttribute(attribute);
			return value;
		} catch (WebDriverException e) {
			logger.handleError("Failed to get value for attribute ", attribute, " for the element ", elementName, " ",
					e);
			return null;
		}
	}

	/**
	 * Executes Javascript
	 * 
	 * @param script
	 *            script to be executed
	 **/
	public void executeJavaScript(String script) {
		try {
			JavascriptExecutor js = (JavascriptExecutor) webDr;
			js.executeScript(script);

		}
		
		catch (Exception e) {
			logger.handleError("Falied to execute ", script);
		}
	}

	/**
	 * For Double clicking on any element
	 * 
	 * @param elementName
	 *            name of element
	 */

	public void doubleclick(String elementName) {
		Actions axn = new Actions(webDr);
		try {
			axn.doubleClick(getControl(elementName)).build().perform();
			logger.trace("Double Clicked on element ",elementName);
		} catch (Exception e) {
			logger.handleError("Failed to double click on " + elementName, e);
		}
	}

	/**
	 * For right clicking on any element
	 * 
	 * @param elementName
	 *            name of element
	 */

	public void rightClick(String elementName, int option) {
		Actions action = new Actions(webDr);
		Actions act = null;
		for (int i = 0; i < option - 1; i++) {
			act = action.contextClick(getControl(elementName)).sendKeys(Keys.ARROW_DOWN);
			act.build().perform();
		}
		act.sendKeys(Keys.ENTER).build().perform();

	}

	/**
	 * Shut downs the webdriver
	 */
	public void closeBrowsers() {
		if (webDr != null)
			browser.closeDriver();
	}

	/**
	 * Takes screenshot
	 */
	public File takescreenshot() {
		try {
			File scrFile = ((TakesScreenshot) webDr).getScreenshotAs(OutputType.FILE);
			return scrFile;
		} catch (Exception e) {
			logger.handleError("Failed to take screenshots", e);
			return null;
		}
	}

	/**
	 * Clear cookies
	 */
	public void clearCookies() {
		try {
			webDr.manage().deleteAllCookies();
		} catch (Exception e) {

			logger.handleError("Failed to clear cookies", e);
		}
	}

	/**
	 * Check the running process and kill it
	 * 
	 * @param serviceName
	 *            Give name of the process that you want to kill
	 * @return Boolean
	 * @throws IOException
	 */

	public void killProcess(String serviceName) throws IOException {
		String line;
		Process p = Runtime.getRuntime().exec(System.getenv("windir") + "\\system32\\" + "tasklist.exe");
		BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
		try {
			while ((line = input.readLine()) != null) {
				if (line.contains(serviceName)) {
					Runtime.getRuntime().exec("taskkill /f /IM " + serviceName);
				}
			}
			input.close();
		} catch (Exception e) {
			logger.handleError("Failed to kill ", serviceName, e);

		}
	}

	/**
	 * Checks whether the page is loaded or not
	 * 
	 * @param maxTimeInSec
	 *            time to wait(In seconds)
	 * @return boolean result
	 */
	public boolean waitForBrowserStability(String maxTimeInSec) {
		boolean bResult = false;
		int maxWait = Integer.parseInt(maxTimeInSec);
		int secsWaited = 0;
		try {
			do {
				Thread.sleep(100);
				secsWaited++;
				if (isBrowserLoaded()) {
					bResult = true;
					break;
				}
			} while (secsWaited < (maxWait * 10));
			Thread.sleep(100);
		}
		catch (TimeoutException e) {
			logger.handleError("Error while waiting for the page to load",e.getMessage());
		}
		catch (Exception e) {
			logger.handleError("Error while waiting for the page to load ", e);
			bResult = false;
		}
		return bResult;
	}

	/**
	 * Checks if body of the page is loaded or not
	 * 
	 * @return Boolean Result
	 */
	public boolean isBrowserLoaded() {
		boolean isBrowserLoaded = false;
		try {
			long timeOut = 5000;
			long end = System.currentTimeMillis() + timeOut;

			while (System.currentTimeMillis() < end) {

				if (String.valueOf(((JavascriptExecutor) webDr).executeScript("return document.readyState"))
						.equals("complete")) {
					isBrowserLoaded = true;
					break;
				}
			}
		} catch (Exception e) {
			logger.handleError("Failed to check for the browser to load", e);
		}
		return isBrowserLoaded;
	}

	public void setFrame(String frame) {
		try {
			if (checkVisible(frame)) {
				webDr.switchTo().frame(getControl(frame));

				logger.trace("Navigated to frame with element name" + frame);
			}
		} catch (NoSuchFrameException e) {

			logger.trace("Unable to locate frame with element name " + frame);
		}

	}

	public boolean checkVisible(String elementName) {

		boolean result = false;
		try {
			if (getControl(elementName).isDisplayed()) {
				result = true;
			}
		}

		catch (ElementNotVisibleException e) {
			logger.trace("Error: Caused while Verifying the Presence of Element \" " + elementName + " \"");
		}

		return result;
	}

	/**
	 * Return the focus to the parent frame
	 * 
	 */

	public void resetFrame() {
		try {
			webDr.switchTo().defaultContent();

			logger.trace("Navigated back to webpage from frame");
		} catch (Exception e) {

			logger.trace("Unable to navigate back to main webpage from frame" + e.getStackTrace());
		}

	}
	
	
	public String getObjMap(String elementName)
	{
		String actualLocator = (String) objMap.properties(elementName).get("locator");
		return actualLocator;
	}
	
	
	public int getEleIndex(String xpath,String filterText){
		
		int index=0;
		List<WebElement> revEle = webDr.findElements(By
				.xpath(xpath));
		String dataLable = "";

		for (int i = 0; i <= revEle.size() - 1; i++) {
			try {
				dataLable = revEle.get(i).getAttribute("data-label");

				if (dataLable.equals(filterText)) {

					index = i + 1;
		
				}
		
			}catch (org.openqa.selenium.StaleElementReferenceException e) {
				continue;
			}
		
		}
		return index;
		
		
	}
	
	public void back(){
		webDr.navigate().back();
	}
	
	public void refresh(){
		webDr.navigate().refresh();
	}
		
	
	/**
	* Setting focus on edit box
	* 
	* Added by MGM
	*/
	public void focus(String elementName) {
	Actions focus = new Actions(webDr);
	try {
	focus.moveToElement(getControl(elementName)).click().perform();
	} catch (Exception e) {
	failed("Set Focus","Should focus on " + elementName , "Not able to set the focus on" + elementName);
	logger.handleError("Failed to set focus on " + elementName, e);
	}
	}
	public String getValueByText(String xpath) {
		WebElement element = getControl(xpath);
		try
		{
		return element.getText();
		 
		}

		catch (Exception e) {
		failed("Get text" ,"Should get the text of xpath "+xpath, "Failed get the text of xpath "+xpath);
		logger.handleError("Error while getting value of element "
		+ xpath, e);
		}

		return null;
		}
	
	public String getDyanmicData(String elementName)
	{
		
		//WebElement getData = uiDriver.getControl("WElement_DynamicData");
		//String temp = uiDriver.getObjMap("WElement_DynamicData");
		String temp = null;
		try{
		
			temp = (String) objMap.properties(elementName).get("locator");
		
	}
		
		catch (Exception e) {
			
			logger.handleError("Failed to replace data " + elementName, e);
			}
	
		return temp;
		
	}
	
	
	public String getValue_Text(String elementName) {
		WebElement element = getControl(elementName);
		try
		{
		return element.getText();
		}

		catch (Exception e) {
		failed("Get text" ,"Should get the text of "+elementName, "Failed get the text of "+elementName);
		logger.handleError("Error while getting value of element "
		+ elementName, e);
		}

		return null;
		}
	
	
	public void click_dynamic(String xpath) {
		try {
		getControl(xpath).click();
		} catch (Exception e) {
		failed("Click","Should be clicked on " + xpath, "Failed to Click on " + xpath);
		logger.handleError("Failed to click on the element ", xpath,
		" ", e);
		}
		}
	
	public boolean checkElementPresent_dynamic(final String xpath) {

		boolean result = false;
		String time = (String) Harness.GCONFIG.get("TimeOutInSec");
		int timeInSec = Integer.parseInt(time);

		try {
			ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver webDriver) {
					WebElement element = getControl(xpath);
					if (element != null) {
						logger.trace("Element found ", xpath);
						return true;

					} else {
						logger.trace("Unable to find Element", xpath);
						return false;

					}
				}
			};

			Wait<WebDriver> wait = new WebDriverWait(webDr, timeInSec);
			try {
				result = wait.until(expectation);
			} catch (TimeoutException e) {
				logger.error("Unable to find element ", xpath,e.getMessage());
			}
		} catch (ElementNotVisibleException e) {

			logger.handleError("", e);
			
		}
		return result;
	}
	
	
	
	public String getValueCheckBox(String xpath) {
		WebElement element = getControl(xpath);
		try
		{
			if (element.isSelected()) {
				return "Yes";
			} else {
				return "No";
			}
				
		}

		 catch (Exception e) {
			 failed("Get text" ,"Should get the value of xpath "+xpath, "Failed get the value of xpath "+xpath);
			logger.handleError("Error while getting value of element "
					+ xpath, e);
		}

		return null;
	}	
	
	
	public void FTPUploader(String host, String user, String pwd) throws Exception{
		
		
		 ftp = new FTPClient();
		ftp.addProtocolCommandListener(new PrintCommandListener(new PrintWriter(System.out)));
		int reply;
		ftp.connect(host);
		reply = ftp.getReplyCode();
		if (!FTPReply.isPositiveCompletion(reply)) {
			ftp.disconnect();
			throw new Exception("Exception in connecting to FTP Server");
		}
		ftp.login(user, pwd);
		ftp.setFileType(FTP.BINARY_FILE_TYPE);
		
		ftp.enterLocalPassiveMode();
	}


	public void uploadFile(String filePath,String fileName)
			throws Exception {
		
		try{
			/*InputStream input = new FileInputStream(new File(localFileFullName));
			String path="/CAFE/in";
			
			ftp.changeWorkingDirectory(path);
			
			ftp.printWorkingDirectory();
			
			ftp.storeUniqueFile(input);*/
			ftp.changeWorkingDirectory("/NETSUIT/in-qa");
			File srcFile = new File(filePath); // replace with actual path
			FileInputStream fis = new FileInputStream(srcFile);
			ftp.storeFile(fileName, fis);
			 
		
		}
		catch(Exception e){
			
			System.out.print("");
		}
	}

	public void disconnect(){
		if (this.ftp.isConnected()) {
			try {
				this.ftp.logout();
				this.ftp.disconnect();
			} catch (IOException f) {
				// do nothing as file is already saved to server
			}
		}
	}

	public void modifyFile(String filePath, String oldString, String newString)
	   {
	       File fileToBeModified = new File(filePath);
	        
	       String oldContent = "";
	        
	       BufferedReader reader = null;
	        
	       FileWriter writer = null;
	        
	       try
	       {
	           reader = new BufferedReader(new FileReader(fileToBeModified));
	            
	           //Reading all the lines of input text file into oldContent
	            
	           String line = reader.readLine();
	            
	           while (line != null) 
	           {
	               oldContent = oldContent + line + System.lineSeparator();
	                
	               line = reader.readLine();
	           }
	            
	           //Replacing oldString with newString in the oldContent
	            
	           String newContent = oldContent.replaceAll(oldString, newString);
	            
	           //Rewriting the input text file with newContent
	            
	           writer = new FileWriter(fileToBeModified);
	            
	           writer.write(newContent);
	       }
	       catch (IOException e)
	       {
	           e.printStackTrace();
	       }
	       finally
	       {
	           try
	           {
	               //Closing the resources
	                
	               reader.close();
	                
	               writer.close();
	           } 
	           catch (IOException e) 
	           {
	               e.printStackTrace();
	           }
	       }
	   }
	
	
	/**
	 * Overriding toString() method to return WebUIDriver format string
	 */
	public String toString() {
		return StringUtils.mapString(this);
	}

	public WebDriver webDr;
	private static ObjectMap objMap;
	private Browser browser;
	public TableHandler th;
	private LogUtils logger = new LogUtils(this);
	
	public int getSizeOfElement(String xpath) {
		try {
			int size = webDr.findElements(By
					.xpath(xpath)).size();
			return size;
		} catch (Exception e) {
		failed("Click","Should be clicked on " + xpath, "Failed to Click on " + xpath);
		logger.handleError("Failed to click on the element ", xpath,
		" ", e);
		return -1;
		}
	}
	
	public void ScrollElelmentIntoView(String elementName) {
		try {
			WebElement element = getControl(elementName);
			((JavascriptExecutor) webDr).executeScript("arguments[0].scrollIntoView(true);", element);
			Thread.sleep(1000); 
		} catch(Exception e) {
			
		}
		
	}
	
	public void ScrollPageUp() {
		try {
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_PAGE_UP);
			robot.keyRelease(KeyEvent.VK_PAGE_UP);
			Thread.sleep(1000); 
		} catch(Exception e) {
			
		}
		
	}public void ScrollPageDown() {
		try {
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
			Thread.sleep(1000); 
		} catch(Exception e) {
			
		}
		
	}
	
	public void SelectValueFromDropDown(String elementName, String value) {		
		try {
			if (checkElementPresent(elementName)) {				
				Select sel = new Select(getControl(elementName));
				sel.selectByValue(value);
				logger.trace("Selected value "+value+" from dropdown");
			} else {
				logger.error("Failed to select value "+value+" from dropdown");
			}
		} catch (Exception e) {
			logger.handleError("Failed to select value "+value+" from dropdown"+ e);
		}
	}
}
