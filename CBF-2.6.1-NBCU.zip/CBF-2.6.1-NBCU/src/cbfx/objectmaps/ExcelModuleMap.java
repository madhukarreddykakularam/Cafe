/******************************************************************************
$Id : ExcelObjectMap.java 12/23/2016 4:08:54 PM
Copyright � 2016 Capgemini Group of companies. All rights reserved
(Subject to Limited Distribution and Restricted Disclosure Only.)
THIS SOURCE FILE MAY CONTAIN INFORMATION WHICH IS THE PROPRIETARY
INFORMATION OF CAPGEMINI GROUP OF COMPANIES AND IS INTENDED FOR USE
ONLY BY THE ENTITY WHO IS ENTITLED TO AND MAY CONTAIN
INFORMATION THAT IS PRIVILEGED, CONFIDENTIAL, OR EXEMPT FROM
DISCLOSURE UNDER APPLICABLE LAW.
YOUR ACCESS TO THIS SOURCE FILE IS GOVERNED BY THE TERMS AND
CONDITIONS OF AN AGREEMENT BETWEEN YOU AND CAPGEMINI GROUP OF COMPANIES.
The USE, DISCLOSURE REPRODUCTION OR TRANSFER OF THIS PROGRAM IS
RESTRICTED AS SET FORTH THEREIN.
******************************************************************************/

package cbfx.objectmaps;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import cbf.harness.ResourcePaths;
import cbf.utils.DTAccess;
import cbf.utils.ExcelAccess;
import cbf.utils.FileUtils;
import cbf.utils.LogUtils;
import cbf.utils.StringUtils;
import cbf.utils.Utils;
import cbf.utils.ExcelAccess.RowHandler;

/**
 * Handles excel repository related functionalities like reading the locators
 *
 */
public class ExcelModuleMap implements ObjectMap {

	public Map<String, List<Map>> uiMap;

	/**
	 * Constructor to initialize locators map
	 * 
	 * @param params
	 *            params required to access locators
	 */
	public ExcelModuleMap(Map params) {
		this.params = params;
		uiMap = readLocators();
	}

	/**
	 * Reads locators and returns List of it
	 * 
	 * @return List of locators
	 */
	private Map<String, List<Map>> readLocators() {
		Workbook workbook;
		String filepath;
		Map<String, List<Map>> map = new HashMap<String, List<Map>>();
		try {
			switch (((String) params.get("workbook")).toLowerCase()) {
			case "single":

				filepath = ResourcePaths.getInstance().getSuiteResource("Plan/AppDriver/OR", "uiMap.xls");
				if (FileUtils.fileExists(filepath)) {
					workbook = ExcelAccess.getWorkbook(filepath);
				} else {
					filepath = ResourcePaths.getInstance().getSuiteResource("Plan/AppDriver/OR", "uiMap.xlsx");
					workbook = ExcelAccess.getWorkbook(filepath);
				}

				for (int sheetNumber = 0; sheetNumber < workbook.getNumberOfSheets(); sheetNumber++) {
					map.put(workbook.getSheetName(sheetNumber),
							new DTAccess(filepath).readSheet(workbook.getSheetName(sheetNumber)));
				}
				break;
			case "multiple":
				filepath = ResourcePaths.getInstance().getSuiteResource("Plan/AppDriver/OR", "");
				for (String file : new File(filepath).list()) {
					if (file.contains("xls")) {
						workbook = ExcelAccess.getWorkbook(filepath + "/" + file);
						List<Map> sheets = new ArrayList<Map>();
						for (int sheetNumber = 0; sheetNumber < workbook.getNumberOfSheets(); sheetNumber++) {
							sheets.addAll((new DTAccess(filepath + "/" + file)
									.readSheet(workbook.getSheetName(sheetNumber))));
							map.put(file.split("\\.")[0], sheets);
						}
					}
				}

				break;

			default:
				logger.error("Incorrect parameter is provided in config to select single/multiple workbook");
				break;
			}

		} catch (Exception e) {

		}
		return map;
	}

	/**
	 * Returns list of locators of specified page
	 * 
	 * @param pageName
	 *            name of page
	 * @return list of map of locators
	 */

	public List<Map> ObjectMaps(String pageName) {
		Map result;
		List<Map> resultMap = new ArrayList();
		String sPageName = "";
		try {
			/*
			 * for (Map map : uiMap) { sElement = ((String)
			 * map.get("elementName")); if (sElement.contains(".")) { String
			 * temp = sElement.substring(0, sElement.indexOf(".")); if
			 * (pageName.matches(temp)) { result = map; resultMap.add(result); }
			 * } }
			 */

			/*
			 * for (Map map : uiMap) { sPageName = ((String) map.get("page"));
			 * 
			 * if (pageName.matches(sPageName)) { result = map;
			 * resultMap.add(result); } }
			 */
		} catch (Exception e) {
			logger.trace("Error: Caused while searching the locators of page \" " + pageName + " \"", e);
		}
		return resultMap;

	}

	/**
	 * Returns all the properties of an element from locator sheet
	 * 
	 * @param element
	 *            element name
	 * @return map of properties of an element
	 */
	public Map properties(String element) {
		Map result = null;
		setCodes();
		try {
			for (Entry<String, List<Map>> mod : uiMap.entrySet()) {
				if (moduleCode.contains(mod.getKey())) {
					for (Map map : mod.getValue()) {

						if (map.get("componentCode").toString().equalsIgnoreCase(compCode)) {
							String temp = (String) map.get("elementName");
							if (element.matches(temp) || element.equals(temp)) {
								result = map;
								break;
							}
						}

					}

				}
			}
			if (result == null) {
				for (Map map : uiMap.get("Global")) {
					String temp = (String) map.get("elementName");
					if (element.matches(temp) || element.equals(temp)) {
						result = map;
						break;
					}

				}
				if (result == null) {
					logger.error("Error in getting properties of " + element + " in uiMap");
				}
			}
		} catch (Exception e) {
			logger.error("Error in accessing locator module sheet/workbook for " + element+" in OR");
		}

		return result;
	}

	private void setCodes() {
		try {
			StackTraceElement[] stacktrace = Thread.currentThread().getStackTrace();
			for (int i = 0; i < stacktrace.length; i++) {
				String className = stacktrace[i].getClassName();
				if (className.contains("moduledrivers")) {
					moduleCode = className;
					compCode = stacktrace[i].getMethodName();
					break;
				}
			}
		} catch (Exception e) {
			logger.error("Error in getting module codes and component codes for accessing locators", e.getCause());
		}
	}

	/**
	 * Overriding toString() method and returns ObjectMap format string
	 */
	public String toString() {
		return StringUtils.mapString(this);
	}

	private String moduleCode = null, compCode = null;
	private Map params;
	LogUtils logger = new LogUtils(this);
}
