package moduledrivers;

import static cbf.engine.TestResultLogger.failed;
import static cbf.engine.TestResultLogger.log;
import static cbf.engine.TestResultLogger.passed;

import java.io.IOException;
import java.sql.SQLException;

import cbf.engine.TestResult.ResultType;
import cbf.utils.DataRow;
import cbf.utils.SleepUtils;
import cbf.utils.SleepUtils.TimeSlab;
import cbfx.basedrivers.BaseWebModuleDriver;

public class SalesforceDriver extends BaseWebModuleDriver {

	/**
	 * Launches Application
	 * 
	 * @param input
	 *            DataRow of input parameters
	 * @param output
	 *            empty DataRow passed to capture any runtime output during
	 *            execution of component
	 */

	public void launchApp(DataRow input, DataRow output) {
		uiDriver.launchApplication(input.get("url"));
		if (uiDriver.checkPage(input.get("pageName"))) {
			passed("Launching the Application", "Should open the Application", "Application opened sucessfully!");
		} else {
			failed("Launching the Application", "Should open the Application", "Error in opening the Application");
		}

	}

	/**
	 * Login to Application
	 * 
	 * @param input
	 *            DataRow of input parameters
	 * @param output
	 *            empty DataRow passed to capture any runtime output during
	 *            execution of component
	 */
	public void login(DataRow input, DataRow output) {
		uiDriver.setValue("username", input.get("username"));
		uiDriver.setValue("password", input.get("password"));
		uiDriver.click("loginBtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		if (uiDriver.checkPage(input.get("pageName"))) {
			passed("Login to Application", "Should login the Application", "Application opened sucessfully!");
		} else {
			failed("Login the Application", "Should open the Application",
					"Error in opening the Application");
		}
	}

	public void verifyAssets(DataRow input, DataRow output)
	{
		
		if((uiDriver.checkElementPresent("sector"))&&(uiDriver.checkElementPresent("assetCategory"))
				&&(uiDriver.checkElementPresent("technology"))&&(uiDriver.checkElementPresent("assetName"))){
			
			passed("Dropdown objects should be exist", "Should find the Dropdown objects", "Dropdown objects found successfully");	
		}
		else
		{
			failed("Dropdown objects should be exist", "Should find the Dropdown objects", "Dropdown objects found unsuccessfully");
		}
		
		if((uiDriver.checkElementPresent("amitavaPic"))&&(uiDriver.checkElementPresent("amitPic"))
				&&(uiDriver.checkElementPresent("phaniPic"))){
			
			passed("Image objects should be exist", "Should find the image objects", "Image objects found successfully");	
		}
		else
		{
			failed("Image objects should be exist", "Should find the image objects", "Image objects found unsuccessfully");
		}
		
		
		if((uiDriver.checkElementPresent("boxContainer"))&&(uiDriver.checkElementPresent("boxDivs"))){
			
			passed("Div objects should be exist", "Should find the div objects", "Div objects found successfully");	
		}
		else
		{
			failed("Div objects should be exist", "Should find the Div objects", "Div objects found unsuccessfully");
		}
		
		
		
	}
	
	
	
	
	
	
	
	/**
	 * Overriding toString() method of object class to print FlightBookingDriver
	 * format string
	 */
	public String toString() {
		return "SalesforceDriver()";
	}

}
