package moduledrivers;

import cbfx.basedrivers.BaseWebModuleDriver;
import static cbf.engine.TestResultLogger.*;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.james.mime4j.field.datetime.DateTime;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.python.antlr.PythonParser.continue_stmt_return;

import cbf.engine.TestResult.ResultType;
import cbf.utils.DataRow;
import cbf.utils.SleepUtils;
import cbf.utils.SleepUtils.TimeSlab;
import cbfx.basedrivers.BaseWebModuleDriver;
import cbfx.objectmaps.ObjectMap;

public class NetSuiteDriver extends BaseWebModuleDriver  {
	
	ArrayList<String> list_InvoiceNumbers = new ArrayList<>();
	
	/****************************************
	 * Name: createInvoiceAndAcceptPayment
	 * Description:Method to create Invoice and accept Payment and to navigate CashAdjacentcode
	 * Date:30-Nov-2017 
	 ****************************************/

	public void createInvoiceAndAcceptPayment(DataRow input, DataRow output) throws InterruptedException 
    {
			SleepUtils.sleep(3);
			String Num = input.get("conf");
			uiDriver.setValue("SearchSO",Num);
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("SalesOrder");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("Bill");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.executeJavaScript("scroll(0,400)");
					
			uiDriver.executeJavaScript("scroll(0,400)");
			SleepUtils.sleep(TimeSlab.LOW);
			SleepUtils.sleep(TimeSlab.LOW);
			
			if(input.get("ReduceAmount").equalsIgnoreCase("Y"))	{
				uiDriver.click("reduceqty");	
			SleepUtils.sleep(TimeSlab.LOW);		
			uiDriver.sendKey("backspace");
				SleepUtils.sleep(TimeSlab.LOW);
				 uiDriver.executeJavaScript("document.getElementById('quantity_formattedValue').value = ''");
				uiDriver.setValue("reduceqtyvalue", input.get("PartialTotalAmt"));
				SleepUtils.sleep(TimeSlab.MEDIUM);
				//uiDriver.executeJavaScript("document.getElementById('item_addedit').click();");
				uiDriver.click("OK");
				SleepUtils.sleep(TimeSlab.MEDIUM);
				uiDriver.handleAlert("", "OK");
				SleepUtils.sleep(TimeSlab.MEDIUM);
				uiDriver.handleAlert("", "OK");
			}
			
			if(input.get("ReduceAmountMultiple").equalsIgnoreCase("Y"))	{
				
			
				for(int i=1;i<=4;i++)
				{
				String QuantityLink = uiDriver.getDyanmicData("QuantityLink");
				String QuantLink = QuantityLink.replace("#", Integer.toString(i));
				uiDriver.click_dynamic(QuantLink);
						
			SleepUtils.sleep(TimeSlab.LOW);				
			uiDriver.sendKey("backspace");
				SleepUtils.sleep(TimeSlab.LOW);
				 uiDriver.executeJavaScript("document.getElementById('quantity_formattedValue').value = ''");
				 SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.setValue("reduceqtyvalue", input.get("invoiceamount"));
				SleepUtils.sleep(TimeSlab.MEDIUM);
				uiDriver.executeJavaScript("scroll(0,1000)");
				//uiDriver.executeJavaScript("document.getElementById('item_addedit').click();");
				uiDriver.click("OK");
				uiDriver.handleAlert("", "OK");
				SleepUtils.sleep(TimeSlab.MEDIUM);
				
				//SleepUtils.sleep(TimeSlab.MEDIUM);
				//uiDriver.handleAlert("", "OK");
			}
			}
			
			if(input.get("ChangeCurrencyType").equalsIgnoreCase("Y"))
			{
				if(uiDriver.checkElementPresent("Accounting")){
					uiDriver.executeJavaScript("scroll(0,500)");
					uiDriver.click("Accounting");
				}
				passed("Click On Accounting button",
						"Should click  on Accounting button",
						"Successfully clicked on Accounting button");				
				SleepUtils.sleep(TimeSlab.LOW);							
				uiDriver.handleAlert("", "OK");
				uiDriver.click("exchangeRate");
				SleepUtils.sleep(TimeSlab.MEDIUM);
				uiDriver.executeJavaScript("document.getElementById('exchangerate_formattedValue').value='"+input.get("exchangeRate")+"';");
				SleepUtils.sleep(TimeSlab.MEDIUM);
				passed("Select Exchange Rate",
						"Exchange Rate should be set successfully", 
						"Exchange Rate "+ input.get("exchangeRat") + " is set successfully");
				String exchangeRate = uiDriver.getValue("exchangeRate");
				uiDriver.handleAlert("", "OK");
 		 		SleepUtils.sleep(TimeSlab.LOW);
	                        output.put("exchangeRate", exchangeRate);
	           		}			
				uiDriver.click("saveBill");
				if(uiDriver.checkElementPresent("DuplicateInvoice")){
					uiDriver.click("SaveDuplicateInvoice");
				}
				
				//uiDriver.executeJavaScript("document.getElementById('btn_secondarymultibutton_submitter').click();");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.handleAlert("", "OK");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.handleAlert("", "OK");
				String invoicenum = uiDriver.getValue("invoicenum");
				output.put("invoicenumber", invoicenum);
				}	
			
   
        public void NavigateTopaidfullinvoice(DataRow input, DataRow output) throws InterruptedException 
    {
    	SleepUtils.sleep(TimeSlab.MEDIUM);
    	String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");
		SleepUtils.sleep(5);
		uiDriver.refresh();
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("relatedRecord");
		SleepUtils.sleep(5);
		uiDriver.click("paidinfullinvoice");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		passed("InvoiceNo", "InvoiceNo Should be Clicked Successfully",
				"InvoiceNo is Clicked Successfully");
		String invoicenumber=uiDriver.getValue("Invoicenum");
		output.put("InvoiceNum", invoicenumber);
		String Masterinvoice = invoicenumber.substring(0, invoicenumber.length()-1);
		output.put("MasterInvoice", Masterinvoice);
    }
		 
      
	/****************************************
	 * Name:  VerifyingPartialAndRestPayment
	 * Description:Method to Verifying Partial And RestPayment
	 * Date:30-Nov-2017 
	 ****************************************/
	public void VerifyingPartialAndRestPayment(DataRow input, DataRow output) throws InterruptedException 
    {
          	String invoicenum = uiDriver.getValue("invoicenum");
            SleepUtils.sleep(TimeSlab.LOW);
            uiDriver.executeJavaScript("scroll(0,-500)");
        	 uiDriver.click("AcceptPayment");
             passed("AcceptPayment", "Should be clicked successfully",
                     "AcceptPayment button is clicked successfully");
             SleepUtils.sleep(TimeSlab.MEDIUM);

             if(input.get("UK_Currency").equals("Y")){
            	 uiDriver.click("exchangeRate");
            	 
            	 uiDriver.handleAlert("", "OK");
            	 //uiDriver.setValue("exchangeRate", input.get("exchangeRate"));
            	 //SleepUtils.sleep(TimeSlab.LOW);
            	 uiDriver.executeJavaScript("document.getElementById('exchangerate_formattedValue').value='"+input.get("exchangeRate")+"';");
            	 //SleepUtils.sleep(TimeSlab.LOW);
            	 uiDriver.handleAlert("", "OK");
            	 String exchangeRate = uiDriver.getValue("exchangeRate");
                 output.put("exchangeRate", exchangeRate);
             }
             
	 		SleepUtils.sleep(TimeSlab.YIELD);
            String partialpayment = uiDriver.getDyanmicData("partialpaymentfield");
            SleepUtils.sleep(TimeSlab.YIELD);
            String ReferenceVal1 = partialpayment.replace("#", invoicenum);
            SleepUtils.sleep(TimeSlab.YIELD);
            uiDriver.executeJavaScript("scroll(0,500)");
            uiDriver.click("PaymentAmt");
            uiDriver.executeJavaScript("document.getElementById('payment_formattedValue').value = ''");
            SleepUtils.sleep(2);
            
            uiDriver.setValue("PaymentAmt", input.get("PartialTotalAmt"));
            SleepUtils.sleep(TimeSlab.LOW);
            
           // uiDriver.executeJavaScript("document.getElementById('payment_formattedValue').value = '"+ input.get("PartialTotalAmt") + "'");
            if(uiDriver.checkElementPresent_dynamic(ReferenceVal1)){
           	 
         	   SleepUtils.sleep(10);
         	   uiDriver.click_dynamic(ReferenceVal1);
                uiDriver.click_dynamic(ReferenceVal1);  
           }
            else{
          	   
          	   SleepUtils.sleep(TimeSlab.LOW);
          	   uiDriver.click("FilterNumber");
          	   uiDriver.click("FirstFilteringNumber");
          	   uiDriver.executeJavaScript("scroll(0,800)");
          	   SleepUtils.sleep(TimeSlab.LOW);
          	  if(uiDriver.checkElementPresent_dynamic(ReferenceVal1)){
                
          		uiDriver.click_dynamic(ReferenceVal1);
                 uiDriver.click_dynamic(ReferenceVal1); 
          	    SleepUtils.sleep(TimeSlab.MEDIUM);
          	  }
          	  else{
          		  
          	   SleepUtils.sleep(TimeSlab.LOW);
          	  uiDriver.executeJavaScript("scroll(0,-800)");
            	   uiDriver.click("FilterNumber");
            	   uiDriver.click("SecondFilteringNumber");
            	   uiDriver.executeJavaScript("scroll(0,800)");
            	   SleepUtils.sleep(TimeSlab.LOW);
            	  if(uiDriver.checkElementPresent_dynamic(ReferenceVal1)){
                  
            		uiDriver.click_dynamic(ReferenceVal1);
                   uiDriver.click_dynamic(ReferenceVal1); 
            	    SleepUtils.sleep(TimeSlab.MEDIUM);
            	    
            	  }
            	  else{
            		  
            		 SleepUtils.sleep(TimeSlab.LOW);
            		 uiDriver.executeJavaScript("scroll(0,-800)");
              	   uiDriver.click("FilterNumber");
              	   uiDriver.click("ThirdFilteringNumber");
              	   uiDriver.executeJavaScript("scroll(0,800)");
              	   SleepUtils.sleep(TimeSlab.LOW);
              	  if(uiDriver.checkElementPresent_dynamic(ReferenceVal1)){
                    
              		uiDriver.click_dynamic(ReferenceVal1);
                     uiDriver.click_dynamic(ReferenceVal1); 
              	    SleepUtils.sleep(TimeSlab.MEDIUM);
              	    
              	  }
            	  }
          		  
          	  }
          	   
             } 
          		  
          	  if(input.get("cashAdjCode").equals("Y")){
             
            	 SleepUtils.sleep(TimeSlab.LOW);
            	 uiDriver.executeJavaScript("scroll(0,-200)");
            	 uiDriver.click("CashAdjCode");
                SleepUtils.sleep(2);
                uiDriver.click("CashAdjCode1");
                uiDriver.setValue("CashAdjCode1",input.get("CashAdjCode1"));
                SleepUtils.sleep(2);
                uiDriver.click("dropdown");
                SleepUtils.sleep(2);
                uiDriver.click("List");
                SleepUtils.sleep(2);
                uiDriver.click("searchbox");
                String invoicenumber="Invoice #"+invoicenum;
                uiDriver.setValue("searchbox",invoicenumber);
                uiDriver.click("searchbutton");
                SleepUtils.sleep(2);
                uiDriver.click("searchedinvoicecode");
                SleepUtils.sleep(2);
                uiDriver.click("WHTCode");
                uiDriver.setValue("EditWHTCode",input.get("WHTCode"));
                SleepUtils.sleep(TimeSlab.LOW);
                uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[3].click();");
                SleepUtils.sleep(TimeSlab.MEDIUM);
                uiDriver.setValue("EditWHTRate",input.get("WHTRate"));
                SleepUtils.sleep(2);
                uiDriver.click("Add");
                SleepUtils.sleep(2);
                uiDriver.click("CAshAdjCodeAmount");
                SleepUtils.sleep(3);
                String WHTAmount = uiDriver.getValue("WHTAmount");   
                uiDriver.setValue("CAshAdjCodeAmount",WHTAmount);
                String WHTpercent=uiDriver.getValue("WHTpercent"); 
                SleepUtils.sleep(2);
                uiDriver.executeJavaScript("scroll(0,-800)");
                output.put("WHTAmount", WHTAmount);
   
     }

           uiDriver.executeJavaScript("scroll(0,-1000)");
           uiDriver.click("acctradiobutton");
   	    	SleepUtils.sleep(TimeSlab.YIELD);
   	    	uiDriver.setValue("Account", "11015051 USL Cash Clearing");
   			 SleepUtils.sleep(TimeSlab.YIELD);
   			uiDriver.setValue("ContractorName", "");
  			 SleepUtils.sleep(TimeSlab.LOW);
            uiDriver.click("SaveInvoice");
            SleepUtils.sleep(TimeSlab.YIELD);
       //     uiDriver.executeJavaScript("document.getElementById('btn_multibutton_submitter').click();");
        //    uiDriver.handleAlert("", "Leave");
            passed("SaveInvoice", "Invoice Should be Saved successfully",
                    "Invoice is Saved successfully");
            String PaymentNumber = uiDriver.getValue("PaymentNumber");
            SleepUtils.sleep(TimeSlab.LOW);
            output.put("PaymentNumber", PaymentNumber);
           
        }
	
	
	/****************************************
	 * Name:  NavigatetoTitleallocationParentmultiple
	 * Description:Method to NavigatetoTitleallocationParentmultiple
	 * Date:30-Nov-2017 
	 ****************************************/
	public void NavigatetoTitleallocationParentmultiple(DataRow input, DataRow output) throws InterruptedException 
    {
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Custom");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,1600)");
		uiDriver.click("TitleAllocationParent");
		/*SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);*/
		uiDriver.executeJavaScript("scroll(0,1200)");
		SleepUtils.sleep(TimeSlab.LOW);
		int accRows = uiDriver.webDr.findElements(By.xpath("//table[@id='recmachcustrecord_nbcu_titleallocpa_contract__tab']/tbody/tr")).size();
		SleepUtils.sleep(TimeSlab.LOW);
		for (int r = 0; r < accRows; r++) {
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.executeJavaScript("scroll(0,900)");
			String s1 = uiDriver.getDyanmicData("DynamicTapid");
			String s2 = s1.replace("#", Integer.toString(r));
			if (uiDriver.checkElementPresent_dynamic(s2)) 
				SleepUtils.sleep(TimeSlab.HIGH);
				uiDriver.click_dynamic(s2);
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.executeJavaScript("scroll(0,500)");
			SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.click("AllocationDetail");
				SleepUtils.sleep(TimeSlab.LOW);
	            int accRows1 = uiDriver.webDr.findElements(By.xpath("//table[@id='recmachcustrecord_nbcu_titleallocch_parent__tab']/tbody/tr")).size();
	            for(int i=0;i<accRows1;i++)
	            {
	                String s3= uiDriver.getDyanmicData("ARAmount");
	                String s4=s1.replace("#", Integer.toString(i));
	                if(uiDriver.checkElementPresent_dynamic(s4)){
	                	
	                    String ARAmount=uiDriver.getValue(s4);
	                    passed("Verify AR Amount "+ARAmount+"",
	                           "SuccessFully Verified AR Amount "+ARAmount+"",
	                            "SuccessFully Verified AR Amount "+ARAmount+"");
	           }

	           String s5= uiDriver.getDyanmicData("WHTAmount");
	           String s6=s3.replace("#", Integer.toString(i));
	           if(uiDriver.checkElementPresent_dynamic(s6)){
	              String WHTAmount=uiDriver.getValue(s6);
	              passed("Verify WHT Amount "+WHTAmount+"",
	                     "SuccessFully Verified WHT Amount "+WHTAmount+"",
	                      "SuccessFully Verified WHT Amount "+WHTAmount+"");
	          }

	          String s7= uiDriver.getDyanmicData("VATAmount");
	          String s8=s5.replace("#", Integer.toString(i));
	          if(uiDriver.checkElementPresent_dynamic(s8)){
	            String VATAmount=uiDriver.getValue(s8);
	            passed("Verify VAT Amount "+VATAmount+"",
	                   "SuccessFully Verified WHT Amount "+VATAmount+"",
	                   "SuccessFully Verified WHT Amount "+VATAmount+"");
	          }
	          String s9= uiDriver.getDyanmicData("CACAmount");
	          String s10=s7.replace("#", Integer.toString(i));
	          if(uiDriver.checkElementPresent_dynamic(s10)){
	               String CACAmount=uiDriver.getValue(s10);
	               passed("Verify CAC Amount "+CACAmount+"",
	                      "SuccessFully Verified WHT Amount "+CACAmount+"",
	                      "SuccessFully Verified WHT Amount "+CACAmount+"");
	            }
	       }
	            uiDriver.executeJavaScript("scroll(0,800)");
	    		SleepUtils.sleep(TimeSlab.LOW);
	    		uiDriver.click("Back1");
	    		SleepUtils.sleep(TimeSlab.HIGH);
	    		uiDriver.click("Custom");
	    		SleepUtils.sleep(TimeSlab.LOW);
	    		uiDriver.executeJavaScript("scroll(0,2500)");
	    		uiDriver.click("TitleAllocationParent");
	    		SleepUtils.sleep(TimeSlab.HIGH);
		
		}
		
		
		
    }
	
		
	/****************************************
	 * Name:  NavigateToMultiplePaymentScreen
	 * Description:Method to NavigateToMultiplePaymentScreen
	 * Date:30-Nov-2017 
	 ****************************************/
	public void NavigateToMultiplePaymentScreen(DataRow input, DataRow output) throws InterruptedException 
    {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String InvoiceNum=input.get("InvoiceNum");
    	String PaymentNumber = input.get("PaymentNumber");
    	String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");
		SleepUtils.sleep(5);
		uiDriver.refresh();
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("relatedRecord");
		SleepUtils.sleep(TimeSlab.LOW);
		String InvoiceLink = uiDriver.getDyanmicData("InvoiceLink");
		String InvLink = InvoiceLink.replace("#",InvoiceNum);
		uiDriver.click_dynamic(InvLink);
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("relatedRecord");
		String PaymentLink = uiDriver.getDyanmicData("PaymentLink");
		String PayLink = PaymentLink.replace("#",PaymentNumber);
		uiDriver.click_dynamic(PayLink);
		 
   }	
	
	/****************************************
	 * Name: AllocateCashtoTitleMap
	 * Description:Method to Allocate Cash to TitleMap
	 *  Date:30-Nov-2017 
	 ****************************************/
    public void AllocateCashtoTitleMap(DataRow input, DataRow output) throws InterruptedException 
    { 
    	   SleepUtils.sleep(TimeSlab.YIELD);
           uiDriver.mouseOver("Customization");
           SleepUtils.sleep(TimeSlab.YIELD);
           uiDriver.mouseOver("Scripting");
           SleepUtils.sleep(TimeSlab.YIELD);
           uiDriver.mouseOver("Scripts");
           SleepUtils.sleep(TimeSlab.YIELD); 
           uiDriver.click("Scripts");
           SleepUtils.sleep(TimeSlab.YIELD);
           uiDriver.click("EditBtnAllocateCashtoTitleMap");
           SleepUtils.sleep(TimeSlab.YIELD);
           uiDriver.mouseOver("SaveBtndropdown");
           SleepUtils.sleep(TimeSlab.YIELD);
           uiDriver.click("SaveAndExecute"); 
           uiDriver.handleAlert("", "OK");
           uiDriver.click("refresh");
           SleepUtils.sleep(TimeSlab.MEDIUM);
           uiDriver.click("refresh");
           SleepUtils.sleep(TimeSlab.HIGH);
          
 }	
	
    
    /****************************************
	 * Name: NavigateToPaymentScreen
	 * Description:Method to Navigate To PaymentScreen
	 *  Date:30-Nov-2017 
	 ****************************************/
    public void NavigateToPaymentScreen(DataRow input, DataRow output) throws InterruptedException 
    {
    	SleepUtils.sleep(TimeSlab.MEDIUM);
    	String PaymentNumber = input.get("PaymentNumber");
    	String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");
		SleepUtils.sleep(5);
		uiDriver.refresh();
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("relatedRecord");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("invoiceNo");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("relatedRecord");
		SleepUtils.sleep(TimeSlab.LOW);
		String PaymentLink = uiDriver.getDyanmicData("PaymentLink");
		String PayLink = PaymentLink.replace("#",PaymentNumber);
		if(uiDriver.checkElementPresent(PayLink)) {
			passed("NavigateToPaymentScreen", "Payment Should be displayed Successfully",
					"Payment is displayed Successfully");
			uiDriver.click_dynamic(PayLink);
		} else {
			failed("NavigateToPaymentScreen", "Payment Should be displayed Successfully",
					"Payment is not displayed Successfully");
		}
		 
   }	
	
    /****************************************
	 * Name: NavigateToPaymentScreen
	 * Description:Method to Navigate To PaymentScreen
	 *  Date:30-Nov-2017 
	 ****************************************/
    public void NavigateToRelatedRecordsAndPaymentScreen(DataRow input, DataRow output) throws InterruptedException 
    {
    	SleepUtils.sleep(TimeSlab.MEDIUM);
    	String PaymentNumber = input.get("PaymentNumber");
    	/*String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");
		SleepUtils.sleep(5);
		uiDriver.refresh();
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("relatedRecord");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("invoiceNo");*/
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("relatedRecord");
		String PaymentLink = uiDriver.getDyanmicData("PaymentLink");
		String PayLink = PaymentLink.replace("#",PaymentNumber);
		if(uiDriver.checkElementPresent(PayLink)) {
			passed("NavigateToPaymentScreen", "Payment Should be displayed Successfully",
					"Payment is displayed Successfully");
			uiDriver.click_dynamic(PayLink);
		} else {
			failed("NavigateToPaymentScreen", "Payment Should be displayed Successfully",
					"Payment is not displayed Successfully");
		}
		 
   }	
	
   /* public void NavigateToTitleAlInPay(DataRow input, DataRow output){

		SleepUtils.sleep(TimeSlab.LOW);

		uiDriver.click("//a[@id='customtxt']");

		SleepUtils.sleep(TimeSlab.LOW);

		uiDriver.executeJavaScript("scroll(0,1000)");

		// uiDriver.click("//a[@id='recmachcustrecord_nbcu_titleallocpa_paymenttxt']");

		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//*[@id='recmachcustrecord_nbcu_titleallocpa_paymenttxt']");

		SleepUtils.sleep(TimeSlab.YIELD);
		
		 * String number_TitleAllocationParent = uiDriver
		 * 
		 * .getValue(
		 * "(//table[@id='recmachcustrecord_nbcu_titleallocpa_payment__tab']//td[text()='"
		 * +input.get("Amount").trim()+"']//..//a)[1]");
		 
		for (int q = 0; q <= 50; q++) {
			if (uiDriver
					.checkElementPresent("(//table[@id='recmachcustrecord_nbcu_titleallocpa_payment__tab']//td[text()='"
							+ input.get("Amount").trim() + "']//..//a)[1]")) {

				uiDriver.click("(//table[@id='recmachcustrecord_nbcu_titleallocpa_payment__tab']//td[text()='"

						+ input.get("Amount").trim() + "']//..//a)[1]");
				break;
			} else {
				SleepUtils.sleep(TimeSlab.HIGH);
				uiDriver.refresh();
				SleepUtils.sleep(TimeSlab.HIGH);
				uiDriver.click("//a[@id='customtxt']");

				SleepUtils.sleep(TimeSlab.LOW);

				uiDriver.executeJavaScript("scroll(0,1000)");

				// uiDriver.click("//a[@id='recmachcustrecord_nbcu_titleallocpa_paymenttxt']");

				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.click("//*[@id='recmachcustrecord_nbcu_titleallocpa_paymenttxt']");
			}
		}

		uiDriver.executeJavaScript("scroll(0,500)");

		if (uiDriver.checkElementPresent("//h1[text()='Title Allocation Parent']")) {

			passed("VerifyTitleAllocationJoural", "Title Allocation Parent Should be displayed",

					"Title Allocation Parent is displayed");

		} else {

			failed("VerifyTitleAllocationJoural", "Title Allocation Parent Should be displayed",

					"Title Allocation Parent is not displayed");

		}

		// Navigating to Allocation Transaction Details

		uiDriver.click("//a[@id='custom54txt' or text()='llocation Detail']");

		SleepUtils.sleep(TimeSlab.LOW);

		uiDriver.click("//a[@id='recmachcustbody_nbcu_titleallocationtxt']");

		SleepUtils.sleep(TimeSlab.YIELD);

		for (int z = 0; z < 50; z++) {
			if (uiDriver.checkElementPresent("(//td[text()='" + input.get("JeType") + "']//..//a)[1]")) {
				passed("VerifyTitleAllocationJoural", input.get("JeType") + " Journal Should be present",

						input.get("") + " Journal is present");
				uiDriver.click("(//td[text()='" + input.get("JeType") + "']//..//a)[1]");
				break;

			} else {
				SleepUtils.sleep(TimeSlab.HIGH);
				uiDriver.refresh();
				SleepUtils.sleep(TimeSlab.HIGH);
				uiDriver.click("//a[@id='custom54txt' or text()='llocation Detail']");

				SleepUtils.sleep(TimeSlab.LOW);

				uiDriver.click("//a[@id='recmachcustbody_nbcu_titleallocationtxt']");
			}

		}
	}*/
    public void NavigateToTitleAlInPay(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.LOW);

		uiDriver.click("//a[@id='customtxt']");

		SleepUtils.sleep(TimeSlab.LOW);

		uiDriver.executeJavaScript("scroll(0,1000)");

		//uiDriver.click("//a[@id='recmachcustrecord_nbcu_titleallocpa_paymenttxt']");
		uiDriver.click("//a[@id='recmachcustrecord_nbcu_titleallocpa_contracttxt']");
		
		SleepUtils.sleep(TimeSlab.YIELD);

		String number_TitleAllocationParent = uiDriver

				.getValue("(//table[@id='recmachcustrecord_nbcu_titleallocpa_contract__tab']//td[text()='"
						+ input.get("Amount").trim() + "']//..//a)[1]");

		uiDriver.click("(//table[@id='recmachcustrecord_nbcu_titleallocpa_contract__tab']//td[text()='"

				+ input.get("Amount").trim() + "']//..//a)[1]");

		if (uiDriver.checkElementPresent("//h1[text()='Title Allocation Parent']")) {

			passed("VerifyTitleAllocationJoural", "Title Allocation Parent Should be displayed",

					"Title Allocation Parent is displayed");

		} else {

			failed("VerifyTitleAllocationJoural", "Title Allocation Parent Should be displayed",

					"Title Allocation Parent is not displayed");

		}

		uiDriver.executeJavaScript("scroll(0,500)");

		// Navigating to Allocation Transaction Details
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//a[@id='custom54txt' or text()='llocation Detail']");

		SleepUtils.sleep(TimeSlab.LOW);

		uiDriver.click("//a[@id='recmachcustbody_nbcu_titleallocationtxt']");

		SleepUtils.sleep(TimeSlab.LOW);
		if (uiDriver.checkElementPresent("//td[text()='" + input.get("JeType") + "']")) {

			passed("VerifyTitleAllocationJoural", input.get("JeType") + " Journal Should be present",

					input.get("") + " Journal is present");

		} else {
			failed("VerifyTitleAllocationJoural", input.get("JeType") + " Journal Should be present",

					input.get("JeType") + " Journal is not present");

		}

		uiDriver.click("(//td[text()='" + input.get("JeType") + "']//..//a)[1]");

	}
    /****************************************
	 * Name: NavigateToInvoiceScreen
	 * Description:Method to Navigate To Invoice Screen
	 *  Date:30-Nov-2017 
	 ****************************************/
    public void NavigateToInvoiceScreen(DataRow input, DataRow output) throws InterruptedException 
    {
    	
    	/*SleepUtils.sleep(100);    	
    	uiDriver.refresh();
    	SleepUtils.sleep(100);
    	uiDriver.refresh();
    	SleepUtils.sleep(100);
    	uiDriver.refresh();
    	SleepUtils.sleep(TimeSlab.MEDIUM);
    	SleepUtils.sleep(TimeSlab.HIGH);
    	SleepUtils.sleep(TimeSlab.HIGH);
    	SleepUtils.sleep(TimeSlab.HIGH);
    	SleepUtils.sleep(TimeSlab.HIGH);
    	SleepUtils.sleep(TimeSlab.MEDIUM);
    	/*uiDriver.click("SalesOrder");
		SleepUtils.sleep(5);
		uiDriver.refresh();
    	 
		String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");*/

		if(input.get("multipleinvoice").equals("Y"))
		{
			for(int i=0; i<60; i++) {
	    		uiDriver.executeJavaScript("scroll(0,500)");
	    		if(uiDriver.checkElementPresent("relatedRecord")) {			
	    			uiDriver.click("relatedRecord"); //*[@id="rlrcdstab_pane_hd"]
	    		} else {
	    			uiDriver.click("//*[@id='rlrcdstab_pane_hd']");
	    		}
	    		
				if(uiDriver.checkElementPresent("//td[text()='Invoice']//following-sibling::td[1]")) {
					if(uiDriver.webDr.findElements(By.xpath("//td[text()='Invoice']//following-sibling::td[1]")).size() > 1) {						
						break;
					} else {
						SleepUtils.sleep(10);
						uiDriver.refresh();				
					}
				} else {
					SleepUtils.sleep(10);
					uiDriver.refresh();				
				}
			}
			
			SleepUtils.sleep(5);
			List<WebElement> list_Invoice = uiDriver.webDr.findElements(By.xpath("//td[text()='Invoice']//following-sibling::td[1]"));
			for(int i=0; i<list_Invoice.size(); i++) {
				String value = list_Invoice.get(i).getText();
				list_InvoiceNumbers.add(value);
			}
			
			String InvoiceLink = uiDriver.getDyanmicData("InvoiceLink");
			String InvoiceNum=input.get("InvoiceNum");
			String InvLink = InvoiceLink.replace("#",InvoiceNum);
			uiDriver.click_dynamic(InvLink);
		}
		else if(input.get("multipleopeninvoice").equals("Y"))
		{
			for(int i=0; i<60; i++) {
	    		uiDriver.executeJavaScript("scroll(0,500)");
	    		if(uiDriver.checkElementPresent("relatedRecord")) {			
	    			uiDriver.click("relatedRecord"); //*[@id="rlrcdstab_pane_hd"]
	    		} else {
	    			uiDriver.click("//*[@id='rlrcdstab_pane_hd']");
	    		}
	    		
				if(uiDriver.checkElementPresent("//td[text()='Invoice']//following-sibling::td[1]")) {
					if(uiDriver.webDr.findElements(By.xpath("//td[text()='Invoice']//following-sibling::td[1]")).size() > 1) {						
						break;
					} else {
						SleepUtils.sleep(10);
						uiDriver.refresh();				
					}
				} else {
					SleepUtils.sleep(10);
					uiDriver.refresh();				
				}
			}
			
			SleepUtils.sleep(5);
			List<WebElement> list_Invoice = uiDriver.webDr.findElements(By.xpath("//td[text()='Invoice']//following-sibling::td[1]"));
			for(int i=0; i<list_Invoice.size(); i++) {
				String value = list_Invoice.get(i).getText();
				list_InvoiceNumbers.add(value);
			}
			
			List<WebElement> fil = uiDriver.webDr.findElements(By.xpath("//*[@id='links_splits']//tbody/tr/td[text()='Open']"));
            int filter = fil.size();
            for(int h=1;h<=filter;h++)
            {
            	if(h>1) {
            		if(uiDriver.checkElementPresent("relatedRecord")) {			
            			uiDriver.click("relatedRecord"); //*[@id="rlrcdstab_pane_hd"]
            		} else {
            			uiDriver.click("//*[@id='rlrcdstab_pane_hd']");
            		}
            		SleepUtils.sleep(5);
            	}
            String InvoiceLink = uiDriver.getDyanmicData("InvoiceLinks");		
			String InvLink = InvoiceLink.replace("#",Integer.toString(h));
			uiDriver.click_dynamic(InvLink);
			SleepUtils.sleep(5);
			passed("InvoiceNo", "InvoiceNo Should be Clicked Successfully",
					"InvoiceNo is Clicked Successfully");
			
			uiDriver.executeJavaScript("scroll(0,400)");
			String invoiceType=uiDriver.getValue_Text("invoiceType");
			if (invoiceType.contains(input.get("InvoiceType"))) 
			{
				passed("Verify the InvoiceType ",
						"InvoiceType should be displayed  as "+input.get("InvoiceType"),
						"InvoiceType is displayed as "+invoiceType);
			}
			else 
			{
				failed("Verify the InvoiceType ",
						"InvoiceType should be displayed  as "+input.get("InvoiceType"),
						"InvoiceType is displayed as "+invoiceType);
			}	
			uiDriver.executeJavaScript("scroll(0,-400)");
			if(uiDriver.checkElementPresent("back")){
				uiDriver.click("back");
			} else {
				uiDriver.back();
			}
			SleepUtils.sleep(TimeSlab.HIGH);
			if(h==filter)
			{				
            	if(uiDriver.checkElementPresent("relatedRecord")) {			
            		uiDriver.click("relatedRecord"); //*[@id="rlrcdstab_pane_hd"]
            	} else {
            		uiDriver.click("//*[@id='rlrcdstab_pane_hd']");
            	}
            	SleepUtils.sleep(5);
//			uiDriver.click("back");
//			SleepUtils.sleep(TimeSlab.HIGH);
//			uiDriver.click("relatedRecord");
			uiDriver.click_dynamic(InvLink);// Added for scenario17
			SleepUtils.sleep(TimeSlab.HIGH);
			}
			uiDriver.executeJavaScript("scroll(0,400)");
            }
		}
		else 
		{
			for(int i=0; i<60; i++) {
	    		uiDriver.executeJavaScript("scroll(0,500)");
	    		if(uiDriver.checkElementPresent("relatedRecord")) {			
	    			uiDriver.click("relatedRecord"); //*[@id="rlrcdstab_pane_hd"]
	    		} else {
	    			uiDriver.click("//*[@id='rlrcdstab_pane_hd']");
	    		}
	    		
				if(uiDriver.checkElementPresent("//td[text()='Invoice']//following-sibling::td[1]")) {
					break;				
				} else {
					SleepUtils.sleep(10);
					uiDriver.refresh();				
				}
			}
			
			SleepUtils.sleep(5);
			List<WebElement> list_Invoice = uiDriver.webDr.findElements(By.xpath("//td[text()='Invoice']//following-sibling::td[1]"));
			for(int i=0; i<list_Invoice.size(); i++) {
				String value = list_Invoice.get(i).getText();
				list_InvoiceNumbers.add(value);
			}
			
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("invoiceNo");
		passed("InvoiceNo", "InvoiceNo Should be Clicked Successfully",
				"InvoiceNo is Clicked Successfully");
		String invoicenumber=uiDriver.getValue("Invoicenum");
		output.put("InvoiceNum", invoicenumber);
		String Masterinvoice = invoicenumber.substring(0, invoicenumber.length()-1);
		output.put("MasterInvoice", Masterinvoice);
    }
		 }	
    /****************************************
	 * Name:Naviagte to Navigatetolaterinvoice
	 * Description:Naviagte to Navigatetolaterinvoice
	 *  Date:31-Oct-2018 
	 ****************************************/
    
    public void Navigatetolaterinvoicesameamount(DataRow input, DataRow output) throws InterruptedException 
    {
    	uiDriver.click("//span[text()='R']");
    	List<WebElement> lst = uiDriver.webDr.findElements(By.xpath("//td[text()='222,095.00']/..//td[3]"));
    	String inv1 = lst.get(0).getText();
    	String inv2 = lst.get(1).getText();
    	int cmp=inv1.compareTo(inv2);
    	if(cmp>0)
    	{
    		uiDriver.click("//td[text()='"+inv1+"']/..//td[1]/a");
    	}
    	else
    	{
    		uiDriver.click("//td[text()='"+inv2+"']/..//td[1]/a");
    	}
    	
    }
    
    
    public void Navigatetoinvoicesameamountwithchoice(DataRow input, DataRow output) throws InterruptedException 
    {
    	uiDriver.click("//span[text()='R']");
    	String amount=input.get("amount");
    	List<WebElement> lst = uiDriver.webDr.findElements(By.xpath("//td[text()='"+amount+"']/..//td[3]"));
    	String inv1 = lst.get(0).getText();
    	String inv2 = lst.get(1).getText();
    	int cmp=inv1.compareTo(inv2);
    	String greater=input.get("great");
    	if(cmp>0 && greater.equalsIgnoreCase("yes"))
    	{
    		uiDriver.click("//td[text()='"+inv1+"']/..//td[1]/a");
    	}
    	else
    	{
    		uiDriver.click("//td[text()='"+inv2+"']/..//td[1]/a");
    	}
    	
    }
    
    /****************************************
	 * Name:Naviagte to customsubtab
	 * Description:Naviagte to customsubtab
	 *  Date:31-Oct-2018 
	 ****************************************/
    public void Navigatetocustomsubtab(DataRow input, DataRow output) throws InterruptedException 
    {
    	
    	SleepUtils.sleep(TimeSlab.HIGH);
    	uiDriver.click("RelatedRecord");
    	SleepUtils.sleep(TimeSlab.LOW);
    	uiDriver.executeJavaScript("scroll(0,500)");
    	uiDriver.click("Billamount");
    	SleepUtils.sleep(TimeSlab.HIGH);
    	uiDriver.executeJavaScript("scroll(0,500)");
    	uiDriver.click("RelatedRecord");
    	SleepUtils.sleep(TimeSlab.HIGH);
    	SleepUtils.sleep(TimeSlab.LOW);
    	uiDriver.refresh();
    	SleepUtils.sleep(TimeSlab.LOW);
    	uiDriver.refresh();
    	SleepUtils.sleep(TimeSlab.HIGH);
    	uiDriver.click("RelatedRecord");
    	SleepUtils.sleep(TimeSlab.HIGH);
    	uiDriver.click("Dateclick");
    	SleepUtils.sleep(TimeSlab.HIGH);
    	Actions action = new Actions(uiDriver.webDr);
        WebElement ele = uiDriver.webDr.findElement(By.xpath("//*[@id='spn_cRR_d1']/a"));
        action.moveToElement(ele).perform();
    	//uiDriver.click("//*[@id='spn_cRR_d1']/a");
    	SleepUtils.sleep(TimeSlab.LOW);
    	uiDriver.click("//span[text()='NBCUniversal Media, LLC 10K QA  -  NBCU: Manager 1']");
    	SleepUtils.sleep(TimeSlab.HIGH);
    	SleepUtils.sleep(TimeSlab.HIGH);
    	SleepUtils.sleep(TimeSlab.HIGH);
    	SleepUtils.sleep(TimeSlab.HIGH);
    	String Num = input.get("conf");
        uiDriver.setValue("SearchSO", Num);
        SleepUtils.sleep(TimeSlab.LOW);
        SleepUtils.sleep(TimeSlab.HIGH);
    	SleepUtils.sleep(TimeSlab.HIGH);
    	SleepUtils.sleep(TimeSlab.HIGH);
        uiDriver.click("SalesOrder");
         
      SleepUtils.sleep(TimeSlab.HIGH);
     SleepUtils.sleep(TimeSlab.HIGH);
     uiDriver.click("RelatedRecord");
     SleepUtils.sleep(TimeSlab.LOW);
     uiDriver.executeJavaScript("scroll(0,600)");
     uiDriver.click("Billamount");
     SleepUtils.sleep(TimeSlab.LOW);
     uiDriver.executeJavaScript("scroll(0,600)");
     uiDriver.click("RelatedRecord");
     SleepUtils.sleep(TimeSlab.LOW);
     uiDriver.click("Dateclick");
     SleepUtils.sleep(TimeSlab.HIGH);
    	
    	uiDriver.click("Cbtbutton");
    	SleepUtils.sleep(TimeSlab.LOW);
    	uiDriver.click("Nextbutton");
    	SleepUtils.sleep(TimeSlab.LOW);
    	uiDriver.click("Nextbutton");
    	SleepUtils.sleep(TimeSlab.LOW);
    	uiDriver.click("Territory");
    	SleepUtils.sleep(TimeSlab.LOW);
    	uiDriver.click("Greece");
    	SleepUtils.sleep(TimeSlab.LOW);
    	uiDriver.click("Right");
    	SleepUtils.sleep(TimeSlab.LOW);
    	uiDriver.click("FTV");
    	SleepUtils.sleep(TimeSlab.LOW);
    	
    	SleepUtils.sleep(TimeSlab.LOW);
    	String totalValue = input.get("totalValue");
    	int totalcolumn = Integer.parseInt(totalValue);
    	for(int i=1;i<=totalcolumn;i++)
    	{
    		
    		uiDriver.click("Title");
    		uiDriver.setValue("Title",input.get("title"+i));
    		SleepUtils.sleep(TimeSlab.LOW);
    		uiDriver.click("ApplyFilters");
    		SleepUtils.sleep(TimeSlab.LOW);
    		if(i>=8)
    		{
    		uiDriver.executeJavaScript("scroll(0,-2500)");
    		}
    		String displayedamount=uiDriver.getValue_Text("Getamountvalue");
    		SleepUtils.sleep(TimeSlab.LOW);
    		uiDriver.click("Textamountvalue");
    		SleepUtils.sleep(TimeSlab.LOW);
    		uiDriver.setValue("Editamountvalue",displayedamount);
    		SleepUtils.sleep(TimeSlab.LOW);
    		uiDriver.click("Okbutton");
    		
    		if(i>=8)
    		{
    			uiDriver.executeJavaScript("scroll(0,-2500)");
    		}
    	}
    	 uiDriver.click("savebutton");
    	 SleepUtils.sleep(TimeSlab.HIGH);
     	SleepUtils.sleep(TimeSlab.HIGH);
     	SleepUtils.sleep(TimeSlab.HIGH);
    }

   
    /****************************************
	 * Name: VerifyCreditMemo
	 * Description:Method to verify credit memo
	 *  Date:30-Nov-2017 
	 ****************************************/
    public void VerifyCreditMemo(DataRow input, DataRow output) throws InterruptedException 
    {
    	
    	String reviseamount=input.get("reviseamount");
    	String payment1=input.get("payment1");
    	String payment2=input.get("payment2");
    	 double reviseamountd = Double.parseDouble(reviseamount);
    	double pay1=Double.parseDouble(payment1);
    	double pay2=Double.parseDouble(payment2);
    	double Payments = pay1+pay2;
    	 double creditamount = Payments-reviseamountd;
    	 String expectedcreditamount = Double.toString(creditamount);
    	String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");
		SleepUtils.sleep(5);
		uiDriver.refresh();
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("relatedRecord");
		SleepUtils.sleep(5);
		uiDriver.click("CreditMemo");
		String actualcreditamount=uiDriver.getValue("CreditMemoamount");
		if(expectedcreditamount.equalsIgnoreCase(actualcreditamount))
		{
		passed("Verifying the credit amount",
				"Credit memo amount  displayed as '" + actualcreditamount+ "' Successfully",
				"Credit memo amount "	+ actualcreditamount + " is displayed Successfully");
    }
    }		
		 
	
		
    /****************************************
	 * Name: Revise Sales order
	 * Description:Method to Revise Sales Order
	 *  Date:30-Nov-2017 
	 ****************************************/
    public void ReviseSalesOrder(DataRow input, DataRow output) throws InterruptedException 
    {
    	String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");
		SleepUtils.sleep(5);
		uiDriver.click("ReviseOrder");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("EditforRevise");
		SleepUtils.sleep(TimeSlab.HIGH);
		for(int i=1;i<=4;i++)
		{
			String updateline = uiDriver.getDyanmicData("updateLineItem");
			String updateLineItem = updateline.replace("#", Integer.toString(i));
			uiDriver.click_dynamic(updateLineItem);
			uiDriver.click("action");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("updateSOLine");			
			
			
		String QuantityLink = uiDriver.getDyanmicData("changeQuantity");
		String QuantLink = QuantityLink.replace("#", Integer.toString(i));
		uiDriver.click_dynamic(QuantLink);
				
	SleepUtils.sleep(TimeSlab.LOW);		
	uiDriver.sendKey("backspace");
		SleepUtils.sleep(TimeSlab.LOW);
		 uiDriver.executeJavaScript("document.getElementById('quantity_formattedValue').value = ''");

		 SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("Updateqty", input.get("invoiceamount"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,1000)");
		
		
		//uiDriver.executeJavaScript("document.getElementById('item_addedit').click();");
		uiDriver.click("OKbutton");		
		uiDriver.handleAlert("", "OK");			
		SleepUtils.sleep(TimeSlab.MEDIUM);
		
		//SleepUtils.sleep(TimeSlab.MEDIUM);
		//uiDriver.handleAlert("", "OK");
	}
	
	//else{}
	uiDriver.click("SaveRevise");
	String RevisedAmount=uiDriver.getValue("ReviseAmount");
	SleepUtils.sleep(TimeSlab.MEDIUM);
	uiDriver.click("CommitRevision");
	SleepUtils.sleep(TimeSlab.MEDIUM);
	uiDriver.setFrame("frame");
	//uiDriver.switchToWindow("Estimate - NetSuite (NBCUniversal Media, LLC - QA)");
	uiDriver.click("OK");
	uiDriver.handleAlert("", "OK");
	passed("Revise Order", "Revise order is successful",
				"Revise order is successful");
	output.put("RevisedAmount", RevisedAmount);
    
		 }	
	
       
    
    /****************************************
   	 * Name: NavigateToTitleAllocationParent
   	 * Description:Method to Navigate To TitleAllocationParent
   	 *  Date:30-Nov-2017 
   	 ****************************************/
	public void NavigateToTitleAllocationParent(DataRow input, DataRow output) throws InterruptedException {
		
		SleepUtils.sleep(5);
		uiDriver.click("Custom");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,1600)");
		uiDriver.click("TitleAllocationParent");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("scroll(0,600)");		       	
			uiDriver.click("TAPId");
            passed("Should click on TAPId",
                   "Should click on TAPId",
                    "Should click on TAPId");
   
		   	   		
		if (input.get("FullPayment").equals("Y")) {
		
			if(input.get("WHT").equals("Y")){
				
				String WHTAmount = input.get("WHTAmt");
		   	    double WHTAmt = Double.parseDouble(WHTAmount);	
		   	    String CashlessTax = input.get("CashlessTax");
				double FullCashlessTaxVal = Double.parseDouble(CashlessTax);
		    	double FullCashlessTaxWithWHT = FullCashlessTaxVal - WHTAmt;
		    	String FullCashlessTaxWithWHTCode = Double.toString(FullCashlessTaxWithWHT) ;
		    	String CashlessTaxAmt = uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE");
		    	String TotalTax = input.get("TotalTax");
				String TotalAmount = input.get("TotalAmount");
	          	String VAT = input.get("VAT");
				// fetching the value from title allocation parent page
				String TotalTaxAmt=uiDriver.getValue("TaxTotal");
				String TotalAmt = uiDriver.getValue("TotalAmount");
				String VATRate=uiDriver.getValue("VAT");
				String VATArr[] = VATRate.split("\\.");
				String VATActualRate = VATArr[0];
				
		    	
		    	if (CashlessTaxAmt.contains(FullCashlessTaxWithWHTCode)) {
					passed("Verifying the CashlessTax",
							"CashlessTax should be displayed as '" + CashlessTax + "' Successfully",
							"CashlessTax " + CashlessTaxAmt + " is displayed Successfully");
				} else {
					failed("Verifying the CashlessTax",
							"CashlessTaxAmt should be displayed as '" + CashlessTax + "' Successfully",
							"CashlessTax " + CashlessTaxAmt + " is not displayed Successfully");
				}
		    	
				if (input.get("TotalTax").equalsIgnoreCase(TotalTaxAmt)||input.get("TotalTax").contains(TotalTaxAmt)) {
					passed("Verifying the TotalTax", "TotalTax should be displayed as '" + TotalTax + "' Successfully",
							"TotalTax " + TotalTaxAmt + " is displayed Successfully");
				} else {
					failed("Verifying the TotalTax", "TotalTax should be displayed as '" + TotalTax + "' Successfully",
							"TotalTax " + TotalTaxAmt + " is not displayed Successfully");
				}
				if (input.get("TotalAmount").contains(TotalAmt)||input.get("TotalAmount").equalsIgnoreCase((TotalAmt))) {
					passed("Verifying the TotalAmount",
							"TotalAmount should be displayed as '" + TotalAmount + "' Successfully",
							"TotalAmount " + TotalAmt + " is displayed Successfully");
				} else {
					failed("Verifying the TotalAmount",
							"TotalAmount should be displayed as '" + TotalAmount + "' Successfully",
							"TotalAmount " + TotalAmt + " is not displayed Successfully");
				}
				if (input.get("VAT").contains(VATRate) || (input.get("VAT").contains(VATActualRate)) || input.get("VAT").equalsIgnoreCase(VATRate)) {
					passed("Verifying the VAT", "VAT should be displayed as '" + VAT + "' Successfully",
							"VAT " + VATRate + " is displayed Successfully");
				} else {
					failed("Verifying the VAT", "VAT should be displayed as '" + VAT + "' Successfully",
							"VAT " + VATRate + " is not displayed Successfully");
				} 	
				
			}
		
			else{
			String CashlessTax = input.get("CashlessTax");
			if(CashlessTax.contains(","))
			{
				CashlessTax=CashlessTax.replace(",", "");
			}
			double FullCashlessTaxVal = Double.parseDouble(CashlessTax);
	    	String TotalTax = input.get("TotalTax");
			String TotalAmount = input.get("TotalAmount");
	    	if(TotalAmount.contains(","))
			{
				TotalAmount=TotalAmount.replace(",", "");
			}
            double TotalAmount1=Double.parseDouble(TotalAmount);
			String VAT = input.get("VAT");
			// fetching the value from title allocation parent page
			
			String CashlessTaxAmt = uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE");
			if(CashlessTaxAmt.contains(","))
			{
				CashlessTaxAmt=CashlessTaxAmt.replace(",", "");
			}
			String TotalTaxAmt=uiDriver.getValue("TaxTotal");
			String TotalAmt = uiDriver.getValue("TotalAmount");
			if(TotalAmt.contains(","))
			{
				TotalAmt=TotalAmt.replace(",", "");
			}
			String VATRate=uiDriver.getValue("VAT");
			String VATArr[] = VATRate.split("\\.");
			String VATActualRate = VATArr[0];
			
			String ExpectedWHTRate = uiDriver.getValue("ExpectedWHTRate");
	 		String ExpectedWHTAmount = uiDriver.getValue("ExpectedWHTAmount");
	 		
	 		String InvoiceExchangeRate = uiDriver.getValue("InvoiceExchangeRate");			
		    double actualInvoiceExchangeRate = Double.parseDouble(InvoiceExchangeRate);
			String paymentExchangeRate = uiDriver.getValue("paymentExchangeRate");	
			double actualpaymentExchangeRate = Double.parseDouble(paymentExchangeRate);
			String gainLossAmount = uiDriver.getValue("gainLossAmount");		
			double actualgainLossAmount1=(actualInvoiceExchangeRate-actualpaymentExchangeRate)*TotalAmount1;
			String actualgainLossAmount2 = Double.toString(actualgainLossAmount1);
			

		if(input.get("GainLoss").equals("Y")) {
		   if (input.get("PaymentRate").contains(paymentExchangeRate)) {
		        passed("Verifying the  PartialCashlessTax",
				"PartialCashlessTax should be displayed as '" + paymentExchangeRate+ "' Successfully",
				"PartialCashlessTax "	+ paymentExchangeRate + " is displayed Successfully");
	          } else {
		        failed("Verifying the  PartialCashlessTax","PartialCashlessTax should be displayed as '" + paymentExchangeRate+ "' Successfully",
				"PartialCashlessTax "+ paymentExchangeRate	+ " is not displayed Successfully");
	}
		
		
		if (input.get("InvoiceRate").contains(InvoiceExchangeRate)) {
		passed("Verifying the  PartialCashlessTax",
				"PartialCashlessTax should be displayed as '" + InvoiceExchangeRate+ "' Successfully",
				"PartialCashlessTax "	+ InvoiceExchangeRate + " is displayed Successfully");
		} else {
				failed("Verifying the  PartialCashlessTax","PartialCashlessTax should be displayed as '" + InvoiceExchangeRate+ "' Successfully",
				"PartialCashlessTax "+ InvoiceExchangeRate	+ " is not displayed Successfully");
		}
			 		 			 		
		if (gainLossAmount.contains(actualgainLossAmount2)) {
		passed("Verifying the  PartialCashlessTax",
				"PartialCashlessTax should be displayed as '" + gainLossAmount+ "' Successfully",
				"PartialCashlessTax "	+ gainLossAmount + " is displayed Successfully");
		} else {
		failed("Verifying the  PartialCashlessTax","PartialCashlessTax should be displayed as '" + gainLossAmount+ "' Successfully",
				"PartialCashlessTax "+ gainLossAmount	+ " is not displayed Successfully");
		}
					
	}

			if (input.get("CashlessTax").contains(CashlessTaxAmt) || CashlessTax.contains(CashlessTaxAmt)) {
				passed("Verifying the CashlessTax",
						"CashlessTax should be displayed as '" + CashlessTax + "' Successfully",
						"CashlessTax " + CashlessTaxAmt + " is displayed Successfully");
			} else {
				failed("Verifying the CashlessTax",
						"CashlessTaxAmt should be displayed as '" + CashlessTax + "' Successfully",
						"CashlessTax " + CashlessTaxAmt + " is not displayed Successfully");
			}
			if (input.get("TotalTax").equalsIgnoreCase(TotalTaxAmt)||input.get("TotalTax").contains(TotalTaxAmt) || TotalAmt.contains(TotalTaxAmt)) {
				passed("Verifying the TotalTax", "TotalTax should be displayed as '" + TotalTax + "' Successfully",
						"TotalTax " + TotalTaxAmt + " is displayed Successfully");
			} else {
				failed("Verifying the TotalTax", "TotalTax should be displayed as '" + TotalTax + "' Successfully",
						"TotalTax " + TotalTaxAmt + " is not displayed Successfully");
			}
			if (input.get("TotalAmount").contains(TotalAmt)||input.get("TotalAmount").equalsIgnoreCase((TotalAmt))) {
				passed("Verifying the TotalAmount",
						"TotalAmount should be displayed as '" + TotalAmount + "' Successfully",
						"TotalAmount " + TotalAmt + " is displayed Successfully");
			} else {
				failed("Verifying the TotalAmount",
						"TotalAmount should be displayed as '" + TotalAmount + "' Successfully",
						"TotalAmount " + TotalAmt + " is not displayed Successfully");
			}
			if (input.get("VAT").contains(VATRate) || (input.get("VAT").contains(VATActualRate)) || input.get("VAT").equalsIgnoreCase(VATRate)) {
				passed("Verifying the VAT", "VAT should be displayed as '" + VAT + "' Successfully",
						"VAT " + VATRate + " is displayed Successfully");
			} else {
				failed("Verifying the VAT", "VAT should be displayed as '" + VAT + "' Successfully",
						"VAT " + VATRate + " is not displayed Successfully");
			}
		}
		}		
			
		if (input.get("PartialPayment").equals("Y")) {
			
			String PartialCashlessTax = input.get("PartialCashlessTax");
			String PartialTaxAmt = input.get("PartialTaxAmt");
			String PartialTotalAmt = input.get("PartialTotalAmt");
			double actualPartialTotalAmt = Double.parseDouble(PartialTotalAmt);	
			String VAT = input.get("VAT");
			// fetching the value from title allocation parent page
			String CashlessTaxAmt = uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE").substring(0,uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE").length() - 1);
			if(CashlessTaxAmt.contains(","))
			{
				CashlessTaxAmt=CashlessTaxAmt.replace(",", "");
			}
			String PartialTaxAmount = uiDriver.getValue("TaxTotal").substring(0,uiDriver.getValue("TaxTotal").length() - 1);
			if(PartialTaxAmount.contains(","))
			{
				PartialTaxAmount=PartialTaxAmount.replace(",", "");
			}
			String PartialTaxTotalAmt = uiDriver.getValue("PartialTotalAmount").substring(0,uiDriver.getValue("TaxTotal").length() - 1);
			if(PartialTaxTotalAmt.contains(","))
			{
				PartialTaxTotalAmt=PartialTaxTotalAmt.replace(",", "");
			}
			String VATArr[] = uiDriver.getValue("VAT").split("\\.");
			String VATRate = VATArr[0];
			String InvoiceExchangeRate = uiDriver.getValue("InvoiceExchangeRate");
	 		double actualInvoiceExchangeRate = Double.parseDouble(InvoiceExchangeRate);
	 		String paymentExchangeRate = uiDriver.getValue("paymentExchangeRate");
	 		double actualpaymentExchangeRate = Double.parseDouble(paymentExchangeRate);
	 		String gainLossAmount = uiDriver.getValue("gainLossAmount");
	 		double actualgainLossAmount1=(actualInvoiceExchangeRate-actualpaymentExchangeRate)*actualPartialTotalAmt;
	 		String actualgainLossAmount2 = Double.toString(actualgainLossAmount1);
	 		
	 		if(input.get("PartialGainLoss").equals("Y")){
	 		if (input.get("PaymentRate").contains(paymentExchangeRate)) {
				passed("Verifying the  PartialCashlessTax",
						"PartialCashlessTax should be displayed as '" + paymentExchangeRate+ "' Successfully",
						"PartialCashlessTax "	+ paymentExchangeRate + " is displayed Successfully");
			} else {
				failed("Verifying the  PartialCashlessTax","PartialCashlessTax should be displayed as '" + paymentExchangeRate+ "' Successfully",
						"PartialCashlessTax "+ paymentExchangeRate	+ " is not displayed Successfully");
			}
	 		
	 		
	 		if (input.get("InvoiceRate").contains(InvoiceExchangeRate)) {
				passed("Verifying the  PartialCashlessTax",
						"PartialCashlessTax should be displayed as '" + InvoiceExchangeRate+ "' Successfully",
						"PartialCashlessTax "	+ InvoiceExchangeRate + " is displayed Successfully");
			} else {
				failed("Verifying the  PartialCashlessTax","PartialCashlessTax should be displayed as '" + InvoiceExchangeRate+ "' Successfully",
						"PartialCashlessTax "+ InvoiceExchangeRate	+ " is not displayed Successfully");
			}
	 			 		 			 		
	 		if (gainLossAmount.contains(actualgainLossAmount2)) {
				passed("Verifying the  PartialCashlessTax",
						"PartialCashlessTax should be displayed as '" + gainLossAmount+ "' Successfully",
						"PartialCashlessTax "	+ gainLossAmount + " is displayed Successfully");
			} else {
				failed("Verifying the  PartialCashlessTax","PartialCashlessTax should be displayed as '" + gainLossAmount+ "' Successfully",
						"PartialCashlessTax "+ gainLossAmount	+ " is not displayed Successfully");
			}
	 }		

			// put it in array using split
			if (input.get("PartialCashlessTax").contains(CashlessTaxAmt)||CashlessTaxAmt.contains(input.get("PartialCashlessTax"))) {
				passed("Verifying the PartialCashlessTax",
						"PartialCashlessTax should be displayed as '" + PartialCashlessTax + "' Successfully",
						"PartialCashlessTax " + CashlessTaxAmt + " is displayed Successfully");
			} else {
				failed("Verifying the PartialCashlessTax",
						"PartialCashlessTax should be displayed as '" + PartialCashlessTax + "' Successfully",
						"PartialCashlessTax " + CashlessTaxAmt + " is not displayed Successfully");
			}
			if (input.get("PartialTaxAmt").contains(PartialTaxAmount)||PartialTaxAmount.contains(input.get("PartialTaxAmt"))) {
				passed("Verifying the PartialTaxAmt",
						"PartialTaxAmt should be displayed as '" + PartialTaxAmt + "' Successfully",
						"PartialTaxAmt " + PartialTaxAmount + " is displayed Successfully");
			} else {
				failed("Verifying the PartialTaxAmt",
						"TotalTax should be displayed as '" + PartialTaxAmt + "' Successfully",
						"PartialTaxAmt " + PartialTaxAmount + " is not displayed Successfully");
			}
			if (input.get("PartialTotalAmt").contains(PartialTaxTotalAmt)||PartialTaxTotalAmt.contains(input.get("PartialTotalAmt"))) {
				passed("Verifying the PartialTotalAmt",
						"PartialTotalAmt should be displayed as '" + PartialTaxTotalAmt + "' Successfully",
						"PartialTotalAmt " + PartialTaxTotalAmt + " is displayed Successfully");
			} else {
				failed("Verifying the PartialTotalAmt",
						"PartialTotalAmt should be displayed as '" + PartialTaxTotalAmt + "' Successfully",
						"PartialTotalAmt " + PartialTaxTotalAmt + " is not displayed Successfully");
			}
			if (input.get("VAT").contains(VATRate)) {
				passed("Verifying the VAT", "VAT should be displayed as '" + VATRate + "' Successfully",
						"VAT " + VATRate + " is displayed Successfully");
			} else {
				failed("Verifying the VAT", "VAT should be displayed as '" + VATRate + "' Successfully",
						"VAT " + VATRate + " is not displayed Successfully");
			}
		}
		if (input.get("EditPayment").equals("Y")) {
			String PayPartialCashlessTax = input.get("PayPartialCashlessTax");
			String payPartialTaxAmt = input.get("payPartialTaxAmt");
			String payPartialTotalAmt = input.get("payPartialTotalAmt");
			
			// fetching the value from title allocation parent page
			String CashlessTaxAmt = uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE").substring(0,uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE").length()-1);
			String PartialTaxAmount = uiDriver.getValue("TaxTotal");
			String PartialTaxTotalAmt = uiDriver.getValue("PartialTotalAmount");
			String VAT = uiDriver.getValue("VAT").substring(0,uiDriver.getValue("VAT").length() - 1);
			// put it in array using split
			if (PartialTaxTotalAmt.contains(input.get("PayPartialCashlessTax"))|input.get("PayPartialCashlessTax").equalsIgnoreCase(PartialTaxTotalAmt)) {
				passed("Verifying the PartialpayCashlessTax",
						"PartialpayCashlessTax should be displayed as '" + PayPartialCashlessTax + "' Successfully",
						"PartialCashlessTax " + PartialTaxTotalAmt + " is displayed Successfully");
			} else {
				failed("Verifying the PartialpayCashlessTax",
						"PartialpayCashlessTax should be displayed as '" + PayPartialCashlessTax + "' Successfully",
						"PartialCashlessTax " + PartialTaxTotalAmt + " is not displayed Successfully");
			}
			if (input.get("payPartialTaxAmt").contains(PartialTaxAmount)|input.get("payPartialTaxAmt").equalsIgnoreCase(PartialTaxAmount)) {
				passed("Verifying the PartialpayTaxAmt",
						"PartialpayTaxAmt should be displayed as '" + payPartialTaxAmt + "' Successfully",
						"PartialTaxAmt " + PartialTaxAmount + " is displayed Successfully");
			} else {
				failed("Verifying the PartialTaxAmt",
						"TotalTax should be displayed as '" + payPartialTaxAmt + "' Successfully",
						"PartialTaxAmt " + PartialTaxAmount + " is not displayed Successfully");
			}
			if (input.get("payPartialTotalAmt").contains(CashlessTaxAmt)|input.get("payPartialTotalAmt").equalsIgnoreCase(CashlessTaxAmt)) {
				passed("Verifying the PartialTotalAmt",
						"PartialTotalAmt should be displayed as '" + payPartialTotalAmt + "' Successfully",
						"PartialTotalAmt " + CashlessTaxAmt + " is displayed Successfully");
			} else {
				failed("Verifying the PartialTotalAmt",
						"PartialTotalAmt should be displayed as '" + payPartialTotalAmt + "' Successfully",
						"PartialTotalAmt " + CashlessTaxAmt + " is not displayed Successfully");
			}
			
		}
		
		if (input.get("RestPartialPayment").equals("Y")) {
			
			
			if(input.get("WHT").equals("Y")){
				
			 String WHTAmount = input.get("WHTAmt");
	   	     double WHTAmt = Double.parseDouble(WHTAmount);
	   	     String RestPartialCashlessTax = input.get("RestPartialCashlessTax");
			double RestPartialCashlessTaxVal = Double.parseDouble(RestPartialCashlessTax);
	    	double RestPartialCashlessTaxWithWHT = RestPartialCashlessTaxVal - WHTAmt;
	    	String RestPartialCashlessTaxWithWHTCode = Double.toString(RestPartialCashlessTaxWithWHT) ;
	    	String CashlessTaxAmt = uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE").substring(0,uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE").length() - 1);
	    	String TotalTax = input.get("TotalTax");
			String TotalAmount = input.get("TotalAmount");
         	String VAT = input.get("VAT");
			// fetching the value from title allocation parent page
			String RestPartialTaxAmt = input.get("RestPartialTaxAmt");
			String RestPartialTotalAmt = input.get("RestPartialTotalAmt");
			 double actualRestPartialTotalAmt=Double.parseDouble(RestPartialTotalAmt);
		// fetching the value from title allocation parent page
			String PartialTaxAmount = uiDriver.getValue("TaxTotal").substring(0,uiDriver.getValue("TaxTotal").length() - 1);
			String PartialTotalAmount = uiDriver.getValue("TotalAmount").substring(0,uiDriver.getValue("TotalAmount").length() - 1);
			String VATArr[] = uiDriver.getValue("VAT").split("\\.");
			String VATRate = VATArr[0];   	
	    	
	    	if (RestPartialCashlessTaxWithWHTCode .contains(CashlessTaxAmt)) {
				passed("Verifying the RestPartialCashlessTax",
						"RestPartialCashlessTax should be displayed as '" + RestPartialCashlessTax + "' Successfully",
						"RestPartialCashlessTax " + CashlessTaxAmt + " is displayed Successfully");
			} else {
				failed("Verifying the RestPartialCashlessTax",
						"RestPartialCashlessTax should be displayed as '" + RestPartialCashlessTax + "' Successfully",
						"RestPartialCashlessTax " + CashlessTaxAmt + " is not displayed Successfully");
			}
	    	
	    	if (input.get("RestPartialTaxAmt").contains(PartialTaxAmount)|input.get("RestPartialTaxAmt").equalsIgnoreCase(PartialTaxAmount)) {
				passed("Verifying the RestPartialTaxAmt",
						"RestPartialTaxAmt should be displayed as '" + RestPartialTaxAmt + "' Successfully",
						"RestPartialTaxAmt " + PartialTaxAmount + " is displayed Successfully");
			} else {
				failed("Verifying the RestPartialTaxAmt",
						"TotalTax should be displayed as '" + RestPartialTaxAmt + "' Successfully",
						"RestPartialTaxAmt " + PartialTaxAmount + " is not displayed Successfully");
			}
			if (input.get("RestPartialTotalAmt").contains(RestPartialTotalAmt)) {
				passed("Verifying the RestPartialTotalAmt",
						"RestPartialTotalAmt should be displayed as '" + PartialTotalAmount + "' Successfully",
						"RestPartialTotalAmt " + PartialTotalAmount + " is displayed Successfully");
			} else {
				failed("Verifying the RestPartialTotalAmt",
						"RestPartialTotalAmt should be displayed as '" + PartialTotalAmount + "' Successfully",
						"RestPartialTotalAmt " + PartialTotalAmount + " is not displayed Successfully");
			}
			if (input.get("VAT").contains(VATRate)) {
				passed("Verifying the VAT", "VAT should be displayed as '" + VAT + "' Successfully",
						"VAT " + VATRate + " is displayed Successfully");
			} else {
				failed("Verifying the VAT", "VAT should be displayed as '" + VAT + "' Successfully",
						"VAT " + VATRate + " is not displayed Successfully");
			}
			}	
	    	
		else{
			
			String RestPartialCashlessTax = input.get("RestPartialCashlessTax");
			double RestPartialCashlessTaxVal = Double.parseDouble(RestPartialCashlessTax);
	    	String RestPartialTaxAmt = input.get("RestPartialTaxAmt");
			String RestPartialTotalAmt = input.get("RestPartialTotalAmt");
			 double actualRestPartialTotalAmt=Double.parseDouble(RestPartialTotalAmt);
			String VAT = input.get("VAT");
			// fetching the value from title allocation parent page
			String CashlessTaxAmt = uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE").substring(0,uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE").length() - 1);
			if(CashlessTaxAmt.contains(","))
			{
				CashlessTaxAmt=CashlessTaxAmt.replace(",", "");
			}
			String PartialTaxAmount = uiDriver.getValue("TaxTotal").substring(0,uiDriver.getValue("TaxTotal").length() - 1);
			if(PartialTaxAmount.contains(","))
			{
				PartialTaxAmount=PartialTaxAmount.replace(",", "");
			}
			String PartialTotalAmount = uiDriver.getValue("TotalAmount").substring(0,uiDriver.getValue("TotalAmount").length() - 1);
			if(PartialTotalAmount.contains(","))
			{
				PartialTotalAmount=PartialTotalAmount.replace(",", "");
			}
			
			String VATArr[] = uiDriver.getValue("VAT").split("\\.");
			String VATRate = VATArr[0];
			//Gain/loss Validation
	 		String InvoiceExchangeRate = uiDriver.getValue("InvoiceExchangeRate");
	 		//.substring(0, uiDriver.getValue("InvoiceExchangeRate").length()-1);
	 		double actualInvoiceExchangeRate = Double.parseDouble(InvoiceExchangeRate);
	 		String paymentExchangeRate = uiDriver.getValue("paymentExchangeRate");
	 		//.substring(0, uiDriver.getValue("paymentExchangeRate").length()-1);
	 		double actualpaymentExchangeRate = Double.parseDouble(paymentExchangeRate);
	 		String gainLossAmount = uiDriver.getValue("gainLossAmount");
	 		//.substring(0, uiDriver.getValue("gainLossAmount").length()-1);
	 		//double actualgainLossAmount = Double.parseDouble(gainLossAmount);
	 		double actualgainLossAmount1=(actualInvoiceExchangeRate-actualpaymentExchangeRate)*actualRestPartialTotalAmt;
	 		String actualgainLossAmount2 = Double.toString(actualgainLossAmount1);
	 		
	 		if(input.get("RestGainLoss").equals("Y")){
	 		
	 		if (input.get("PaymentRate").contains(paymentExchangeRate)) {
				passed("Verifying the  PartialCashlessTax",
						"PartialCashlessTax should be displayed as '" + paymentExchangeRate+ "' Successfully",
						"PartialCashlessTax "	+ paymentExchangeRate + " is displayed Successfully");
			} else {
				failed("Verifying the  PartialCashlessTax","PartialCashlessTax should be displayed as '" + paymentExchangeRate+ "' Successfully",
						"PartialCashlessTax "+ paymentExchangeRate	+ " is not displayed Successfully");
			}
	 		
	 		
	 		if (input.get("InvoiceRate").contains(InvoiceExchangeRate)) {
				passed("Verifying the  PartialCashlessTax",
						"PartialCashlessTax should be displayed as '" + InvoiceExchangeRate+ "' Successfully",
						"PartialCashlessTax "	+ InvoiceExchangeRate + " is displayed Successfully");
			} else {
				failed("Verifying the  PartialCashlessTax","PartialCashlessTax should be displayed as '" + InvoiceExchangeRate+ "' Successfully",
						"PartialCashlessTax "+ InvoiceExchangeRate	+ " is not displayed Successfully");
			}
	 			 		 			 		
	 		if (gainLossAmount.contains(actualgainLossAmount2)) {
				passed("Verifying the  PartialCashlessTax",
						"PartialCashlessTax should be displayed as '" + gainLossAmount+ "' Successfully",
						"PartialCashlessTax "	+ gainLossAmount + " is displayed Successfully");
			} else {
				failed("Verifying the  PartialCashlessTax","PartialCashlessTax should be displayed as '" + gainLossAmount+ "' Successfully",
						"PartialCashlessTax "+ gainLossAmount	+ " is not displayed Successfully");
			}
	 		
	 }
	 		
	 		
	 		
	 		
	 		
	 		
	 		
	 		
			if (input.get("RestPartialCashlessTax").contains(CashlessTaxAmt)) {
				passed("Verifying the RestPartialCashlessTax",
						"RestPartialCashlessTax should be displayed as '" + RestPartialCashlessTax + "' Successfully",
						"RestPartialCashlessTax " + CashlessTaxAmt + " is displayed Successfully");
			} else {
				failed("Verifying the RestPartialCashlessTax",
						"RestPartialCashlessTax should be displayed as '" + RestPartialCashlessTax + "' Successfully",
						"RestPartialCashlessTax " + CashlessTaxAmt + " is not displayed Successfully");
			}
			if (input.get("RestPartialTaxAmt").contains(PartialTaxAmount)|input.get("RestPartialTaxAmt").equalsIgnoreCase(PartialTaxAmount)) {
				passed("Verifying the RestPartialTaxAmt",
						"RestPartialTaxAmt should be displayed as '" + RestPartialTaxAmt + "' Successfully",
						"RestPartialTaxAmt " + PartialTaxAmount + " is displayed Successfully");
			} else {
				failed("Verifying the RestPartialTaxAmt",
						"TotalTax should be displayed as '" + RestPartialTaxAmt + "' Successfully",
						"RestPartialTaxAmt " + PartialTaxAmount + " is not displayed Successfully");
			}
			if (input.get("RestPartialTotalAmt").contains(RestPartialTotalAmt)) {
				passed("Verifying the RestPartialTotalAmt",
						"RestPartialTotalAmt should be displayed as '" + PartialTotalAmount + "' Successfully",
						"RestPartialTotalAmt " + PartialTotalAmount + " is displayed Successfully");
			} else {
				failed("Verifying the RestPartialTotalAmt",
						"RestPartialTotalAmt should be displayed as '" + PartialTotalAmount + "' Successfully",
						"RestPartialTotalAmt " + PartialTotalAmount + " is not displayed Successfully");
			}
			if (input.get("VAT").contains(VATRate)) {
				passed("Verifying the VAT", "VAT should be displayed as '" + VAT + "' Successfully",
						"VAT " + VATRate + " is displayed Successfully");
			} else {
				failed("Verifying the VAT", "VAT should be displayed as '" + VAT + "' Successfully",
						"VAT " + VATRate + " is not displayed Successfully");
			}
			}	

       if(input.get("CashAdjCode").equals("Y")){
    	   
    	  String WHtAmount = uiDriver.getValue("WHTAmountCashAdjCode");
    	  if(input.get("WHTAmt").contains(WHtAmount)){
    		  passed("Verifying the  WHtAmount",
						"WHtAmount should be displayed as '" + WHtAmount+ "' Successfully",
						"WHtAmount "	+ WHtAmount + " is displayed Successfully");
			} else {
				failed("Verifying the  WHtAmount",	"WHtAmount should be displayed as '" + WHtAmount+ "' Successfully",
						"WHtAmount "+ WHtAmount + " is not displayed Successfully");
			}  
    		  
    		  
    	  }
    	  		  
    	  
    	   
       }
   
	}
		
	
       
   /****************************************
 	 * Name: MRAdjustAllocatedCashbyTitle
     * Description:Method to MRAdjustAllocatedCashbyTitle
     * Date:30-Nov-2017 
  
   ****************************************/   
	public void MRAdjustAllocatedCashbyTitle(DataRow input, DataRow output)throws InterruptedException, ParseException
	{
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Customization");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Scripting");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Scripts");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Scripts");
		SleepUtils.sleep(TimeSlab.YIELD);
		if(uiDriver.checkElementPresent("EditBtnMRAdjustAllocatedCash"))
		{
			uiDriver.click("EditBtnMRAdjustAllocatedCash");
		}
		else
		{
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Next");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("EditBtnMRAdjustAllocatedCash");
		}
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("deployments");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("manualscript");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("edit");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.mouseOver("SaveBtndropdown");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("SaveAndExecute");
		uiDriver.handleAlert("", "OK");
		uiDriver.click("refresh");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("refresh");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refresh");
		uiDriver.click("refresh");
		uiDriver.click("refresh");
		uiDriver.click("refresh");
				
	}	
	/****************************************
 	 * Name: MRSORevisionCBT
     * Description:Method to run MRSORevisionCBT
     * Date:30-Nov-2017 
  
   ****************************************/   
	public void MRSORevisionCBT(DataRow input, DataRow output)throws InterruptedException, ParseException
	{
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Customization");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Scripting");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Scripts");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Scripts");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("EditBtnMRSORevision");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("SaveBtndropdown");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("SaveAndExecute");
		uiDriver.handleAlert("", "OK");
		uiDriver.click("refresh");	
		SleepUtils.sleep(30);
		uiDriver.click("refresh");		
		SleepUtils.sleep(TimeSlab.YIELD);
		
	}
	
	
	/****************************************
 	 * Name: RevisionInvoiceCreditMR
     * Description:Method to run RevisionInvoiceCreditMR
     * Date:30-Nov-2017 
  
   ****************************************/   
	public void RevisionInvoiceCreditMR(DataRow input, DataRow output)throws InterruptedException, ParseException
	{
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Customization");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Scripting");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("Scripts");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Scripts");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("EditInvoiceCredit");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("SaveBtndropdown");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("SaveAndExecute");
		uiDriver.handleAlert("", "OK");
		uiDriver.click("refresh");	
		SleepUtils.sleep(30);
		uiDriver.click("refresh");			
		
	}
	
	
	
	
	/****************************************
   	 * Name: Edit Payment
   	 * Description:Method to edit payment
   	 *  Date:30-Nov-2017 
   	 ****************************************/
	public void EditPayment(DataRow input, DataRow output) throws InterruptedException {
		String invoicenum = input.get("invoicenumber");
		
		uiDriver.click("EditPayment");
        SleepUtils.sleep(TimeSlab.HIGH);
        uiDriver.executeJavaScript("scroll(0,-500)");
    	                      
        
        uiDriver.click("PaymentAmt");
        uiDriver.executeJavaScript("document.getElementById('payment_formattedValue').value = ''");
        SleepUtils.sleep(2);
        
        uiDriver.setValue("PaymentAmt", input.get("PartialTotalAmt"));
        if(input.get("Unappply").equals("N"))
        {
        String partialpayment = uiDriver.getDyanmicData("partialpaymentfield");
        SleepUtils.sleep(TimeSlab.YIELD);
        String ReferenceVal1 = partialpayment.replace("#", invoicenum);
        SleepUtils.sleep(TimeSlab.YIELD);
        uiDriver.executeJavaScript("scroll(0,500)");
       // uiDriver.executeJavaScript("document.getElementById('payment_formattedValue').value = '"+ input.get("PartialTotalAmt") + "'");
        uiDriver.click_dynamic(ReferenceVal1);
        uiDriver.click_dynamic(ReferenceVal1);
        }
        uiDriver.executeJavaScript("scroll(0,-1000)");
        uiDriver.click("acctradiobutton");
		SleepUtils.sleep(TimeSlab.YIELD);
		 uiDriver.setValue("Account", "30 Undeposited Funds");
		 SleepUtils.sleep(TimeSlab.HIGH);
        //uiDriver.click("Save");
        SleepUtils.sleep(TimeSlab.YIELD);
        uiDriver.executeJavaScript("document.getElementById('btn_multibutton_submitter').click();");
        passed("Edit Payment", "Payment should edited be successfully",
                "Payment is edited successfully");
        String PaymentNumber = uiDriver.getValue("PaymentNumber");
        SleepUtils.sleep(TimeSlab.LOW);
        output.put("PaymentNumber", PaymentNumber);
        SleepUtils.sleep(TimeSlab.LOW);
       
	}
	
	/****************************************
 	 * Name: VerifyJournalsafterMRAdjust
     * Description:Verify Journals after MRAdjust
     * Date:30-Nov-2017 
   ****************************************/   
	public void VerifyJournalsafterMRAdjust(DataRow input, DataRow output) throws InterruptedException
	{
		SleepUtils.sleep(2);
		uiDriver.click("Custom");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("scroll(0,900)");
		uiDriver.click("TitleAllocationParent");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("TAPId");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("checkjournals");
		SleepUtils.sleep(TimeSlab.LOW);
		int accRows = uiDriver.webDr.findElements(By.xpath("//table[@id='recmachcustbody_nbcu_titleallocation__tab']/tbody/tr")).size();
		int invoiceRow = 2;
		for (int r = 1; r < accRows + 1; r++) {
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.executeJavaScript("scroll(0,-200)");
			uiDriver.click("checkjournals");
			uiDriver.executeJavaScript("scroll(0,900)");
			String s1 = uiDriver.getDyanmicData("DocNum");
			String s2 = s1.replace("#", Integer.toString(r));
			if (uiDriver.checkElementPresent_dynamic(s2)) {

				uiDriver.click(s2);
				uiDriver.executeJavaScript("scroll(0,800)");
				int transRows = uiDriver.webDr.findElements(By.xpath("//*[@id='line_splits']//tbody/tr")).size();
				for (int i = 0; i < transRows - 1; i++) {
					uiDriver.executeJavaScript("scroll(0,100);");
					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Deferred Rev - Unpaid"))
					{

						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[2]").equals(""))

						{

							failed("Validating Debit Amount",
							"Validating Debit Amount should be successfull",
							"Debit amount is not Deferred Rev - Unpaid");

						}

						else
						{

							passed("Debit is Deferred Rev - Unpaid",
							"Debit is Deferred Rev - Unpaid",
							"Debit amount is Deferred Rev - Unpaid");

						}

					}

					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Generic Billed"))
					{

						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[2]").equals(""))

						{

							failed("Validating Debit Amount",
							"Validating Debit Amount should be successfull",
							"Debit amount is not Generic Billed");

						}

						else
						{

							passed("Debit is Generic Billed",
							"Debit is Deferred Rev - Unpaid",
							"Debit amount is Generic Billed");

						}

					}

					
					
					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Contract revenue - Dom"))
					{
						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals(""))
						{

							failed("Validating Credit Amount",
							"Validating Debit Amount should be successfull",
							"Credit amount is not Contract revenue - Dom");

						}

						else
						{
							passed("Credit is Deferred Rev - Generic",
							"Credit is Bad Debt",
							"Credit amount is Contract revenue - Dom");
						}
					}

					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Undeposited"))
					{
						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals(""))
						{

							failed("Validating Debit Amount",
							"Validating Debit Amount should be successfull",
						   "Debit amount is not Billed Dom AR");
						}

						else
						{
							passed("Debit is Billed Dom AR",
							"Debit is Billed Dom AR",
							"Debit amount is Billed Dom AR");
						}
					}

					if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Billed Dom"))
					{
						if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals(""))
						{

							failed("Validating Debit Amount",
							"Validating Credit Amount should be successfull",
							"Credit amount is not Billed Dom");

						}

						else
						{
							passed("Credit is Billed Dom",
							"Credit is Billed Dom",
							"Credit amount is Billed Dom");
						}

					}

					invoiceRow++;

				}

				uiDriver.executeJavaScript("scroll(0,800)");
				SleepUtils.sleep(5);
				uiDriver.click("Back1");
				invoiceRow = 2;
				SleepUtils.sleep(5);
				SleepUtils.sleep(5);
			} else

			{

			}

		}

	}

	
	
	/****************************************
 	 * Name: NavigateToTitleAllocationChild
     * Description:NavigateToTitleAllocationChild
     * Date:30-Nov-2017 
   ****************************************/   
	public void NavigateToTitleAllocationChild(DataRow input, DataRow output) throws InterruptedException 
    {
		SleepUtils.sleep(5);
		uiDriver.executeJavaScript("scroll(0,500)");
		SleepUtils.sleep(5);
			uiDriver.click("AllocationDetail");
			SleepUtils.sleep(5);
            int accRows = uiDriver.webDr.findElements(By.xpath("//table[@id='recmachcustrecord_nbcu_titleallocch_parent__tab']/tbody/tr")).size();
            for(int i=0;i<accRows;i++)
            {
                String s1= uiDriver.getDyanmicData("ARAmount");
                String s2=s1.replace("#", Integer.toString(i));
                if(uiDriver.checkElementPresent_dynamic(s2)){
                	
                    String ARAmount=uiDriver.getValue(s2);
                    passed("Verify AR Amount "+ARAmount+"",
                           "SuccessFully Verified AR Amount "+ARAmount+"",
                            "SuccessFully Verified AR Amount "+ARAmount+"");
           }

           String s3= uiDriver.getDyanmicData("WHTAmount");
           String s4=s3.replace("#", Integer.toString(i));
           if(uiDriver.checkElementPresent_dynamic(s4)){
              String WHTAmount=uiDriver.getValue(s4);
              passed("Verify WHT Amount "+WHTAmount+"",
                     "SuccessFully Verified WHT Amount "+WHTAmount+"",
                      "SuccessFully Verified WHT Amount "+WHTAmount+"");
          }

          String s5= uiDriver.getDyanmicData("VATAmount");
          String s6=s5.replace("#", Integer.toString(i));
          if(uiDriver.checkElementPresent_dynamic(s6)){
            String VATAmount=uiDriver.getValue(s6);
            passed("Verify VAT Amount "+VATAmount+"",
                   "SuccessFully Verified WHT Amount "+VATAmount+"",
                   "SuccessFully Verified WHT Amount "+VATAmount+"");
          }
          String s7= uiDriver.getDyanmicData("CACAmount");
          String s8=s7.replace("#", Integer.toString(i));
          if(uiDriver.checkElementPresent_dynamic(s8)){
               String CACAmount=uiDriver.getValue(s8);
               passed("Verify CAC Amount "+CACAmount+"",
                      "SuccessFully Verified WHT Amount "+CACAmount+"",
                      "SuccessFully Verified WHT Amount "+CACAmount+"");
               SleepUtils.sleep(10);
               
            }
       }
    } 



    /****************************************
 	 * Name: VerifyingFullPayment
     * VerifyingFullPayment
     * Date:28-Feb-2017 
     ****************************************/  
	public void VerifyingFullPayment(DataRow input, DataRow output) throws InterruptedException

	{
	     SleepUtils.sleep(TimeSlab.LOW);   
        String invoicenum = uiDriver.getValue("invoicenum");
        SleepUtils.sleep(TimeSlab.LOW);                        
        uiDriver.executeJavaScript("scroll(0,-500)");
        uiDriver.click("AcceptPayment");
        passed("AcceptPayment", "Should be clicked successfully",
                "AcceptPayment button is clicked successfully");
        
        if(input.get("UK_Currency").equals("Y")){
       	 uiDriver.click("exchangeRate");
       	 
       	 uiDriver.handleAlert("", "OK");
       	 //uiDriver.setValue("exchangeRate", input.get("exchangeRate"));
       	 uiDriver.executeJavaScript("document.getElementById('exchangerate_formattedValue').value='"+input.get("exchangeRate")+"';");
       	 uiDriver.handleAlert("", "OK");
       	 String exchangeRate = uiDriver.getValue("exchangeRate");
            output.put("exchangeRate", exchangeRate);
        }
        
        SleepUtils.sleep(TimeSlab.YIELD);
        String partialpayment = uiDriver.getDyanmicData("partialpaymentfield");
        SleepUtils.sleep(TimeSlab.YIELD);
        String ReferenceVal1 = partialpayment.replace("#", invoicenum);
        SleepUtils.sleep(TimeSlab.YIELD);
        uiDriver.executeJavaScript("scroll(0,500)");
        //uiDriver.click("PaymentAmt");
        //uiDriver.executeJavaScript("document.getElementById('payment_formattedValue').value = ''");
        //SleepUtils.sleep(2);
        
        //uiDriver.setValue("PaymentAmt", input.get("PartialTotalAmt"));
        SleepUtils.sleep(TimeSlab.LOW);
        
       // uiDriver.executeJavaScript("document.getElementById('payment_formattedValue').value = '"+ input.get("PartialTotalAmt") + "'");
        if(uiDriver.checkElementPresent_dynamic(ReferenceVal1)){
       	 
     	   SleepUtils.sleep(10);
     	   uiDriver.click_dynamic(ReferenceVal1);
            uiDriver.click_dynamic(ReferenceVal1);  
       }
        else{
      	   
      	   SleepUtils.sleep(TimeSlab.LOW);
      	   uiDriver.click("FilterNumber");
      	   uiDriver.click("FirstFilteringNumber");
      	   uiDriver.executeJavaScript("scroll(0,800)");
      	   SleepUtils.sleep(TimeSlab.LOW);
      	  if(uiDriver.checkElementPresent_dynamic(ReferenceVal1)){
            
      		uiDriver.click_dynamic(ReferenceVal1);
             uiDriver.click_dynamic(ReferenceVal1); 
      	    SleepUtils.sleep(TimeSlab.MEDIUM);
      	  }
      	  else{
      		  
      	   SleepUtils.sleep(TimeSlab.LOW);
      	  uiDriver.executeJavaScript("scroll(0,-800)");
        	   uiDriver.click("FilterNumber");
        	   uiDriver.click("SecondFilteringNumber");
        	   uiDriver.executeJavaScript("scroll(0,800)");
        	   SleepUtils.sleep(TimeSlab.LOW);
        	  if(uiDriver.checkElementPresent_dynamic(ReferenceVal1)){
              
        		uiDriver.click_dynamic(ReferenceVal1);
               uiDriver.click_dynamic(ReferenceVal1); 
        	    SleepUtils.sleep(TimeSlab.MEDIUM);
        	    
        	  }
        	  else{
        		  
        		 SleepUtils.sleep(TimeSlab.LOW);
        		 uiDriver.executeJavaScript("scroll(0,-800)");
          	   uiDriver.click("FilterNumber");
          	   uiDriver.click("ThirdFilteringNumber");
          	   uiDriver.executeJavaScript("scroll(0,800)");
          	   SleepUtils.sleep(TimeSlab.LOW);
          	  if(uiDriver.checkElementPresent_dynamic(ReferenceVal1)){
                
          		uiDriver.click_dynamic(ReferenceVal1);
                 uiDriver.click_dynamic(ReferenceVal1); 
          	    SleepUtils.sleep(TimeSlab.MEDIUM);
          	    
          	  }
        	  }
      		  
      	  }
      	   
         }
        
        if(input.get("cashAdjCode").equals("Y")){
            
       	 SleepUtils.sleep(TimeSlab.LOW);
       	 uiDriver.click("CashAdjCode");
           SleepUtils.sleep(2);
           uiDriver.click("CashAdjCode1");
           uiDriver.setValue("CashAdjCode1",input.get("CashAdjCode1"));
           SleepUtils.sleep(2);
           uiDriver.click("dropdown");
           SleepUtils.sleep(2);
           uiDriver.click("List");
           SleepUtils.sleep(2);
           uiDriver.click("searchbox");
           String invoicenumber="Invoice #"+invoicenum;
           uiDriver.setValue("searchbox",invoicenumber);
           uiDriver.click("searchbutton");
           SleepUtils.sleep(2);
           uiDriver.click("searchedinvoicecode");
           SleepUtils.sleep(2);
           uiDriver.click("WHTCode");
           uiDriver.setValue("EditWHTCode",input.get("WHTCode"));
           SleepUtils.sleep(TimeSlab.LOW);
           uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[3].click();");
           SleepUtils.sleep(TimeSlab.MEDIUM);
           uiDriver.setValue("EditWHTRate",input.get("WHTRate"));
           SleepUtils.sleep(2);
           uiDriver.click("Add");
           SleepUtils.sleep(2);
           uiDriver.click("CAshAdjCodeAmount");
           SleepUtils.sleep(3);
           String WHTAmount = uiDriver.getValue("WHTAmount");   
           uiDriver.setValue("CAshAdjCodeAmount",WHTAmount);
           String WHTpercent=uiDriver.getValue("WHTpercent"); 
           SleepUtils.sleep(2);
           uiDriver.executeJavaScript("scroll(0,-800)");
           output.put("WHTAmount", WHTAmount);
        }
        
       uiDriver.executeJavaScript("scroll(0,-500)");
       uiDriver.click("acctradiobutton");
	    SleepUtils.sleep(TimeSlab.YIELD);
			 uiDriver.setValue("Account", "11015051 USL Cash Clearing");
			 SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.setValue("ContractorName", "");
			 
			 SleepUtils.sleep(TimeSlab.YIELD);
       //uiDriver.click("SaveInvoice");
       SleepUtils.sleep(TimeSlab.YIELD);
       uiDriver.executeJavaScript("document.getElementById('btn_multibutton_submitter').click();");
       uiDriver.handleAlert("", "Leave");            
       passed("SaveInvoice", "Invoice Should be Saved successfully",
               "Invoice is Saved successfully");
       String PaymentNumber = uiDriver.getValue("PaymentNumber");
       SleepUtils.sleep(TimeSlab.LOW);
       output.put("PaymentNumber", PaymentNumber);          
        }
	
	/****************************************
	  * Name: Cash Adj Code
	  * Description:Verify Journals after MRAdjust
	  * Date:30-Nov-2017
	****************************************/

	     public void CashAdjCode(DataRow input, DataRow output)

	     {

	             uiDriver.click("Editbtn");
	            SleepUtils.sleep(2);
	            /*uiDriver.click("CashAdjCode");
	            SleepUtils.sleep(2);
	            uiDriver.click("CashAdjCode1");
	            uiDriver.setValue("CashAdjCode1",input.get("WHTCode"));
	            SleepUtils.sleep(2);
	            uiDriver.click("dropdown");
	            SleepUtils.sleep(2);
	            uiDriver.click("List");
	            SleepUtils.sleep(2);
	            uiDriver.click("searchbox");
	            String invoicenum=input.get("invoicenum");
	            String invoicenumber="Invoice #"+invoicenum;
	            //uiDriver.setValue("searchbox", invoicenumber);
	            uiDriver.setValue("searchbox", "Invoice #1C364");
	            uiDriver.click("searchbutton");
	            SleepUtils.sleep(2);
	            uiDriver.click("searchedinvoicecode");
	            SleepUtils.sleep(2);
	            uiDriver.click("WHTCode");
	            uiDriver.setValue("EditWHTCode",input.get("WHTCode"));
	            SleepUtils.sleep(TimeSlab.MEDIUM);
	           // uiDriver.click("WHTRate");
	            
	            uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[3].click();");
	            SleepUtils.sleep(TimeSlab.MEDIUM);
	            uiDriver.setValue("EditWHTRate",input.get("cashadjcode"));
	            //SleepUtils.sleep(TimeSlab.LOW);  
	           // uiDriver.executeJavaScript("document.getElementById('custrecord_nbcu_whti_wht_rate_formattedValue').value='"+input.get("cashadjcode")+"';");
	           // uiDriver.setValue("EditWHTRate",input.get("cashadjcode"));
	            SleepUtils.sleep(2);
	            uiDriver.click("Add");
	            SleepUtils.sleep(2);
	            uiDriver.click("CAshAdjCodeAmount");
	            SleepUtils.sleep(3);
	            String CACamount=uiDriver.getValue("WHTAmount");   
	            uiDriver.setValue("Amount",CACamount);
	            String WHTpercent=uiDriver.getValue("WHTpercent"); 
	            SleepUtils.sleep(2);
	            uiDriver.executeJavaScript("scroll(0,-800)");
	            output.put("WHTpercent", WHTpercent);
	            
	            uiDriver.click("Save");
	            SleepUtils.sleep(TimeSlab.LOW) ;*/
	            SleepUtils.sleep(TimeSlab.LOW);
	            uiDriver.click("CashAdjCode");
	             SleepUtils.sleep(2);
	             uiDriver.click("CashAdjCode1");
	             SleepUtils.sleep(2);
	             SleepUtils.sleep(2);
	             SleepUtils.sleep(2);
	             uiDriver.setValue("CashAdjCode1",input.get("CashAdjCode1"));
	             SleepUtils.sleep(2);
	             uiDriver.click("dropdown");
	             SleepUtils.sleep(2);
	             uiDriver.click("List");
	             SleepUtils.sleep(2);
	             uiDriver.click("searchbox");
	             String invoicenum=input.get("invoicenum");
	             String invoicenumber="Invoice #"+invoicenum;
	             uiDriver.setValue("searchbox",invoicenumber);
	             uiDriver.click("searchbutton");
	             SleepUtils.sleep(2);
	             uiDriver.click("searchedinvoicecode");
	             SleepUtils.sleep(2);
	             uiDriver.click("WHTCode");
	             uiDriver.setValue("EditWHTCode",input.get("WHTCode"));
	             SleepUtils.sleep(TimeSlab.LOW);
	             uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[3].click();");
	             SleepUtils.sleep(TimeSlab.MEDIUM);
	             uiDriver.setValue("EditWHTRate",input.get("WHTRate"));
	             SleepUtils.sleep(2);
	             uiDriver.click("Add");
	              SleepUtils.sleep(2);
	              uiDriver.click("CAshAdjCodeAmount");
	              SleepUtils.sleep(3);
	              String WHTAmount = uiDriver.getValue("WHTAmount");   
	              uiDriver.setValue("CAshAdjCodeAmount",WHTAmount);
	              String WHTpercent=uiDriver.getValue("WHTpercent"); 
	              SleepUtils.sleep(2);
	              uiDriver.executeJavaScript("scroll(0,-800)");
	              output.put("WHTAmount", WHTAmount);
	              uiDriver.executeJavaScript("scroll(0,-800)");
	              output.put("WHTpercent", WHTpercent);
	              
	              uiDriver.click("Save");
	              SleepUtils.sleep(TimeSlab.LOW);
	            
	     }
	/****************************************
 	 * Name: EditingARAmount
     * Description:EditingARAmount
     * Date:26-Feb-2017 
   ****************************************/ 
	public void EditingARAmount(DataRow input, DataRow output) throws InterruptedException 

    {	SleepUtils.sleep(TimeSlab.LOW);   
		
		
		if(input.get("editmultiple").equals("Y")){
			uiDriver.executeJavaScript("scroll(0,-1000)");
			
			uiDriver.click("EditBtn");
				for(int i=1;i<=4;i++)
				{

				String Aramountedit1 = uiDriver.getDyanmicData("Aramountedit");
				String updateArmount2 = Aramountedit1.replace("#", Integer.toString(i));
				uiDriver.click_dynamic(updateArmount2);
				                     

				uiDriver.executeJavaScript("document.getElementById('custrecord_nbcu_titleallocch_allocamount_formattedValue').value = ''");

				                    if(i==1)
				                     {
				                           uiDriver.setValue("EditedARAmount",input.get("amount1"));
				                     }
				                     if(i==2)
				                     {
				                    	 uiDriver.setValue("EditedARAmount",input.get("amount2"));    
				                    	 }
				                     if(i==3)
				                     {
				                    	 uiDriver.setValue("EditedARAmount",input.get("amount3")); 
				                    	 }
				                     if(i==4)
				                     {
				                    	 uiDriver.setValue("EditedARAmount",input.get("amount4")); 
				                     }
				}
				uiDriver.executeJavaScript("scroll(0,-300)");
			    uiDriver.click("SaveBtn");
			    if(uiDriver.isAlertPresent()){
				 String alerttext=uiDriver.getAlertText();   
				 System.out.println(alerttext);
				 uiDriver.handleAlert("", "OK");
				 //uiDriver.handleAlert("Payment amounts allocated to the lines do not match the total payment amount. Please allocate the remaining balance to the lines., button","OK");
				 if(alerttext.contains("Payment amounts allocated to the lines do not match the total payment amount. Please allocate the remaining balance to the lines."))
				 {
					 passed("Validation alert verified ", "amount should not be allocated more than the payment amount",
		                     "amount is not  allocated more than the payment amount"); 
				 }
				 
				 uiDriver.click("CancelBtn");
			    }
				 
				//}
				
				
				
				}
				                     else if(input.get("editmultiple").equals("N"))
				                     {


		
		Double ChangedARAmt = 10.00;
		uiDriver.executeJavaScript("scroll(0,-200)");
		uiDriver.click("EditBtn");
		 SleepUtils.sleep(5);
		uiDriver.executeJavaScript("scroll(0,-200)");
		String ARAmt = uiDriver.getValue("ARAmount");
 		Double ARAmnt = Double.parseDouble(ARAmt);
		Double ARAmount = ARAmnt + ChangedARAmt ;
		String NewARAmount = Double.toString(ARAmount);
		uiDriver.click("ARAmount");
		uiDriver.executeJavaScript("document.getElementById('custrecord_nbcu_titleallocch_allocamount_formattedValue').value = ''");
		uiDriver.setValue("EditedARAmount",NewARAmount );
		  passed("ARAmount", "ARAmount Should be entered successfully "+NewARAmount+" ",
                  "ARAmount is entered successfully as  "+NewARAmount+"");
		  String ARAmt1 = uiDriver.getValue("ARAmount1");
			Double ARAmnt1= Double.parseDouble(ARAmt1);
			Double ARAmount1 = ARAmnt1 - ChangedARAmt ;
			String NewARAmount1 = Double.toString(ARAmount1);
			uiDriver.click("EditARAmount1");
			uiDriver.executeJavaScript("document.getElementById('custrecord_nbcu_titleallocch_allocamount_formattedValue').value = ''");
			uiDriver.setValue("EditARAmountValue",NewARAmount1);
			uiDriver.executeJavaScript("scroll(0,-300)");
		    uiDriver.click("SaveBtn");
}
   }
	
	public void NavigateToCustomization(DataRow input, DataRow output) throws InterruptedException
		{
			
			uiDriver.mouseOver("Customization");
		    SleepUtils.sleep(TimeSlab.YIELD);
		    uiDriver.mouseOver("ListsandRecords");
		    SleepUtils.sleep(TimeSlab.YIELD);
		    uiDriver.mouseOver("RecordTypes");
		    SleepUtils.sleep(TimeSlab.YIELD);
		    uiDriver.click("RecordTypes");
		    SleepUtils.sleep(TimeSlab.YIELD); 
		} 
	
		    
	 public void ValidateTitleAllocationParent(DataRow input, DataRow output) throws InterruptedException
		    {
		 
		 uiDriver.executeJavaScript("scroll(0,1200)");
		 		uiDriver.click("TitleAllocationParent");
		 		SleepUtils.sleep(TimeSlab.YIELD);
		    
		    String customertype=uiDriver.getValue("Customer");
		      if(customertype.equals("List/Record"))
		    {
		    	
		    	passed("Validated customertype "+customertype+"",
                        "Customertype should be validated successfully"+customertype+"",
                         "SuccessFully Validated customertype"+customertype+"");
		    }
		      else
		      {
		    	  failed("Not Validated customertype "+customertype+"",
                        "customertype should be validated successfully"+customertype+"",
                         "customertype is not validated successfully "+customertype+"");
		      }
		      
		    String Invoicetype=uiDriver.getValue("Invoice");
		      if(Invoicetype.equals("List/Record"))
		    {
		    	passed("Validated Invoicetype "+Invoicetype+"",
                        "Invoicetype should be validated successfully"+Invoicetype+"",
                         "SuccessFully Validated Invoicetype"+Invoicetype+"");
		    }
		      else
		      {
		    	  failed("Not Validated Invoicetype "+Invoicetype+"",
                        "Invoicetype should be validated successfully"+Invoicetype+"",
                         "Invoicetype is not validated successfully "+Invoicetype+"");
		      }
		    
		    String Contracttype=uiDriver.getValue("Contract");
		      if(Contracttype.equals("List/Record"))
		    {
		    	passed("Validated Contracttype "+Contracttype+"",
                        "Contracttype should be validated successfully"+Contracttype+"",
                         "SuccessFully Validated customertype"+Contracttype+"");
		    }
		      else
		      {
		    	  failed("Not Validated Contracttype "+Contracttype+"",
                        "Contracttype should be validated successfully"+Contracttype+"",
                         "Contracttype is not validated successfully "+Contracttype+"");
		      }
		    
		    String Paymenttype=uiDriver.getValue("Payment");
		      if(Paymenttype.equals("List/Record"))
		    {
		    	passed("Validated Paymenttype "+Paymenttype+"",
                        "Paymenttype should be validated successfully"+Paymenttype+"",
                         "SuccessFully Validated Paymenttype"+Paymenttype+"");
		    }
		      else
		      {
		    	  failed("Not Validated Paymenttype "+Paymenttype+"",
                        "Paymenttype should be validated successfully"+Paymenttype+"",
                         "Paymenttype is not validated successfully "+Paymenttype+"");
		      }
		
		    String InvoiceTotaltype=uiDriver.getValue("InvoiceTotal");
		      if(InvoiceTotaltype.equals("Currency"))
		    {
		    	passed("Validated InvoiceTotaltype "+InvoiceTotaltype+"",
                        "InvoiceTotaltype should be validated successfully"+InvoiceTotaltype+"",
                         "SuccessFully Validated InvoiceTotaltype"+InvoiceTotaltype+"");
		    }
		      else
		      {
		    	  failed("Not Validated InvoiceTotaltype "+InvoiceTotaltype+"",
                        "InvoiceTotaltype should be validated successfully"+InvoiceTotaltype+"",
                         "InvoiceTotaltype is not validated successfully "+InvoiceTotaltype+"");
		      }
		      
		    String AppliedtoInvoicetype=uiDriver.getValue("AppliedtoInvoice");
		      if(AppliedtoInvoicetype.equals("Currency"))
		    {
		    	passed("Validated AppliedtoInvoicetype "+AppliedtoInvoicetype+"",
                        "AppliedtoInvoicetype should be validated successfully"+AppliedtoInvoicetype+"",
                         "SuccessFully Validated AppliedtoInvoicetype "+AppliedtoInvoicetype+"");
		    }
		      else
		      {
		    	  failed("Not Validated AppliedtoInvoicetype "+AppliedtoInvoicetype+"",
                        "AppliedtoInvoicetype should be validated successfully"+AppliedtoInvoicetype+"",
                         "AppliedtoInvoicetype is not validated successfully "+AppliedtoInvoicetype+"");
		      }
		      
		    String CashAccounttype=uiDriver.getValue("CashAccount");
		      if(CashAccounttype.equals("List/Record"))
		    {
		    	passed("Validated CashAccounttype "+CashAccounttype+"",
                        "CashAccounttype should be validated successfully"+CashAccounttype+"",
                         "SuccessFully Validated CashAccounttype "+CashAccounttype+"");
		    }
		      
		      else
		      {
		    	  failed("Not Validated CashAccounttype "+CashAccounttype+"",
                        "CashAccounttype should be validated successfully"+CashAccounttype+"",
                         "CashAccounttype is not validated successfully "+CashAccounttype+"");
		      }
		      
		    String CashBasistype=uiDriver.getValue("CashBasis");
		      if(CashBasistype.equalsIgnoreCase("Check Box"))
		    {
		    	passed("Validated CashBasistype "+CashBasistype+"",
                        "CashBasistype should be validated successfully"+CashBasistype+"",
                         "SuccessFully Validated CashBasistype "+CashBasistype+"");
		    }
		      else
		      {
		    	  failed("Not Validated CashBasistype "+CashBasistype+"",
                        "CashBasistype should be validated successfully"+CashBasistype+"",
                         "CashBasistype is not validated successfully "+CashBasistype+"");
		      }

		}


	 public void ValidateTitleAllocationChild(DataRow input, DataRow output) throws InterruptedException
	    {
		 
		 	uiDriver.click("TitleAllocationChild");
		    SleepUtils.sleep(TimeSlab.YIELD);
		    	    
			    String TitleAllocationParenttype=uiDriver.getValue("TitleAllocationParent");
				      if(TitleAllocationParenttype.equals("List/Record"))
				      	{
				    	
				    	passed("Validated TitleAllocationParenttype "+TitleAllocationParenttype+"",
			                 "TitleAllocationParenttype should be validated successfully"+TitleAllocationParenttype+"",
			                  "SuccessFully Validated TitleAllocationParenttype"+TitleAllocationParenttype+"");
				      	}
				      else
				      {
				    	  failed("Not Validated TitleAllocationParenttype "+TitleAllocationParenttype+"",
			                 "TitleAllocationParenttype should be validated successfully"+TitleAllocationParenttype+"",
			                  "TitleAllocationParenttype is not validated successfully "+TitleAllocationParenttype+"");
				      }
	 
				 String ContractLinetype = uiDriver.getValue("ContractLine");
			     if(ContractLinetype.equals("Integer Number"))
				     {
				   	
				   	passed("Validated ContractLinetype "+ContractLinetype+"",
				            "ContractLinetype should be validated successfully"+ContractLinetype+"",
				             "SuccessFully Validated ContractLinetype"+ContractLinetype+"");
				     }
				     else
				     {
				   	  failed("Not Validated ContractLinetype "+ContractLinetype+"",
				            "ContractLinetype should be validated successfully"+ContractLinetype+"",
				             "ContractLinetype is not validated successfully "+ContractLinetype+"");
				     }
			     
			     
			     
			     String InvoiceLinetype=uiDriver.getValue("InvoiceLine");
			      if(InvoiceLinetype.equals("Integer Number"))
			      	{
			    	
			    	passed("Validated InvoiceLinetype "+InvoiceLinetype+"",
		                 "InvoiceLinetype should be validated successfully"+InvoiceLinetype+"",
		                  "SuccessFully Validated InvoiceLinetype"+InvoiceLinetype+"");
			      	}
			      else
			      {
			    	  failed("Not Validated InvoiceLinetype "+InvoiceLinetype+"",
		                 "InvoiceLinetype should be validated successfully"+InvoiceLinetype+"",
		                  "InvoiceLinetype is not validated successfully "+InvoiceLinetype+"");
			      }
			      
			      
			      String Titletype=uiDriver.getValue("Title");
			      if(Titletype.equals("List/Record"))
			      	{
			    	
			    	passed("Validated Titletype "+Titletype+"",
		                 "Titletype should be validated successfully"+Titletype+"",
		                  "SuccessFully Validated Titletype"+Titletype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated Titletype "+Titletype+"",
		                 "Titletype should be validated successfully"+Titletype+"",
		                  "Titletype is not validated successfully "+Titletype+"");
			      	}
			      
			      String InvoiceLineAmounttype=uiDriver.getValue("InvoiceLineAmount");
			      if(InvoiceLineAmounttype.equals("Currency"))
			      	{
			    	
			    	passed("Validated InvoiceLineAmounttype "+InvoiceLineAmounttype+"",
		                 "InvoiceLineAmounttype should be validated successfully"+InvoiceLineAmounttype+"",
		                  "SuccessFully Validated InvoiceLineAmounttype"+InvoiceLineAmounttype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated InvoiceLineAmounttype "+InvoiceLineAmounttype+"",
		                 "InvoiceLineAmounttype should be validated successfully"+InvoiceLineAmounttype+"",
		                  "InvoiceLineAmounttype is not validated successfully "+InvoiceLineAmounttype+"");
			      	}
			      
			      String WHTPercentagetype=uiDriver.getValue("WHTPercentage");
			      if(WHTPercentagetype.equals("Percent"))
			      	{
			    	
			    	passed("Validated WHTPercentagetype "+WHTPercentagetype+"",
		                 "WHTPercentagetype should be validated successfully"+WHTPercentagetype+"",
		                  "SuccessFully Validated WHTPercentagetype"+WHTPercentagetype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated WHTPercentagetype "+WHTPercentagetype+"",
		                 "WHTPercentagetype should be validated successfully"+WHTPercentagetype+"",
		                  "WHTPercentagetype is not validated successfully "+WHTPercentagetype+"");
			      	}
			      			      
			      String RevisionNumbertype=uiDriver.getValue("RevisionNumber");
			      if(RevisionNumbertype.equals("Integer Number"))
			      	{
			    	
			    	passed("Validated RevisionNumbertype "+RevisionNumbertype+"",
		                 "RevisionNumbertype should be validated successfully"+RevisionNumbertype+"",
		                  "SuccessFully Validated RevisionNumbertype"+RevisionNumbertype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated RevisionNumbertype "+RevisionNumbertype+"",
		                 "RevisionNumbertype should be validated successfully"+RevisionNumbertype+"",
		                  "RevisionNumbertype is not validated successfully "+RevisionNumbertype+"");
			      	}
			      
			      String GLPNtype=uiDriver.getValue("GLPN");
			      if(GLPNtype.equals("List/Record"))
			      	{
			    	
			    	passed("Validated GLPNtype "+GLPNtype+"",
		                 "GLPNtype should be validated successfully"+GLPNtype+"",
		                  "SuccessFully Validated GLPNtype"+GLPNtype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated GLPNtype "+GLPNtype+"",
		                 "GLPNtype should be validated successfully"+GLPNtype+"",
		                  "GLPNtype is not validated successfully "+GLPNtype+"");
			      	}
			      
			      String MarketCodetype=uiDriver.getValue("MarketCode");
			      if(MarketCodetype.equals("List/Record"))
			      	{
			    	
			    	passed("Validated MarketCodetype "+MarketCodetype+"",
		                 "MarketCodetype should be validated successfully"+MarketCodetype+"",
		                  "SuccessFully Validated MarketCodetype"+MarketCodetype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated MarketCodetype "+MarketCodetype+"",
		                 "MarketCodetype should be validated successfully"+MarketCodetype+"",
		                  "MarketCodetype is not validated successfully "+MarketCodetype+"");
			      	}
			      String Righttype=uiDriver.getValue("Right");
			      if(Righttype.equals("List/Record"))
			      	{
			    	
			    	passed("Validated Righttype "+Righttype+"",
		                 "Righttype should be validated successfully"+Righttype+"",
		                  "SuccessFully Validated Righttype"+Righttype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated Righttype "+Righttype+"",
		                 "Righttype should be validated successfully"+Righttype+"",
		                  "Righttype is not validated successfully "+Righttype+"");
			      	}
			      String Territorytype=uiDriver.getValue("Territory");
			      if(Territorytype.equals("List/Record"))
			      	{
			    	
			    	passed("Validated Territorytype "+Territorytype+"",
		                 "Territorytype should be validated successfully"+Territorytype+"",
		                  "SuccessFully Validated Territorytype"+Territorytype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated Territorytype "+Territorytype+"",
		                 "Territorytype should be validated successfully"+Territorytype+"",
		                  "Territorytype is not validated successfully "+Territorytype+"");
			      	}
			      
			      String Closedtype=uiDriver.getValue("Closed");
			      if(Closedtype.equals("Check Box"))
			      	{
			    	
			    	passed("Validated Closedtype "+Closedtype+"",
		                 "Closedtype should be validated successfully"+Closedtype+"",
		                  "SuccessFully Validated Closedtype"+Closedtype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated Closedtype "+Closedtype+"",
		                 "Closedtype should be validated successfully"+Closedtype+"",
		                  "Closedtype is not validated successfully "+Closedtype+"");
			      	}
			      
			      String CBRecEdtype=uiDriver.getValue("CBRecEd");
			      if(CBRecEdtype.equals("Check Box"))
			      	{
			    	
			    	passed("Validated CBRecEdtype "+CBRecEdtype+"",
		                 "CBRecEdtype should be validated successfully"+CBRecEdtype+"",
		                  "SuccessFully Validated CBRecEdtype"+CBRecEdtype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated CBRecEdtype "+CBRecEdtype+"",
		                 "CBRecEdtype should be validated successfully"+CBRecEdtype+"",
		                  "CBRecEdtype is not validated successfully "+CBRecEdtype+"");
			      	}
			      
			      String RRSDtype=uiDriver.getValue("RRSD");
			      if(RRSDtype.equals("Date"))
			      	{
			    	
			    	passed("Validated RRSDtype "+RRSDtype+"",
		                 "RRSDtype should be validated successfully"+RRSDtype+"",
		                  "SuccessFully Validated RRSDtype"+RRSDtype+"");
			      	}
			      else
			      	{
			    	  failed("Not Validated RRSDtype "+RRSDtype+"",
		                 "RRSDtype should be validated successfully"+RRSDtype+"",
		                  "RRSDtype is not validated successfully "+RRSDtype+"");
			      	}
			    }

	 /****************************************
	 	 * Name: ValidateAllocationARAmount
	     *Description: ValidateAllocationARAmount
	     * Date:29-Mar-2018 
	     ****************************************/  	 
	 public void ValidateAllocationARAmount(DataRow input, DataRow output) throws InterruptedException
	    {
	 
	 		SleepUtils.sleep(TimeSlab.YIELD);
	    
	    String AllocatedAramount=uiDriver.getValue("ARAmountLine1");
	      if(AllocatedAramount.equals("0.00"))
	    {
	    	
	    	passed("Validated AllocatedAramount "+AllocatedAramount+"",
                 "AllocatedAramount should be validated successfully"+AllocatedAramount+"",
                  "SuccessFully Validated AllocatedAramount"+AllocatedAramount+"");
	    }
	      else
	      {
	    	  failed("Not Validated AllocatedAramount "+AllocatedAramount+"",
                 "AllocatedAramount should be validated successfully"+AllocatedAramount+"",
                  "AllocatedAramount is not validated successfully "+AllocatedAramount+"");
	      }
	    }
	 

	
	 /****************************************
		 * Name: EditContractWizard
		 * Description: EditContractWizard
		 *  Date: 11-July-2018
		 ****************************************/
	/*	public void EditMultipleContractWizard(DataRow input, DataRow output) {
			
			uiDriver.executeJavaScript("(scroll(0,-300));");
			uiDriver.click("Edit");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("Next");
			SleepUtils.sleep(TimeSlab.MEDIUM);
		//	uiDriver.click("MarketCode");
			String ContractLineFilter  = uiDriver.getDyanmicData("ContractLineFilters");
			String titleValues = ContractLineFilter.replace("#",input.get("title"));
			uiDriver.setValue(titleValues, input.get("titleVal"));
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("ApplyFilters");
 			SleepUtils.sleep(TimeSlab.YIELD);
			SleepUtils.sleep(TimeSlab.YIELD);
			List<WebElement> ContractLines = uiDriver.webDr.findElements(By.xpath("//*[@id='contract_lines_splits']//tr"));
			int MC = ContractLines.size();
		/*	for (int i = 0; i < MC - 1; i++) {
				
				String FMV = uiDriver.getDyanmicData("FMV");
				String FMVVal = FMV.replace("#", Integer.toString(i));
				uiDriver.setValue(FMVVal, input.get("ContractValues"));
				SleepUtils.sleep(TimeSlab.LOW);
			}

			uiDriver.executeJavaScript("(scroll(0,-300));");
			SleepUtils.sleep(TimeSlab.HIGH);
			for (int j = 0; j < MC - 1; j++) {
				String Chkbox = uiDriver.getDyanmicData("chkbox");
				String ChkboxChk = Chkbox.replace("#", Integer.toString(j));
				uiDriver.focus(ChkboxChk);
				// uiDriver.click_dynamic(ChkboxChk);
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.executeJavaScript("(scroll(0,300));");
				SleepUtils.sleep(TimeSlab.LOW);
			}
			for (int i = 0; i < MC - 1; i++) {
				
				String ProductOwner = uiDriver.getDyanmicData("ProductOwner");
				String ProductOwnerVal = ProductOwner.replace("#", Integer.toString(i));
				uiDriver.setValue(ProductOwnerVal, input.get("ProductOwnerValues"));
				SleepUtils.sleep(TimeSlab.LOW);
			}
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.executeJavaScript("(scroll(0,-1500));");
			uiDriver.click("MoveDown");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.executeJavaScript("(scroll(0,-1500));");
			uiDriver.executeJavaScript("(scroll(0,1500));");
			uiDriver.click("Save");
			SleepUtils.sleep(TimeSlab.HIGH);
			SleepUtils.sleep(TimeSlab.HIGH);
		}*/
		
		
	public void EditMultipleContractWizard(DataRow input, DataRow output) {
			
			uiDriver.executeJavaScript("(scroll(0,-300));");
			uiDriver.click("Edit");
			SleepUtils.sleep(TimeSlab.HIGH);
			if(input.get("SHIPTO").equals("Y")){
				uiDriver.setValue("//*[@id='inpt_tax_address_list1']", input.get("TaxAddress"));
		
			}	
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("Next");
			SleepUtils.sleep(TimeSlab.HIGH);
			String ContractLineFilter  = uiDriver.getDyanmicData("ContractLineFilters");
			String titleValues = ContractLineFilter.replace("#",input.get("title"));
			uiDriver.setValue(titleValues, input.get("titleVal"));
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("ApplyFilters");
 			SleepUtils.sleep(TimeSlab.YIELD);
			SleepUtils.sleep(TimeSlab.YIELD);
			if(uiDriver.checkElementPresent("//*[@id='pagination_selector_fs']/div[1]/input")){
				uiDriver.click("//*[@id='pagination_selector_fs']/div[1]/span");
				List<WebElement> fil = uiDriver.webDr.findElements(By.xpath("//div[@class='dropdownDiv']/div"));
				int filter = fil.size();
				for(int i=1;i<=filter;i++){
				if(i!=1){
					uiDriver.click("//*[@id='pagination_selector_fs']/div[1]/span");
					}
					String filterval = uiDriver.getDyanmicData("filters");
					String values = filterval.replace("#", Integer.toString(i));
					uiDriver.click_dynamic(values);
					SleepUtils.sleep(TimeSlab.HIGH);
					List<WebElement> ContractLines = uiDriver.webDr.findElements(By.xpath("//*[@id='contract_lines_splits']//tr"));
					int MC = ContractLines.size();
					uiDriver.executeJavaScript("(scroll(0,-300));");
					SleepUtils.sleep(TimeSlab.HIGH);
				
					if(input.get("Product").equals("Y")){
					for (int k = 0; k< MC - 1; k++) {
						
						String ProductOwner = uiDriver.getDyanmicData("ProductOwner");
						String ProductOwnerVal = ProductOwner.replace("#", Integer.toString(k));
						uiDriver.setValue(ProductOwnerVal, input.get("ProductOwnerValues"));
						SleepUtils.sleep(TimeSlab.LOW);
					}
					}
					
					if(input.get("ContractVal").equals("Y")){
						
						for (int l = 0; l < MC - 1; l++) {
							
							String FMV = uiDriver.getDyanmicData("FMV");
							String FMVVal = FMV.replace("#", Integer.toString(l));
							uiDriver.setValue(FMVVal, input.get("ContractValues"));
							SleepUtils.sleep(TimeSlab.LOW);
						}	
					
					}
					
					for (int j = 1; j < MC ; j++) {
						//String chkboxStatuses = uiDriver.getAttribute("Chkboxes", "class");
						String Chkbox = uiDriver.getDyanmicData("chkbox");
						String ChkboxChk = Chkbox.replace("#", Integer.toString(j));
						String chkboxArr[] = ChkboxChk.split("=");
						String chkboxVal = chkboxArr[1];
						String SelectedChkbox = chkboxVal.replace("\"", "");
						String actualSelectedValue = SelectedChkbox.replace("]", "").trim();
						SleepUtils.sleep(TimeSlab.LOW);
						uiDriver.executeJavaScript("document.getElementById('"+actualSelectedValue+"').click();");
						/*Actions action = new Actions(uiDriver.webDr);
			            WebElement ele = uiDriver.webDr.findElement(By.xpath(ChkboxChk));
			        	SleepUtils.sleep(TimeSlabLOW);
			            action.moveToElement(ele).click().build().perform();*/
			            SleepUtils.sleep(TimeSlab.MEDIUM);
					}
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.executeJavaScript("(scroll(0,-1500));");
					uiDriver.click("MoveDown");
					SleepUtils.sleep(TimeSlab.MEDIUM);
					
				}
				uiDriver.click("Save");
				SleepUtils.sleep(TimeSlab.HIGH);
				SleepUtils.sleep(TimeSlab.HIGH);
				SleepUtils.sleep(TimeSlab.HIGH);
			
			}
			else{
				
			//do nothing	
			}	
			
	
	}
	
	 /****************************************
	 * Name: ValidateWhtJournal
	 * Description: Validate cash adj journal in payment 
	 * Date: 13-mar-2019
	 ****************************************/

 
	
	
	public void ValidateWhtJournal(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
    	String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");
		uiDriver.executeJavaScript("scroll(0,500)");	
		uiDriver.click("relatedRecord");
		String Invoices = uiDriver.getDyanmicData("InvoiceLinks");
		String InvoiceLink = Invoices.replace("#",input.get("Amount"));
		uiDriver.click_dynamic(InvoiceLink);
		
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.executeJavaScript("scroll(0,500)");
		
		
		
		
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("relatedRecord");
		uiDriver.click("payment");
		SleepUtils.sleep(TimeSlab.MEDIUM);
        SleepUtils.sleep(TimeSlab.MEDIUM);
        uiDriver.executeJavaScript("scroll(0,500)");
        uiDriver.click("Relatedtransaction");
        SleepUtils.sleep(TimeSlab.LOW);
        uiDriver.click("Journalcashadj");
        SleepUtils.sleep(TimeSlab.LOW);
        uiDriver.executeJavaScript("scroll(0,500)");
        
        // Validating journal
        
        int invoiceRow = 2;
		int accRows = uiDriver.webDr.findElements(By.xpath("//table[contains(@id,'line_splits')]//tbody/tr")).size();
		for (int i = 0; i < accRows - 1; i++) {
			if (uiDriver.getValue("//table[contains(@id,'line_splits')]//tbody/tr["+ invoiceRow + "]/td[1]").contains("11015051 USL Cash Clearing"))

			{
				if (uiDriver.getValue("//table[contains(@id,'line_splits')]//tbody/tr["+ invoiceRow + "]/td[3]").equals("")) {
					failed("Validating Credit Amount",
							"Validating Credit Amount should be successfull",
							"Credit amount is not USL Cash Clearing");
				} else {
					passed("Credit is USL Cash Clearing",
							"Credit is USL Cash Clearing",
							"Credit amount is "+uiDriver.getValue_Text("//table[contains(@id,'line_splits')]//tbody/tr["+ invoiceRow + "]/td[3]"));
				}
			}
			
			if (uiDriver.getValue("//table[contains(@id,'line_splits')]//tbody/tr["+ invoiceRow + "]/td[1]").contains("74300391 WHT Expense"))

			{
				if (uiDriver.getValue("//table[contains(@id,'line_splits')]//tbody/tr["+ invoiceRow + "]/td[3]").equals("")) {
					failed("Validating DEBIT Amount",
							"Validating DEBIT Amount should be successfull",
							"DEBIT amount is not  WHT Expense");
				} else {
					passed("DEBIT is  WHT Expense",
							"DEBIT is  WHT Expense",
							"DEBIT amount is  WHT Expense" +uiDriver.getValue_Text("//table[contains(@id,'line_splits')]//tbody/tr["+ invoiceRow + "]/td[2]"));
				}
				
			}
			invoiceRow++;

			
			
		}
        
    
	}
	
	
	public void ValidateCreditmemosalesAnB(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
    	String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Mastercontract");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");
		uiDriver.executeJavaScript("scroll(0,500)");
		String CreditMemoNo=uiDriver.getDyanmicData("CreditmemoNum");
		String CreditPath=CreditMemoNo.replace("#",input.get("CreditAmount"));
		String CreditNum= uiDriver.getValue_Text(CreditPath);
		SleepUtils.sleep(TimeSlab.LOW);
		String CreditMemoDate=uiDriver.getDyanmicData("Creditmemo");
		String CMDLink=CreditMemoDate.replace("#",input.get("CreditAmount"));
		uiDriver.click_dynamic(CMDLink);
		SleepUtils.sleep(TimeSlab.HIGH);
		String Creditmemotype= uiDriver.getValue("Creditmemotype");
		System.out.println(input.get("Creditmemotype"));
		
		if(input.get("Creditmemotype").contains(Creditmemotype)) {
			passed("Credit memo type ", "Credit memo type Should be displayed as" +Creditmemotype,
					"Credit memo type is displayed Successfully as" +Creditmemotype);
			
			
		}
		String NumB =Num +'B';
		uiDriver.setValue("SearchSO", NumB);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.executeJavaScript("scroll(0,400)");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//span[text()='R']");
		SleepUtils.sleep(TimeSlab.LOW);
		String invoices = uiDriver.getDyanmicData("Invoices");
		String invoice = invoices.replace("#",input.get("invoiceAmount")); 
		uiDriver.click_dynamic(invoice);
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,400)");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//span[text()='R']");
		if(uiDriver.getValue("CreditmemoNum1").contains(CreditNum)) {
			passed("CreditMemo num ", "Credit memo Num Should be displayed as" +CreditNum,
					"Credit memo Num is displayed Successfully as" +CreditNum);
			
			
		}
		
	}
	public void NavigatetoCreditMemo(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
    	String Num = input.get("conf");
		uiDriver.setValue("//*[@id='_searchstring']", Num);
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//*[text()='Master Contract Parent: ']");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");
		uiDriver.executeJavaScript("scroll(0,500)");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String CreditMemoNo=uiDriver.getDyanmicData("CreditmemoNum");
		String CreditPath=CreditMemoNo.replace("#",input.get("CreditAmount"));
		String CreditNum= uiDriver.getValue_Text(CreditPath);
		SleepUtils.sleep(TimeSlab.LOW);
		String CreditMemoDate=uiDriver.getDyanmicData("Creditmemo");
		String CMDLink=CreditMemoDate.replace("#",input.get("CreditAmount"));
		uiDriver.click_dynamic(CMDLink);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		/*String CreditNum= uiDriver.getValue("//*[text()='Credit Memo']/following::a[1]");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//*[text()='Credit Memo']/preceding::a[1]")*/;
		
	}
	
	public void NavigateToPaymentWizard(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.mouseOver("//li[@data-title='Transactions']//span[text()='Transactions']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.mouseOver("//li[@data-title='Customers']//span[text()='Customers']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.mouseOver("//li[@data-title='Payment Wizard']//span[text()='Payment Wizard']");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//li[@data-title='Payment Wizard']//span[text()='Payment Wizard']");
		SleepUtils.sleep(TimeSlab.HIGH);
		
		if(uiDriver.checkElementPresent("//h1[@class='uir-record-type' and contains(text(),'Payment Wizard: Select Customer')]")) {
			passed("NavigateToPaymentWizard", "Payment Wizard Screen Should be displayed",
					"Payment Wizard Screen is displayed");
		} else {
			failed("NavigateToPaymentWizard", "Payment Wizard Screen Should be displayed",
					"Payment Wizard Screen is not displayed");
		}
	}
	
	public void PaymentWizardPayment(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.setValue("//input[@name='inpt_custpage_subsidiary']", input.get("Subsidiary"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("//input[@name='inpt_custpage_customer']", input.get("Customer"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//input[@value='Next']");
		SleepUtils.sleep(TimeSlab.HIGH);
		if(uiDriver.checkElementPresent("//h1[@class='uir-record-type' and contains(text(),'Payment Wizard: Set Up Payment')]")) {
			passed("PaymentWizardPayment", "SetUp Payment Screen Should be displayed",
					"SetUp Payment Screen is displayed");
		} else {
			failed("PaymentWizardPayment", "SetUp Payment Screen Should be displayed",
					"SetUp Payment Screen is not displayed");
		}
		
		uiDriver.setValue("//input[@name='inpt_custpage_currency']", input.get("Currency"));
		SleepUtils.sleep(TimeSlab.LOW);
		//uiDriver.setValue("//span[@id='custpage_exchange_rate_fs']//input", input.get("ExchangeRate"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("//input[@name='inpt_custpage_account']", input.get("Account"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("//input[@name='inpt_custpage_ar_account']", input.get("AR Account"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("//span[@id='custpage_true_cash_amount_fs']//input[@onkeyup]", input.get("True Cash"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("(//input[@value='Next'])[2]");
		SleepUtils.sleep(TimeSlab.HIGH);
		if(uiDriver.checkElementPresent("//h1[@class='uir-record-type' and contains(text(),'Payment Wizard: Apply Payment')]")) {
			passed("PaymentWizardPayment", "Apply Payment Screen Should be displayed",
					"Apply Payment Screen is displayed");
		} else {
			failed("PaymentWizardPayment", "Apply Payment Screen Should be displayed",
					"Apply Payment Screen is not displayed");
		}
		
		for(int i=0; i<list_InvoiceNumbers.size(); i++) {
			String temp = list_InvoiceNumbers.get(i).substring(0, list_InvoiceNumbers.get(i).length()-1);
			uiDriver.setValue("//input[@name='custpage_filter_master_invoice_number']", temp);
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//input[@id='custpage_do_filter']");
			SleepUtils.sleep(TimeSlab.HIGH);
			uiDriver.click("//td[text()='"+temp+"']//preceding-sibling::td/span");
		 
		}
		uiDriver.click("//input[@id='secondarysubmitter']");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.handleAlert("", "OK");
		SleepUtils.sleep(TimeSlab.HIGH);
		if(uiDriver.checkElementPresent("//h1[@class='uir-record-type' and text()='Payment']") && 
				uiDriver.checkElementPresent("//div[@class='uir-record-status' and text()='Deposited']")) {
			passed("PaymentWizardPayment", "Payment should be done successfully",
					"Payment is done successfully");
		} else {
			failed("PaymentWizardPayment", "Payment should be done successfully",
					"Payment is not done successfully");
		}
	}

	/****************************************
	 * Name: Validate Netsuite after generation of armr invoice 
	 * Date: 29-mar-2019
	 * 
	 * Description:Checks if the Item coloum is replaced by placeholder to title
	 *
	 ****************************************/
	public void ValidateNsAfterArmrInv(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,500)");
		List<WebElement> lst=uiDriver.webDr.findElements(By.xpath("//*[@id='item_splits']/tbody/tr"));
		
		for(int i=2;i <=lst.size() ;i++) {
			
			if(uiDriver.getValue("//*[@id='item_splits']/tbody/tr["+i+"]/td/a").equalsIgnoreCase(input.get("ITEM"))) {
				passed("Validation in Netsuite", " Placeholder in coloum item should be replaced with "+input.get("ITEM"),
						"Placeholder in coloum item is replaced with "+uiDriver.getValue("//*[@id='item_splits']/tbody/tr["+i+"]/td/a"));
			}
			else {
				failed("Validation in Netsuite", " Placeholder in coloum item should be replaced with "+input.get("ITEM"),
						"Placeholder in coloum item is replaced with "+uiDriver.getValue("//*[@id='item_splits']/tbody/tr["+i+"]/td/a"));
			}
			
			if(uiDriver.getValue("//*[@id='item_splits']/tbody/tr["+i+"]/td[3]").equalsIgnoreCase(input.get("SUBTYPE"))) {
				passed("Validation in Netsuite", " Subtype for each line should be "+input.get("SUBTYPE"),
						" Subtype for each line is "+uiDriver.getValue("//*[@id='item_splits']/tbody/tr["+i+"]/td[3]"));
			}
			else {
				failed("Validation in Netsuite", " Subtype for each line should be "+input.get("SUBTYPE"),
						" Subtype for each line is "+uiDriver.getValue("//*[@id='item_splits']/tbody/tr["+i+"]/td[3]"));
			}
			if(uiDriver.getValue("//*[@id='item_splits']/tbody/tr["+i+"]/td[12]").equalsIgnoreCase(input.get("MARKET CODE"))) {
				passed("Validation in Netsuite", " Market code  for each line should be "+input.get("MARKET CODE"),
						"Market code for each line is "+uiDriver.getValue("//*[@id='item_splits']/tbody/tr["+i+"]/td[13]"));
			}
			else {
				failed("Validation in Netsuite", " Market code  for each line should be "+input.get("MARKET CODE"),
						"Market code for each line is "+uiDriver.getValue("//*[@id='item_splits']/tbody/tr["+i+"]/td[13]"));
			}
			if(uiDriver.getValue("//*[@id='item_splits']/tbody/tr["+i+"]/td[30]").equalsIgnoreCase(input.get("REVENUE RECOGNITION METHOD"))) {
				passed("Validation in Netsuite", " Revenue Recognition Method on each line should be "+input.get("REVENUE RECOGNITION METHOD"),
						"Revenue Recognition Method on each line is "+uiDriver.getValue("//*[@id='item_splits']/tbody/tr["+i+"]/td[31]"));
			}
			else {
				failed("Validation in Netsuite", " Revenue Recognition Method on each line should be "+input.get("REVENUE RECOGNITION METHOD"),
						"Revenue Recognition Method on each line is "+uiDriver.getValue("//*[@id='item_splits']/tbody/tr["+i+"]/td[31]"));
			}
		}
		
	}
	
	/****************************************
	 * Name: Validate Netsuite after generation of Customer Credit 
	 * Date: 04-April-2019
	 * 
	 * Description:Validate Netsuite after generation of Customer Credit
	 *
	 ****************************************/
	public void ValidateNSCustomerCredit(DataRow input, DataRow output) {
	
		SleepUtils.sleep(TimeSlab.LOW);
		
		for(int i=0;i<60;i++){
			uiDriver.click("//a[@id='rlrcdstabtxt']"); //Related Records
			SleepUtils.sleep(TimeSlab.LOW);
			if(uiDriver.checkElementPresent("//td[text()='Customer Credit']")) {
				break;
			}
			else{
				SleepUtils.sleep(10);
				uiDriver.refresh();	
			}
		}
		
		if(uiDriver.checkElementPresent("//td[text()='Customer Credit']")) {
			passed("ValidateNSCustomerCredit", 
					"Customer Credit details should be displayed",
					"Customer Credit details is displayed");
			
			uiDriver.click("//td[text()='Customer Credit']//..//td//a"); //Date link
			SleepUtils.sleep(TimeSlab.MEDIUM);
			
			String ActualTotalAmount = uiDriver.getValue("//span[@id='total_fs_lbl_uir_label']//..//span[@class='uir-field inputreadonly']"); //Actual Total Amount
			String ExpectedTotalAmount = input.get("TotalAmount");
			if(ExpectedTotalAmount.trim().equalsIgnoreCase(ActualTotalAmount.trim())) {
				passed("ValidateNSCustomerCredit", 
						"Customer Credit Total Amount should be displayed and matched",
						"Customer Credit details is displayed and matched");
			} else {
				failed("ValidateNSCustomerCredit", 
						"Customer Credit Total Amount should be displayed and matched",
						"Customer Credit details is either not displayed or not matched");
			}
			
		} else {
			failed("ValidateNSCustomerCredit", 
					"Customer Credit details should be displayed",
					"Customer Credit details is not displayed");
		}
	
	}
	
	/****************************************
	 * Name: ValidateNSMasterCredit
	 * Date: 04-April-2019
	 * 
	 * Description:Validate ValidateNSMasterCredit
	 *
	 ****************************************/
	public void ValidateNSMasterCredit(DataRow input, DataRow output) {
	
		SleepUtils.sleep(TimeSlab.MEDIUM);
    	String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Mastercontract");
		passed("ValidateNSMasterCredit", "Master Order Should be displayed Successfully",
				"Master Order is displayed Successfully");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,500)");
		
		for(int i=0;i<60;i++){
			if(uiDriver.checkElementPresent("//td[text()='Customer Credit']")) {
				break;
			}
			else{
				SleepUtils.sleep(10);
				uiDriver.refresh();
			}
		}
		
		if(uiDriver.checkElementPresent("//td[text()='Credit Memo']//..//td[1]//a")) {
			passed("ValidateNSMasterCredit", 
					"Master Credit details should be displayed in Master Contract",
					"Master Credit details is displayed in Master Contract");
			
			List<WebElement> list_MasterCreditMemo = uiDriver.webDr.findElements(By.xpath("//td[text()='Credit Memo']//..//td[1]//a"));
			int count = list_MasterCreditMemo.size();
			int flag = 0;
			for(int i=count-1; i>=0; i--) {
				SleepUtils.sleep(TimeSlab.HIGH);
				list_MasterCreditMemo.get(i).click();
				SleepUtils.sleep(TimeSlab.MEDIUM);
				String ActualStatus = uiDriver.getValue("//div[@class='uir-record-status']");
				String ExpectedStatus = input.get("Status");
				if(ExpectedStatus.trim().equalsIgnoreCase(ActualStatus.trim())) {
					flag = 1;		
					passed("ValidateNSMasterCredit", 
							"Master Credit Status should be displayed and matched",
							"Master Credit Status is displayed and matched");

					String ActualTotalAmount = uiDriver.getValue("//span[@id='total_fs_lbl_uir_label']//..//span[@class='uir-field inputreadonly']"); //Actual Total Amount
					String ExpectedTotalAmount = input.get("TotalAmount");
					if(ExpectedTotalAmount.trim().equalsIgnoreCase(ActualTotalAmount.trim())) {
						passed("ValidateNSMasterCredit", 
								"Master Credit Total Amount should be displayed and matched",
								"Master Credit details is displayed and matched");
					} else {
						failed("ValidateNSMasterCredit", 
								"Master Credit Total Amount should be displayed and matched",
								"Master Credit details is either not displayed or not matched");
					}
					
					break;
				}
				uiDriver.click("//input[@value='Back']"); //Back button
				SleepUtils.sleep(TimeSlab.LOW);
			}
			if(flag == 0) {				
				failed("ValidateNSMasterCredit", 
						"Master Credit Status should be displayed and matched",
						"Master Credit Status is either not displayed or not matched");
			}
			
		} else {
			failed("ValidateNSMasterCredit", 
					"Master Credit details should be displayed in Master Contract",
					"Master Credit details is not displayed in Master Contract");
		}
		
		uiDriver.click("//a[text()='Master Credit Memo Parent']//..//..//..//span[@class='inputreadonly']//a"); //Master Credit Memo Parent
	}
	
	/****************************************
	 * Name: ValidateNSMasterCreditMemoParentPDF
	 * Date: 04-April-2019
	 * 
	 * Description:ValidateNSMasterCreditMemoParentPDF
	 *
	 ****************************************/
	public void ValidateNSMasterCreditMemoParentPDF(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("//*[text()='download']"); //Download button
		SleepUtils.sleep(TimeSlab.HIGH);
		
		uiDriver.back();
		SleepUtils.sleep(TimeSlab.HIGH);
	}
	
	/****************************************
	 * Name: ValidateWhtJournal Description: Validate cash adj journal in payment
	 * Date: 13-mar-2019
	 * 
	 * @throws InterruptedException
	 ****************************************/

	public void ValidatePaymentJournal(DataRow input, DataRow output) throws InterruptedException {
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully", "SalesOrder is displayed Successfully");
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("relatedRecord");
		String Invoices = uiDriver.getDyanmicData("InvoiceLinks");
		String InvoiceLink = Invoices.replace("#", input.get("TotalAmount"));
		uiDriver.click_dynamic(InvoiceLink);

		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.executeJavaScript("scroll(0,500)");

		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("relatedRecord");
		uiDriver.click("payment");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.executeJavaScript("scroll(0,500)");
		WebElement w = uiDriver.webDr.findElement(By.xpath("//*[contains(text(),'lated Transactions')]"));
		String id = w.getAttribute("id");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("scroll(0,-1000)");
		// if(uiDriver.checkElementPresent_dynamic("reclassJEntry")){
		uiDriver.executeJavaScript("document.getElementById('" + id + "').click();");
		SleepUtils.sleep(TimeSlab.LOW);
		
		int RowSize;
		if(uiDriver.checkElementPresent("//*[@id='recmachcustbody_nbcu_related_record__tab']//tr")) {
		List<WebElement> reclasslink = uiDriver.webDr
				.findElements(By.xpath("//*[@id='recmachcustbody_nbcu_related_record__tab']//tr"));
		 RowSize = reclasslink.size();
		}
		else {
			List<WebElement> reclasslink = uiDriver.webDr
					.findElements(By.xpath("//*[@id='customsublist11__div']//tbody//tr"));
			 RowSize = reclasslink.size();
		}
		Thread.sleep(5);
		for (int r = 1; r <=RowSize; r++) {

			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.executeJavaScript("scroll(0,500)");
			uiDriver.executeJavaScript("document.getElementById('" + id + "').click();");
			// Validating journal
			String s1 = uiDriver.getDyanmicData("DocNum");
			String s2 = s1.replace("#", Integer.toString(r));
			if (uiDriver.checkElementPresent_dynamic(s2)) {
				uiDriver.click(s2);
				passed("Click On the Revenue Paln Number " + s2 + "",
						"Should be SuccessFully Clicked on Revenue Paln Number " + s2 + "",
						"SuccessFully Clicked on Revenue Paln Number " + s2 + "");
				int invoiceRow = 2;
				int accRows = uiDriver.webDr.findElements(By.xpath("//table[contains(@id,'line_splits')]//tbody/tr"))
						.size();
				for (int i = 0; i < accRows - 1; i++) {
					if (uiDriver.getValue("//table[contains(@id,'line_splits')]//tbody/tr[" + invoiceRow + "]/td[1]")
							.contains("11015051 USL Cash Clearing"))

					{
						if (uiDriver
								.getValue("//table[contains(@id,'line_splits')]//tbody/tr[" + invoiceRow + "]/td[3]")
								.equals("")) {
							failed("Validating Credit Amount", "Validating Credit Amount should be successfull",
									"Credit amount is not USL Cash Clearing");
						} else {
							passed("Credit is USL Cash Clearing", "Credit is USL Cash Clearing",
									"Credit amount is "
											+ uiDriver.getValue_Text("//table[contains(@id,'line_splits')]//tbody/tr["
													+ invoiceRow + "]/td[3]"));
						}
					}

					if (uiDriver.getValue("//table[contains(@id,'line_splits')]//tbody/tr[" + invoiceRow + "]/td[1]")
							.contains("74300391 WHT Expense"))

					{
						if (uiDriver
								.getValue("//table[contains(@id,'line_splits')]//tbody/tr[" + invoiceRow + "]/td[3]")
								.equals("")) {
							passed("DEBIT is  WHT Expense", "DEBIT is  WHT Expense",
									"DEBIT amount is  WHT Expense"
											+ uiDriver.getValue_Text("//table[contains(@id,'line_splits')]//tbody/tr["
													+ invoiceRow + "]/td[2]"));
						} else {
							passed("DEBIT is  WHT Expense", "DEBIT is  WHT Expense",
									"DEBIT amount is  WHT Expense"
											+ uiDriver.getValue_Text("//table[contains(@id,'line_splits')]//tbody/tr["
													+ invoiceRow + "]/td[2]"));
						}

					}

					invoiceRow++;

				}
			}
			uiDriver.executeJavaScript("scroll(0,-15000)");
			try {
			WebElement w1 = uiDriver.webDr.findElement(By.xpath("//*[@value='Back' and @name='_back']"));
			String s = w1.getAttribute("id");
			uiDriver.executeJavaScript("document.getElementById('" + s + "').click();");
			} catch(Exception e) {
				uiDriver.back();
			}

		}

	}
	
	/****************************************
   	 * Name:Validatetitlelicensefee
   	 * Description:Validate title license fee
   	 *  Date:30-April-2018 
   	 ****************************************/
       public void Validatetitlelicensefee(DataRow input, DataRow output) 
       {
       	
       	SleepUtils.sleep(TimeSlab.HIGH);
       	uiDriver.click("Mastercontract");
       	SleepUtils.sleep(TimeSlab.HIGH);
       	uiDriver.click("(//table[@id='customsublist20__tab']//tr)[2]//td[3]/a");
       	SleepUtils.sleep(TimeSlab.HIGH);
       	uiDriver.executeJavaScript("scroll(0,400)");
       	SleepUtils.sleep(TimeSlab.LOW);
       	List<WebElement> fil = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']/tbody/tr"));
		int filter = fil.size();
		
		for(int i=2;i<=filter;i++)
		{
			String title=uiDriver.getValueByText("//table[@id='item_splits']/tbody/tr["+i+"]/td[5]/a");
			String amount=uiDriver.getValueByText("//table[@id='item_splits']/tbody/tr["+i+"]/td[17]");
			String Territory=uiDriver.getValueByText("//table[@id='item_splits']/tbody/tr["+i+"]/td[11]");
			String Subtype=uiDriver.getValueByText("//table[@id='item_splits']/tbody/tr["+i+"]/td[3]");
			String PRODUCTTYPE=uiDriver.getValueByText("//table[@id='item_splits']/tbody/tr["+i+"]/td[8]");
			String Marketcode=uiDriver.getValueByText("//table[@id='item_splits']/tbody/tr["+i+"]/td[13]");
			String Right=uiDriver.getValueByText("//table[@id='item_splits']/tbody/tr["+i+"]/td[12]");
			
			passed("Validate Title license fee", "For title "+title+" "
					+ ",Amount should be "+amount+" Territory should be "+Territory+" Subtype should be "+Subtype+" PRODUCTTYPE should be "+PRODUCTTYPE+" Marketcode should be "+Marketcode+
					" Right should be "+Right,
					"For title "+title+" "
					+ ",Amount is  "+amount+" Territory is "+Territory+" Subtype  is "+Subtype+" PRODUCTTYPE is "+PRODUCTTYPE+" Marketcode is "+Marketcode+
					" Right is"+Right);
	
		}
       }
       
       /****************************************
		 * Name: ValidateRevRecMethodNS_PULAK
		 * Description: ValidateRevenueRecognitionMethodNS_PULAK
		 * Date: 21-June-2019
		 ****************************************/		
		public void ValidateRevRecMethodNS_PULAK(DataRow input, DataRow output){
			
			String Titles = input.get("TitleName");
			String Title[] = Titles.split(";");
			String Methods = input.get("RevRecMethod");
			String Method[] = Methods.split(";");
			
			for(int i=0; i<Title.length; i++) {				
				String actual_RevRecMethod = uiDriver.getValue("//a[contains(text(),'"+Title[i].trim()+"')]//..//..//td[31]");
				String expected_RevRecMethod = Method[i].trim();
				
				if(expected_RevRecMethod.equalsIgnoreCase(actual_RevRecMethod)) {
					passed("ValidateRevRecMethodNS_PULAK",
							expected_RevRecMethod+" Revenue Recognition Method should be displayed for Title "+Title[i].trim(),
							actual_RevRecMethod+" Revenue Recognition Method is displayed for Title "+Title[i].trim());
				} else {
					failed("ValidateRevRecMethodNS_PULAK",
							expected_RevRecMethod+" Revenue Recognition Method should be displayed for Title "+Title[i].trim(),
							actual_RevRecMethod+" Revenue Recognition Method is displayed for Title "+Title[i].trim());
				}
			}
		}
		
		/****************************************
		 * Name: ExecuteCustomizationScript
		 * Description: ExecuteCustomizationScript 
		 * Date: 24-June-2019
		 ****************************************/
		public void ExecuteCustomizationScript(DataRow input, DataRow output) throws InterruptedException {
			
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.mouseOver("//span[text()='Customization']");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.mouseOver("//span[text()='Scripting']");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.mouseOver("//span[contains(text(),'Scripts')]");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//span[contains(text(),'Scripts')]");
			SleepUtils.sleep(TimeSlab.YIELD);
			SleepUtils.sleep(TimeSlab.LOW);
			String option_ScriptName = input.get("option_ScriptName");
			String xpath_ScriptName = "//td[text()='"+option_ScriptName+"']//..//a[text()='Edit']";
			if(uiDriver.checkElementPresent(xpath_ScriptName)) {
				uiDriver.click(xpath_ScriptName);
			}
			else {
				uiDriver.click("//*[@id='segment_fs']/span[1]/span");
				SleepUtils.sleep(TimeSlab.HIGH);
				String option_Dropdown1 = input.get("option_Dropdown1");
				String option_Dropdown2 = input.get("option_Dropdown2");
				String option_Dropdown = "//a[contains(@title,'"+option_Dropdown1+"') and contains(@title,'"+option_Dropdown2+"')]";
				uiDriver.click(option_Dropdown);
				SleepUtils.sleep(TimeSlab.HIGH);
				uiDriver.click(xpath_ScriptName);
				SleepUtils.sleep(TimeSlab.LOW);
			}
			uiDriver.click("//*[@id='scriptdeploymentstxt']");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//*[@id='deploymentsrow1']/td/a");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//*[@id='edit']");
			SleepUtils.sleep(TimeSlab.LOW);
			if(uiDriver.checkElementPresent("//td[@role='menuitem']/a/span[text()='Save and Execute']")) {	
				uiDriver.click("//td[@role='menuitem']/a/span[text()='Save and Execute']");
				uiDriver.handleAlert("", "OK");
			}
			else {
				for(int i=0;i<=50;i++) {
					SleepUtils.sleep(30);
					uiDriver.refresh();		
					uiDriver.mouseOver("//*[@id='main_form']/table/tbody/tr[1]/td/table/tbody/tr/td/table/tbody/tr/td[1]/table/tbody/tr/td[3]");
					System.out.println("***********************"+i);
					if(uiDriver.checkElementPresent("//td[@role='menuitem']/a/span[text()='Save and Execute']")) {	
						uiDriver.click("//td[@role='menuitem']/a/span[text()='Save and Execute']");
						uiDriver.handleAlert("", "OK");
						break;
					}
				}	
			}
			uiDriver.refresh();	
			SleepUtils.sleep(30);
			uiDriver.refresh();	
			for(int i=0;i<=50;i++){
				SleepUtils.sleep(30);
				uiDriver.refresh();			
				System.out.println("***********************"+i);
				System.out.println(uiDriver.getValue("//*[@id='row0']/td[6]"));
				if(uiDriver.getValue("//*[@id='row0']/td[6]").equalsIgnoreCase("Complete"))
					passed("Verify CompleteStatus",
							"CompleteStatus should be displayed successfully",
							"CompleteStatus is not displayed successfully");
				break;				
			}	
	  	}
		
		/****************************************
		 * Name: EditTitleDetails
		 * Description: EditTitleDetails
		 * Date: 25-June-2019
		 ****************************************/
		public void EditTitleDetails(DataRow input, DataRow output) throws InterruptedException {
			
		SleepUtils.sleep(TimeSlab.HIGH);
		String Num = input.get("conf");
		uiDriver.setValue("//*[@id='_searchstring']", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("//a[contains(text(),'Title: ')]");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		passed("Title", "Title Should be displayed Successfully", "Title is displayed Successfully");
		SleepUtils.sleep(5);

		if (uiDriver.checkElementPresent("//input[@id='edit']")) {
			uiDriver.click("//input[@id='edit']");
				SleepUtils.sleep(TimeSlab.LOW);
			}
			
			if(input.get("Name").equalsIgnoreCase("NA")) {				
			} else {				
				uiDriver.setValue("//input[@id='name']", input.get("Name"));
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			if(input.get("TitleName").equalsIgnoreCase("NA")) {				
			} else {				
				uiDriver.setValue("//input[@id='custrecord_nbcu_title_name']", input.get("TitleName"));
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			if(input.get("ProductOwner").equalsIgnoreCase("NA")) {				
			} else {				
				uiDriver.setValue("//input[@id='custrecord_nbcu_title_prod_owner']", input.get("ProductOwner"));
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			if(input.get("AirReleaseDate").equalsIgnoreCase("NA")) {				
			} else {				
				uiDriver.setValue("//input[@id='custrecord_nbcu_title_rdad']", input.get("AirReleaseDate"));
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			if(input.get("ProductType").equalsIgnoreCase("NA")) {				
			} else {			
				uiDriver.click("//img[@id='inpt_custrecord_nbcu_title_prod_type1_arrow']");
				SleepUtils.sleep(TimeSlab.YIELD);
				String ProductType = "//div[contains(@id,'nl') and text()='"+input.get("ProductType").trim()+"']";
				uiDriver.click(ProductType);
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			if(input.get("TitleCode").equalsIgnoreCase("NA")) {				
			} else {				
				uiDriver.setValue("//input[@id='custrecord_nbcu_title_ft_title_cd']", input.get("TitleCode"));
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			if(input.get("SeriesName").equalsIgnoreCase("NA")) {				
			} else {				
				uiDriver.setValue("//input[@id='custrecord_nbcu_series_title_name']", input.get("SeriesName"));
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			if(input.get("SeasonName").equalsIgnoreCase("NA")) {				
			} else {				
				uiDriver.setValue("//input[@id='custrecord_nbcu_season_title_name']", input.get("SeasonName"));
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			if(input.get("SeasonID").equalsIgnoreCase("NA")) {				
			} else {				
				uiDriver.setValue("//input[@id='custrecord_nbcu_season_id']", input.get("SeasonID"));
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			if(input.get("EpisodeID").equalsIgnoreCase("NA")) {				
			} else {				
				uiDriver.setValue("//input[@id='custrecord_nbcu_episode_id']", input.get("EpisodeID"));
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			if(input.get("TitleID").equalsIgnoreCase("NA")) {				
			} else {				
				uiDriver.setValue("//input[@id='custrecord_nbcu_title_number']", input.get("TitleID"));
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			
			if(uiDriver.checkElementPresent("//input[@id='btn_multibutton_submitter']")) {				
				uiDriver.click("//input[@id='btn_multibutton_submitter']");
				SleepUtils.sleep(TimeSlab.LOW);
			} else {
				uiDriver.click("//input[@id='btn_secondarymultibutton_submitter']");
				SleepUtils.sleep(TimeSlab.LOW);
			}
		}
		
		/****************************************
		 * Name: NavigateToCustomerSearch
		 * Description: NavigateToCustomerSearch
		 * Date: 19-July-2019
		 ****************************************/
		public void NavigateToCustomerSearch(DataRow input, DataRow output) throws InterruptedException {
			
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.mouseOver("//a//span[text()='Lists']");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.mouseOver("//a//span[text()='Relationships']");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.mouseOver("//a//span[text()='Customers']");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.mouseOver("(//a//span[text()='Search'])[1]");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("(//a//span[text()='Search'])[1]");
			SleepUtils.sleep(TimeSlab.LOW);
			
			uiDriver.setValue("//span[@id='Entity_ENTITYID_fs']//input", input.get("CustomerName"));
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//td[@id='tdbody_submitter']//input");
			SleepUtils.sleep(TimeSlab.LOW);
			if(uiDriver.checkElementPresent("//td[contains(text(),'"+input.get("CustomerName")+"')]")){
				passed("NavigateToCustomerSearch", 
						input.get("CustomerName")+" Customer should be displayed", 
						input.get("CustomerName")+" Customer is displayed");
			} else {
				failed("NavigateToCustomerSearch", 
						input.get("CustomerName")+" Customer should be displayed", 
						input.get("CustomerName")+" Customer is displayed");
			}
		}
		
		/****************************************
		 * Name: ValidateCustomerTaxRegNumber
		 * Description: ValidateCustomerTaxRegNumber
		 * Date: 19-July-2019
		 ****************************************/
		public void ValidateCustomerTaxRegNumber(DataRow input, DataRow output) throws InterruptedException {
			
			boolean flag = false;
			List<WebElement> list_CustomerRows = uiDriver.webDr.findElements(By.xpath("//td[contains(text(),'"+input.get("CustomerName")+"')]//..//..//tr"));
			for(int i=2; i<list_CustomerRows.size(); i++) {
				String actual_CustomerID = uiDriver.getValue("//td[contains(text(),'"+input.get("CustomerName")+"')]//..//..//tr["+i+"]//td//a[1]");
				if(input.get("CustomerID").contains(actual_CustomerID)) {			
					uiDriver.click("//td[contains(text(),'"+input.get("CustomerName")+"')]//..//..//tr["+i+"]//td//a[1]");
					SleepUtils.sleep(TimeSlab.LOW);
					uiDriver.executeJavaScript("scroll(0,200)");
					uiDriver.click("//a[@id='financialtxt']//span[text()='F']");
					SleepUtils.sleep(TimeSlab.YIELD);
					String actual_TaxRegNumber = uiDriver.getValue("//span[@id='resalenumber_fs_lbl_uir_label']/following-sibling::span");
					SleepUtils.sleep(TimeSlab.YIELD);
					if(input.get("TaxRegNumber").contains(actual_TaxRegNumber)) {
						flag = true;
						passed("ValidateCustomerTaxRegNumber", 
								input.get("TaxRegNumber")+" TaxRegNumber should be displayed for Customer "+input.get("CustomerName"), 
								actual_TaxRegNumber+" TaxRegNumber is displayed for Customer "+input.get("CustomerName")+" "+actual_CustomerID);
						break;
					} 
				}
			}
			if(flag == false){
				failed("ValidateCustomerTaxRegNumber", 
						input.get("TaxRegNumber")+" TaxRegNumber should be displayed for Customer "+input.get("CustomerName"), 
						input.get("TaxRegNumber")+" TaxRegNumber is not displayed for Customer "+input.get("CustomerName"));
			}
		}
		
			
	/****************************************
	 * Name: ValidateTitleAllocationTransactionJoural
	 * Description:ValidateTitleAllocationTransactionJoural
	 * Date: 06-Aug-2019
	 ****************************************/
		public void VerifyTitleAllocationJournal(DataRow input, DataRow output) throws InterruptedException {
			try {
				// Navigating to Sales Order
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.setValue("//input[@id='_searchstring']", input.get("conf"));
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.click("//a[contains(text(),'Sales Order:')]");
				SleepUtils.sleep(TimeSlab.LOW);
				if (uiDriver.checkElementPresent("//h1[text()='Sales Order']")) {
					passed("VerifyTitleAllocationJoural", "Sales Order Should be displayed", "Sales Order is displayed");
				} else {
					failed("VerifyTitleAllocationJoural", "Sales Order Should be displayed",
							"Sales Order is not displayed");
				}
				uiDriver.click("//a[@id='rlrcdstabtxt']");
				SleepUtils.sleep(TimeSlab.LOW);

				String TotalAmounts = input.get("TotalAmount");
				String TotalAmount[] = TotalAmounts.split(";");

				String JETypes = input.get("JEType");
				String JEType[] = JETypes.split(";");

				String Accounts = input.get("Account");
				String Account[] = Accounts.split(";");

				String Amounts = input.get("Amount");
				String Amount[] = Amounts.split(";");

				String Names = input.get("Name");
				String Name[] = Names.split(";");

				String Territories = input.get("Territory");
				String Territory[] = Territories.split(";");

				String MarketCodes = input.get("MarketCode");
				String MarketCode[] = MarketCodes.split(";");

				String GLPNs = input.get("GLPN");
				String GLPN[] = GLPNs.split(";");

				List<WebElement> Invoices = uiDriver.webDr.findElements(By.xpath("//td[text()='Invoice']//..//a"));
				int total_Invoices = Invoices.size();

				int flag = 0, x = 0;
				for (int i = 0; i < TotalAmount.length; i++) {
					// Navigating to Invoice matched with Amount specified in Test
					// Data
					((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView(true);",
							uiDriver.webDr.findElement(By.xpath("//a[@id='rlrcdstabtxt']")));
					((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();",
							uiDriver.webDr.findElement(By.xpath("//a[@id='rlrcdstabtxt']")));
					SleepUtils.sleep(TimeSlab.LOW);

					String xpath_Invoice = "//td[text()='Invoice']//..//td[text()='" + TotalAmount[i].trim() + "']//..//a";
					// uiDriver.click(xpath_Invoice);
					List<WebElement> element = uiDriver.webDr.findElements(By.xpath(xpath_Invoice));
					if (element.size() > 1) {
						((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView(true);",
								element.get(flag));
						((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();", element.get(flag));
						flag++;
					} else {
						((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView(true);",
								element.get(0));
						((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();", element.get(0));
					}
					SleepUtils.sleep(TimeSlab.LOW);
					if (uiDriver.checkElementPresent("//h1[text()='Invoice']")) {
						passed("VerifyTitleAllocationJoural", "Invoice Should be displayed", "Invoice is displayed");
					} else {
						failed("VerifyTitleAllocationJoural", "Invoice Should be displayed", "Invoice is not displayed");
					}
					uiDriver.executeJavaScript("scroll(0,500)");

					// Navigating to Title Allocation Parent
					uiDriver.click("//a[@id='customtxt']");
					SleepUtils.sleep(TimeSlab.LOW);
					uiDriver.executeJavaScript("scroll(0,1000)");
					uiDriver.click("//a[@id='recmachcustrecord_nbcu_titleallocpa_invoicetxt']");
					SleepUtils.sleep(TimeSlab.YIELD);
					String number_TitleAllocationParent = uiDriver
							.getValue("(//table[@id='recmachcustrecord_nbcu_titleallocpa_invoice__tab']//a)[1]");
					uiDriver.click("(//table[@id='recmachcustrecord_nbcu_titleallocpa_invoice__tab']//a)[1]");
					if (uiDriver.checkElementPresent("//h1[text()='Title Allocation Parent']")) {
						passed("VerifyTitleAllocationJoural", "Title Allocation Parent Should be displayed",
								"Title Allocation Parent is displayed");
					} else {
						failed("VerifyTitleAllocationJoural", "Title Allocation Parent Should be displayed",
								"Title Allocation Parent is not displayed");
					}
					uiDriver.executeJavaScript("scroll(0,500)");

					// Navigating to Allocation Transaction Details
					uiDriver.click("//a[text()='llocation Detail']");
					SleepUtils.sleep(TimeSlab.LOW);
					uiDriver.click("//a[@id='recmachcustbody_nbcu_titleallocationtxt']");
					SleepUtils.sleep(TimeSlab.YIELD);

					// Navigating to and validating Journals
					for (int j = 0; j < JEType.length; j++) {
						uiDriver.click("//a[text()='llocation Detail']");
						SleepUtils.sleep(TimeSlab.LOW);
						uiDriver.click("//a[@id='recmachcustbody_nbcu_titleallocationtxt']");
						SleepUtils.sleep(TimeSlab.YIELD);

						if (uiDriver.checkElementPresent("//td[text()='" + JEType[j].trim() + "']")) {
							passed("VerifyTitleAllocationJoural", JEType[j].trim() + " Journal Should be present",
									JEType[j].trim() + " Journal is present");
						} else {
							failed("VerifyTitleAllocationJoural", JEType[j].trim() + " Journal Should be present",
									JEType[j].trim() + " Journal is not present");
						}

						uiDriver.click("(//td[text()='" + JEType[j].trim() + "']//..//a)[1]");
						if (uiDriver.checkElementPresent("//h1[text()='Journal']")) {
							passed("VerifyTitleAllocationJoural", "Journal Should be displayed", "Journal is displayed");
						} else {
							failed("VerifyTitleAllocationJoural", "Journal Should be displayed",
									"Journal is not displayed");
						}

						List<WebElement> LineItems = uiDriver.webDr
								.findElements(By.xpath("//table[@id='line_splits']//tr"));
						int total_LineItems = LineItems.size();

						int temp = 0;
						for (int k = 2; k < total_LineItems; k++) {

							String xpath = "//table[@id='line_splits']//td[contains(text(),'" + GLPN[x].trim() + "')]";

							List<WebElement> el = uiDriver.webDr.findElements(
									By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'" + GLPN[x].trim()
											+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Account']//..//preceding-sibling::*)+1]"));
							String actual_Account;
							try {
								actual_Account = el.get(temp).getText();
							} catch (Exception e) {
								temp = 0;
								actual_Account = el.get(temp).getText();
							}
							String expected_Account = Account[x].trim();
							if (expected_Account.toLowerCase().contains(actual_Account.toLowerCase())
									|| expected_Account.toLowerCase().contains(actual_Account.toLowerCase())) {
								passed("VerifyTitleAllocationJoural-" + "-Invoice" + (i + 1) + "-Journal " + JEType[j]
										+ "-Line Item" + (k - 1), "Account Should be displayed as " + expected_Account,
										"Account is displayed as " + actual_Account);
							} else {
								failed("VerifyTitleAllocationJoural-" + "-Invoice" + (i + 1) + "-Journal " + JEType[j]
										+ "-Line Item" + (k - 1), "Account Should be displayed as " + expected_Account,
										"Account is displayed as " + actual_Account);
							}

							el = uiDriver.webDr.findElements(
									By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'" + GLPN[x].trim()
											+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Debit']//..//preceding-sibling::*)+1]"));
							String act_Amount = el.get(temp).getText();
							if (act_Amount.trim().equals(null) || act_Amount.trim().equals("")) {
								el = uiDriver.webDr.findElements(
										By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'" + GLPN[x].trim()
												+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Credit']//..//preceding-sibling::*)+1]"));
								act_Amount = el.get(temp).getText();
								String exp_Amount = Amount[x].trim();
								String act_Amount1 = act_Amount.replace(",", "");
								String exp_Amount1 = act_Amount.replace(",", "");
								float actual_Amount = Float.parseFloat(act_Amount1);
								float expected_Amount = Float.parseFloat(exp_Amount1);
								if (expected_Amount == actual_Amount) {
									passed("VerifyTitleAllocationJoural-" + "-Invoice" + (i + 1) + "-Journal " + JEType[j]
											+ "-Line Item" + (k - 1), "Credit Amount Should be displayed as " + exp_Amount,
											"Credit Amount is displayed as " + act_Amount);
								} else {
									failed("VerifyTitleAllocationJoural-" + "-Invoice" + (i + 1) + "-Journal " + JEType[j]
											+ "-Line Item" + (k - 1), "Credit Amount Should be displayed as " + exp_Amount,
											"Credit Amount is displayed as " + act_Amount);
								}
							} else {
								String exp_Amount = Amount[x].trim();
								String act_Amount1 = act_Amount.replace(",", "");
								String exp_Amount1 = act_Amount.replace(",", "");
								float actual_Amount = Float.parseFloat(act_Amount1);
								float expected_Amount = Float.parseFloat(exp_Amount1);
								if (expected_Amount == actual_Amount) {
									passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
											"Debit Amount Should be displayed as " + exp_Amount,
											"Debit Amount is displayed as " + act_Amount);
								} else {
									failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item" + (j - 1),
											"Debit Amount Should be displayed as " + exp_Amount,
											"Debit Amount is displayed as " + act_Amount);
								}
							}

							el = uiDriver.webDr.findElements(
									By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'" + GLPN[x].trim()
											+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Name']//..//preceding-sibling::*)+1]"));
							String actual_Name = el.get(temp).getText();
							String expected_Name = Name[x].trim();
							if (expected_Name.toLowerCase().contains(actual_Name.toLowerCase())
									|| actual_Name.toLowerCase().contains(expected_Name.toLowerCase())) {
								passed("VerifyTitleAllocationJoural-" + "-Invoice" + (i + 1) + "-Journal " + JEType[j]
										+ "-Line Item" + (k - 1), "Name Should be displayed as " + expected_Name,
										"Name is displayed as " + actual_Name);
							} else {
								failed("VerifyTitleAllocationJoural-" + "-Invoice" + (i + 1) + "-Journal " + JEType[j]
										+ "-Line Item" + (k - 1), "Name Should be displayed as " + expected_Name,
										"Name is displayed as " + actual_Name);
							}

							el = uiDriver.webDr.findElements(
									By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'" + GLPN[x].trim()
											+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Territory']//..//preceding-sibling::*)+1]"));
							String actual_Territory = el.get(temp).getText();
							String expected_Territory = Territory[x].trim();
							if (expected_Territory.toLowerCase().contains(actual_Territory.toLowerCase())
									|| actual_Territory.toLowerCase().contains(expected_Territory.toLowerCase())) {
								passed("VerifyTitleAllocationJoural-" + "-Invoice" + (i + 1) + "-Journal " + JEType[j]
										+ "-Line Item" + (k - 1), "Territory Should be displayed as " + expected_Territory,
										"Territory is displayed as " + actual_Territory);
							} else {
								failed("VerifyTitleAllocationJoural-" + "-Invoice" + (i + 1) + "-Journal " + JEType[j]
										+ "-Line Item" + (k - 1), "Territory Should be displayed as " + expected_Territory,
										"Territory is displayed as " + actual_Territory);
							}

							uiDriver.webDr.findElements(By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'"
									+ GLPN[x].trim()
									+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Market Code']//..//preceding-sibling::*)+1]"));
							String actual_MarketCode = el.get(temp).getText();
							String expected_MarketCode = MarketCode[x].trim();
							if (expected_MarketCode.toLowerCase().contains(actual_MarketCode.toLowerCase())
									|| actual_MarketCode.toLowerCase().contains(expected_MarketCode.toLowerCase())) {
								passed("VerifyTitleAllocationJoural-" + "-Invoice" + (i + 1) + "-Journal " + JEType[j]
										+ "-Line Item" + (k - 1),
										"MarketCode Should be displayed as " + expected_MarketCode,
										"MarketCode is displayed as " + actual_MarketCode);
							} else {
								failed("VerifyTitleAllocationJoural-" + "-Invoice" + (i + 1) + "-Journal " + JEType[j]
										+ "-Line Item" + (k - 1),
										"MarketCode Should be displayed as " + expected_MarketCode,
										"MarketCode is displayed as " + actual_MarketCode);
							}

							el = uiDriver.webDr.findElements(
									By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'" + GLPN[x].trim()
											+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]"));
							String actual_GLPN = el.get(temp).getText();
							String expected_GLPN = GLPN[x].trim();
							if (expected_GLPN.toLowerCase().contains(actual_GLPN.toLowerCase())
									|| actual_GLPN.toLowerCase().contains(expected_GLPN.toLowerCase())) {
								passed("VerifyTitleAllocationJoural-" + "-Invoice" + (i + 1) + "-Journal " + JEType[j]
										+ "-Line Item" + (k - 1), "GLPN Should be displayed as " + expected_GLPN,
										"GLPN is displayed as " + actual_GLPN);
							} else {
								failed("VerifyTitleAllocationJoural-" + "-Invoice" + (i + 1) + "-Journal " + JEType[j]
										+ "-Line Item" + (k - 1), "GLPN Should be displayed as " + expected_GLPN,
										"GLPN is displayed as " + actual_GLPN);
							}

							el = uiDriver.webDr.findElements(By.xpath(xpath));
							if (el.size() > 1) {
								temp++;
							} else {
								temp = 0;
							}

							x++;

						}

						while (true) {
							if (uiDriver.checkElementPresent("//h1[text()='Title Allocation Parent']")) {
								break;
							} else {
								uiDriver.back();
								SleepUtils.sleep(TimeSlab.YIELD);
							}
						}
					}

					while (true) {
						if (uiDriver.checkElementPresent("//h1[text()='Invoice']")) {
							break;
						} else {
							uiDriver.back();
							SleepUtils.sleep(TimeSlab.YIELD);
						}
					}
				}

			} catch (Exception e) {
				failed("VerifyTitleAllocationJoural", "Error in VerifyTitleAllocationJoural method",
						"Error : " + e.toString());
			}
		}
		
	/****************************************
	 * Name: ValidateTitleAllocationTransactionJoural
	 * Description:ValidateTitleAllocationTransactionJoural
	 * Date: 08-Aug-2019
	 ****************************************/
	public void ChangeCustomerPreference(DataRow input, DataRow output) throws InterruptedException {
		try {

			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.setValue("//input[@id='_searchstring']", input.get("Customer"));
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//a[contains(text(),'Customer:')]");
			SleepUtils.sleep(TimeSlab.LOW);
			if (uiDriver.checkElementPresent("//h1[text()='Customer']")) {
				passed("ChangeCustomerPreference", "Customer Should be displayed", "Customer is displayed");
			} else {
				failed("ChangeCustomerPreference", "Customer Should be displayed", "Customer is not displayed");
			}

			uiDriver.click("//input[@id='edit']");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.executeJavaScript("scroll(0,500)");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("//a[@id='preferencestxt']");
			SleepUtils.sleep(TimeSlab.LOW);

			if (input.get("Email").equalsIgnoreCase("Yes")) {
				if (uiDriver.checkElementPresent(
						"//span[@id='custentity_nbcu_email_fs' and @class='checkbox_unck']//input")) {
					uiDriver.click("//span[@id='custentity_nbcu_email_fs' and @class='checkbox_unck']//img");
				} else {
					System.out.println("'Email' Checkbox is already checked");
				}
				if (uiDriver.checkElementPresent(
						"//span[@id='custentity_nbcu_email_fs' and @class='checkbox_ck']//input")) {
					passed("ChangeCustomerPreference", "'Email' Checkbox should be checked",
							"'Email' Checkbox is checked");
				} else {
					failed("ChangeCustomerPreference", "'Email' Checkbox should be checked",
							"'Email' Checkbox is not checked");
				}

			} else if (input.get("Email").equalsIgnoreCase("No")) {
				if (uiDriver.checkElementPresent(
						"//span[@id='custentity_nbcu_email_fs' and @class='checkbox_ck']//input")) {
					uiDriver.click("//span[@id='custentity_nbcu_email_fs' and @class='checkbox_ck']//img");
				} else {
					System.out.println("'Email' Checkbox is already unchecked");
				}
				if (uiDriver.checkElementPresent(
						"//span[@id='custentity_nbcu_email_fs' and @class='checkbox_unck']//input")) {
					passed("ChangeCustomerPreference", "'Email' Checkbox should be unchecked",
							"'Email' Checkbox is unchecked");
				} else {
					failed("ChangeCustomerPreference", "'Email' Checkbox should be unchecked",
							"'Email' Checkbox is not unchecked");
				}
			}

			if (input.get("Email With Manual Attachment").equalsIgnoreCase("Yes")) {
				if (uiDriver.checkElementPresent(
						"//span[@id='custentity_nbcu_email_with_attach_fs' and @class='checkbox_unck']//input")) {
					uiDriver.click(
							"//span[@id='custentity_nbcu_email_with_attach_fs' and @class='checkbox_unck']//img");
				} else {
					System.out.println("'Email With Manual Attachment' Checkbox is already checked");
				}
				if (uiDriver.checkElementPresent(
						"//span[@id='custentity_nbcu_email_with_attach_fs' and @class='checkbox_ck']//input")) {
					passed("ChangeCustomerPreference", "'Email With Manual Attachment' Checkbox should be checked",
							"'Email With Manual Attachment' Checkbox is checked");
				} else {
					failed("ChangeCustomerPreference", "'Email With Manual Attachment' Checkbox should be checked",
							"'Email With Manual Attachment' Checkbox is not checked");
				}

			} else if (input.get("Email With Manual Attachment").equalsIgnoreCase("No")) {
				if (uiDriver.checkElementPresent(
						"//span[@id='custentity_nbcu_email_with_attach_fs' and @class='checkbox_ck']//input")) {
					uiDriver.click("//span[@id='custentity_nbcu_email_with_attach_fs' and @class='checkbox_ck']//img");
				} else {
					System.out.println("'Email With Manual Attachment' Checkbox is already unchecked");
				}
				if (uiDriver.checkElementPresent(
						"//span[@id='custentity_nbcu_email_with_attach_fs' and @class='checkbox_unck']//input")) {
					passed("ChangeCustomerPreference", "'Email With Manual Attachment' Checkbox should be unchecked",
							"'Email With Manual Attachment' Checkbox is unchecked");
				} else {
					failed("ChangeCustomerPreference", "'Email With Manual Attachment' Checkbox should be unchecked",
							"'Email With Manual Attachment' Checkbox is not unchecked");
				}
			}

			if (input.get("Email With Signature").equalsIgnoreCase("Yes")) {
				if (uiDriver.checkElementPresent(
						"//span[@id='custentity_nbcu_email_with_sig_fs' and @class='checkbox_unck']//input")) {
					uiDriver.click("//span[@id='custentity_nbcu_email_with_sig_fs' and @class='checkbox_unck']//img");
				} else {
					System.out.println("'Email With Signature' Checkbox is already checked");
				}
				if (uiDriver.checkElementPresent(
						"//span[@id='custentity_nbcu_email_with_sig_fs' and @class='checkbox_ck']//input")) {
					passed("ChangeCustomerPreference", "'Email With Signature' Checkbox should be checked",
							"'Email With Signature' Checkbox is checked");
				} else {
					failed("ChangeCustomerPreference", "'Email With Signature' Checkbox should be checked",
							"'Email With Signature' Checkbox is not checked");
				}

			} else if (input.get("Email With Signature").equalsIgnoreCase("No")) {
				if (uiDriver.checkElementPresent(
						"//span[@id='custentity_nbcu_email_with_sig_fs' and @class='checkbox_ck']//input")) {
					uiDriver.click("//span[@id='custentity_nbcu_email_with_sig_fs' and @class='checkbox_ck']//img");
				} else {
					System.out.println("'Email With Signature' Checkbox is already unchecked");
				}
				if (uiDriver.checkElementPresent(
						"//span[@id='custentity_nbcu_email_with_sig_fs' and @class='checkbox_unck']//input")) {
					passed("ChangeCustomerPreference", "'Email With Signature' Checkbox should be unchecked",
							"'Email With Signature' Checkbox is unchecked");
				} else {
					failed("ChangeCustomerPreference", "'Email With Signature' Checkbox should be unchecked",
							"'Email With Signature' Checkbox is not unchecked");
				}
			}

			if (input.get("Post").equalsIgnoreCase("Yes")) {
				if (uiDriver.checkElementPresent(
						"//span[@id='custentity_nbcu_post_fs' and @class='checkbox_unck']//input")) {
					uiDriver.click("//span[@id='custentity_nbcu_post_fs' and @class='checkbox_unck']//img");
				} else {
					System.out.println("'Post' Checkbox is already checked");
				}
				if (uiDriver
						.checkElementPresent("//span[@id='custentity_nbcu_post_fs' and @class='checkbox_ck']//input")) {
					passed("ChangeCustomerPreference", "'Post' Checkbox should be checked",
							"'Post' Checkbox is checked");
				} else {
					failed("ChangeCustomerPreference", "'Post' Checkbox should be checked",
							"'Post' Checkbox is not checked");
				}

			} else if (input.get("Post").equalsIgnoreCase("No")) {
				if (uiDriver
						.checkElementPresent("//span[@id='custentity_nbcu_post_fs' and @class='checkbox_ck']//input")) {
					uiDriver.click("//span[@id='custentity_nbcu_post_fs' and @class='checkbox_ck']//img");
				} else {
					System.out.println("'Post' Checkbox is already unchecked");
				}
				if (uiDriver.checkElementPresent(
						"//span[@id='custentity_nbcu_post_fs' and @class='checkbox_unck']//input")) {
					passed("ChangeCustomerPreference", "'Post' Checkbox should be unchecked",
							"'Post' Checkbox is unchecked");
				} else {
					failed("ChangeCustomerPreference", "'Post' Checkbox should be unchecked",
							"'Post' Checkbox is not unchecked");
				}
			}

			if (input.get("Fedex").equalsIgnoreCase("Yes")) {
				if (uiDriver.checkElementPresent(
						"//span[@id='custentity_nbcu_fedex_fs' and @class='checkbox_unck']//input")) {
					uiDriver.click("//span[@id='custentity_nbcu_fedex_fs' and @class='checkbox_unck']//img");
				} else {
					System.out.println("'Fedex' Checkbox is already checked");
				}
				if (uiDriver.checkElementPresent(
						"//span[@id='custentity_nbcu_fedex_fs' and @class='checkbox_ck']//input")) {
					passed("ChangeCustomerPreference", "'Fedex' Checkbox should be checked",
							"'Fedex' Checkbox is checked");
				} else {
					failed("ChangeCustomerPreference", "'Fedex' Checkbox should be checked",
							"'Fedex' Checkbox is not checked");
				}

			} else if (input.get("Fedex").equalsIgnoreCase("No")) {
				if (uiDriver.checkElementPresent(
						"//span[@id='custentity_nbcu_fedex_fs' and @class='checkbox_ck']//input")) {
					uiDriver.click("//span[@id='custentity_nbcu_fedex_fs' and @class='checkbox_ck']//img");
				} else {
					System.out.println("'Fedex' Checkbox is already unchecked");
				}
				if (uiDriver.checkElementPresent(
						"//span[@id='custentity_nbcu_fedex_fs' and @class='checkbox_unck']//input")) {
					passed("ChangeCustomerPreference", "'Fedex' Checkbox should be unchecked",
							"'Fedex' Checkbox is unchecked");
				} else {
					failed("ChangeCustomerPreference", "'Fedex' Checkbox should be unchecked",
							"'Fedex' Checkbox is not unchecked");
				}
			}

			uiDriver.executeJavaScript("scroll(0,-1000)");
			uiDriver.setValue("//span[@id='email_fs']//input", input.get("Email ID"));
			uiDriver.click("//td[@id='spn_multibutton_submitter']");
			if (uiDriver.checkElementPresent(
					"//div[@class='title' and text()='Confirmation']//..//div[@class='descr' and text()='Customer successfully Saved']")) {
				passed("ChangeCustomerPreference", "Customer should be updated successfully",
						"Customer is updated successfully");
			} else {
				failed("ChangeCustomerPreference", "Customer should be updated successfully",
						"Customer is not updated successfully");
			}

		} catch (Exception e) {
			failed("ChangeCustomerPreference", "Error in ChangeCustomerPreference method", "Error : " + e.toString());
		}
	}
	
	
	/****************************************
	 * 
	 * Name: VeryfyGlAccountData
	 * 
	 * Description: To verify details of Invoice GLImpact
	 * 
	 * Date: 08/06/2019
	 * 
	 ****************************************/

	public void VeryfyGlAccountData(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.HIGH);

		String ACCOUNT = input.get("ACCOUNT");

		String ACCOUNTS[] = ACCOUNT.split(";");

		String DEBIT = input.get("DEBIT");

		String DEBITS[] = DEBIT.split(";");

		String CREDIT = input.get("CREDIT");

		String CREDITS[] = CREDIT.split(";");

		String Name = input.get("Name");

		String Names[] = Name.split(";");

		String Subsidiary = input.get("Subsidiary");

		String Subsidiarys[] = Subsidiary.split(";");

		String MarketCode = input.get("MarketCode");

		String MarketCodes[] = MarketCode.split(";");

		String Territory = input.get("Territory");

		String Territorys[] = Territory.split(";");

		String GLPN = input.get("GLPN");

		String GLPNS[] = GLPN.split(";");

		System.out.println(ACCOUNTS.length);

		for (int i = 0; i < ACCOUNTS.length; i++) {

			String xpath_Project = "//*[contains(text(),'"+ACCOUNTS[i].trim()+"')]";

			if (uiDriver.checkElementPresent(xpath_Project)) {

				passed("ValidateTheGlImpact",

						ACCOUNTS[i].trim() + "Account Details should be displayed in GLImpact screen",

						ACCOUNTS[i].trim() + "Account Details is displayed in GLImpact screen");

				String actual_ACCOUNTS = uiDriver

						.getValue("(//*[contains(text(),'" + ACCOUNTS[i].trim() + "')]//..//td[1])[1]");

				if (actual_ACCOUNTS != null && !actual_ACCOUNTS.equals(" ")) {

					String expected_ACCOUNTS = ACCOUNTS[i].trim();

					if (expected_ACCOUNTS.equalsIgnoreCase(actual_ACCOUNTS)) {

						passed("ValidateTheGLImpact",

								ACCOUNTS[i].trim() + " Account should be displayed as " + ACCOUNTS[i].trim(),

								ACCOUNTS[i].trim() + " Account is displayed as " + ACCOUNTS[i].trim());

					} else {

						failed("ValidateTheGLImpact",

								ACCOUNTS[i].trim() + " Account should be displayed as " + ACCOUNTS[i].trim(),

								ACCOUNTS[i].trim() + " Account is not displayed as " + ACCOUNTS[i].trim());

					}

				} else {

				}

				String actual_DEBIT = uiDriver

						.getValue("(//*[contains(text(),'" + ACCOUNTS[i].trim() + "')]//..//td[2])[1]");

				if (actual_DEBIT != null && !actual_DEBIT.equals(" ")) {

					String expected_DEBIT = DEBITS[i].trim();

					if (expected_DEBIT.equalsIgnoreCase(actual_DEBIT)) {

						passed("ValidateTheGLImpact",

								DEBITS[i].trim() + " Debit should be displayed as " + DEBITS[i].trim(),

								DEBITS[i].trim() + " Debit is displayed as " + DEBITS[i].trim());

					} else {

						failed("ValidateTheGLImpact",

								DEBITS[i].trim() + " Debit should be displayed as " + DEBITS[i].trim(),

								DEBITS[i].trim() + " Debit is not displayed as " + DEBITS[i].trim());

					}

				} else {

				}

				String actual_CREDIT = uiDriver

						.getValue("(//*[contains(text(),'" + ACCOUNTS[i].trim() + "')]//..//td[3])[1]");

				if (actual_CREDIT != null && !actual_CREDIT.equals(" ")) {

					String expected_CREDIT = CREDITS[i].trim();

					if (expected_CREDIT.equalsIgnoreCase(actual_CREDIT)) {

						passed("ValidateTheGLImpact",

								CREDITS[i].trim() + " Credit should be displayed as " + CREDITS[i].trim(),

								CREDITS[i].trim() + " Credit is displayed as " + CREDITS[i].trim());

					} else {

						failed("ValidateTheGLImpact",

								CREDITS[i].trim() + " Credit should be displayed as " + CREDITS[i].trim(),

								CREDITS[i].trim() + " Credit is not displayed as " + CREDITS[i].trim());

					}

				} else {

					System.out.println("NULL");

				}

				String actual_Name = uiDriver

						.getValue("(//*[contains(text(),'" + ACCOUNTS[i].trim() + "')]//..//td[6])[1]");

				if (actual_Name != null && !actual_Name.equals(" ")) {

					String expected_Name = Names[i].trim();

					if (expected_Name.equalsIgnoreCase(actual_Name)) {

						passed("ValidateTheGLImpact",
								Names[i].trim() + " Name should be displayed as " + Names[i].trim(),

								Names[i].trim() + " Name is displayed as " + Names[i].trim());

					} else {

						failed("ValidateTheGLImpact",
								Names[i].trim() + " Name should be displayed as " + Names[i].trim(),

								Names[i].trim() + " Name is not displayed as " + Names[i].trim());

					}

				} else {

				}

				String actual_Subsidiary = uiDriver

						.getValue("(//*[contains(text(),'" + ACCOUNTS[i].trim() + "')]//..//td[7])[1]");

				if (actual_Subsidiary != null && !actual_Subsidiary.equals(" ")) {

					String expected_Subsidiary = Subsidiarys[i].trim();

					if (expected_Subsidiary.equalsIgnoreCase(actual_Subsidiary)) {

						passed("ValidateTheGLImpact",

								Subsidiarys[i].trim() + " Subsidiary should be displayed as " + Subsidiarys[i].trim(),

								Subsidiarys[i].trim() + " Subsidiary is displayed as " + Subsidiarys[i].trim());

					} else {

						failed("ValidateTheGLImpact",

								Subsidiarys[i].trim() + " Subsidiary should be displayed as " + Subsidiarys[i].trim(),

								Subsidiarys[i].trim() + " Subsidiary is not displayed as " + Subsidiarys[i].trim());

					}

				} else {

				}

				String actual_MarketCode = uiDriver

						.getValue("(//*[contains(text(),'" + ACCOUNTS[i].trim() + "')]//..//td[8])[1]");

				if (actual_MarketCode != null && !actual_MarketCode.equals(" ")) {

					String expected_MarketCode = MarketCodes[i].trim();

					if (expected_MarketCode.equalsIgnoreCase(actual_MarketCode)) {

						passed("ValidateTheGLImpact",

								MarketCodes[i].trim() + " MarketCode should be displayed as " + MarketCodes[i].trim(),

								MarketCodes[i].trim() + " MarketCode is displayed as " + MarketCodes[i].trim());

					} else {

						failed("ValidateTheGLImpact",

								MarketCodes[i].trim() + " MarketCode should be displayed as " + MarketCodes[i].trim(),

								MarketCodes[i].trim() + " MarketCode is not displayed as " + MarketCodes[i].trim());

					}

				} else {

				}

				String actual_Territory = uiDriver

						.getValue("(//*[contains(text(),'" + ACCOUNTS[i].trim() + "')]//..//td[9])[1]");

				if (actual_Territory != null && !actual_Territory.equals(" ")) {

					String expected_Territory = Territorys[i].trim();

					if (expected_Territory.equalsIgnoreCase(actual_Territory)) {

						passed("ValidateTheGLImpact",

								Territorys[i].trim() + " Territory should be displayed as " + Territorys[i].trim(),

								Territorys[i].trim() + " Territory is displayed as " + Territorys[i].trim());

					} else {

						failed("ValidateTheGLImpact",

								Territorys[i].trim() + " Territory should be displayed as " + Territorys[i].trim(),

								Territorys[i].trim() + " Territory is not displayed as " + Territorys[i].trim());

					}

				} else {

				}

				String actual_GLPN = uiDriver

						.getValue("(//*[contains(text(),'" + ACCOUNTS[i].trim() + "')]//..//td[10])[1]");

				if (actual_GLPN != null && !actual_GLPN.equals(" ")) {

					String expected_GLPN = GLPNS[i].trim();

					if (expected_GLPN.equalsIgnoreCase(actual_GLPN)) {

						passed("ValidateTheGLImpact",
								GLPNS[i].trim() + " GLPN should be displayed as " + GLPNS[i].trim(),

								GLPNS[i].trim() + " GLPN is displayed as " + GLPNS[i].trim());

					} else {

						failed("ValidateTheGLImpact",
								GLPNS[i].trim() + " GLPN should be displayed as " + GLPNS[i].trim(),

								GLPNS[i].trim() + " GLPN is not displayed as " + GLPNS[i].trim());

					}

				} else {

				}

			}

		}

	}
	

	/****************************************
	 * Name: VerifyBilledARJE Description:Method to VerifyBilledARJE Date:
	 * 6-Aug-2019
	 ****************************************/
	public void VerifyBilledARJE(DataRow input, DataRow output) throws InterruptedException {

		try{
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("//*[text()='lated Transactions']");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("scroll(0,1500)");
		SleepUtils.sleep(5);
		if (uiDriver.checkElementPresent("//td[contains(text(),'Reclass - Billed AR')]//..//td[1]//a")) {
			passed("Validating JE type", "Reclass Billed AR should be present", "Reclass Billed AR JE Type is present");
			SleepUtils.sleep(5);
			uiDriver.click("//td[contains(text(),'Reclass - Billed AR')]//..//td[1]//a");
			SleepUtils.sleep(5);
			uiDriver.executeJavaScript("scroll(0,800)");
			int invoiceRow = 2;
			int transRows = uiDriver.webDr.findElements(By.xpath("//*[@id='line_splits']//tbody/tr")).size();
			System.out.println(transRows);
			String[] accounts = input.get("Account").split(";");
			String[] debit = input.get("Debit").split(";");
			String[] credit = input.get("Credit").split(";");

//			String[] memo = input.get("Memo").split(";");
			String[] name = input.get("Name").split(";");
			String[] marketCode = input.get("Market Code").split(";");

			String[] territory = input.get("Territory").split(";");
//			String[] title = input.get("Title").split(";");
//			String[] SOLine = input.get("SO Line").split(";");

//			String[] sourceLine = input.get("Source Line").split(";");
//			String[] FTLineUniqueKey = input.get("FT Line Unique Key").split(";");
//			String[] salesorder = input.get("Sales order").split(";");

//			String[] Invoicelineuniquekey = input.get("Invoice line unique key").split(";");
			String[] GLPN = input.get("GLPN").split(";");
//			String[] Costcenter = input.get("Cost center").split(";");

//			String[] Profitcenter = input.get("Profit center").split(";");
//			String[] Contractexchangerate = input.get("Contract exchange rate").split(";");
//			String[] Basecurrency = input.get("Base currency").split(";");

//			String[] Basecurrencyvalue = input.get("Base currency value").split(";");
//			String[] Localcontractcurrency = input.get("Local contract currency").split(";");
//			String[] Localcontractcurrencyvalue = input.get("Local contract currency value").split(";");

//			String[] Startedate = input.get("Starte date").split(";");
//			String[] Enddate = input.get("End date").split(";");
//			String[] History = input.get("History").split(";");
			
			for (int i = 0; i < transRows - 1; i++) {
				String actualAccount = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[1]");
				String debitAmount = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[2]");
				String creditAmount = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[3]");
//				String actualmemo = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[4]");
				String actualname = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[5]");
				String actualmarketCode = uiDriver
						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[6]");
				String actualterritory = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[7]");
//				String actualtitle = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[8]");
//				String actualSOLine = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[9]");
//				String actualsourceLine = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[10]");
//				String actualFTLineUniqueKey = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[11]");
//				String actualsalesorder = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[12]");
//				String actualInvoicelineuniquekey = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[13]");
				String actualGLPN = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[14]");
//				String actualCostcenter = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[15]");
//				String actualProfitcenter = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[16]");
//				String actualContractexchangerate = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[17]");
//				String actualBasecurrency = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[18]");
//				String actualBasecurrencyvalue = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[19]");
//				String actualLocalcontractcurrency = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[20]");
//				String actualLocalcontractcurrencyvalue = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[21]");
//				String actualStartedate = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[22]");
//				String actualEnddate = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[23]");
//				String actualHistory = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[24]");

				uiDriver.executeJavaScript("scroll(0,100);");
				if (actualAccount.contains(accounts[i])) {
					passed("Validating account details", "account should be" + accounts[i],
							actualAccount + "account details correctly displayed");
				} else {
					failed("Validating account details", "account details should be " + accounts[i],
							actualAccount + "account details are incorrect");
				}

				String expected_debit = debit[i].trim();

				expected_debit = expected_debit.replace("Null", " ");

				if (debitAmount.contains(expected_debit)) {
					passed("Validating amount details", " debit amount should be " + expected_debit,
							debitAmount + "debit amount details correctly displayed");
				} else {
					failed("Validating amount details",
							"Validating debit amount should be dispaying correctly" + expected_debit,
							debitAmount + "debit amount details are incorrect");
				}

				String expected_credit = credit[i].trim();

				expected_credit = expected_credit.replace("Null", " ");

				if (creditAmount.contains(expected_credit)) {
					passed("Validating total credit amount details", "total credit amount should be " + expected_credit,
							creditAmount + " total credit amount correctly displayed");
				} else {
					failed("Validating credit amount details", "total credit amount should be " + expected_credit,
							creditAmount + " total credit amount details are incorrect");
				}

//				String expected_memo = memo[i].trim();
//
//				expected_memo = expected_memo.replace("Null", " ");
//
//				if (actualmemo.contains(expected_memo)) {
//					passed("Validating memo details", "memo should be " + expected_memo,
//							actualmemo + " memo correctly displayed");
//				} else {
//					failed("Validating memo details", "memo should be " + expected_memo,
//							actualmemo + " memo details are incorrect");
//				}

				String expected_name = name[i].trim();

				expected_name = expected_name.replace("Null", " ");

				if (actualname.contains(expected_name)) {
					passed("Validating name details", "name should be " + expected_name,
							actualname + " name correctly displayed");
				} else {
					failed("Validating namedetails", "name should be " + expected_name,
							actualname + "name details are incorrect");
				}

				String expected_marketcode = marketCode[i].trim();

				expected_marketcode = expected_marketcode.replace("Null", " ");

				if (actualmarketCode.contains(expected_marketcode)) {
					passed("Validating market code details", "market code should be " + expected_marketcode,
							actualmarketCode + " market code correctly displayed");
				} else {
					failed("Validating market code details", "market code should be " + expected_marketcode,
							actualmarketCode + " market code details are incorrect");
				}

				String expected_territory = territory[i].trim();

				expected_territory = expected_territory.replace("Null", " ");

				if (actualterritory.contains(expected_territory)) {
					passed("Validating territory details", "territory should be " + expected_territory,
							actualterritory + " territory correctly displayed");
				} else {
					failed("Validating territory details", "territory should be " + expected_territory,
							actualterritory + " territory details are incorrect");
				}

//				String expected_title = title[i].trim();
//
//				expected_title = expected_title.replace("Null", " ");
//
//				if (actualtitle.contains(expected_title)) {
//					passed("Validating title details", "title should be " + expected_title,
//							actualtitle + " title correctly displayed");
//				} else {
//					failed("Validating title details", "title should be " + expected_title,
//							actualtitle + " title details are incorrect");
//				}
//
//				String expected_SOLine = SOLine[i].trim();
//
//				expected_SOLine = expected_SOLine.replace("Null", " ");
//
//				if (actualSOLine.contains(expected_SOLine)) {
//					passed("Validating soline details", "soline should be " + expected_SOLine,
//							actualSOLine + " soline correctly displayed");
//				} else {
//					failed("Validating soline details", "soline should be " + expected_SOLine,
//							actualSOLine + " soline details are incorrect");
//				}
//
//				String expected_sourceLine = sourceLine[i].trim();
//
//				expected_sourceLine = expected_sourceLine.replace("Null", " ");
//
//				if (actualsourceLine.contains(expected_sourceLine)) {
//					passed("Validating sourceline details", "sourceline should be " + expected_sourceLine,
//							actualsourceLine + " sourceline correctly displayed");
//				} else {
//					failed("Validating sourceline details", "sourceline should be " + expected_sourceLine,
//							actualsourceLine + " sourceline details are incorrect");
//				}
//				String expected_FTLineUniqueKey = FTLineUniqueKey[i].trim();
//
//				expected_FTLineUniqueKey = expected_FTLineUniqueKey.replace("Null", " ");
//
//				if (actualFTLineUniqueKey.contains(expected_FTLineUniqueKey)) {
//					passed("Validating FTLineUniqueKey details",
//							"FTLineUniqueKey should be " + expected_FTLineUniqueKey,
//							actualFTLineUniqueKey + " FTLineUniqueKey correctly displayed");
//				} else {
//					failed("Validating FTLineUniqueKey details",
//							"FTLineUniqueKey should be " + expected_FTLineUniqueKey,
//							actualFTLineUniqueKey + " FTLineUniqueKey details are incorrect");
//				}
//				String expected_salesorder = salesorder[i].trim();
//
//				expected_salesorder = expected_salesorder.replace("Null", " ");
//
//				if (actualsalesorder.contains(expected_salesorder)) {
//					passed("Validating salesorder details", "salesorder should be " + expected_salesorder,
//							actualsalesorder + " salesorder correctly displayed");
//				} else {
//					failed("Validating salesorder details", "salesorder should be " + expected_salesorder,
//							actualsalesorder + " salesorder details are incorrect");
//				}
//
//				String expected_Invoicelineuniquekey = Invoicelineuniquekey[i].trim();
//
//				expected_Invoicelineuniquekey = expected_Invoicelineuniquekey.replace("Null", " ");
//
//				if (actualInvoicelineuniquekey.contains(expected_Invoicelineuniquekey)) {
//					passed("Validating Invoicelineuniquekey details",
//							"Invoicelineuniquekey should be " + expected_Invoicelineuniquekey,
//							actualInvoicelineuniquekey + " Invoicelineuniquekey correctly displayed");
//				} else {
//					failed("Validating Invoicelineuniquekey details",
//							"Invoicelineuniquekey should be " + expected_Invoicelineuniquekey,
//							actualInvoicelineuniquekey + " Invoicelineuniquekey details are incorrect");
//				}

				String expected_GLPN = GLPN[i].trim();

				expected_GLPN = expected_GLPN.replace("Null", " ");

				if (actualGLPN.contains(expected_GLPN)) {
					passed("Validating GLPN details", "GLPN should be " + expected_GLPN,
							actualGLPN + " GLPN correctly displayed");
				} else {
					failed("Validating GLPN details", "GLPN should be " + expected_GLPN,
							actualGLPN + " GLPN details are incorrect");
				}

//				String expected_Costcenter = Costcenter[i].trim();
//
//				expected_Costcenter = expected_Costcenter.replace("Null", " ");
//
//				if (actualCostcenter.contains(expected_Costcenter)) {
//					passed("Validating Costcenter details", "Costcenter should be " + expected_Costcenter,
//							actualCostcenter + " Costcenter correctly displayed");
//				} else {
//					failed("Validating Costcenter details", "Costcenter should be " + expected_Costcenter,
//							actualCostcenter + " Costcenter details are incorrect");
//				}
//
//				String expected_Profitcenter = Profitcenter[i].trim();
//
//				expected_Profitcenter = expected_Profitcenter.replace("Null", " ");
//
//				if (actualProfitcenter.contains(expected_Profitcenter)) {
//					passed("Validating Profitcenter details", "Profitcenter should be " + expected_Profitcenter,
//							actualProfitcenter + " Profitcenter correctly displayed");
//				} else {
//					failed("Validating Profitcenter details", "Profitcenter should be " + expected_Profitcenter,
//							actualProfitcenter + " Profitcenter details are incorrect");
//				}
//
//				String expected_Contractexchangerate = Contractexchangerate[i].trim();
//
//				expected_Contractexchangerate = expected_Contractexchangerate.replace("Null", " ");
//
//				if (actualContractexchangerate.contains(expected_Contractexchangerate)) {
//					passed("Validating Contractexchangerate details",
//							"Contractexchangerate should be " + expected_Contractexchangerate,
//							actualContractexchangerate + " Contractexchangerate correctly displayed");
//				} else {
//					failed("Validating Contractexchangerate details",
//							"Contractexchangerate should be " + expected_Contractexchangerate,
//							actualContractexchangerate + " Contractexchangerate details are incorrect");
//				}
//
//				String expected_Basecurrency = Basecurrency[i].trim();
//
//				expected_Basecurrency = expected_Basecurrency.replace("Null", " ");
//
//				if (actualBasecurrency.contains(expected_Profitcenter)) {
//					passed("Validating Basecurrency details", "Basecurrency should be " + expected_Basecurrency,
//							actualBasecurrency + " Basecurrency correctly displayed");
//				} else {
//					failed("Validating Basecurrency details", "Basecurrency should be " + expected_Basecurrency,
//							actualBasecurrency + " Basecurrency details are incorrect");
//				}
//
//				String expected_Basecurrencyvalue = Basecurrencyvalue[i].trim();
//
//				expected_Basecurrencyvalue = expected_Basecurrencyvalue.replace("Null", " ");
//
//				if (actualBasecurrencyvalue.contains(expected_Basecurrencyvalue)) {
//					passed("Validating Basecurrencyvalue details",
//							"Basecurrencyvalue should be " + expected_Basecurrencyvalue,
//							actualBasecurrencyvalue + " Basecurrencyvalue correctly displayed");
//				} else {
//					failed("Validating Basecurrencyvalue details",
//							"Basecurrencyvalue should be " + expected_Basecurrencyvalue,
//							actualBasecurrencyvalue + " Basecurrencyvalue details are incorrect");
//				}
//
//				String expected_Localcontractcurrency = Localcontractcurrency[i].trim();
//
//				expected_Localcontractcurrency = expected_Localcontractcurrency.replace("Null", " ");
//
//				if (actualLocalcontractcurrency.contains(expected_Localcontractcurrency)) {
//					passed("Validating Localcontractcurrency details",
//							"Localcontractcurrency should be " + expected_Localcontractcurrency,
//							actualLocalcontractcurrency + " Localcontractcurrency correctly displayed");
//				} else {
//					failed("Validating Localcontractcurrency details",
//							"Localcontractcurrency should be " + expected_Localcontractcurrency,
//							actualLocalcontractcurrency + " Localcontractcurrency details are incorrect");
//				}
//
//				String expected_Localcontractcurrencyvalue = Localcontractcurrencyvalue[i].trim();
//
//				expected_Localcontractcurrencyvalue = expected_Localcontractcurrencyvalue.replace("Null", " ");
//
//				if (actualLocalcontractcurrencyvalue.contains(expected_Localcontractcurrencyvalue)) {
//					passed("Validating Localcontractcurrencyvalue details",
//							"Localcontractcurrencyvalue should be " + expected_Localcontractcurrencyvalue,
//							actualLocalcontractcurrencyvalue + " Localcontractcurrencyvalue correctly displayed");
//				} else {
//					failed("Validating Localcontractcurrencyvalue details",
//							"Localcontractcurrencyvalue should be " + expected_Localcontractcurrencyvalue,
//							actualLocalcontractcurrencyvalue + " Localcontractcurrencyvalue details are incorrect");
//				}
//
//				String expected_Startedate = Startedate[i].trim();
//
//				expected_Startedate = expected_Startedate.replace("Null", " ");
//
//				if (actualStartedate.contains(expected_Startedate)) {
//					passed("Validating Startedate details", "Startedate should be " + expected_Startedate,
//							actualStartedate + " Startedate correctly displayed");
//				} else {
//					failed("Validating Startedate details", "Startedate should be " + expected_Startedate,
//							actualStartedate + " Startedate details are incorrect");
//				}
//
//				String expected_Enddate = Enddate[i].trim();
//
//				expected_Enddate = expected_Enddate.replace("Null", " ");
//
//				if (actualEnddate.contains(expected_Enddate)) {
//					passed("Validating Enddate details", "Enddate should be " + expected_Enddate,
//							actualEnddate + " Enddate correctly displayed");
//				} else {
//					failed("Validating Enddate details", "Enddate should be " + expected_Enddate,
//							actualEnddate + " Enddate details are incorrect");
//				}
//
//				String expected_History = History[i].trim();
//
//				expected_History = expected_History.replace("Null", " ");
//
//				if (actualHistory.contains(expected_History)) {
//					passed("Validating History details", "History should be " + expected_History,
//							actualHistory + " History correctly displayed");
//				} else {
//					failed("Validating History details", "History should be " + expected_History,
//							actualHistory + " History details are incorrect");
//				}
				invoiceRow++;
			}
		} else {
			failed("Validating JE type", "Reclass Billed AR should be present", "Reclass Billed AR is not present");
		}

		if (uiDriver.checkElementPresent("//input[@id='_back']")) {
			uiDriver.executeJavaScript("scroll(0,-1000)");
			uiDriver.click("//input[@id='_back']");
			SleepUtils.sleep(TimeSlab.HIGH);
		} else {
			uiDriver.back();
			SleepUtils.sleep(TimeSlab.HIGH);
		}
		}catch(Exception e){
			uiDriver.back();
			SleepUtils.sleep(TimeSlab.HIGH);
		}
	}

	/****************************************
	 * Name: VerifyDeferredRevJE Description:Method to VerifyDeferredRevJE Date:
	 * 6-Aug-2019
	 ****************************************/
	public void VerifyDeferredRevJE(DataRow input, DataRow output) throws InterruptedException {

		try{
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//*[text()='lated Transactions']");
		SleepUtils.sleep(TimeSlab.LOW);
		if (uiDriver.checkElementPresent("//td[contains(text(),'Reclass - Deferred Revenue')]//..//td[1]//a")) {
			passed("Validating JE type", "Reclass Deferred revenue should be present",
					"Reclass Deferred revenue JE Type is present");
			SleepUtils.sleep(5);
			uiDriver.click("//td[contains(text(),'Reclass - Deferred Revenue')]//..//td[1]//a");
			SleepUtils.sleep(5);
			uiDriver.executeJavaScript("scroll(0,300)");
			int invoiceRow = 2;
			int transRows = uiDriver.webDr.findElements(By.xpath("//*[@id='line_splits']//tbody/tr")).size();

			String[] accounts = input.get("Account").split(";");
			String[] debit = input.get("Debit").split(";");
			String[] credit = input.get("Credit").split(";");

//			String[] memo = input.get("Memo").split(";");
			String[] name = input.get("Name").split(";");
			String[] marketCode = input.get("Market Code").split(";");

			String[] territory = input.get("Territory").split(";");
//			String[] title = input.get("Title").split(";");
//			String[] SOLine = input.get("SO Line").split(";");
//
//			String[] sourceLine = input.get("Source Line").split(";");
//			String[] FTLineUniqueKey = input.get("FT Line Unique Key").split(";");
//			String[] salesorder = input.get("Sales order").split(";");
//
//			String[] Invoicelineuniquekey = input.get("Invoice line unique key").split(";");
			String[] GLPN = input.get("GLPN").split(";");
//			String[] Costcenter = input.get("Cost center").split(";");
//
//			String[] Profitcenter = input.get("Profit center").split(";");
//			String[] Contractexchangerate = input.get("Contract exchange rate").split(";");
//			String[] Basecurrency = input.get("Base currency").split(";");
//
//			String[] Basecurrencyvalue = input.get("Base currency value").split(";");
//			String[] Localcontractcurrency = input.get("Local contract currency").split(";");
//			String[] Localcontractcurrencyvalue = input.get("Local contract currency value").split(";");
//
//			String[] Startedate = input.get("Starte date").split(";");
//			String[] Enddate = input.get("End date").split(";");
//			String[] History = input.get("History").split(";");

			for (int i = 0; i < transRows - 1; i++) {
				uiDriver.executeJavaScript("scroll(0,100);");
				String actualAccount = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[1]");
				String debitAmount = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[2]");
				String creditAmount = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[3]");

//				String actualmemo = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[4]");
				String actualname = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[5]");
				String actualmarketCode = uiDriver
						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[6]");
				String actualterritory = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[7]");
//				String actualtitle = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[8]");
//				String actualSOLine = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[9]");
//				String actualsourceLine = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[10]");
//				String actualFTLineUniqueKey = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[11]");
//				String actualsalesorder = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[12]");
//				String actualInvoicelineuniquekey = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[13]");
				String actualGLPN = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[14]");
//				String actualCostcenter = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[15]");
//				String actualProfitcenter = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[16]");
//				String actualContractexchangerate = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[17]");
//				String actualBasecurrency = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[18]");
//				String actualBasecurrencyvalue = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[19]");
//				String actualLocalcontractcurrency = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[20]");
//				String actualLocalcontractcurrencyvalue = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[21]");
//				String actualStartedate = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[22]");
//				String actualEnddate = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[23]");
//				String actualHistory = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[24]");

				if (actualAccount.contains(accounts[i])) {
					passed("Validating account details", "account should be" + accounts[i],
							actualAccount + "account details correctly displayed");
				} else {
					failed("Validating account details", "account details should be " + accounts[i],
							actualAccount + "account details are incorrect");
				}
				String expected_debit = debit[i].trim();

				expected_debit = expected_debit.replace("Null", " ");
				if (debitAmount.contains(expected_debit)) {
					passed("Validating amount details", " debit amount should be " + expected_debit,
							debitAmount + "debit amount details correctly displayed");
				} else {
					failed("Validating amount details",
							"Validating debit amount should be dispaying correctly" + expected_debit,
							debitAmount + "debit amount details are incorrect");
				}

				String expected_credit = credit[i].trim();

				expected_credit = expected_credit.replace("Null", " ");
				if (creditAmount.contains(expected_credit)) {
					passed("Validating amount details", " credit amount should be " + expected_credit,
							creditAmount + "credit amount details correctly displayed");
				} else {
					failed("Validating amount details", "credit amount should be " + expected_credit,
							creditAmount + "credit amount details are incorrect");
				}

//				String expected_memo = memo[i].trim();
//
//				expected_memo = expected_memo.replace("Null", " ");
//
//				if (actualmemo.contains(expected_memo)) {
//					passed("Validating memo details", "memo should be " + expected_memo,
//							actualmemo + " memo correctly displayed");
//				} else {
//					failed("Validating memo details", "memo should be " + expected_memo,
//							actualmemo + " memo details are incorrect");
//				}

				String expected_name = name[i].trim();

				expected_name = expected_name.replace("Null", " ");

				if (actualname.contains(expected_name)) {
					passed("Validating name details", "name should be " + expected_name,
							actualname + " name correctly displayed");
				} else {
					failed("Validating namedetails", "name should be " + expected_name,
							actualname + "name details are incorrect");
				}

				String expected_marketcode = marketCode[i].trim();

				expected_marketcode = expected_marketcode.replace("Null", " ");

				if (actualmarketCode.contains(expected_marketcode)) {
					passed("Validating market code details", "market code should be " + expected_marketcode,
							actualmarketCode + " market code correctly displayed");
				} else {
					failed("Validating market code details", "market code should be " + expected_marketcode,
							actualmarketCode + " market code details are incorrect");
				}

				String expected_territory = territory[i].trim();

				expected_territory = expected_territory.replace("Null", " ");

				if (actualterritory.contains(expected_territory)) {
					passed("Validating territory details", "territory should be " + expected_territory,
							actualterritory + " territory correctly displayed");
				} else {
					failed("Validating territory details", "territory should be " + expected_territory,
							actualterritory + " territory details are incorrect");
				}

//				String expected_title = title[i].trim();
//
//				expected_title = expected_title.replace("Null", " ");
//
//				if (actualtitle.contains(expected_title)) {
//					passed("Validating title details", "title should be " + expected_title,
//							actualtitle + " title correctly displayed");
//				} else {
//					failed("Validating title details", "title should be " + expected_title,
//							actualtitle + " title details are incorrect");
//				}
//
//				String expected_SOLine = SOLine[i].trim();
//
//				expected_SOLine = expected_SOLine.replace("Null", " ");
//
//				if (actualSOLine.contains(expected_SOLine)) {
//					passed("Validating soline details", "soline should be " + expected_SOLine,
//							actualSOLine + " soline correctly displayed");
//				} else {
//					failed("Validating soline details", "soline should be " + expected_SOLine,
//							actualSOLine + " soline details are incorrect");
//				}
//
//				String expected_sourceLine = sourceLine[i].trim();
//
//				expected_sourceLine = expected_sourceLine.replace("Null", " ");
//
//				if (actualsourceLine.contains(expected_sourceLine)) {
//					passed("Validating sourceline details", "sourceline should be " + expected_sourceLine,
//							actualsourceLine + " sourceline correctly displayed");
//				} else {
//					failed("Validating sourceline details", "sourceline should be " + expected_sourceLine,
//							actualsourceLine + " sourceline details are incorrect");
//				}
//				String expected_FTLineUniqueKey = FTLineUniqueKey[i].trim();
//
//				expected_FTLineUniqueKey = expected_FTLineUniqueKey.replace("Null", " ");
//
//				if (actualFTLineUniqueKey.contains(expected_FTLineUniqueKey)) {
//					passed("Validating FTLineUniqueKey details",
//							"FTLineUniqueKey should be " + expected_FTLineUniqueKey,
//							actualFTLineUniqueKey + " FTLineUniqueKey correctly displayed");
//				} else {
//					failed("Validating FTLineUniqueKey details",
//							"FTLineUniqueKey should be " + expected_FTLineUniqueKey,
//							actualFTLineUniqueKey + " FTLineUniqueKey details are incorrect");
//				}
//				String expected_salesorder = salesorder[i].trim();
//
//				expected_salesorder = expected_salesorder.replace("Null", " ");
//
//				if (actualsalesorder.contains(expected_salesorder)) {
//					passed("Validating salesorder details", "salesorder should be " + expected_salesorder,
//							actualsalesorder + " salesorder correctly displayed");
//				} else {
//					failed("Validating salesorder details", "salesorder should be " + expected_salesorder,
//							actualsalesorder + " salesorder details are incorrect");
//				}
//
//				String expected_Invoicelineuniquekey = Invoicelineuniquekey[i].trim();
//
//				expected_Invoicelineuniquekey = expected_Invoicelineuniquekey.replace("Null", " ");
//
//				if (actualInvoicelineuniquekey.contains(expected_Invoicelineuniquekey)) {
//					passed("Validating Invoicelineuniquekey details",
//							"Invoicelineuniquekey should be " + expected_Invoicelineuniquekey,
//							actualInvoicelineuniquekey + " Invoicelineuniquekey correctly displayed");
//				} else {
//					failed("Validating Invoicelineuniquekey details",
//							"Invoicelineuniquekey should be " + expected_Invoicelineuniquekey,
//							actualInvoicelineuniquekey + " Invoicelineuniquekey details are incorrect");
//				}

				String expected_GLPN = GLPN[i].trim();

				expected_GLPN = expected_GLPN.replace("Null", " ");

				if (actualGLPN.contains(expected_GLPN)) {
					passed("Validating GLPN details", "GLPN should be " + expected_GLPN,
							actualGLPN + " GLPN correctly displayed");
				} else {
					failed("Validating GLPN details", "GLPN should be " + expected_GLPN,
							actualGLPN + " GLPN details are incorrect");
				}

//				String expected_Costcenter = Costcenter[i].trim();
//
//				expected_Costcenter = expected_Costcenter.replace("Null", " ");
//
//				if (actualCostcenter.contains(expected_Costcenter)) {
//					passed("Validating Costcenter details", "Costcenter should be " + expected_Costcenter,
//							actualCostcenter + " Costcenter correctly displayed");
//				} else {
//					failed("Validating Costcenter details", "Costcenter should be " + expected_Costcenter,
//							actualCostcenter + " Costcenter details are incorrect");
//				}
//
//				String expected_Profitcenter = Profitcenter[i].trim();
//
//				expected_Profitcenter = expected_Profitcenter.replace("Null", " ");
//
//				if (actualProfitcenter.contains(expected_Profitcenter)) {
//					passed("Validating Profitcenter details", "Profitcenter should be " + expected_Profitcenter,
//							actualProfitcenter + " Profitcenter correctly displayed");
//				} else {
//					failed("Validating Profitcenter details", "Profitcenter should be " + expected_Profitcenter,
//							actualProfitcenter + " Profitcenter details are incorrect");
//				}
//
//				String expected_Contractexchangerate = Contractexchangerate[i].trim();
//
//				expected_Contractexchangerate = expected_Contractexchangerate.replace("Null", " ");
//
//				if (actualContractexchangerate.contains(expected_Contractexchangerate)) {
//					passed("Validating Contractexchangerate details",
//							"Contractexchangerate should be " + expected_Contractexchangerate,
//							actualContractexchangerate + " Contractexchangerate correctly displayed");
//				} else {
//					failed("Validating Contractexchangerate details",
//							"Contractexchangerate should be " + expected_Contractexchangerate,
//							actualContractexchangerate + " Contractexchangerate details are incorrect");
//				}
//
//				String expected_Basecurrency = Basecurrency[i].trim();
//
//				expected_Basecurrency = expected_Basecurrency.replace("Null", " ");
//
//				if (actualBasecurrency.contains(expected_Profitcenter)) {
//					passed("Validating Basecurrency details", "Basecurrency should be " + expected_Basecurrency,
//							actualBasecurrency + " Basecurrency correctly displayed");
//				} else {
//					failed("Validating Basecurrency details", "Basecurrency should be " + expected_Basecurrency,
//							actualBasecurrency + " Basecurrency details are incorrect");
//				}
//
//				String expected_Basecurrencyvalue = Basecurrencyvalue[i].trim();
//
//				expected_Basecurrencyvalue = expected_Basecurrencyvalue.replace("Null", " ");
//
//				if (actualBasecurrencyvalue.contains(expected_Basecurrencyvalue)) {
//					passed("Validating Basecurrencyvalue details",
//							"Basecurrencyvalue should be " + expected_Basecurrencyvalue,
//							actualBasecurrencyvalue + " Basecurrencyvalue correctly displayed");
//				} else {
//					failed("Validating Basecurrencyvalue details",
//							"Basecurrencyvalue should be " + expected_Basecurrencyvalue,
//							actualBasecurrencyvalue + " Basecurrencyvalue details are incorrect");
//				}
//
//				String expected_Localcontractcurrency = Localcontractcurrency[i].trim();
//
//				expected_Localcontractcurrency = expected_Localcontractcurrency.replace("Null", " ");
//
//				if (actualLocalcontractcurrency.contains(expected_Localcontractcurrency)) {
//					passed("Validating Localcontractcurrency details",
//							"Localcontractcurrency should be " + expected_Localcontractcurrency,
//							actualLocalcontractcurrency + " Localcontractcurrency correctly displayed");
//				} else {
//					failed("Validating Localcontractcurrency details",
//							"Localcontractcurrency should be " + expected_Localcontractcurrency,
//							actualLocalcontractcurrency + " Localcontractcurrency details are incorrect");
//				}
//
//				String expected_Localcontractcurrencyvalue = Localcontractcurrencyvalue[i].trim();
//
//				expected_Localcontractcurrencyvalue = expected_Localcontractcurrencyvalue.replace("Null", " ");
//
//				if (actualLocalcontractcurrencyvalue.contains(expected_Localcontractcurrencyvalue)) {
//					passed("Validating Localcontractcurrencyvalue details",
//							"Localcontractcurrencyvalue should be " + expected_Localcontractcurrencyvalue,
//							actualLocalcontractcurrencyvalue + " Localcontractcurrencyvalue correctly displayed");
//				} else {
//					failed("Validating Localcontractcurrencyvalue details",
//							"Localcontractcurrencyvalue should be " + expected_Localcontractcurrencyvalue,
//							actualLocalcontractcurrencyvalue + " Localcontractcurrencyvalue details are incorrect");
//				}
//
//				String expected_Startedate = Startedate[i].trim();
//
//				expected_Startedate = expected_Startedate.replace("Null", " ");
//
//				if (actualStartedate.contains(expected_Startedate)) {
//					passed("Validating Startedate details", "Startedate should be " + expected_Startedate,
//							actualStartedate + " Startedate correctly displayed");
//				} else {
//					failed("Validating Startedate details", "Startedate should be " + expected_Startedate,
//							actualStartedate + " Startedate details are incorrect");
//				}
//
//				String expected_Enddate = Enddate[i].trim();
//
//				expected_Enddate = expected_Enddate.replace("Null", " ");
//
//				if (actualEnddate.contains(expected_Enddate)) {
//					passed("Validating Enddate details", "Enddate should be " + expected_Enddate,
//							actualEnddate + " Enddate correctly displayed");
//				} else {
//					failed("Validating Enddate details", "Enddate should be " + expected_Enddate,
//							actualEnddate + " Enddate details are incorrect");
//				}
//
//				String expected_History = History[i].trim();
//
//				expected_History = expected_History.replace("Null", " ");
//
//				if (actualHistory.contains(expected_History)) {
//					passed("Validating History details", "History should be " + expected_History,
//							actualHistory + " History correctly displayed");
//				} else {
//					failed("Validating History details", "History should be " + expected_History,
//							actualHistory + " History details are incorrect");
//				}

				invoiceRow++;
			}
		} else {
			failed("Validating JE type", "Reclass deferred revenue JE Type should be present",
					"Reclass deferred revenue JE Type is not present");
		}
		
		if (uiDriver.checkElementPresent("//input[@id='_back']")) {
			uiDriver.executeJavaScript("scroll(0,-1000)");
			uiDriver.click("//input[@id='_back']");
		} else {
			uiDriver.back();
		}}catch(Exception e){
			uiDriver.back();
			SleepUtils.sleep(TimeSlab.HIGH);}
	}
	
	/****************************************
	 * Name: VerifyReclassPCCCJE Description:Method to VerifyDeferredRevJE Date:
	 * 6-Aug-2019
	 ****************************************/
	public void VerifyReclassPCCCJE(DataRow input, DataRow output) throws InterruptedException {

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//*[text()='lated Transactions']");
		SleepUtils.sleep(TimeSlab.LOW);
		if (uiDriver.checkElementPresent("//td[contains(text(),'Reclass - PC/CC')]//..//td[1]//a")) {
			passed("Validating JE type", "Reclass - PC/CC revenue should be present",
					"Reclass - PC/CC revenue JE Type is present");
			SleepUtils.sleep(5);
			uiDriver.click("//td[contains(text(),'Reclass - PC/CC')]//..//td[1]//a");
			SleepUtils.sleep(5);
			uiDriver.executeJavaScript("scroll(0,300)");
			int invoiceRow = 2;
			int transRows = uiDriver.webDr.findElements(By.xpath("//*[@id='line_splits']//tbody/tr")).size();

			String[] accounts = input.get("Account").split(";");
			String[] debit = input.get("Debit").split(";");
			String[] credit = input.get("Credit").split(";");

//			String[] memo = input.get("Memo").split(";");
			String[] name = input.get("Name").split(";");
			String[] marketCode = input.get("Market Code").split(";");

			String[] territory = input.get("Territory").split(";");
//			String[] title = input.get("Title").split(";");
//			String[] SOLine = input.get("SO Line").split(";");
//
//			String[] sourceLine = input.get("Source Line").split(";");
//			String[] FTLineUniqueKey = input.get("FT Line Unique Key").split(";");
//			String[] salesorder = input.get("Sales order").split(";");
//
//			String[] Invoicelineuniquekey = input.get("Invoice line unique key").split(";");
			String[] GLPN = input.get("GLPN").split(";");
//			String[] Costcenter = input.get("Cost center").split(";");
//
//			String[] Profitcenter = input.get("Profit center").split(";");
//			String[] Contractexchangerate = input.get("Contract exchange rate").split(";");
//			String[] Basecurrency = input.get("Base currency").split(";");
//
//			String[] Basecurrencyvalue = input.get("Base currency value").split(";");
//			String[] Localcontractcurrency = input.get("Local contract currency").split(";");
//			String[] Localcontractcurrencyvalue = input.get("Local contract currency value").split(";");
//
//			String[] Startedate = input.get("Starte date").split(";");
//			String[] Enddate = input.get("End date").split(";");
//			String[] History = input.get("History").split(";");

			for (int i = 0; i < transRows - 1; i++) {
				uiDriver.executeJavaScript("scroll(0,100);");
				String actualAccount = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[1]");
				String debitAmount = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[2]");
				String creditAmount = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[3]");

//				String actualmemo = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[4]");
				String actualname = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[5]");
				String actualmarketCode = uiDriver
						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[6]");
				String actualterritory = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[7]");
//				String actualtitle = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[8]");
//				String actualSOLine = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[9]");
//				String actualsourceLine = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[10]");
//				String actualFTLineUniqueKey = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[11]");
//				String actualsalesorder = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[12]");
//				String actualInvoicelineuniquekey = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[13]");
				String actualGLPN = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[14]");
//				String actualCostcenter = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[15]");
//				String actualProfitcenter = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[16]");
//				String actualContractexchangerate = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[17]");
//				String actualBasecurrency = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[18]");
//				String actualBasecurrencyvalue = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[19]");
//				String actualLocalcontractcurrency = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[20]");
//				String actualLocalcontractcurrencyvalue = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[21]");
//				String actualStartedate = uiDriver
//						.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[22]");
//				String actualEnddate = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[23]");
//				String actualHistory = uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow + "]/td[24]");

				if (actualAccount.contains(accounts[i])) {
					passed("Validating account details", "account should be" + accounts[i],
							actualAccount + "account details correctly displayed");
				} else {
					failed("Validating account details", "account details should be " + accounts[i],
							actualAccount + "account details are incorrect");
				}
				String expected_debit = debit[i].trim();

				expected_debit = expected_debit.replace("Null", " ");
				if (debitAmount.contains(expected_debit)) {
					passed("Validating amount details", " debit amount should be " + expected_debit,
							debitAmount + "debit amount details correctly displayed");
				} else {
					failed("Validating amount details",
							"Validating debit amount should be dispaying correctly" + expected_debit,
							debitAmount + "debit amount details are incorrect");
				}

				String expected_credit = credit[i].trim();

				expected_credit = expected_credit.replace("Null", " ");
				if (creditAmount.contains(expected_credit)) {
					passed("Validating amount details", " credit amount should be " + expected_credit,
							creditAmount + "credit amount details correctly displayed");
				} else {
					failed("Validating amount details", "credit amount should be " + expected_credit,
							creditAmount + "credit amount details are incorrect");
				}

//				String expected_memo = memo[i].trim();
//
//				expected_memo = expected_memo.replace("Null", " ");
//
//				if (actualmemo.contains(expected_memo)) {
//					passed("Validating memo details", "memo should be " + expected_memo,
//							actualmemo + " memo correctly displayed");
//				} else {
//					failed("Validating memo details", "memo should be " + expected_memo,
//							actualmemo + " memo details are incorrect");
//				}

				String expected_name = name[i].trim();

				expected_name = expected_name.replace("Null", " ");

				if (actualname.contains(expected_name)) {
					passed("Validating name details", "name should be " + expected_name,
							actualname + " name correctly displayed");
				} else {
					failed("Validating namedetails", "name should be " + expected_name,
							actualname + "name details are incorrect");
				}

				String expected_marketcode = marketCode[i].trim();

				expected_marketcode = expected_marketcode.replace("Null", " ");

				if (actualmarketCode.contains(expected_marketcode)) {
					passed("Validating market code details", "market code should be " + expected_marketcode,
							actualmarketCode + " market code correctly displayed");
				} else {
					failed("Validating market code details", "market code should be " + expected_marketcode,
							actualmarketCode + " market code details are incorrect");
				}

				String expected_territory = territory[i].trim();

				expected_territory = expected_territory.replace("Null", " ");

				if (actualterritory.contains(expected_territory)) {
					passed("Validating territory details", "territory should be " + expected_territory,
							actualterritory + " territory correctly displayed");
				} else {
					failed("Validating territory details", "territory should be " + expected_territory,
							actualterritory + " territory details are incorrect");
				}

//				String expected_title = title[i].trim();
//
//				expected_title = expected_title.replace("Null", " ");
//
//				if (actualtitle.contains(expected_title)) {
//					passed("Validating title details", "title should be " + expected_title,
//							actualtitle + " title correctly displayed");
//				} else {
//					failed("Validating title details", "title should be " + expected_title,
//							actualtitle + " title details are incorrect");
//				}
//
//				String expected_SOLine = SOLine[i].trim();
//
//				expected_SOLine = expected_SOLine.replace("Null", " ");
//
//				if (actualSOLine.contains(expected_SOLine)) {
//					passed("Validating soline details", "soline should be " + expected_SOLine,
//							actualSOLine + " soline correctly displayed");
//				} else {
//					failed("Validating soline details", "soline should be " + expected_SOLine,
//							actualSOLine + " soline details are incorrect");
//				}
//
//				String expected_sourceLine = sourceLine[i].trim();
//
//				expected_sourceLine = expected_sourceLine.replace("Null", " ");
//
//				if (actualsourceLine.contains(expected_sourceLine)) {
//					passed("Validating sourceline details", "sourceline should be " + expected_sourceLine,
//							actualsourceLine + " sourceline correctly displayed");
//				} else {
//					failed("Validating sourceline details", "sourceline should be " + expected_sourceLine,
//							actualsourceLine + " sourceline details are incorrect");
//				}
//				String expected_FTLineUniqueKey = FTLineUniqueKey[i].trim();
//
//				expected_FTLineUniqueKey = expected_FTLineUniqueKey.replace("Null", " ");
//
//				if (actualFTLineUniqueKey.contains(expected_FTLineUniqueKey)) {
//					passed("Validating FTLineUniqueKey details",
//							"FTLineUniqueKey should be " + expected_FTLineUniqueKey,
//							actualFTLineUniqueKey + " FTLineUniqueKey correctly displayed");
//				} else {
//					failed("Validating FTLineUniqueKey details",
//							"FTLineUniqueKey should be " + expected_FTLineUniqueKey,
//							actualFTLineUniqueKey + " FTLineUniqueKey details are incorrect");
//				}
//				String expected_salesorder = salesorder[i].trim();
//
//				expected_salesorder = expected_salesorder.replace("Null", " ");
//
//				if (actualsalesorder.contains(expected_salesorder)) {
//					passed("Validating salesorder details", "salesorder should be " + expected_salesorder,
//							actualsalesorder + " salesorder correctly displayed");
//				} else {
//					failed("Validating salesorder details", "salesorder should be " + expected_salesorder,
//							actualsalesorder + " salesorder details are incorrect");
//				}
//
//				String expected_Invoicelineuniquekey = Invoicelineuniquekey[i].trim();
//
//				expected_Invoicelineuniquekey = expected_Invoicelineuniquekey.replace("Null", " ");
//
//				if (actualInvoicelineuniquekey.contains(expected_Invoicelineuniquekey)) {
//					passed("Validating Invoicelineuniquekey details",
//							"Invoicelineuniquekey should be " + expected_Invoicelineuniquekey,
//							actualInvoicelineuniquekey + " Invoicelineuniquekey correctly displayed");
//				} else {
//					failed("Validating Invoicelineuniquekey details",
//							"Invoicelineuniquekey should be " + expected_Invoicelineuniquekey,
//							actualInvoicelineuniquekey + " Invoicelineuniquekey details are incorrect");
//				}

				String expected_GLPN = GLPN[i].trim();

				expected_GLPN = expected_GLPN.replace("Null", " ");

				if (actualGLPN.contains(expected_GLPN)) {
					passed("Validating GLPN details", "GLPN should be " + expected_GLPN,
							actualGLPN + " GLPN correctly displayed");
				} else {
					failed("Validating GLPN details", "GLPN should be " + expected_GLPN,
							actualGLPN + " GLPN details are incorrect");
				}

//				String expected_Costcenter = Costcenter[i].trim();
//
//				expected_Costcenter = expected_Costcenter.replace("Null", " ");
//
//				if (actualCostcenter.contains(expected_Costcenter)) {
//					passed("Validating Costcenter details", "Costcenter should be " + expected_Costcenter,
//							actualCostcenter + " Costcenter correctly displayed");
//				} else {
//					failed("Validating Costcenter details", "Costcenter should be " + expected_Costcenter,
//							actualCostcenter + " Costcenter details are incorrect");
//				}
//
//				String expected_Profitcenter = Profitcenter[i].trim();
//
//				expected_Profitcenter = expected_Profitcenter.replace("Null", " ");
//
//				if (actualProfitcenter.contains(expected_Profitcenter)) {
//					passed("Validating Profitcenter details", "Profitcenter should be " + expected_Profitcenter,
//							actualProfitcenter + " Profitcenter correctly displayed");
//				} else {
//					failed("Validating Profitcenter details", "Profitcenter should be " + expected_Profitcenter,
//							actualProfitcenter + " Profitcenter details are incorrect");
//				}
//
//				String expected_Contractexchangerate = Contractexchangerate[i].trim();
//
//				expected_Contractexchangerate = expected_Contractexchangerate.replace("Null", " ");
//
//				if (actualContractexchangerate.contains(expected_Contractexchangerate)) {
//					passed("Validating Contractexchangerate details",
//							"Contractexchangerate should be " + expected_Contractexchangerate,
//							actualContractexchangerate + " Contractexchangerate correctly displayed");
//				} else {
//					failed("Validating Contractexchangerate details",
//							"Contractexchangerate should be " + expected_Contractexchangerate,
//							actualContractexchangerate + " Contractexchangerate details are incorrect");
//				}
//
//				String expected_Basecurrency = Basecurrency[i].trim();
//
//				expected_Basecurrency = expected_Basecurrency.replace("Null", " ");
//
//				if (actualBasecurrency.contains(expected_Profitcenter)) {
//					passed("Validating Basecurrency details", "Basecurrency should be " + expected_Basecurrency,
//							actualBasecurrency + " Basecurrency correctly displayed");
//				} else {
//					failed("Validating Basecurrency details", "Basecurrency should be " + expected_Basecurrency,
//							actualBasecurrency + " Basecurrency details are incorrect");
//				}
//
//				String expected_Basecurrencyvalue = Basecurrencyvalue[i].trim();
//
//				expected_Basecurrencyvalue = expected_Basecurrencyvalue.replace("Null", " ");
//
//				if (actualBasecurrencyvalue.contains(expected_Basecurrencyvalue)) {
//					passed("Validating Basecurrencyvalue details",
//							"Basecurrencyvalue should be " + expected_Basecurrencyvalue,
//							actualBasecurrencyvalue + " Basecurrencyvalue correctly displayed");
//				} else {
//					failed("Validating Basecurrencyvalue details",
//							"Basecurrencyvalue should be " + expected_Basecurrencyvalue,
//							actualBasecurrencyvalue + " Basecurrencyvalue details are incorrect");
//				}
//
//				String expected_Localcontractcurrency = Localcontractcurrency[i].trim();
//
//				expected_Localcontractcurrency = expected_Localcontractcurrency.replace("Null", " ");
//
//				if (actualLocalcontractcurrency.contains(expected_Localcontractcurrency)) {
//					passed("Validating Localcontractcurrency details",
//							"Localcontractcurrency should be " + expected_Localcontractcurrency,
//							actualLocalcontractcurrency + " Localcontractcurrency correctly displayed");
//				} else {
//					failed("Validating Localcontractcurrency details",
//							"Localcontractcurrency should be " + expected_Localcontractcurrency,
//							actualLocalcontractcurrency + " Localcontractcurrency details are incorrect");
//				}
//
//				String expected_Localcontractcurrencyvalue = Localcontractcurrencyvalue[i].trim();
//
//				expected_Localcontractcurrencyvalue = expected_Localcontractcurrencyvalue.replace("Null", " ");
//
//				if (actualLocalcontractcurrencyvalue.contains(expected_Localcontractcurrencyvalue)) {
//					passed("Validating Localcontractcurrencyvalue details",
//							"Localcontractcurrencyvalue should be " + expected_Localcontractcurrencyvalue,
//							actualLocalcontractcurrencyvalue + " Localcontractcurrencyvalue correctly displayed");
//				} else {
//					failed("Validating Localcontractcurrencyvalue details",
//							"Localcontractcurrencyvalue should be " + expected_Localcontractcurrencyvalue,
//							actualLocalcontractcurrencyvalue + " Localcontractcurrencyvalue details are incorrect");
//				}
//
//				String expected_Startedate = Startedate[i].trim();
//
//				expected_Startedate = expected_Startedate.replace("Null", " ");
//
//				if (actualStartedate.contains(expected_Startedate)) {
//					passed("Validating Startedate details", "Startedate should be " + expected_Startedate,
//							actualStartedate + " Startedate correctly displayed");
//				} else {
//					failed("Validating Startedate details", "Startedate should be " + expected_Startedate,
//							actualStartedate + " Startedate details are incorrect");
//				}
//
//				String expected_Enddate = Enddate[i].trim();
//
//				expected_Enddate = expected_Enddate.replace("Null", " ");
//
//				if (actualEnddate.contains(expected_Enddate)) {
//					passed("Validating Enddate details", "Enddate should be " + expected_Enddate,
//							actualEnddate + " Enddate correctly displayed");
//				} else {
//					failed("Validating Enddate details", "Enddate should be " + expected_Enddate,
//							actualEnddate + " Enddate details are incorrect");
//				}
//
//				String expected_History = History[i].trim();
//
//				expected_History = expected_History.replace("Null", " ");
//
//				if (actualHistory.contains(expected_History)) {
//					passed("Validating History details", "History should be " + expected_History,
//							actualHistory + " History correctly displayed");
//				} else {
//					failed("Validating History details", "History should be " + expected_History,
//							actualHistory + " History details are incorrect");
//				}

				invoiceRow++;
			}
		} else {
			failed("Validating JE type", "Reclass deferred revenue JE Type should be present",
					"Reclass deferred revenue JE Type is not present");
		}
		
		if (uiDriver.checkElementPresent("//input[@id='_back']")) {
			uiDriver.executeJavaScript("scroll(0,-1000)");
			uiDriver.click("//input[@id='_back']");
		} else {
			uiDriver.back();
		}
		}
	
	
	
	public void validateCreditMemo(DataRow input, DataRow output) {

		uiDriver.click("//*[text()='elated Records']");
		SleepUtils.sleep(TimeSlab.YIELD);
		//
		//uiDriver.click("//*[text()='Credit Memo']/preceding::a[1]");
		String CreditMemoDate=uiDriver.getDyanmicData("Creditmemo");
		String CMDLink=CreditMemoDate.replace("#",input.get("CreditAmount"));
		uiDriver.click_dynamic(CMDLink);
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,5000)");

		String actual_Customer = uiDriver.getValue("//span[@id='entity_fs_lbl_uir_label']//following-sibling::span//a");
		String actual_Status = uiDriver.getValue("//div[@class='uir-record-status']");
		String actual_Subsidiary = uiDriver
				.getValue("//span[@id='subsidiary_lbl_uir_label']//following-sibling::span//span");
		String actual_RevisionNumber = uiDriver
				.getValue("//span[@id='custbody_nbcu_revision_number_fs_lbl_uir_label']//following-sibling::span");
		String actual_CreditMemoType = uiDriver
				.getValue("//span[@id='custbody_nbcu_cm_type_fs_lbl_uir_label']//following-sibling::span//span");

		String expected_Customer = input.get("Customer");
		String expected_Status = input.get("Status");
		String expected_Subsidiary = input.get("Subsidiary");
		String expected_RevisionNumber = input.get("RevisionNumber");
		String expected_CreditMemoType = input.get("CreditMemoType");

		if (actual_Customer.toLowerCase().trim().contains(expected_Customer.toLowerCase().trim())
				|| expected_Customer.toLowerCase().trim().contains(actual_Customer.toLowerCase().trim())) {
			passed("validateCreditMemo", "Customer should be displayed as : " + expected_Customer.trim(),
					"Customer is displayed as : " + actual_Customer.trim());
		} else {
			failed("validateCreditMemo", "Customer should be displayed as : " + expected_Customer.trim(),
					"Customer is displayed as : " + actual_Customer.trim());
		}

		if (actual_Status.toLowerCase().trim().contains(expected_Status.toLowerCase().trim())
				|| expected_Status.toLowerCase().trim().contains(actual_Status.toLowerCase().trim())) {
			passed("validateCreditMemo", "Status should be displayed as : " + expected_Status.trim(),
					"Status is displayed as : " + actual_Status.trim());
		} else {
			failed("validateCreditMemo", "Status should be displayed as : " + expected_Status.trim(),
					"Status is displayed as : " + actual_Status.trim());
		}

		if (actual_Subsidiary.toLowerCase().trim().contains(expected_Subsidiary.toLowerCase().trim())
				|| expected_Subsidiary.toLowerCase().trim().contains(actual_Subsidiary.toLowerCase().trim())) {
			passed("validateCreditMemo", "Subsidiary should be displayed as : " + expected_Subsidiary.trim(),
					"Subsidiary is displayed as : " + actual_Subsidiary.trim());
		} else {
			failed("validateCreditMemo", "Subsidiary should be displayed as : " + expected_Subsidiary.trim(),
					"Subsidiary is displayed as : " + actual_Subsidiary.trim());
		}

		if (actual_RevisionNumber.toLowerCase().trim().contains(expected_RevisionNumber.toLowerCase().trim())
				|| expected_RevisionNumber.toLowerCase().trim().contains(actual_RevisionNumber.toLowerCase().trim())) {
			passed("validateCreditMemo", "RevisionNumber should be displayed as : " + expected_RevisionNumber.trim(),
					"RevisionNumber is displayed as : " + actual_RevisionNumber.trim());
		} else {
			failed("validateCreditMemo", "RevisionNumber should be displayed as : " + expected_RevisionNumber.trim(),
					"RevisionNumber is displayed as : " + actual_RevisionNumber.trim());
		}

		if (actual_CreditMemoType.toLowerCase().trim().contains(expected_CreditMemoType.toLowerCase().trim())
				|| expected_CreditMemoType.toLowerCase().trim().contains(actual_CreditMemoType.toLowerCase().trim())) {
			passed("validateCreditMemo", "InvoiceType should be displayed as : " + expected_CreditMemoType.trim(),
					"InvoiceType is displayed as : " + actual_CreditMemoType.trim());
		} else {
			failed("validateCreditMemo", "InvoiceType should be displayed as : " + expected_CreditMemoType.trim(),
					"InvoiceType is displayed as : " + actual_CreditMemoType.trim());
		}

		String Items = input.get("Item");
		String Item[] = Items.split(";");

		String Quantities = input.get("Quantity");
		String Quantity[] = Quantities.split(";");

		String Rates = input.get("Rate");
		String Rate[] = Rates.split(";");

		String Amounts = input.get("Amount");
		String Amount[] = Amounts.split(";");

		String TaxCodes = input.get("Tax Code");
		String TaxCode[] = TaxCodes.split(";");

		String MarketCodes = input.get("Market Code");
		String MarketCode[] = MarketCodes.split(";");

		String Territories = input.get("Territory");
		String Territory[] = Territories.split(";");

		String TitleIDs = input.get("Title ID");
		String TitleID[] = TitleIDs.split(";");

		String GLPNs = input.get("GLPN");
		String GLPN[] = GLPNs.split(";");

		String ProductOwners = input.get("Product Owner");
		String ProductOwner[] = ProductOwners.split(";");

		String Rights = input.get("Right");
		String Right[] = Rights.split(";");

		String UnbilledRevenueAccounts = input.get("Unbilled Revenue Account");
		String UnbilledRevenueAccount[] = UnbilledRevenueAccounts.split(";");

		String BilledRevenueAccounts = input.get("Billed Revenue Account");
		String BilledRevenueAccount[] = BilledRevenueAccounts.split(";");

		String BilledARAccounts = input.get("Billed AR Account");
		String BilledARAccount[] = BilledARAccounts.split(";");

		String UnbilledARAccounts = input.get("Unbilled AR Account");
		String UnbilledARAccount[] = UnbilledARAccounts.split(";");

		String PaidDeferredRevenueAccounts = input.get("Paid Deferred Revenue Account");
		String PaidDeferredRevenueAccount[] = PaidDeferredRevenueAccounts.split(";");

		String UnpaidDeferredRevenueAccounts = input.get("Unpaid Deferred Revenue Account");
		String UnpaidDeferredRevenueAccount[] = UnpaidDeferredRevenueAccounts.split(";");

		String BadDebtRevenueAccounts = input.get("Bad Debt Revenue Account");
		String BadDebtRevenueAccount[] = BadDebtRevenueAccounts.split(";");

		List<WebElement> LineItems = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tr"));
		int total_LineItems = LineItems.size();
		int actualsize=BadDebtRevenueAccount.length;

		int k = 0, temp = 0;
		for (int j = 2; j <= actualsize+1; j++) {

			List<WebElement> el;
			String xpath = "//table[@id='item_splits']//td[contains(text(),'" + GLPN[k].trim() + "')]";

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Item']//..//preceding-sibling::*)+1]")) {
				String actual_Item;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Item']//..//preceding-sibling::*)+1]"));
				try {
					actual_Item = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_Item = el.get(0).getText();
				}

				String expected_Item = Item[k].trim();
				expected_Item = expected_Item.replace("Null", " ");

				if (expected_Item.contains(actual_Item) || actual_Item.contains(expected_Item)) {
					passed("validateCreditMemo", "Item Should be displayed as " + expected_Item,
							"Item is displayed as " + actual_Item);
				} else {
					failed("validateCreditMemo", "Item Should be displayed as " + expected_Item,
							"Item is displayed as " + actual_Item);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Quantity']//..//preceding-sibling::*)+1]")) {
				String actual_Quantity;
				float actual_Quantity_temp;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Quantity']//..//preceding-sibling::*)+1]"));
				try {
					actual_Quantity = el.get(temp).getText();
					actual_Quantity = actual_Quantity.replace(",", "");
					actual_Quantity_temp = Float.parseFloat(actual_Quantity);
				} catch (Exception e) {
					temp = 0;
					actual_Quantity = el.get(0).getText();
					actual_Quantity = actual_Quantity.replace(",", "");
					actual_Quantity_temp = Float.parseFloat(actual_Quantity);
				}

				String expected_Quantity = Quantity[k].trim();
				expected_Quantity = expected_Quantity.replace("Null", " ");
				expected_Quantity = expected_Quantity.replace(",", "");
				Float expected_Quantity_temp = Float.parseFloat(actual_Quantity);

				if (expected_Quantity_temp == actual_Quantity_temp) {
					passed("validateCreditMemo", "Quantity Should be displayed as " + expected_Quantity,
							"Quantity is displayed as " + actual_Quantity);
				} else {
					failed("validateCreditMemo", "Quantity Should be displayed as " + expected_Quantity,
							"Quantity is displayed as " + actual_Quantity);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Rate']//..//preceding-sibling::*)+1]")) {
				String actual_Rate;
				float actual_Rate_temp;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Rate']//..//preceding-sibling::*)+1]"));
				try {
					actual_Rate = el.get(temp).getText();
					actual_Rate = actual_Rate.replace(",", "");
					actual_Rate_temp = Float.parseFloat(actual_Rate);
				} catch (Exception e) {
					temp = 0;
					actual_Rate = el.get(0).getText();
					actual_Rate = actual_Rate.replace(",", "");
					actual_Rate_temp = Float.parseFloat(actual_Rate);
				}

				String expected_Rate = Rate[k].trim();
				expected_Rate = expected_Rate.replace("Null", " ");
				expected_Rate = expected_Rate.replace(",", "");
				Float expected_Rate_temp = Float.parseFloat(actual_Rate);

				if (expected_Rate_temp == actual_Rate_temp) {
					passed("validateCreditMemo", "Rate Should be displayed as " + expected_Rate,
							"Rate is displayed as " + actual_Rate);
				} else {
					failed("validateCreditMemo", "Rate Should be displayed as " + expected_Rate,
							"Rate is displayed as " + actual_Rate);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Amount']//..//preceding-sibling::*)+1]")) {
				String actual_Amount;
				float actual_Amount_temp;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Amount']//..//preceding-sibling::*)+1]"));
				try {
					actual_Amount = el.get(temp).getText();
					actual_Amount = actual_Amount.replace(",", "");
					actual_Amount_temp = Float.parseFloat(actual_Amount);
				} catch (Exception e) {
					temp = 0;
					actual_Amount = el.get(0).getText();
					actual_Amount = actual_Amount.replace(",", "");
					actual_Amount_temp = Float.parseFloat(actual_Amount);
				}

				String expected_Amount = Amount[k].trim();
				expected_Amount = expected_Amount.replace("Null", " ");
				expected_Amount = expected_Amount.replace(",", "");
				Float expected_Amount_temp = Float.parseFloat(actual_Amount);

				if (expected_Amount_temp == actual_Amount_temp) {
					passed("validateCreditMemo", "Amount Should be displayed as " + expected_Amount,
							"Amount is displayed as " + actual_Amount);
				} else {
					failed("validateCreditMemo", "Amount Should be displayed as " + expected_Amount,
							"Amount is displayed as " + actual_Amount);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Tax Code']//..//preceding-sibling::*)+1]")) {
				String actual_TaxCode;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Tax Code']//..//preceding-sibling::*)+1]"));
				try {
					actual_TaxCode = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_TaxCode = el.get(0).getText();
				}

				String expected_TaxCode = TaxCode[k].trim();
				expected_TaxCode = expected_TaxCode.replace("Null", " ");

				if (expected_TaxCode.contains(actual_TaxCode) || actual_TaxCode.contains(expected_TaxCode)) {
					passed("validateCreditMemo", "TaxCode Should be displayed as " + expected_TaxCode,
							"TaxCode is displayed as " + actual_TaxCode);
				} else {
					failed("validateCreditMemo", "TaxCode Should be displayed as " + expected_TaxCode,
							"TaxCode is displayed as " + actual_TaxCode);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Market Code']//..//preceding-sibling::*)+1]")) {
				String actual_MarketCode;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Market Code']//..//preceding-sibling::*)+1]"));
				try {
					actual_MarketCode = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_MarketCode = el.get(0).getText();
				}

				String expected_MarketCode = MarketCode[k].trim();
				expected_MarketCode = expected_MarketCode.replace("Null", " ");

				if (expected_MarketCode.contains(actual_MarketCode)
						|| actual_MarketCode.contains(expected_MarketCode)) {
					passed("validateCreditMemo", "MarketCode Should be displayed as " + expected_MarketCode,
							"MarketCode is displayed as " + actual_MarketCode);
				} else {
					failed("validateCreditMemo", "MarketCode Should be displayed as " + expected_MarketCode,
							"MarketCode is displayed as " + actual_MarketCode);
				}
			}
			
			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Territory']//..//preceding-sibling::*)+1]")) {
				String actual_Territory;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Territory']//..//preceding-sibling::*)+1]"));
				try {
					actual_Territory = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_Territory = el.get(0).getText();
				}

				String expected_Territory = Territory[k].trim();
				expected_Territory = expected_Territory.replace("Null", " ");

				if (expected_Territory.contains(actual_Territory)
						|| actual_Territory.contains(expected_Territory)) {
					passed("validateCreditMemo", "Territory Should be displayed as " + expected_Territory,
							"Territory is displayed as " + actual_Territory);
				} else {
					failed("validateCreditMemo", "Territory Should be displayed as " + expected_Territory,
							"Territory is displayed as " + actual_Territory);
				}
			}

			// String actual_Territory =
			// uiDriver.getValue("(//table[@id='item_splits']//tr)["+j+"]//td[8]");
			String actual_Territory = uiDriver.getValue("//table[@id='item_splits']/tbody/tr[" + j
					+ "]//td[count(//table[@id='item_splits']//td/div[contains(text(),'Territory')]/../preceding-sibling::*)+1]");
			String expected_Territory = Territory[k].trim();
			if (expected_Territory.contains(actual_Territory) || actual_Territory.contains(expected_Territory)) {
				passed("validateCreditMemo", "Territory Should be displayed as " + expected_Territory,
						"Territory is displayed as " + actual_Territory);
			} else {
				failed("validateCreditMemo", "Territory Should be displayed as " + expected_Territory,
						"Territory is displayed as " + actual_Territory);
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title ID']//..//preceding-sibling::*)+1]")) {
				String actual_TitleID;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title ID']//..//preceding-sibling::*)+1]"));
				try {
					actual_TitleID = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_TitleID = el.get(0).getText();
				}

				String expected_TitleID = TitleID[k].trim();
				expected_TitleID = expected_TitleID.replace("Null", " ");

				if (expected_TitleID.contains(actual_TitleID) || actual_TitleID.contains(expected_TitleID)) {
					passed("validateCreditMemo", "TitleID Should be displayed as " + expected_TitleID,
							"TitleID is displayed as " + actual_TitleID);
				} else {
					failed("validateCreditMemo", "TitleID Should be displayed as " + expected_TitleID,
							"TitleID is displayed as " + actual_TitleID);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]")) {
				String actual_GLPN;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]"));
				try {
					actual_GLPN = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_GLPN = el.get(0).getText();
				}

				String expected_GLPN = GLPN[k].trim();
				expected_GLPN = expected_GLPN.replace("Null", " ");

				if (expected_GLPN.contains(actual_GLPN) || actual_GLPN.contains(expected_GLPN)) {
					passed("validateCreditMemo", "GLPN Should be displayed as " + expected_GLPN,
							"GLPN is displayed as " + actual_GLPN);
				} else {
					failed("validateCreditMemo", "GLPN Should be displayed as " + expected_GLPN,
							"GLPN is displayed as " + actual_GLPN);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Owner']//..//preceding-sibling::*)+1]")) {
				String actual_ProductOwner;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Owner']//..//preceding-sibling::*)+1]"));
				try {
					actual_ProductOwner = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_ProductOwner = el.get(0).getText();
				}

				String expected_ProductOwner = ProductOwner[k].trim();
				expected_ProductOwner = expected_ProductOwner.replace("Null", " ");

				if (expected_ProductOwner.contains(actual_ProductOwner)
						|| actual_ProductOwner.contains(expected_ProductOwner)) {
					passed("validateCreditMemo", "ProductOwner Should be displayed as " + expected_ProductOwner,
							"ProductOwner is displayed as " + actual_ProductOwner);
				} else {
					failed("validateCreditMemo", "ProductOwner Should be displayed as " + expected_ProductOwner,
							"ProductOwner is displayed as " + actual_ProductOwner);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Right']//..//preceding-sibling::*)+1]")) {
				String actual_Right;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Right']//..//preceding-sibling::*)+1]"));
				try {
					actual_Right = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_Right = el.get(0).getText();
				}

				String expected_Right = Right[k].trim();
				expected_Right = expected_Right.replace("Null", " ");

				if (expected_Right.contains(actual_Right) || actual_Right.contains(expected_Right)) {
					passed("validateCreditMemo", "Right Should be displayed as " + expected_Right,
							"Right is displayed as " + actual_Right);
				} else {
					failed("validateCreditMemo", "Right Should be displayed as " + expected_Right,
							"Right is displayed as " + actual_Right);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled Revenue Account']//..//preceding-sibling::*)+1]")) {
				String actual_UnbilledRevenueAccount;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled Revenue Account']//..//preceding-sibling::*)+1]"));
				try {
					actual_UnbilledRevenueAccount = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_UnbilledRevenueAccount = el.get(0).getText();
				}

				String expected_UnbilledRevenueAccount = UnbilledRevenueAccount[k].trim();
				expected_UnbilledRevenueAccount = expected_UnbilledRevenueAccount.replace("Null", " ");

				if (expected_UnbilledRevenueAccount.contains(actual_UnbilledRevenueAccount)
						|| actual_UnbilledRevenueAccount.contains(expected_UnbilledRevenueAccount)) {
					passed("validateCreditMemo",
							"UnbilledRevenueAccount Should be displayed as " + expected_UnbilledRevenueAccount,
							"UnbilledRevenueAccount is displayed as " + actual_UnbilledRevenueAccount);
				} else {
					failed("validateCreditMemo",
							"UnbilledRevenueAccount Should be displayed as " + expected_UnbilledRevenueAccount,
							"UnbilledRevenueAccount is displayed as " + actual_UnbilledRevenueAccount);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed Revenue Account']//..//preceding-sibling::*)+1]")) {
				String actual_BilledRevenueAccount;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed Revenue Account']//..//preceding-sibling::*)+1]"));
				try {
					actual_BilledRevenueAccount = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_BilledRevenueAccount = el.get(0).getText();
				}

				String expected_BilledRevenueAccount = BilledRevenueAccount[k].trim();
				expected_BilledRevenueAccount = expected_BilledRevenueAccount.replace("Null", " ");

				if (expected_BilledRevenueAccount.contains(actual_BilledRevenueAccount)
						|| actual_BilledRevenueAccount.contains(expected_BilledRevenueAccount)) {
					passed("validateCreditMemo",
							"BilledRevenueAccount Should be displayed as " + expected_BilledRevenueAccount,
							"BilledRevenueAccount is displayed as " + actual_BilledRevenueAccount);
				} else {
					failed("validateCreditMemo",
							"BilledRevenueAccount Should be displayed as " + expected_BilledRevenueAccount,
							"BilledRevenueAccount is displayed as " + actual_BilledRevenueAccount);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed AR Account']//..//preceding-sibling::*)+1]")) {
				String actual_BilledARAccount;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed AR Account']//..//preceding-sibling::*)+1]"));
				try {
					actual_BilledARAccount = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_BilledARAccount = el.get(0).getText();
				}

				String expected_BilledARAccount = BilledARAccount[k].trim();
				expected_BilledARAccount = expected_BilledARAccount.replace("Null", " ");

				if (expected_BilledARAccount.contains(actual_BilledARAccount)
						|| actual_BilledARAccount.contains(expected_BilledARAccount)) {
					passed("validateCreditMemo", "BilledARAccount Should be displayed as " + expected_BilledARAccount,
							"BilledARAccount is displayed as " + actual_BilledARAccount);
				} else {
					failed("validateCreditMemo", "BilledARAccount Should be displayed as " + expected_BilledARAccount,
							"BilledARAccount is displayed as " + actual_BilledARAccount);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled AR Account']//..//preceding-sibling::*)+1]")) {
				String actual_UnbilledARAccount;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled AR Account']//..//preceding-sibling::*)+1]"));
				try {
					actual_UnbilledARAccount = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_UnbilledARAccount = el.get(0).getText();
				}

				String expected_UnbilledARAccount = UnbilledARAccount[k].trim();
				expected_UnbilledARAccount = expected_UnbilledARAccount.replace("Null", " ");

				if (expected_UnbilledARAccount.contains(actual_UnbilledARAccount)
						|| actual_UnbilledARAccount.contains(expected_UnbilledARAccount)) {
					passed("validateCreditMemo",
							"UnbilledARAccount Should be displayed as " + expected_UnbilledARAccount,
							"UnbilledARAccount is displayed as " + actual_UnbilledARAccount);
				} else {
					failed("validateCreditMemo",
							"UnbilledARAccount Should be displayed as " + expected_UnbilledARAccount,
							"UnbilledARAccount is displayed as " + actual_UnbilledARAccount);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Paid Deferred Account']//..//preceding-sibling::*)+1]")) {
				String actual_PaidDeferredRevenueAccount;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Paid Deferred Account']//..//preceding-sibling::*)+1]"));
				try {
					actual_PaidDeferredRevenueAccount = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_PaidDeferredRevenueAccount = el.get(0).getText();
				}

				String expected_PaidDeferredRevenueAccount = PaidDeferredRevenueAccount[k].trim();
				expected_PaidDeferredRevenueAccount = expected_PaidDeferredRevenueAccount.replace("Null", " ");

				if (expected_PaidDeferredRevenueAccount.contains(actual_PaidDeferredRevenueAccount)
						|| actual_PaidDeferredRevenueAccount.contains(expected_PaidDeferredRevenueAccount)) {
					passed("validateCreditMemo",
							"PaidDeferredRevenueAccount Should be displayed as " + expected_PaidDeferredRevenueAccount,
							"PaidDeferredRevenueAccount is displayed as " + actual_PaidDeferredRevenueAccount);
				} else {
					failed("validateCreditMemo",
							"PaidDeferredRevenueAccount Should be displayed as " + expected_PaidDeferredRevenueAccount,
							"PaidDeferredRevenueAccount is displayed as " + actual_PaidDeferredRevenueAccount);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unpaid Deferred Account']//..//preceding-sibling::*)+1]")) {
				String actual_UnpaidDeferredRevenueAccount;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unpaid Deferred Account']//..//preceding-sibling::*)+1]"));
				try {
					actual_UnpaidDeferredRevenueAccount = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_UnpaidDeferredRevenueAccount = el.get(0).getText();
				}

				String expected_UnpaidDeferredRevenueAccount = UnpaidDeferredRevenueAccount[k].trim();
				expected_UnpaidDeferredRevenueAccount = expected_UnpaidDeferredRevenueAccount.replace("Null", " ");

				if (expected_UnpaidDeferredRevenueAccount.contains(actual_UnpaidDeferredRevenueAccount)
						|| actual_UnpaidDeferredRevenueAccount.contains(expected_UnpaidDeferredRevenueAccount)) {
					passed("validateCreditMemo",
							"UnpaidDeferredRevenueAccount Should be displayed as "
									+ expected_UnpaidDeferredRevenueAccount,
							"UnpaidDeferredRevenueAccount is displayed as " + actual_UnpaidDeferredRevenueAccount);
				} else {
					failed("validateCreditMemo",
							"UnpaidDeferredRevenueAccount Should be displayed as "
									+ expected_UnpaidDeferredRevenueAccount,
							"UnpaidDeferredRevenueAccount is displayed as " + actual_UnpaidDeferredRevenueAccount);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Bad Debt Revenue Account']//..//preceding-sibling::*)+1]")) {
				String actual_BadDebtRevenueAccount;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Bad Debt Revenue Account']//..//preceding-sibling::*)+1]"));
				try {
					actual_BadDebtRevenueAccount = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_BadDebtRevenueAccount = el.get(0).getText();
				}

				String expected_BadDebtRevenueAccount = BadDebtRevenueAccount[k].trim();
				expected_BadDebtRevenueAccount = expected_BadDebtRevenueAccount.replace("Null", " ");

				if (expected_BadDebtRevenueAccount.contains(actual_BadDebtRevenueAccount)
						|| actual_BadDebtRevenueAccount.contains(expected_BadDebtRevenueAccount)) {
					passed("validateCreditMemo",
							"BadDebtRevenueAccount Should be displayed as " + expected_BadDebtRevenueAccount,
							"BadDebtRevenueAccount is displayed as " + actual_BadDebtRevenueAccount);
				} else {
					failed("validateCreditMemo",
							"BadDebtRevenueAccount Should be displayed as " + expected_BadDebtRevenueAccount,
							"BadDebtRevenueAccount is displayed as " + actual_BadDebtRevenueAccount);
				}
			}
			
			k++;
		}
		
		if(uiDriver.checkElementPresent("//input[@id='_back']")) {
			uiDriver.executeJavaScript("scroll(0,-1000)");
			uiDriver.click("//input[@id='_back']");
		} else {
			uiDriver.back();
		}
	}
	
	public void abc(DataRow input, DataRow output) throws InterruptedException {
		String GLPNs = input.get("GLPN");
		String GLPN[] = GLPNs.split(";");

		String Items = input.get("Item");
		String Item[] = Items.split(";");
		
		List<WebElement> LineItems = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tr"));
		int total_LineItems = LineItems.size();

		int temp = 0, k = 0;
		for (int j = 2; j < total_LineItems; j++) {

			String xpath = "//table[@id='line_splits']//td[contains(text(),'" + GLPN[k].trim() + "')]";

			List<WebElement> el = uiDriver.webDr
					.findElements(By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
							+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Item']//..//preceding-sibling::*)+1]"));
			String actual_Account;
			try {
				actual_Account = el.get(temp).getText();
			} catch (Exception e) {
				temp = 0;
				actual_Account = el.get(temp).getText();
			}
			String expected_Account = Item[k].trim();
			if (expected_Account.toLowerCase().contains(actual_Account.toLowerCase())
					|| expected_Account.toLowerCase().contains(actual_Account.toLowerCase())) {
				passed("VerifyTitleAllocationJoural-", "Account Should be displayed as " + expected_Account,
						"Account is displayed as " + actual_Account);
			} else {
				failed("VerifyTitleAllocationJoural-", "Account Should be displayed as " + expected_Account,
						"Account is displayed as " + actual_Account);
			}

			el = uiDriver.webDr.findElements(By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'"
					+ GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]"));
			String actual_GLPN = el.get(temp).getText();
			String expected_GLPN = GLPN[k].trim();
			if (expected_GLPN.toLowerCase().contains(actual_GLPN.toLowerCase())
					|| actual_GLPN.toLowerCase().contains(expected_GLPN.toLowerCase())) {
				passed("VerifyTitleAllocationJoural-", "GLPN Should be displayed as " + expected_GLPN,
						"GLPN is displayed as " + actual_GLPN);
			} else {
				failed("VerifyTitleAllocationJoural-", "GLPN Should be displayed as " + expected_GLPN,
						"GLPN is displayed as " + actual_GLPN);
			}

			el = uiDriver.webDr.findElements(By.xpath(xpath));
			if (el.size() > 1) {
				temp++;
			} else {
				temp = 0;
			}
			
			k++;
		}
	}
	
	
	/****************************************
	 * 
	 * Name: VeryfyGlAccountData1
	 * 
	 * Description: To verify details of Invoice GLImpact
	 * 
	 * Date: 16/08/2019
	 * 
	 ****************************************/
	public void VerifyGlAccountDataold(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.HIGH);

		String ACCOUNT = input.get("ACCOUNT");
		String ACCOUNTS[] = ACCOUNT.split(";");

		String DEBIT = input.get("DEBIT");
		String DEBITS[] = DEBIT.split(";");

		String CREDIT = input.get("CREDIT");
		String CREDITS[] = CREDIT.split(";");

		String Name = input.get("Name");
		String Names[] = Name.split(";");

		String Subsidiary = input.get("Subsidiary");
		String Subsidiarys[] = Subsidiary.split(";");

		String MarketCode = input.get("MarketCode");
		String MarketCodes[] = MarketCode.split(";");

		String Territory = input.get("Territory");
		String Territorys[] = Territory.split(";");

		String GLPN = input.get("GLPN");
		String GLPNS[] = GLPN.split(";");

		System.out.println(ACCOUNTS.length);

		int temp = 0;

		for (int k = 0; k < GLPNS.length; k++) {

			String xpath = "//table[@id='div__bodytab']//td[contains(text(),'" + GLPNS[k].trim() + "')]";

			if (uiDriver.checkElementPresent("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
					+ GLPNS[k].trim().replace("NULL", " ")
					+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Account']//..//preceding-sibling::*)+1]")) {
			List<WebElement> el = uiDriver.webDr
					.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
							+ GLPNS[k].trim().replace("NULL", " ")
							+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Account']//..//preceding-sibling::*)+1]"));

			String actual_Account;
			try {
				actual_Account = el.get(temp).getText();
			} catch (Exception e) {
				temp = 0;
				actual_Account = el.get(temp).getText();
			}

			String expected_Account = ACCOUNTS[k].trim();
			if (actual_Account != null && !actual_Account.equals(" ") && !actual_Account.equals("")) {
				if (expected_Account.toLowerCase().contains(actual_Account.toLowerCase())
						|| actual_Account.toLowerCase().contains(expected_Account.toLowerCase())) {
					passed("VerifyGLImpactData", "Account Should be displayed as " + expected_Account,
							"Account is displayed as " + actual_Account);
				} else {
					failed("VerifyGLImpactData", "Account Should be displayed as " + expected_Account,
							"Account is not displayed as " + actual_Account);
				}
			} else {
				// nothing
			}
			}
						
			if (uiDriver.checkElementPresent("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
					+ GLPNS[k].trim().replace("NULL", " ")
					+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Name']//..//preceding-sibling::*)-6]")) {
				List<WebElement> el = uiDriver.webDr.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
					+ GLPNS[k].trim().replace("NULL", " ")
					+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Name']//..//preceding-sibling::*)-6]"));

			String actual_Name;
			try {
				actual_Name = el.get(temp).getText();
			} catch (Exception e) {
				temp = 0;
				actual_Name = el.get(temp).getText();
			}

			String expected_Name = Names[k].trim();
			if (actual_Name != null && !actual_Name.equals(" ") && !actual_Name.equals("")) {
				if (expected_Name.toLowerCase().contains(actual_Name.toLowerCase())
						|| actual_Name.toLowerCase().contains(expected_Name.toLowerCase())) {
					passed("VerifyGLImpactData", "Name Should be displayed as " + expected_Name,
							"Name is displayed as " + actual_Name);
				} else {
					failed("VerifyGLImpactData", "Name Should be displayed as " + expected_Name,
							"Name should not be displayed as " + actual_Name);
				}
			} else {
				// nothing
			}
			}

			if (uiDriver.checkElementPresent("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
					+ GLPNS[k].trim().replace("NULL", " ")
					+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Subsidiary']//..//preceding-sibling::*)-5]")) {
			List<WebElement> el = uiDriver.webDr.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
					+ GLPNS[k].trim().replace("NULL", " ")
					+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Subsidiary']//..//preceding-sibling::*)-5]"));

			String actual_Subsidiary;
			try {
				actual_Subsidiary = el.get(temp).getText();
			} catch (Exception e) {
				temp = 0;
				actual_Subsidiary = el.get(temp).getText();
			}

			String expected_Subsidiary = Subsidiarys[k].trim();
			if (actual_Subsidiary != null && !actual_Subsidiary.equals(" ") && !actual_Subsidiary.equals("")) {
				if (expected_Subsidiary.toLowerCase().contains(actual_Subsidiary.toLowerCase())
						|| actual_Subsidiary.toLowerCase().contains(expected_Subsidiary.toLowerCase())) {
					passed("VerifyGLImpactData", "Subsidiary Should be displayed as " + expected_Subsidiary,
							"Subsidiary is displayed as " + actual_Subsidiary);
				} else {
					failed("VerifyGLImpactData", "Subsidiary Should be displayed as " + expected_Subsidiary,
							"Subsidiary should not be displayed as " + actual_Subsidiary);
				}
			} else {
				// nothing
			}
			}
						
			if (uiDriver.checkElementPresent("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
					+ GLPNS[k].trim().replace("NULL", " ")
					+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Market Code']//..//preceding-sibling::*)-6]")) {
				List<WebElement> el = uiDriver.webDr.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
					+ GLPNS[k].trim().replace("NULL", " ")
					+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Market Code']//..//preceding-sibling::*)-6]"));

			String actual_MarketCode;
			try {
				actual_MarketCode = el.get(temp).getText();
			} catch (Exception e) {
				temp = 0;
				actual_MarketCode = el.get(temp).getText();
			}

			String expected_MarketCode = MarketCodes[k].trim();
			if (actual_MarketCode != null && !actual_MarketCode.equals(" ") && !actual_MarketCode.equals("")) {
				if (expected_MarketCode.toLowerCase().contains(actual_MarketCode.toLowerCase())
						|| actual_MarketCode.toLowerCase().contains(expected_MarketCode.toLowerCase())) {
					passed("VerifyGLImpactData", "MarketCode Should be displayed as " + expected_MarketCode,
							"MarketCode is displayed as " + actual_MarketCode);
				} else {
					failed("VerifyGLImpactData", "MarketCode Should be displayed as " + expected_MarketCode,
							"MarketCode should not be displayed as " + actual_MarketCode);
				}
			} else {
				// nothing
			}
			}

			if (uiDriver.checkElementPresent("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
					+ GLPNS[k].trim().replace("NULL", " ")
					+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Territory']//..//preceding-sibling::*)-7]")) {
			List<WebElement> el = uiDriver.webDr.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
					+ GLPNS[k].trim().replace("NULL", " ")
					+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Territory']//..//preceding-sibling::*)-7]"));

			String actual_Territory;
			try {
				actual_Territory = el.get(temp).getText();
			} catch (Exception e) {
				temp = 0;
				actual_Territory = el.get(temp).getText();
			}

			String expected_Territory = Territorys[k].trim();
			if (actual_Territory != null && !actual_Territory.equals(" ") && !actual_Territory.equals("")) {
				if (expected_Territory.toLowerCase().contains(actual_Territory.toLowerCase())
						|| actual_Territory.toLowerCase().contains(expected_Territory.toLowerCase())) {
					passed("VerifyGLImpactData", "Territory Should be displayed as " + expected_Territory,
							"Territory is displayed as " + actual_Territory);
				} else {
					failed("VerifyGLImpactData", "Territory Should be displayed as " + expected_Territory,
							"Territory should not be displayed as " + actual_Territory);
				}
			} else {
				// nothing
			}
			}
			
			if (uiDriver.checkElementPresent("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
					+ GLPNS[k].trim().replace("NULL", " ")
					+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Amount (Debit)']/../preceding-sibling::*)]")) {
			List<WebElement> el = uiDriver.webDr.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
					+ GLPNS[k].trim().replace("NULL", " ")
					+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Amount (Debit)']/../preceding-sibling::*)]"));
			String actual_Debit;
			try {
				actual_Debit = el.get(temp).getText();
			} catch (Exception e) {
				temp = 0;
				actual_Debit = el.get(temp).getText();
			}
			
			String expected_Debit = DEBITS[k].trim();
			if (actual_Debit != null && !actual_Debit.equals(" ") && !actual_Debit.equals("")) {
				try {
				expected_Debit = expected_Debit.replace(",", "");
				expected_Debit = expected_Debit.replace("$", "");
				
				actual_Debit = actual_Debit.replace(",", "");
				actual_Debit = actual_Debit.replace("$", "");

				Float exp_Debit_exchanged = Float.parseFloat(expected_Debit) * Float.parseFloat(text_ExchangeNumber);
				Float act_Debit_exchanged = Float.parseFloat(actual_Debit) * Float.parseFloat(text_ExchangeNumber);
				exp_Debit_exchanged = (float) Math.round(exp_Debit_exchanged);
				act_Debit_exchanged = (float) Math.round(act_Debit_exchanged);
				
				Float exp_Debit = Float.parseFloat(expected_Debit);
				Float act_Debit = Float.parseFloat(actual_Debit);
				exp_Debit = (float) Math.round(exp_Debit);
				act_Debit = (float) Math.round(act_Debit);

				if (exp_Debit_exchanged.toString().trim().contains(act_Debit_exchanged.toString().trim()) 
						|| act_Debit_exchanged.toString().trim().contains(exp_Debit_exchanged.toString().trim())
						|| exp_Debit.toString().trim().contains(act_Debit.toString().trim()) 
						|| act_Debit.toString().trim().contains(exp_Debit.toString().trim())
						|| exp_Debit_exchanged.toString().trim().contains(act_Debit.toString().trim())
						|| act_Debit.toString().trim().contains(exp_Debit_exchanged.toString().trim())
						|| exp_Debit.toString().trim().contains(act_Debit_exchanged.toString().trim())
						|| act_Debit_exchanged.toString().trim().contains(exp_Debit.toString().trim())) {
					passed("VerifyGLImpactData", "Debit Amount Should be displayed as " + expected_Debit,
							"Debit Amount is displayed as " + actual_Debit);
				} else {
					failed("VerifyGLImpactData", "Debit Amount Should be displayed as " + expected_Debit,
							"Debit Amount should not be displayed as " + actual_Debit);
				}
				} catch (Exception e) {					
				}
			}
			else {
				// Null
			}
			}
			
			if (uiDriver.checkElementPresent("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
					+ GLPNS[k].trim().replace("NULL", " ")
					+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Amount (Credit)']//..//preceding-sibling::*)-1]")) {
			List<WebElement> el = uiDriver.webDr.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
					+ GLPNS[k].trim().replace("NULL", " ")
					+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Amount (Credit)']//..//preceding-sibling::*)-1]"));
			String actual_Credit;
			try {
				actual_Credit = el.get(temp).getText();
			} catch (Exception e) {
				temp = 0;
				actual_Credit = el.get(temp).getText();
			}
			
			String expected_Credit = CREDITS[k].trim();
			if (actual_Credit != null && !actual_Credit.equals(" ") && !actual_Credit.equals("")) {
				try {
				expected_Credit = expected_Credit.replace(",", "");
				expected_Credit = expected_Credit.replace("$", "");
				
				actual_Credit = actual_Credit.replace(",", "");
				actual_Credit = actual_Credit.replace("$", "");

				Float exp_Credit_exchanged = Float.parseFloat(expected_Credit) * Float.parseFloat(text_ExchangeNumber);
				Float act_Credit_exchanged = Float.parseFloat(actual_Credit) * Float.parseFloat(text_ExchangeNumber);
				exp_Credit_exchanged = (float) Math.round(exp_Credit_exchanged);
				act_Credit_exchanged = (float) Math.round(act_Credit_exchanged);
				
				Float exp_Credit = Float.parseFloat(expected_Credit);
				Float act_Credit = Float.parseFloat(actual_Credit);
				exp_Credit = (float) Math.round(exp_Credit);
				act_Credit = (float) Math.round(act_Credit);

				if (exp_Credit_exchanged.toString().trim().contains(act_Credit_exchanged.toString().trim()) 
						|| act_Credit_exchanged.toString().trim().contains(exp_Credit_exchanged.toString().trim())
						|| exp_Credit.toString().trim().contains(act_Credit.toString().trim()) 
						|| act_Credit.toString().trim().contains(exp_Credit.toString().trim())
						|| exp_Credit_exchanged.toString().trim().contains(act_Credit.toString().trim())
						|| act_Credit.toString().trim().contains(exp_Credit_exchanged.toString().trim())
						|| exp_Credit.toString().trim().contains(act_Credit_exchanged.toString().trim())
						|| act_Credit_exchanged.toString().trim().contains(exp_Credit.toString().trim())) {
					passed("VerifyGLImpactData", "Credit Amount Should be displayed as " + expected_Credit,
							"Credit Amount is displayed as " + actual_Credit);
				} else {
					failed("VerifyGLImpactData", "Credit Amount Should be displayed as " + expected_Credit,
							"Credit Amount should not be displayed as " + actual_Credit);
				}
				} catch (Exception e) {					
				}
			}
			else {
				// Null
			}
			}

			List<WebElement> el = uiDriver.webDr.findElements(By.xpath(xpath));
			if (el.size() > 1) {
				temp++;
			} else {
				temp = 0;
			}
		}
		
		 while (true) {
		 if (uiDriver.checkElementPresent("//h1[text()='Invoice' or text()='Payment' "
		 		+ "or text()='Title Allocation Parent' or text()='Revenue Arrangement' "
		 		+ "or text()='Customer Credit'  or text()='Credit Memo']")) {
		 break;
		 } else {
		 uiDriver.back();
		 SleepUtils.sleep(TimeSlab.YIELD);
		 }
		 }

	}
	
	String text_ExchangeNumber;
	public void getExchangeNumber(DataRow input, DataRow output) throws InterruptedException {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("//input[@id='_searchstring']", input.get("conf"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//a[contains(text(),'Sales Order:')]");
		SleepUtils.sleep(TimeSlab.LOW);
		if (uiDriver.checkElementPresent("//h1[text()='Sales Order']")) {
		} else {
			failed("getExchangeNumber", "Sales Order Should be displayed", "Sales Order is not displayed");
		}

		uiDriver.click("//a[@id='accntingtabtxt']");
		SleepUtils.sleep(TimeSlab.LOW);
		text_ExchangeNumber = uiDriver.getValue("//span[@id='exchangerate_fs_lbl']//..//following-sibling::span");
		if (text_ExchangeNumber == null) {
			failed("getExchangeNumber", "Exchange Number should be stored successfully",
					"Exchange Number is not stored successfully");
		} else {
			passed("getExchangeNumber", "Exchange Number should be stored successfully",
					"Exchange Number is stored successfully as : " + text_ExchangeNumber);
		}

		uiDriver.click("//a[@id='itemstxt']");
		SleepUtils.sleep(TimeSlab.LOW);
	}

	
		public void NavigateToJE(DataRow input, DataRow output){
		      SleepUtils.sleep(TimeSlab.LOW);
		     // To click on Specific journal pass jeName in data sheet
		          uiDriver.click("//a[contains(text(),'lated Transactions') or (text()='lated Transactions')]");  
		          SleepUtils.sleep(TimeSlab.YIELD);
		          String JeXpath = "(//*[contains(text(),'#')]/preceding::a[3])[last()]";
		          String ActualJe = JeXpath.replace("#",input.get("JeName"));
		          uiDriver.click_dynamic(ActualJe);
		          SleepUtils.sleep(TimeSlab.LOW);
		          uiDriver.executeJavaScript("scroll(0,500)");
		     
		     }
		
		public void VeryfyJeGeneric(DataRow input, DataRow output) {
			try{
			

			String ACCOUNT = input.get("ACCOUNT");
			String ACCOUNTS[] = ACCOUNT.split(";");

			String DEBIT = input.get("DEBIT");
			String DEBITS[] = DEBIT.split(";");

			String CREDIT = input.get("CREDIT");
			String CREDITS[] = CREDIT.split(";");

			String Name = input.get("Name");
			String Names[] = Name.split(";");

			String Subsidiary = input.get("Subsidiary");
			String Subsidiarys[] = Subsidiary.split(";");

			String MarketCode = input.get("MarketCode");
			String MarketCodes[] = MarketCode.split(";");

			String Territory = input.get("Territory");
			String Territorys[] = Territory.split(";");

			String GLPN = input.get("GLPN");
			String GLPNS[] = GLPN.split(";");

			System.out.println(ACCOUNTS.length);

			List<WebElement> NoRows = uiDriver.webDr.findElements(By.xpath("//*[@id='line_splits']/tbody/tr"));
			int temp = 0, k = 0;
			for (int i = 0; i < ACCOUNTS.length; i++) {

				String xpath = "//table[@id='line_splits']//td[contains(text(),'" + GLPNS[k].trim() + "')]";

				String xpath_Project = "//*[contains(text(),'Billed') or contains(text(),'Deferred Rev') or contains(text(),'Generic') or contains(text(),'Bad Debt')or contains(text(),'Deferred Rev -Unpaid - Intl') or contains(text(),'Write Off') or contains(text(),'Billed Intl AR') or contains(text(),'Clearing') or contains(text(),'Expense')or contains(text(),'Deferred Rev') or contains(text(),'Contract revenue')]";

				if (uiDriver.checkElementPresent(xpath_Project)) {
					
					// Account
					List<WebElement> el = uiDriver.webDr.findElements(
							By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'" + GLPNS[k].trim()
									+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Account']//..//preceding-sibling::*)+1]"));

					String Account;
					try {
						Account = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						Account = el.get(temp).getText();
					}

					String actual_ACCOUNTS = Account;
					if (actual_ACCOUNTS != null && !actual_ACCOUNTS.equals(" ") && !actual_ACCOUNTS.equals("")) {

						String expected_ACCOUNTS = ACCOUNTS[k].trim();
						
						try{
							List<String> ls = new ArrayList<String>(Arrays.asList(expected_ACCOUNTS));
							for(String l:ls){
							if (l.toLowerCase().trim().contains(actual_ACCOUNTS.toLowerCase().trim())
									|| actual_ACCOUNTS.toLowerCase().trim()
											.contains(l.toLowerCase().trim())) {
							//	if(expected_ACCOUNTS.toLowerCase().trim().equals(actual_ACCOUNTS.toLowerCase().trim())){
								passed("Validate Journal",
										ACCOUNTS[k].trim() + " Account should be displayed as " + ACCOUNTS[k].trim(),
										ACCOUNTS[k].trim() + " Account is displayed as " + actual_ACCOUNTS.trim());
								break;
								//}
								
							}/* else {
								failed("Validate Journal",
										ACCOUNTS[k].trim() + " Account should be displayed as " + ACCOUNTS[k].trim(),
										ACCOUNTS[k].trim() + " Account is not displayed as " + actual_ACCOUNTS.trim());
							}*/
							
						}}catch(Exception e){
							failed("Validate Journal",
									ACCOUNTS[k].trim() + " Account should be displayed as " + ACCOUNTS[k].trim(),
									ACCOUNTS[k].trim() + " Account is not displayed as " + actual_ACCOUNTS.trim()); 	
						}
					} else {
					}

					el = uiDriver.webDr.findElements(By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'"
							+ GLPNS[k].trim()
							+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Name']//..//preceding-sibling::*)+1]"));

					String name;
					try {
						name = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						name = el.get(temp).getText();
					}

					String actual_name = name;
					if (actual_name != null && !actual_name.equals(" ") && !actual_name.equals("")) {

						String expected_name = Names[k].trim();
						if (expected_name.toLowerCase().trim().contains(actual_name.toLowerCase().trim()) 
								|| actual_name.toLowerCase().trim().contains(expected_name.toLowerCase().trim())) {

							passed("Validate Journal",
									Names[k].trim() + " Names should be displayed as " + Names[k].trim(),
									Names[k].trim() + " Names is displayed as " + actual_name.trim());
						} else {
							failed("Validate Journal",
									Names[k].trim() + " Names should be displayed as " + Names[k].trim(),
									Names[k].trim() + " Names is displayed as " + actual_name.trim());
						}
					} else {
					}

					// Market code
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'"
							+ GLPNS[k].trim()
							+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Market Code']//..//preceding-sibling::*)+1]"));

					String Marketcode;
					try {
						Marketcode = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						Marketcode = el.get(temp).getText();
					}

					String actual_Marketcode = Marketcode;
					if (actual_Marketcode != null && !actual_Marketcode.equals(" ") && !actual_Marketcode.equals("")) {

						String expected_Marketcode = MarketCodes[k].trim();
						if (expected_Marketcode.toLowerCase().trim().contains(actual_Marketcode.toLowerCase().trim()) 
								|| actual_Marketcode.toLowerCase().trim().contains(expected_Marketcode.toLowerCase().trim())) {

							passed("Validate Journal",
									MarketCodes[k].trim() + " MarketCode should be displayed as " + MarketCodes[k].trim(),
									MarketCodes[k].trim() + " MarketCode is displayed as " + actual_Marketcode.trim());
						} else {
							failed("Validate Journal",
									MarketCodes[k].trim() + " MarketCode should be displayed as " + MarketCodes[k].trim(),
									MarketCodes[k].trim() + " MarketCode is displayed as " + actual_Marketcode.trim());
						}
					} else {
					}

					// Territory
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'"
							+ GLPNS[k].trim()
							+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Territory']//..//preceding-sibling::*)+1]"));

					String territory;
					try {
						territory = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						territory = el.get(temp).getText();
					}

					String actual_territory = territory;
					if (actual_territory != null && !actual_territory.equals(" ") && !actual_territory.equals("")) {

						String expected_territory = Territorys[k].trim();
						if (expected_territory.toLowerCase().trim().contains(actual_territory.toLowerCase().trim()) 
								|| actual_territory.toLowerCase().trim().contains(expected_territory.toLowerCase().trim())) {

							passed("Validate Journal",
									Territorys[k].trim() + " Territorys should be displayed as " + Territorys[k].trim(),
									Territorys[k].trim() + " Territorys is displayed as " + actual_territory.trim());
						} else {
							failed("Validate Journal",
									Territorys[k].trim() + " Territorys should be displayed as " + Territorys[k].trim(),
									Territorys[k].trim() + " Territorys is displayed as " + actual_territory.trim());
						}
					} else {
					}

					// GLPN
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'"
							+ GLPNS[k].trim()
							+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]"));

					String GLPn;
					try {
						GLPn = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						GLPn = el.get(temp).getText();
					}

					String actual_GLPN = GLPn;
					if (actual_GLPN != null && !actual_GLPN.equals(" ") && !actual_GLPN.equals("")) {

						String expected_GLPN = GLPNS[k].trim();
						if (expected_GLPN.toLowerCase().trim().contains(actual_GLPN.toLowerCase().trim()) 
								|| actual_GLPN.toLowerCase().trim().contains(expected_GLPN.toLowerCase().trim())) {

							passed("Validate Journal",
									GLPNS[k].trim() + " GLPNS should be displayed as " + GLPNS[k].trim(),
									GLPNS[k].trim() + " GLPNS is displayed as " + actual_GLPN.trim());
						} else {
							failed("Validate Journal",
									GLPNS[k].trim() + " GLPNS should be displayed as " + GLPNS[k].trim(),
									GLPNS[k].trim() + " GLPNS is displayed as " + actual_GLPN.trim());
						}
					} else {
					}

					String actual_Subsidiary = uiDriver
							.getValue("//*[text()='Subsidiary']/following::span[1]");

					if (actual_Subsidiary != null && !actual_Subsidiary.equals(" ") && !actual_Subsidiary.equals("")) {

						String expected_Subsidiary = Subsidiarys[i].trim();
						if (expected_Subsidiary.toLowerCase().trim().contains(actual_Subsidiary.toLowerCase().trim()) 
								|| actual_Subsidiary.toLowerCase().trim().contains(expected_Subsidiary.toLowerCase().trim())) {

							passed("Validate Journal",
									Subsidiarys[i].trim() + " Subsidiary should be displayed as " + Subsidiarys[i].trim(),
									Subsidiarys[i].trim() + " Subsidiary is displayed as " + actual_Subsidiary.trim());
						} else {
							failed("Validate Journal",
									Subsidiarys[i].trim() + " Subsidiary should be displayed as " + Subsidiarys[i].trim(),
									Subsidiarys[i].trim() + " Subsidiary is displayed as " + actual_Subsidiary.trim());
						}
					} else {
					}
					
					// Debit
					if(uiDriver.checkElementPresent("//table[@id='line_splits']//tbody//td[contains(text(),'"
							+ GLPNS[k].trim()
							+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Debit']//..//preceding-sibling::*)+1]")) {
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'"
							+ GLPNS[k].trim()
							+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Debit']//..//preceding-sibling::*)+1]"));

					String actual_Debit;
					try {
						actual_Debit = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_Debit = el.get(temp).getText();
					}
					
					String expected_Debit = DEBITS[k].trim();
					if (actual_Debit != null && !actual_Debit.equals(" ") && !actual_Debit.equals("")) {
						try {
						expected_Debit = expected_Debit.replace(",", "");
						expected_Debit = expected_Debit.replace("$", "");
						
						actual_Debit = actual_Debit.replace(",", "");
						actual_Debit = actual_Debit.replace("$", "");

						Float exp_Debit_exchanged = Float.parseFloat(expected_Debit) * Float.parseFloat(text_ExchangeNumber);
						Float act_Debit_exchanged = Float.parseFloat(actual_Debit) * Float.parseFloat(text_ExchangeNumber);
						exp_Debit_exchanged = (float) Math.round(exp_Debit_exchanged);
						act_Debit_exchanged = (float) Math.round(act_Debit_exchanged);
						
						Float exp_Debit = Float.parseFloat(expected_Debit);
						Float act_Debit = Float.parseFloat(actual_Debit);
						exp_Debit = (float) Math.round(exp_Debit);
						act_Debit = (float) Math.round(act_Debit);
						
						if (exp_Debit_exchanged.toString().trim().contains(act_Debit_exchanged.toString().trim()) 
								|| act_Debit_exchanged.toString().trim().contains(exp_Debit_exchanged.toString().trim())
								|| exp_Debit.toString().trim().contains(act_Debit.toString().trim()) 
								|| act_Debit.toString().trim().contains(exp_Debit.toString().trim())
								|| exp_Debit_exchanged.toString().trim().contains(act_Debit.toString().trim())
								|| act_Debit.toString().trim().contains(exp_Debit_exchanged.toString().trim())
								|| exp_Debit.toString().trim().contains(act_Debit_exchanged.toString().trim())
								|| act_Debit_exchanged.toString().trim().contains(exp_Debit.toString().trim())) {
							passed("Validate Journal", "Debit Amount Should be displayed as " + expected_Debit,
									"Debit Amount is displayed as " + actual_Debit);
						} else {
							failed("Validate Journal", "Debit Amount Should be displayed as " + expected_Debit,
									"Debit Amount should not be displayed as " + actual_Debit);
						}
						} catch (Exception e) {					
						}
					}
					else {
						// Null
					}
					}

					// Credit
					if(uiDriver.checkElementPresent("//table[@id='line_splits']//tbody//td[contains(text(),'"
							+ GLPNS[k].trim()
							+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Credit']//..//preceding-sibling::*)+1]")) {
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'"
							+ GLPNS[k].trim()
							+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Credit']//..//preceding-sibling::*)+1]"));

					String actual_Credit;
					try {
						actual_Credit = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_Credit = el.get(temp).getText();
					}
					
					String expected_Credit = DEBITS[k].trim();
					if (actual_Credit != null && !actual_Credit.equals(" ") && !actual_Credit.equals("")) {
						try {
						expected_Credit = expected_Credit.replace(",", "");
						expected_Credit = expected_Credit.replace("$", "");
						
						actual_Credit = actual_Credit.replace(",", "");
						actual_Credit = actual_Credit.replace("$", "");

						Float exp_Credit_exchanged = Float.parseFloat(expected_Credit) * Float.parseFloat(text_ExchangeNumber);
						Float act_Credit_exchanged = Float.parseFloat(actual_Credit) * Float.parseFloat(text_ExchangeNumber);
						exp_Credit_exchanged = (float) Math.round(exp_Credit_exchanged);
						act_Credit_exchanged = (float) Math.round(act_Credit_exchanged);
						
						Float exp_Credit = Float.parseFloat(expected_Credit);
						Float act_Credit = Float.parseFloat(actual_Credit);
						exp_Credit = (float) Math.round(exp_Credit);
						act_Credit = (float) Math.round(act_Credit);
						
						if (exp_Credit_exchanged.toString().trim().contains(act_Credit_exchanged.toString().trim()) 
								|| act_Credit_exchanged.toString().trim().contains(exp_Credit_exchanged.toString().trim())
								|| exp_Credit.toString().trim().contains(act_Credit.toString().trim()) 
								|| act_Credit.toString().trim().contains(exp_Credit.toString().trim())
								|| exp_Credit_exchanged.toString().trim().contains(act_Credit.toString().trim())
								|| act_Credit.toString().trim().contains(exp_Credit_exchanged.toString().trim())
								|| exp_Credit.toString().trim().contains(act_Credit_exchanged.toString().trim())
								|| act_Credit_exchanged.toString().trim().contains(exp_Credit.toString().trim())) {
							passed("Validate Journal", "Credit Amount Should be displayed as " + expected_Credit,
									"Credit Amount is displayed as " + actual_Credit);
						} else {
							failed("Validate Journal", "Credit Amount Should be displayed as " + expected_Credit,
									"Credit Amount should not be displayed as " + actual_Credit);
						}
						} catch (Exception e) {					
						}
					}
					else {
						// Null
					}
					}
				
					if (el.size() > 1) {
						temp++;
					} else {
						temp = 0;
					}
					k++;
				}

			}

			while (true) {
				 if (uiDriver.checkElementPresent("//h1[text()='Invoice' or text()='Payment' "
				 		+ "or text()='Title Allocation Parent' or text()='Revenue Arrangement' "
				 		+ "or text()='Customer Credit'  or text()='Credit Memo']")) {
				 break;
				 } else {
				 uiDriver.back();
				 SleepUtils.sleep(TimeSlab.YIELD);
				 }
			}
			
			}
			catch(Exception e){
				 uiDriver.back();
				 SleepUtils.sleep(TimeSlab.LOW);
			}

		}

		/****************************************
		 * Name: NavigateToInvoiceScreen Description:Method to Navigate To Invoice
		 * Screen Date:30-Nov-2017
		 ****************************************/
		public void NavigateToinvoiceDueDate(DataRow input, DataRow output) throws InterruptedException {

			SleepUtils.sleep(TimeSlab.MEDIUM);
			String Num = input.get("conf");
			uiDriver.setValue("SearchSO", Num);
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("SalesOrder");
			passed("SalesOrder", "SalesOrder Should be displayed Successfully", "SalesOrder is displayed Successfully");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			// uiDriver.refresh();
			// uiDriver.executeJavaScript("scroll(0,500)");
			uiDriver.click("relatedRecord");
			SleepUtils.sleep(TimeSlab.LOW);
			String amount = input.get("amount");
			List<WebElement> lst = uiDriver.webDr
					.findElements(By.xpath("//td[contains(text(),'" + amount + "')]//..//td[text()='Invoice']/..//td[3]"));
			for(int i=1;i<=lst.size();i++){
			uiDriver.click("(//td[contains(text(),'" + amount + "')]//..//td[text()='Invoice']/..//td[1]/a)["+i+"]");
			SleepUtils.sleep(TimeSlab.LOW);
			String date=uiDriver.getValue_Text("//*[text()='Due Date']/following::span[1]");
			if(date.equals(input.get("date"))){
				break;
			}else{
				uiDriver.back();
				SleepUtils.sleep(TimeSlab.MEDIUM);
				uiDriver.click("relatedRecord");
				SleepUtils.sleep(TimeSlab.LOW);
			}
			}
			String invoicenumber = uiDriver.getValue("Invoicenum");
			output.put("invoice1", invoicenumber);
					
		}

		/****************************************
		 * Name: NavigateToInvoiceScreen Description:Method to Navigate To Invoice
		 * Screen Date:30-Nov-2017
		 ****************************************/
		public void NavigateToOLDinvoice(DataRow input, DataRow output) throws InterruptedException {

			SleepUtils.sleep(TimeSlab.MEDIUM);
			String Num = input.get("conf");
			uiDriver.setValue("SearchSO", Num);
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.click("SalesOrder");
			passed("SalesOrder", "SalesOrder Should be displayed Successfully", "SalesOrder is displayed Successfully");
			SleepUtils.sleep(5);
			// uiDriver.refresh();
			// uiDriver.executeJavaScript("scroll(0,500)");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("relatedRecord");
			SleepUtils.sleep(TimeSlab.LOW);
			String amount = input.get("amount");
			List<WebElement> lst = uiDriver.webDr
					.findElements(By.xpath("//td[contains(text(),'" + amount + "')]//..//td[text()='Invoice']/..//td[3]"));

			String invoice1 = lst.get(0).getText();
			String invoice2 = lst.get(1).getText();

			String inv1 = lst.get(0).getText().substring(2, lst.get(0).getText().length() - 1);
			String inv2 = lst.get(1).getText().substring(2, lst.get(1).getText().length() - 1);
			int I1 = Integer.parseInt(inv1);
			int I2 = Integer.parseInt(inv2);

			if (I1 < I2) {
				uiDriver.webDr.findElement(By.xpath("//td[contains(text(),'" + invoice1 + "')]/..//a[1]")).click();
			} else {
				uiDriver.webDr.findElement(By.xpath("//td[contains(text(),'" + invoice2 + "')]/..//a[1]")).click();

			}

		}

		
		public void ValidateLineitemsinNS(DataRow input, DataRow output) {

			String Item = input.get("Item");

			String item[] = Item.split(";");

			String revrecmethod = input.get("Rev Rec Method");

			String Revrecmethod[] = revrecmethod.split(";");

			String subtype = input.get("Sub Type");

			String Subtype[] = subtype.split(";");

			String Onnetwork = input.get("On Network");

			String onnetwork[] = Onnetwork.split(";");

			String Continuousproduction = input.get("Continuous Production");

			String continuousproduction[] = Continuousproduction.split(";");

			String MarketCode = input.get("Market Code");

			String marketCode[] = MarketCode.split(";");

			String Right = input.get("Right");

			String right[] = Right.split(";");

			String Territory = input.get("Territory");

			String territory[] = Territory.split(";");

			String TitleID = input.get("Title ID");

			String titleID[] = TitleID.split(";");

			String Quantity = input.get("Quantity");

			String quantity[] = Quantity.split(";");

			String Rate = input.get("Rate");

			String rate[] = Rate.split(";");

			String Amount = input.get("Amount");

			String amount[] = Amount.split(";");

			String NetRevisedAmount = input.get("Net Revised Amount");

			String netRevisedAmount[] = NetRevisedAmount.split(";");

			String Productowner = input.get("Product Owner");

			String productowner[] = Productowner.split(";");

			String GLPN = input.get("GLPN");

			String gLPN[] = GLPN.split(";");

			String ProductType = input.get("Product Type");

			String productType[] = ProductType.split(";");

			String RevRecStartDate = input.get("Rev Rec Start Date");

			String revRecStartDate[] = RevRecStartDate.split(";");

			String RevRecEndDate = input.get("Rev Rec End Date");

			String revRecEndDate[] = RevRecEndDate.split(";");

			String TaxCode = input.get("Tax Code");

			String taxCode[] = TaxCode.split(";");

			String SplitWindowNumber = input.get("Split Window Number");

			String splitWindowNumber[] = SplitWindowNumber.split(";");

			String UnbilledRevenueAccount = input.get("Unbilled Revenue Account");

			String unbilledRevenueAccount[] = UnbilledRevenueAccount.split(";");

			String BilledRevenueAccount = input.get("Billed Revenue Account");

			String billedRevenueAccount[] = BilledRevenueAccount.split(";");

			String BilledARAccount = input.get("Billed AR Account");

			String billedARAccount[] = BilledARAccount.split(";");

			String UnbilledARAccount = input.get("Unbilled AR Account");

			String unbilledARAccount[] = UnbilledARAccount.split(";");

			String PaidDeferredRevenueAccount = input.get("Paid Deferred Revenue Account");

			String paidDeferredRevenueAccount[] = PaidDeferredRevenueAccount.split(";");

			String UnpaidDeferredRevenueAccount = input.get("Unpaid Deferred Revenue Account");

			String unpaidDeferredRevenueAccount[] = UnpaidDeferredRevenueAccount.split(";");

			String BadDebtRevenueAccount = input.get("Bad Debt Revenue Account");

			String badDebtRevenueAccount[] = BadDebtRevenueAccount.split(";");

			List<WebElement> LineItems = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tr"));
			int total_LineItems = LineItems.size();
			int k = 0, temp = 0;
			for (int i = 0; i < gLPN.length; i++) {

				List<WebElement> el;
				String xpath = "//table[@id='item_splits']//td[contains(text(),'" + gLPN[k].trim() + "')]";

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Item']//..//preceding-sibling::*)+1]")) {
					String actual_Item;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Item']//..//preceding-sibling::*)+1]"));
					try {
						actual_Item = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_Item = el.get(0).getText();
					}

					String expected_Item = item[k].trim();
					expected_Item = expected_Item.replace("Null", " ");

					if (expected_Item.toLowerCase().trim().contains(actual_Item.toLowerCase().trim())
							|| actual_Item.toLowerCase().trim().contains(expected_Item.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"Item Should be displayed as " + expected_Item, "Item is displayed as " + actual_Item);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"Item Should be displayed as " + expected_Item, "Item is not displayed as " + actual_Item);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Revenue Recognition Method']//..//preceding-sibling::*)+1]")) {
					String actual_Revrecmethod;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Revenue Recognition Method']//..//preceding-sibling::*)+1]"));
					try {
						actual_Revrecmethod = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_Revrecmethod = el.get(0).getText();
					}

					String expected_Revrecmethod = Revrecmethod[k].trim();
					expected_Revrecmethod = expected_Revrecmethod.replace("Null", " ");

					if (expected_Revrecmethod.toLowerCase().trim().contains(actual_Revrecmethod.toLowerCase().trim())
							|| actual_Revrecmethod.toLowerCase().trim()
									.contains(expected_Revrecmethod.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"Revrecmethod Should be displayed as " + expected_Revrecmethod,
								"Revrecmethod is displayed as " + actual_Revrecmethod);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"Revrecmethod Should be displayed as " + expected_Revrecmethod,
								"Revrecmethod is not displayed as " + actual_Revrecmethod);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='On Network']//..//preceding-sibling::*)+1]")) {
					String actual_onnetwork;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='On Network']//..//preceding-sibling::*)+1]"));
					try {
						actual_onnetwork = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_onnetwork = el.get(0).getText();
					}

					String expected_onnetwork = onnetwork[k].trim();
					expected_onnetwork = expected_onnetwork.replace("Null", " ");

					if (expected_onnetwork.toLowerCase().trim().contains(actual_onnetwork.toLowerCase().trim())
							|| actual_onnetwork.toLowerCase().trim().contains(expected_onnetwork.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"onnetwork Should be displayed as " + expected_onnetwork,
								"onnetwork is displayed as " + actual_onnetwork);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"onnetwork Should be displayed as " + expected_onnetwork,
								"onnetwork is not displayed as " + actual_onnetwork);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Continuous Production']//..//preceding-sibling::*)+1]")) {
					String actual_continuousproduction;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Continuous Production']//..//preceding-sibling::*)+1]"));
					try {
						actual_continuousproduction = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_continuousproduction = el.get(0).getText();
					}

					String expected_continuousproduction = continuousproduction[k].trim();
					expected_continuousproduction = expected_continuousproduction.replace("Null", " ");

					if (expected_continuousproduction.toLowerCase().trim()
							.contains(actual_continuousproduction.toLowerCase().trim())
							|| actual_continuousproduction.toLowerCase().trim()
									.contains(expected_continuousproduction.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"continuousproduction Should be displayed as " + expected_continuousproduction,
								"continuousproduction is displayed as " + actual_continuousproduction);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"continuousproduction Should be displayed as " + expected_continuousproduction,
								"continuousproduction is not displayed as " + actual_continuousproduction);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Rate']//..//preceding-sibling::*)+1]")) {
					String actual_Rate;
					Float actual_Rate_temp;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Rate']//..//preceding-sibling::*)+1]"));
					try {
						actual_Rate = el.get(temp).getText();
						actual_Rate = actual_Rate.replace(",", "");
						actual_Rate = actual_Rate.replace("$", "");
						actual_Rate_temp = Float.parseFloat(actual_Rate);
					} catch (Exception e) {
						temp = 0;
						actual_Rate = el.get(0).getText();
						actual_Rate = actual_Rate.replace(",", "");
						actual_Rate = actual_Rate.replace("$", "");
						actual_Rate_temp = Float.parseFloat(actual_Rate);
					}

					String expected_Rate = rate[k].trim();
					expected_Rate = expected_Rate.replace("Null", " ");
					expected_Rate = expected_Rate.replace(",", "");
					expected_Rate = expected_Rate.replace("$", "");
					Float expected_Rate_temp = Float.parseFloat(actual_Rate);

					if (expected_Rate_temp.toString().trim().contains(actual_Rate_temp.toString().trim())
							|| actual_Rate_temp.toString().trim().contains(expected_Rate_temp.toString().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"Rate Should be displayed as " + expected_Rate, "Rate is displayed as " + actual_Rate);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"Rate Should be displayed as " + expected_Rate, "Rate is not displayed as " + actual_Rate);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Owner']//..//preceding-sibling::*)+1]")) {
					String actual_ProductOwner;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Owner']//..//preceding-sibling::*)+1]"));
					try {
						actual_ProductOwner = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_ProductOwner = el.get(0).getText();
					}

					String expected_ProductOwner = productowner[k].trim();
					expected_ProductOwner = expected_ProductOwner.replace("Null", " ");

					if (expected_ProductOwner.toLowerCase().trim().contains(actual_ProductOwner.toLowerCase().trim())
							|| actual_ProductOwner.toLowerCase().trim()
									.contains(expected_ProductOwner.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"ProductOwner Should be displayed as " + expected_ProductOwner,
								"ProductOwner is displayed as " + actual_ProductOwner);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"ProductOwner Should be displayed as " + expected_ProductOwner,
								"ProductOwner is not displayed as " + actual_ProductOwner);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]")) {
					String actual_GLPN;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]"));
					try {
						actual_GLPN = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_GLPN = el.get(0).getText();
					}

					String expected_GLPN = gLPN[k].trim();
					expected_GLPN = expected_GLPN.replace("Null", " ");

					if (expected_GLPN.toLowerCase().trim().contains(actual_GLPN.toLowerCase().trim())
							|| actual_GLPN.toLowerCase().trim().contains(expected_GLPN.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"GLPN Should be displayed as " + expected_GLPN, "GLPN is displayed as " + actual_GLPN);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"GLPN Should be displayed as " + expected_GLPN, "GLPN is not displayed as " + actual_GLPN);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Type']//..//preceding-sibling::*)+1]")) {
					String actual_ProductType;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Type']//..//preceding-sibling::*)+1]"));
					try {
						actual_ProductType = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_ProductType = el.get(0).getText();
					}

					String expected_ProductType = productType[k].trim();
					expected_ProductType = expected_ProductType.replace("Null", " ");

					if (expected_ProductType.toLowerCase().trim().contains(actual_ProductType.toLowerCase().trim())
							|| actual_ProductType.toLowerCase().trim()
									.contains(expected_ProductType.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"ProductType Should be displayed as " + expected_ProductType,
								"ProductType is displayed as " + actual_ProductType);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"ProductType Should be displayed as " + expected_ProductType,
								"ProductType is not displayed as " + actual_ProductType);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Revenue Recognition Start Date']//..//preceding-sibling::*)+1]")) {
					String actual_RevenueRecognitionStartDate;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Revenue Recognition Start Date']//..//preceding-sibling::*)+1]"));
					try {
						actual_RevenueRecognitionStartDate = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_RevenueRecognitionStartDate = el.get(0).getText();
					}

					String expected_RevenueRecognitionStartDate = revRecStartDate[k].trim();
					expected_RevenueRecognitionStartDate = expected_RevenueRecognitionStartDate.replace("Null", " ");

					if (expected_RevenueRecognitionStartDate.toLowerCase().trim()
							.contains(actual_RevenueRecognitionStartDate.toLowerCase().trim())
							|| actual_RevenueRecognitionStartDate.toLowerCase().trim()
									.contains(expected_RevenueRecognitionStartDate.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"RevenueRecognitionStartDate Should be displayed as "
										+ expected_RevenueRecognitionStartDate,
								"RevenueRecognitionStartDate is displayed as " + actual_RevenueRecognitionStartDate);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"RevenueRecognitionStartDate Should be displayed as "
										+ expected_RevenueRecognitionStartDate,
								"RevenueRecognitionStartDate is not displayed as " + actual_RevenueRecognitionStartDate);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Revenue Recognition End Date']//..//preceding-sibling::*)+1]")) {
					String actual_RevenueRecognitionEndDate;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Revenue Recognition End Date']//..//preceding-sibling::*)+1]"));
					try {
						actual_RevenueRecognitionEndDate = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_RevenueRecognitionEndDate = el.get(0).getText();
					}

					String expected_RevenueRecognitionEndDate = revRecEndDate[k].trim();
					expected_RevenueRecognitionEndDate = expected_RevenueRecognitionEndDate.replace("Null", " ");

					if (expected_RevenueRecognitionEndDate.toLowerCase().trim()
							.contains(actual_RevenueRecognitionEndDate.toLowerCase().trim())
							|| actual_RevenueRecognitionEndDate.toLowerCase().trim()
									.contains(expected_RevenueRecognitionEndDate.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"RevenueRecognitionEndDate Should be displayed as " + expected_RevenueRecognitionEndDate,
								"RevenueRecognitionEndDate is displayed as " + actual_RevenueRecognitionEndDate);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"RevenueRecognitionEndDate Should be displayed as " + expected_RevenueRecognitionEndDate,
								"RevenueRecognitionEndDate is not displayed as " + actual_RevenueRecognitionEndDate);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Tax Code']//..//preceding-sibling::*)+1]")) {
					String actual_TaxCode;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Tax Code']//..//preceding-sibling::*)+1]"));
					try {
						actual_TaxCode = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_TaxCode = el.get(0).getText();
					}

					String expected_TaxCode = taxCode[k].trim();
					expected_TaxCode = expected_TaxCode.replace("Null", " ");

					if (expected_TaxCode.toLowerCase().trim().contains(actual_TaxCode.toLowerCase().trim())
							|| actual_TaxCode.toLowerCase().trim().contains(expected_TaxCode.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"TaxCode Should be displayed as " + expected_TaxCode,
								"TaxCode is displayed as " + actual_TaxCode);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"TaxCode Should be displayed as " + expected_TaxCode,
								"TaxCode is not displayed as " + actual_TaxCode);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Split Window Number']//..//preceding-sibling::*)+1]")) {
					String actual_splitWindowNumber;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Split Window Number']//..//preceding-sibling::*)+1]"));
					try {
						actual_splitWindowNumber = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_splitWindowNumber = el.get(0).getText();
					}

					String expected_splitWindowNumber = splitWindowNumber[k].trim();
					expected_splitWindowNumber = expected_splitWindowNumber.replace("Null", " ");

					if (expected_splitWindowNumber.toLowerCase().trim()
							.contains(actual_splitWindowNumber.toLowerCase().trim())
							|| actual_splitWindowNumber.toLowerCase().trim()
									.contains(expected_splitWindowNumber.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"splitWindowNumber Should be displayed as " + expected_splitWindowNumber,
								"splitWindowNumber is displayed as " + actual_splitWindowNumber);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"splitWindowNumber Should be displayed as " + expected_splitWindowNumber,
								"splitWindowNumber is not displayed as " + actual_splitWindowNumber);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Market Code']//..//preceding-sibling::*)+1]")) {
					String actual_MarketCode;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Market Code']//..//preceding-sibling::*)+1]"));
					try {
						actual_MarketCode = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_MarketCode = el.get(0).getText();
					}

					String expected_MarketCode = marketCode[k].trim();
					expected_MarketCode = expected_MarketCode.replace("Null", " ");

					if (expected_MarketCode.toLowerCase().trim().contains(actual_MarketCode.toLowerCase().trim())
							|| actual_MarketCode.toLowerCase().trim().contains(expected_MarketCode.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"MarketCode Should be displayed as " + expected_MarketCode,
								"MarketCode is displayed as " + actual_MarketCode);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"MarketCode Should be displayed as " + expected_MarketCode,
								"MarketCode is not displayed as " + actual_MarketCode);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Territory']//..//preceding-sibling::*)+1]")) {
					String actual_Territory;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Territory']//..//preceding-sibling::*)+1]"));
					try {
						actual_Territory = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_Territory = el.get(0).getText();
					}

					String expected_Territory = territory[k].trim();
					expected_Territory = expected_Territory.replace("Null", " ");

					if (expected_Territory.toLowerCase().trim().contains(actual_Territory.toLowerCase().trim())
							|| actual_Territory.toLowerCase().trim().contains(expected_Territory.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"Territory Should be displayed as " + expected_Territory,
								"Territory is displayed as " + actual_Territory);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"Territory Should be displayed as " + expected_Territory,
								"Territory is not displayed as " + actual_Territory);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title']//..//preceding-sibling::*)+1]")) {
					String actual_Title;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title']//..//preceding-sibling::*)+1]"));
					try {
						actual_Title = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_Title = el.get(0).getText();
					}

					String expected_Title = titleID[k].trim();
					expected_Title = expected_Title.replace("Null", " ");

					if (expected_Title.toLowerCase().trim().contains(actual_Title.toLowerCase().trim())
							|| actual_Title.toLowerCase().trim().contains(expected_Title.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"Title Should be displayed as " + expected_Title, "Title is displayed as " + actual_Title);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"Title Should be displayed as " + expected_Title, "Title is not displayed as " + actual_Title);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Right']//..//preceding-sibling::*)+1]")) {
					String actual_Right;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Right']//..//preceding-sibling::*)+1]"));
					try {
						actual_Right = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_Right = el.get(0).getText();
					}

					String expected_Right = right[k].trim();
					expected_Right = expected_Right.replace("Null", " ");

					if (expected_Right.toLowerCase().trim().contains(actual_Right.toLowerCase().trim())
							|| actual_Right.toLowerCase().trim().contains(expected_Right.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"Right Should be displayed as " + expected_Right, "Right is displayed as " + actual_Right);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"Right Should be displayed as " + expected_Right, "Right is not displayed as " + actual_Right);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled Revenue Account']//..//preceding-sibling::*)+1]")) {
					String actual_unbilledRevenueAccount;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled Revenue Account']//..//preceding-sibling::*)+1]"));
					try {
						actual_unbilledRevenueAccount = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_unbilledRevenueAccount = el.get(0).getText();
					}

					String expected_unbilledRevenueAccount = unbilledRevenueAccount[k].trim();
					expected_unbilledRevenueAccount = expected_unbilledRevenueAccount.replace("Null", " ");

					if (expected_unbilledRevenueAccount.toLowerCase().trim()
							.contains(actual_unbilledRevenueAccount.toLowerCase().trim())
							|| actual_unbilledRevenueAccount.toLowerCase().trim()
									.contains(expected_unbilledRevenueAccount.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"unbilledRevenueAccount Should be displayed as " + expected_unbilledRevenueAccount,
								"unbilledRevenueAccount is displayed as " + actual_unbilledRevenueAccount);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"unbilledRevenueAccount Should be displayed as " + expected_unbilledRevenueAccount,
								"unbilledRevenueAccount is not displayed as " + actual_unbilledRevenueAccount);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed Revenue Account']//..//preceding-sibling::*)+1]")) {
					String actual_BilledRevenueAccount;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed Revenue Account']//..//preceding-sibling::*)+1]"));
					try {
						actual_BilledRevenueAccount = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_BilledRevenueAccount = el.get(0).getText();
					}

					String expected_BilledRevenueAccount = billedRevenueAccount[k].trim();
					expected_BilledRevenueAccount = expected_BilledRevenueAccount.replace("Null", " ");

					if (expected_BilledRevenueAccount.toLowerCase().trim()
							.contains(actual_BilledRevenueAccount.toLowerCase().trim())
							|| actual_BilledRevenueAccount.toLowerCase().trim()
									.contains(expected_BilledRevenueAccount.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"BilledRevenueAccount Should be displayed as " + expected_BilledRevenueAccount,
								"BilledRevenueAccount is displayed as " + actual_BilledRevenueAccount);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"BilledRevenueAccount Should be displayed as " + expected_BilledRevenueAccount,
								"BilledRevenueAccount is not displayed as " + actual_BilledRevenueAccount);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled AR']//..//preceding-sibling::*)+1]")) {
					String actual_unbilledARAccount;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled AR']//..//preceding-sibling::*)+1]"));
					try {
						actual_unbilledARAccount = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_unbilledARAccount = el.get(0).getText();
					}

					String expected_unbilledARAccount = unbilledARAccount[k].trim();
					expected_unbilledARAccount = expected_unbilledARAccount.replace("Null", " ");

					if (expected_unbilledARAccount.toLowerCase().trim()
							.contains(actual_unbilledARAccount.toLowerCase().trim())
							|| actual_unbilledARAccount.toLowerCase().trim()
									.contains(expected_unbilledARAccount.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"unbilledARAccount Should be displayed as " + expected_unbilledARAccount,
								"unbilledARAccount is displayed as " + actual_unbilledARAccount);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"unbilledARAccount Should be displayed as " + expected_unbilledARAccount,
								"unbilledARAccount is not displayed as " + actual_unbilledARAccount);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed AR Account']//..//preceding-sibling::*)+1]")) {
					String actual_BilledARAccount;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed AR Account']//..//preceding-sibling::*)+1]"));
					try {
						actual_BilledARAccount = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_BilledARAccount = el.get(0).getText();
					}

					String expected_BilledARAccount = billedARAccount[k].trim();
					expected_BilledARAccount = expected_BilledARAccount.replace("Null", " ");

					if (expected_BilledARAccount.toLowerCase().trim().contains(actual_BilledARAccount.toLowerCase().trim())
							|| actual_BilledARAccount.toLowerCase().trim()
									.contains(expected_BilledARAccount.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"BilledARAccount Should be displayed as " + expected_BilledARAccount,
								"BilledARAccount is displayed as " + actual_BilledARAccount);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"BilledARAccount Should be displayed as " + expected_BilledARAccount,
								"BilledARAccount is not displayed as " + actual_BilledARAccount);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Paid Deferred']//..//preceding-sibling::*)+1]")) {
					String actual_PaidDeferred;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Paid Deferred']//..//preceding-sibling::*)+1]"));
					try {
						actual_PaidDeferred = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_PaidDeferred = el.get(0).getText();
					}

					String expected_PaidDeferred = paidDeferredRevenueAccount[k].trim();
					expected_PaidDeferred = expected_PaidDeferred.replace("Null", " ");

					if (expected_PaidDeferred.toLowerCase().trim().contains(actual_PaidDeferred.toLowerCase().trim())
							|| actual_PaidDeferred.toLowerCase().trim()
									.contains(expected_PaidDeferred.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"PaidDeferred Should be displayed as " + expected_PaidDeferred,
								"PaidDeferred is displayed as " + actual_PaidDeferred);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"PaidDeferred Should be displayed as " + expected_PaidDeferred,
								"PaidDeferred is not displayed as " + actual_PaidDeferred);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Bad Debt Revenue']//..//preceding-sibling::*)+1]")) {
					String actual_BadDebtRevenue;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Bad Debt Revenue']//..//preceding-sibling::*)+1]"));
					try {
						actual_BadDebtRevenue = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_BadDebtRevenue = el.get(0).getText();
					}

					String expected_BadDebtRevenue = badDebtRevenueAccount[k].trim();
					expected_BadDebtRevenue = expected_BadDebtRevenue.replace("Null", " ");

					if (expected_BadDebtRevenue.toLowerCase().trim().contains(actual_BadDebtRevenue.toLowerCase().trim())
							|| actual_BadDebtRevenue.toLowerCase().trim()
									.contains(expected_BadDebtRevenue.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"BadDebtRevenue Should be displayed as " + expected_BadDebtRevenue,
								"BadDebtRevenue is displayed as " + actual_BadDebtRevenue);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"BadDebtRevenue Should be displayed as " + expected_BadDebtRevenue,
								"BadDebtRevenue is not displayed as " + actual_BadDebtRevenue);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Quantity']//..//preceding-sibling::*)+1]")) {
					String actual_Quantity;
					Float actual_Quantity_temp;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Quantity']//..//preceding-sibling::*)+1]"));
					try {
						actual_Quantity = el.get(temp).getText();
						actual_Quantity = actual_Quantity.replace(",", "");
						actual_Quantity = actual_Quantity.replace("$", "");
						actual_Quantity_temp = Float.parseFloat(actual_Quantity);
					} catch (Exception e) {
						temp = 0;
						actual_Quantity = el.get(0).getText();
						actual_Quantity = actual_Quantity.replace(",", "");
						actual_Quantity = actual_Quantity.replace("$", "");
						actual_Quantity_temp = Float.parseFloat(actual_Quantity);
					}

					try {
						String expected_Quantity = quantity[k].trim();
						expected_Quantity = expected_Quantity.replace("Null", " ");
						expected_Quantity = expected_Quantity.replace(",", "");
						expected_Quantity = expected_Quantity.replace("$", "");
						Float expected_Quantity_temp = Float.parseFloat(expected_Quantity);

						if (expected_Quantity_temp.toString().trim().contains(actual_Quantity_temp.toString().trim())
								|| actual_Quantity_temp.toString().trim()
										.contains(expected_Quantity_temp.toString().trim())) {
							passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
									"Quantity Should be displayed as " + expected_Quantity,
									"Quantity is displayed as " + actual_Quantity);
						} else {
							failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
									"Quantity Should be displayed as " + expected_Quantity,
									"Quantity is not displayed as " + actual_Quantity);
						}
					} catch (Exception e) {
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Amount']//..//preceding-sibling::*)+1]")) {
					String actual_Amount;
					Float actual_Amount_temp;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Amount']//..//preceding-sibling::*)+1]"));
					try {
						actual_Amount = el.get(temp).getText();
						actual_Amount = actual_Amount.replace(",", "");
						actual_Amount = actual_Amount.replace("$", "");
						actual_Amount_temp = Float.parseFloat(actual_Amount);
					} catch (Exception e) {
						temp = 0;
						actual_Amount = el.get(0).getText();
						actual_Amount = actual_Amount.replace(",", "");
						actual_Amount = actual_Amount.replace("$", "");
						actual_Amount_temp = Float.parseFloat(actual_Amount);
					}

					try {
						String expected_Amount = amount[k].trim();
						expected_Amount = expected_Amount.replace("Null", " ");
						expected_Amount = expected_Amount.replace(",", "");
						expected_Amount = expected_Amount.replace("$", "");
						Float expected_Amount_temp = Float.parseFloat(expected_Amount);

						if (expected_Amount_temp.toString().trim().contains(actual_Amount_temp.toString().trim())
								|| actual_Amount_temp.toString().trim().contains(expected_Amount_temp.toString().trim())) {
							passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
									"Amount Should be displayed as " + expected_Amount,
									"Amount is displayed as " + actual_Amount);
						} else {
							failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
									"Amount Should be displayed as " + expected_Amount,
									"Amount is not displayed as " + actual_Amount);
						}
					} catch (Exception e) {
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Net Revised Amount']//..//preceding-sibling::*)+1]")) {
					String actual_NetRevisedAmount;
					Float actual_NetRevisedAmount_temp;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Net Revised Amount']//..//preceding-sibling::*)+1]"));
					try {
						actual_NetRevisedAmount = el.get(temp).getText();
						actual_NetRevisedAmount = actual_NetRevisedAmount.replace(",", "");
						actual_NetRevisedAmount = actual_NetRevisedAmount.replace("$", "");
						actual_NetRevisedAmount_temp = Float.parseFloat(actual_NetRevisedAmount);
					} catch (Exception e) {
						temp = 0;
						actual_NetRevisedAmount = el.get(0).getText();
						actual_NetRevisedAmount = actual_NetRevisedAmount.replace(",", "");
						actual_NetRevisedAmount = actual_NetRevisedAmount.replace("$", "");
						actual_NetRevisedAmount_temp = Float.parseFloat(actual_NetRevisedAmount);
					}

					try {
						String expected_NetRevisedAmount = netRevisedAmount[k].trim();
						expected_NetRevisedAmount = expected_NetRevisedAmount.replace("Null", " ");
						expected_NetRevisedAmount = expected_NetRevisedAmount.replace(",", "");
						expected_NetRevisedAmount = expected_NetRevisedAmount.replace("$", "");
						Float expected_NetRevisedAmount_temp = Float.parseFloat(expected_NetRevisedAmount);

						if (expected_NetRevisedAmount_temp.toString().trim()
								.contains(actual_NetRevisedAmount_temp.toString().trim())
								|| actual_NetRevisedAmount_temp.toString().trim()
										.contains(expected_NetRevisedAmount_temp.toString().trim())) {
							passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
									"NetRevisedAmount Should be displayed as " + expected_NetRevisedAmount,
									"NetRevisedAmount is displayed as " + actual_NetRevisedAmount);
						} else {
							failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
									"NetRevisedAmount Should be displayed as " + expected_NetRevisedAmount,
									"NetRevisedAmount is not displayed as " + actual_NetRevisedAmount);
						}
					} catch (Exception e) {
					}
				}

				el = uiDriver.webDr.findElements(By.xpath(xpath));
				if (el.size() > 1) {
					temp++;
				} else {
					temp = 0;
				}

				k++;
			}

		}

		
		
		
		public void ValidateLineitemsinNSscen28(DataRow input, DataRow output) {

			String Item = input.get("Item");

			String item[] = Item.split(";");
			
			List<String> ls=new ArrayList<String>(Arrays.asList(item));
			

			String revrecmethod = input.get("Rev Rec Method");

			String Revrecmethod[] = revrecmethod.split(";");

			String subtype = input.get("Sub Type");

			String Subtype[] = subtype.split(";");

			String Onnetwork = input.get("On Network");

			String onnetwork[] = Onnetwork.split(";");

			String Continuousproduction = input.get("Continuous Production");

			String continuousproduction[] = Continuousproduction.split(";");

			String MarketCode = input.get("Market Code");

			String marketCode[] = MarketCode.split(";");

			String Right = input.get("Right");

			String right[] = Right.split(";");

			String Territory = input.get("Territory");

			String territory[] = Territory.split(";");

			String TitleID = input.get("Title ID");

			String titleID[] = TitleID.split(";");

			String Quantity = input.get("Quantity");

			String quantity[] = Quantity.split(";");

			String Rate = input.get("Rate");

			String rate[] = Rate.split(";");

			String Amount = input.get("Amount");

			String amount[] = Amount.split(";");

			String NetRevisedAmount = input.get("Net Revised Amount");

			String netRevisedAmount[] = NetRevisedAmount.split(";");

			String Productowner = input.get("Product Owner");

			String productowner[] = Productowner.split(";");

			String GLPN = input.get("GLPN");

			String gLPN[] = GLPN.split(";");

			String ProductType = input.get("Product Type");

			String productType[] = ProductType.split(";");

			String RevRecStartDate = input.get("Rev Rec Start Date");

			String revRecStartDate[] = RevRecStartDate.split(";");

			String RevRecEndDate = input.get("Rev Rec End Date");

			String revRecEndDate[] = RevRecEndDate.split(";");

			String TaxCode = input.get("Tax Code");

			String taxCode[] = TaxCode.split(";");

			String SplitWindowNumber = input.get("Split Window Number");

			String splitWindowNumber[] = SplitWindowNumber.split(";");

			String UnbilledRevenueAccount = input.get("Unbilled Revenue Account");

			String unbilledRevenueAccount[] = UnbilledRevenueAccount.split(";");

			String BilledRevenueAccount = input.get("Billed Revenue Account");

			String billedRevenueAccount[] = BilledRevenueAccount.split(";");

			String BilledARAccount = input.get("Billed AR Account");

			String billedARAccount[] = BilledARAccount.split(";");

			String UnbilledARAccount = input.get("Unbilled AR Account");

			String unbilledARAccount[] = UnbilledARAccount.split(";");

			String PaidDeferredRevenueAccount = input.get("Paid Deferred Revenue Account");

			String paidDeferredRevenueAccount[] = PaidDeferredRevenueAccount.split(";");

			String UnpaidDeferredRevenueAccount = input.get("Unpaid Deferred Revenue Account");

			String unpaidDeferredRevenueAccount[] = UnpaidDeferredRevenueAccount.split(";");

			String BadDebtRevenueAccount = input.get("Bad Debt Revenue Account");

			String badDebtRevenueAccount[] = BadDebtRevenueAccount.split(";");

			List<WebElement> LineItems = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tr"));
			int total_LineItems = LineItems.size();
			int k = 0, temp = 0;
			for (int i = 0; i < gLPN.length; i++) {

				List<WebElement> el;
				String xpath = "//table[@id='item_splits']//td[contains(text(),'" + gLPN[k].trim() + "')]";

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Item']//..//preceding-sibling::*)+1]")) {
					String actual_Item;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Item']//..//preceding-sibling::*)+1]"));
					try {
						actual_Item = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_Item = el.get(0).getText();
					}

					String expected_Item = item[k].trim();
					expected_Item = expected_Item.replace("Null", " ");
					
					if(ls.contains(actual_Item))
							{

					
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"Item Should be displayed as " + expected_Item, "Item is displayed as " + actual_Item);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"Item Should be displayed as " + expected_Item, "Item is displayed as " + actual_Item);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Revenue Recognition Method']//..//preceding-sibling::*)+1]")) {
					String actual_Revrecmethod;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Revenue Recognition Method']//..//preceding-sibling::*)+1]"));
					try {
						actual_Revrecmethod = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_Revrecmethod = el.get(0).getText();
					}

					String expected_Revrecmethod = Revrecmethod[k].trim();
					expected_Revrecmethod = expected_Revrecmethod.replace("Null", " ");
					List<String> revrec=new ArrayList<String>(Arrays.asList(Revrecmethod));

					if (revrec.contains(actual_Revrecmethod.trim())
							|| actual_Revrecmethod.toLowerCase().trim()
									.contains(expected_Revrecmethod.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"Revrecmethod Should be displayed as " + expected_Revrecmethod,
								"Revrecmethod is displayed as " + actual_Revrecmethod);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"Revrecmethod Should be displayed as " + expected_Revrecmethod,
								"Revrecmethod is displayed as " + actual_Revrecmethod);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='On Network']//..//preceding-sibling::*)+1]")) {
					String actual_onnetwork;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='On Network']//..//preceding-sibling::*)+1]"));
					try {
						actual_onnetwork = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_onnetwork = el.get(0).getText();
					}

					String expected_onnetwork = onnetwork[k].trim();
					expected_onnetwork = expected_onnetwork.replace("Null", " ");
					
					List<String> onnetwork1=new ArrayList<String>(Arrays.asList(onnetwork));

					if (onnetwork1.contains(actual_onnetwork.toLowerCase().trim())
							|| actual_onnetwork.toLowerCase().trim().contains(expected_onnetwork.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"onnetwork Should be displayed as " + expected_onnetwork,
								"onnetwork is displayed as " + actual_onnetwork);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"onnetwork Should be displayed as " + expected_onnetwork,
								"onnetwork is displayed as " + actual_onnetwork);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Continuous Production']//..//preceding-sibling::*)+1]")) {
					String actual_continuousproduction;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Continuous Production']//..//preceding-sibling::*)+1]"));
					try {
						actual_continuousproduction = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_continuousproduction = el.get(0).getText();
					}

					String expected_continuousproduction = continuousproduction[k].trim();
					expected_continuousproduction = expected_continuousproduction.replace("Null", " ");
					
					
					List<String> continuousproduction1=new ArrayList<String>(Arrays.asList(continuousproduction));

					if (continuousproduction1
							.contains(actual_continuousproduction.trim())
							|| actual_continuousproduction.toLowerCase().trim()
									.contains(expected_continuousproduction.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"continuousproduction Should be displayed as " + expected_continuousproduction,
								"continuousproduction is displayed as " + actual_continuousproduction);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"continuousproduction Should be displayed as " + expected_continuousproduction,
								"continuousproduction is displayed as " + actual_continuousproduction);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Rate']//..//preceding-sibling::*)+1]")) {
					String actual_Rate;
					Float actual_Rate_temp;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Rate']//..//preceding-sibling::*)+1]"));
					try {
						actual_Rate = el.get(temp).getText();
						actual_Rate = actual_Rate.replace(",", "");
						actual_Rate = actual_Rate.replace("$", "");
						actual_Rate_temp = Float.parseFloat(actual_Rate);
					} catch (Exception e) {
						temp = 0;
						actual_Rate = el.get(0).getText();
						actual_Rate = actual_Rate.replace(",", "");
						actual_Rate = actual_Rate.replace("$", "");
						actual_Rate_temp = Float.parseFloat(actual_Rate);
					}

					String expected_Rate = rate[k].trim();
					expected_Rate = expected_Rate.replace("Null", " ");
					expected_Rate = expected_Rate.replace(",", "");
					expected_Rate = expected_Rate.replace("$", "");
					Float expected_Rate_temp = Float.parseFloat(actual_Rate);
					
					
					List<String> rate1=new ArrayList<String>(Arrays.asList(rate));

					if (rate1.contains(actual_Rate_temp.toString().trim())
							|| actual_Rate_temp.toString().trim().contains(expected_Rate_temp.toString().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"Rate Should be displayed as " + expected_Rate, "Rate is displayed as " + actual_Rate);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"Rate Should be displayed as " + expected_Rate, "Rate is displayed as " + actual_Rate);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Owner']//..//preceding-sibling::*)+1]")) {
					String actual_ProductOwner;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Owner']//..//preceding-sibling::*)+1]"));
					try {
						actual_ProductOwner = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_ProductOwner = el.get(0).getText();
					}

					String expected_ProductOwner = productowner[k].trim();
					expected_ProductOwner = expected_ProductOwner.replace("Null", " ");
					
					
					List<String> productowner1=new ArrayList<String>(Arrays.asList(productowner));

					if (productowner1.contains(actual_ProductOwner.toLowerCase().trim())
							|| actual_ProductOwner.toLowerCase().trim()
									.contains(expected_ProductOwner.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"ProductOwner Should be displayed as " + expected_ProductOwner,
								"ProductOwner is displayed as " + actual_ProductOwner);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"ProductOwner Should be displayed as " + expected_ProductOwner,
								"ProductOwner is displayed as " + actual_ProductOwner);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]")) {
					String actual_GLPN;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]"));
					try {
						actual_GLPN = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_GLPN = el.get(0).getText();
					}

					String expected_GLPN = gLPN[k].trim();
					expected_GLPN = expected_GLPN.replace("Null", " ");
					
					List<String> gLPN1=new ArrayList<String>(Arrays.asList(gLPN));

					if (gLPN1.contains(actual_GLPN.toLowerCase().trim())
							|| actual_GLPN.toLowerCase().trim().contains(expected_GLPN.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"GLPN Should be displayed as " + expected_GLPN, "GLPN is displayed as " + actual_GLPN);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"GLPN Should be displayed as " + expected_GLPN, "GLPN is displayed as " + actual_GLPN);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Type']//..//preceding-sibling::*)+1]")) {
					String actual_ProductType;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Type']//..//preceding-sibling::*)+1]"));
					try {
						actual_ProductType = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_ProductType = el.get(0).getText();
					}

					String expected_ProductType = productType[k].trim();
					expected_ProductType = expected_ProductType.replace("Null", " ");
					List<String> productType1=new ArrayList<String>(Arrays.asList(productType));
					if (productType1.contains(actual_ProductType)
							|| actual_ProductType.toLowerCase().trim()
									.contains(expected_ProductType.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"ProductType Should be displayed as " + expected_ProductType,
								"ProductType is displayed as " + actual_ProductType);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"ProductType Should be displayed as " + expected_ProductType,
								"ProductType is displayed as " + actual_ProductType);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Revenue Recognition Start Date']//..//preceding-sibling::*)+1]")) {
					String actual_RevenueRecognitionStartDate;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Revenue Recognition Start Date']//..//preceding-sibling::*)+1]"));
					try {
						actual_RevenueRecognitionStartDate = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_RevenueRecognitionStartDate = el.get(0).getText();
					}

					String expected_RevenueRecognitionStartDate = revRecStartDate[k].trim();
					expected_RevenueRecognitionStartDate = expected_RevenueRecognitionStartDate.replace("Null", " ");
					List<String> revRecStartDate1=new ArrayList<String>(Arrays.asList(revRecStartDate));
					if (revRecStartDate1
							.contains(actual_RevenueRecognitionStartDate.toLowerCase().trim())
							|| actual_RevenueRecognitionStartDate.toLowerCase().trim()
									.contains(expected_RevenueRecognitionStartDate.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"RevenueRecognitionStartDate Should be displayed as "
										+ expected_RevenueRecognitionStartDate,
								"RevenueRecognitionStartDate is displayed as " + actual_RevenueRecognitionStartDate);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"RevenueRecognitionStartDate Should be displayed as "
										+ expected_RevenueRecognitionStartDate,
								"RevenueRecognitionStartDate is displayed as " + actual_RevenueRecognitionStartDate);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Revenue Recognition End Date']//..//preceding-sibling::*)+1]")) {
					String actual_RevenueRecognitionEndDate;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Revenue Recognition End Date']//..//preceding-sibling::*)+1]"));
					try {
						actual_RevenueRecognitionEndDate = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_RevenueRecognitionEndDate = el.get(0).getText();
					}

					String expected_RevenueRecognitionEndDate = revRecEndDate[k].trim();
					expected_RevenueRecognitionEndDate = expected_RevenueRecognitionEndDate.replace("Null", " ");
					List<String> revRecEndDate1=new ArrayList<String>(Arrays.asList(revRecEndDate));
					if (revRecEndDate1
							.contains(actual_RevenueRecognitionEndDate)
							|| actual_RevenueRecognitionEndDate.toLowerCase().trim()
									.contains(expected_RevenueRecognitionEndDate.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"RevenueRecognitionEndDate Should be displayed as " + expected_RevenueRecognitionEndDate,
								"RevenueRecognitionEndDate is displayed as " + actual_RevenueRecognitionEndDate);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"RevenueRecognitionEndDate Should be displayed as " + expected_RevenueRecognitionEndDate,
								"RevenueRecognitionEndDate is displayed as " + actual_RevenueRecognitionEndDate);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Tax Code']//..//preceding-sibling::*)+1]")) {
					String actual_TaxCode;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Tax Code']//..//preceding-sibling::*)+1]"));
					try {
						actual_TaxCode = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_TaxCode = el.get(0).getText();
					}

					String expected_TaxCode = taxCode[k].trim();
					expected_TaxCode = expected_TaxCode.replace("Null", " ");
					List<String> taxCode1=new ArrayList<String>(Arrays.asList(taxCode));
					if (taxCode1.contains(actual_TaxCode)
							|| actual_TaxCode.toLowerCase().trim().contains(expected_TaxCode.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"TaxCode Should be displayed as " + expected_TaxCode,
								"TaxCode is displayed as " + actual_TaxCode);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"TaxCode Should be displayed as " + expected_TaxCode,
								"TaxCode is displayed as " + actual_TaxCode);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Split Window Number']//..//preceding-sibling::*)+1]")) {
					String actual_splitWindowNumber;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Split Window Number']//..//preceding-sibling::*)+1]"));
					try {
						actual_splitWindowNumber = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_splitWindowNumber = el.get(0).getText();
					}

					String expected_splitWindowNumber = splitWindowNumber[k].trim();
					expected_splitWindowNumber = expected_splitWindowNumber.replace("Null", " ");
					List<String> splitWindowNumber1=new ArrayList<String>(Arrays.asList(splitWindowNumber));
					if (splitWindowNumber1
							.contains(actual_splitWindowNumber)
							|| actual_splitWindowNumber.toLowerCase().trim()
									.contains(expected_splitWindowNumber.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"splitWindowNumber Should be displayed as " + expected_splitWindowNumber,
								"splitWindowNumber is displayed as " + actual_splitWindowNumber);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"splitWindowNumber Should be displayed as " + expected_splitWindowNumber,
								"splitWindowNumber is displayed as " + actual_splitWindowNumber);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Market Code']//..//preceding-sibling::*)+1]")) {
					String actual_MarketCode;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Market Code']//..//preceding-sibling::*)+1]"));
					try {
						actual_MarketCode = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_MarketCode = el.get(0).getText();
					}

					String expected_MarketCode = marketCode[k].trim();
					expected_MarketCode = expected_MarketCode.replace("Null", " ");
					List<String> marketCode1=new ArrayList<String>(Arrays.asList(marketCode));
					if (marketCode1.contains(actual_MarketCode)
							) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"MarketCode Should be displayed as " + expected_MarketCode,
								"MarketCode is displayed as " + actual_MarketCode);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"MarketCode Should be displayed as " + expected_MarketCode,
								"MarketCode is displayed as " + actual_MarketCode);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Territory']//..//preceding-sibling::*)+1]")) {
					String actual_Territory;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Territory']//..//preceding-sibling::*)+1]"));
					try {
						actual_Territory = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_Territory = el.get(0).getText();
					}

					String expected_Territory = territory[k].trim();
					expected_Territory = expected_Territory.replace("Null", " ");
					List<String> territory1=new ArrayList<String>(Arrays.asList(territory));
					if (territory1.contains(actual_Territory)
							) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"Territory Should be displayed as " + expected_Territory,
								"Territory is displayed as " + actual_Territory);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"Territory Should be displayed as " + expected_Territory,
								"Territory is displayed as " + actual_Territory);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title']//..//preceding-sibling::*)+1]")) {
					String actual_Title;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title']//..//preceding-sibling::*)+1]"));
					try {
						actual_Title = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_Title = el.get(0).getText();
					}

					String expected_Title = titleID[k].trim();
					expected_Title = expected_Title.replace("Null", " ");
					List<String> titleID1=new ArrayList<String>(Arrays.asList(titleID));
					if (titleID1.contains(actual_Title)
							|| actual_Title.toLowerCase().trim().contains(expected_Title.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"Title Should be displayed as " + expected_Title, "Title is displayed as " + actual_Title);
					} 
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Right']//..//preceding-sibling::*)+1]")) {
					String actual_Right;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Right']//..//preceding-sibling::*)+1]"));
					try {
						actual_Right = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_Right = el.get(0).getText();
					}

					String expected_Right = right[k].trim();
					expected_Right = expected_Right.replace("Null", " ");
					List<String> right1=new ArrayList<String>(Arrays.asList(right));
					if (right1.contains(actual_Right)
							) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"Right Should be displayed as " + expected_Right, "Right is displayed as " + actual_Right);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"Right Should be displayed as " + expected_Right, "Right is displayed as " + actual_Right);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled Revenue Account']//..//preceding-sibling::*)+1]")) {
					String actual_unbilledRevenueAccount;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled Revenue Account']//..//preceding-sibling::*)+1]"));
					try {
						actual_unbilledRevenueAccount = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_unbilledRevenueAccount = el.get(0).getText();
					}

					String expected_unbilledRevenueAccount = unbilledRevenueAccount[k].trim();
					expected_unbilledRevenueAccount = expected_unbilledRevenueAccount.replace("Null", " ");
					
					
					
					List<String> unbilledRevenueAccount1=new ArrayList<String>(Arrays.asList(unbilledRevenueAccount));

					if (unbilledRevenueAccount1
							.contains(actual_unbilledRevenueAccount)
							|| actual_unbilledRevenueAccount.toLowerCase().trim()
									.contains(expected_unbilledRevenueAccount.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"unbilledRevenueAccount Should be displayed as " + expected_unbilledRevenueAccount,
								"unbilledRevenueAccount is displayed as " + actual_unbilledRevenueAccount);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"unbilledRevenueAccount Should be displayed as " + expected_unbilledRevenueAccount,
								"unbilledRevenueAccount is displayed as " + actual_unbilledRevenueAccount);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed Revenue Account']//..//preceding-sibling::*)+1]")) {
					String actual_BilledRevenueAccount;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed Revenue Account']//..//preceding-sibling::*)+1]"));
					try {
						actual_BilledRevenueAccount = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_BilledRevenueAccount = el.get(0).getText();
					}

					String expected_BilledRevenueAccount = billedRevenueAccount[k].trim();
					expected_BilledRevenueAccount = expected_BilledRevenueAccount.replace("Null", " ");
					List<String> billedRevenueAccount1=new ArrayList<String>(Arrays.asList(billedRevenueAccount));
					if (billedRevenueAccount1.contains(actual_BilledRevenueAccount)
							|| actual_BilledRevenueAccount.toLowerCase().trim()
									.contains(expected_BilledRevenueAccount.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"BilledRevenueAccount Should be displayed as " + expected_BilledRevenueAccount,
								"BilledRevenueAccount is displayed as " + actual_BilledRevenueAccount);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"BilledRevenueAccount Should be displayed as " + expected_BilledRevenueAccount,
								"BilledRevenueAccount is displayed as " + actual_BilledRevenueAccount);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled AR']//..//preceding-sibling::*)+1]")) {
					String actual_unbilledARAccount;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled AR']//..//preceding-sibling::*)+1]"));
					try {
						actual_unbilledARAccount = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_unbilledARAccount = el.get(0).getText();
					}

					String expected_unbilledARAccount = unbilledARAccount[k].trim();
					expected_unbilledARAccount = expected_unbilledARAccount.replace("Null", " ");
					List<String> unbilledARAccount1=new ArrayList<String>(Arrays.asList(unbilledARAccount));
					if (unbilledARAccount1.contains(actual_unbilledARAccount)
							|| actual_unbilledARAccount.toLowerCase().trim()
									.contains(expected_unbilledARAccount.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"unbilledARAccount Should be displayed as " + expected_unbilledARAccount,
								"unbilledARAccount is displayed as " + actual_unbilledARAccount);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"unbilledARAccount Should be displayed as " + expected_unbilledARAccount,
								"unbilledARAccount is displayed as " + actual_unbilledARAccount);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed AR Account']//..//preceding-sibling::*)+1]")) {
					String actual_BilledARAccount;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed AR Account']//..//preceding-sibling::*)+1]"));
					try {
						actual_BilledARAccount = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_BilledARAccount = el.get(0).getText();
					}

					String expected_BilledARAccount = billedARAccount[k].trim();
					expected_BilledARAccount = expected_BilledARAccount.replace("Null", " ");
					List<String> billedARAccount1=new ArrayList<String>(Arrays.asList(billedARAccount));
					if (billedARAccount1.contains(actual_BilledARAccount)
							|| actual_BilledARAccount.toLowerCase().trim()
									.contains(expected_BilledARAccount.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"BilledARAccount Should be displayed as " + expected_BilledARAccount,
								"BilledARAccount is displayed as " + actual_BilledARAccount);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"BilledARAccount Should be displayed as " + expected_BilledARAccount,
								"BilledARAccount is displayed as " + actual_BilledARAccount);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Paid Deferred']//..//preceding-sibling::*)+1]")) {
					String actual_PaidDeferred;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Paid Deferred']//..//preceding-sibling::*)+1]"));
					try {
						actual_PaidDeferred = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_PaidDeferred = el.get(0).getText();
					}

					String expected_PaidDeferred = paidDeferredRevenueAccount[k].trim();
					expected_PaidDeferred = expected_PaidDeferred.replace("Null", " ");
					List<String> paidDeferredRevenueAccount1=new ArrayList<String>(Arrays.asList(paidDeferredRevenueAccount));
					if (paidDeferredRevenueAccount1.contains(actual_PaidDeferred)
							|| actual_PaidDeferred.toLowerCase().trim()
									.contains(expected_PaidDeferred.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"PaidDeferred Should be displayed as " + expected_PaidDeferred,
								"PaidDeferred is displayed as " + actual_PaidDeferred);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"PaidDeferred Should be displayed as " + expected_PaidDeferred,
								"PaidDeferred is displayed as " + actual_PaidDeferred);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Bad Debt Revenue']//..//preceding-sibling::*)+1]")) {
					String actual_BadDebtRevenue;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Bad Debt Revenue']//..//preceding-sibling::*)+1]"));
					try {
						actual_BadDebtRevenue = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_BadDebtRevenue = el.get(0).getText();
					}

					String expected_BadDebtRevenue = badDebtRevenueAccount[k].trim();
					expected_BadDebtRevenue = expected_BadDebtRevenue.replace("Null", " ");
					List<String> badDebtRevenueAccount1=new ArrayList<String>(Arrays.asList(badDebtRevenueAccount));
					if (badDebtRevenueAccount1.contains(actual_BadDebtRevenue)
							|| actual_BadDebtRevenue.toLowerCase().trim()
									.contains(expected_BadDebtRevenue.toLowerCase().trim())) {
						passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"BadDebtRevenue Should be displayed as " + expected_BadDebtRevenue,
								"BadDebtRevenue is displayed as " + actual_BadDebtRevenue);
					} else {
						failed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
								"BadDebtRevenue Should be displayed as " + expected_BadDebtRevenue,
								"BadDebtRevenue is displayed as " + actual_BadDebtRevenue);
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Quantity']//..//preceding-sibling::*)+1]")) {
					String actual_Quantity;
					Float actual_Quantity_temp;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Quantity']//..//preceding-sibling::*)+1]"));
					try {
						actual_Quantity = el.get(temp).getText();
						actual_Quantity = actual_Quantity.replace(",", "");
						actual_Quantity = actual_Quantity.replace("$", "");
						actual_Quantity_temp = Float.parseFloat(actual_Quantity);
					} catch (Exception e) {
						temp = 0;
						actual_Quantity = el.get(0).getText();
						actual_Quantity = actual_Quantity.replace(",", "");
						actual_Quantity = actual_Quantity.replace("$", "");
						actual_Quantity_temp = Float.parseFloat(actual_Quantity);
					}

					try {
						String expected_Quantity = quantity[k].trim();
						expected_Quantity = expected_Quantity.replace("Null", " ");
						expected_Quantity = expected_Quantity.replace(",", "");
						expected_Quantity = expected_Quantity.replace("$", "");
						Float expected_Quantity_temp = Float.parseFloat(expected_Quantity);
						List<String> quantity1=new ArrayList<String>(Arrays.asList(quantity));
						if (quantity1.contains(actual_Quantity_temp)
								|| actual_Quantity_temp.toString().trim()
										.contains(expected_Quantity_temp.toString().trim())) {
							passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
									"Quantity Should be displayed as " + expected_Quantity,
									"Quantity is displayed as " + actual_Quantity);
						}
					} catch (Exception e) {
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Amount']//..//preceding-sibling::*)+1]")) {
					String actual_Amount;
					Float actual_Amount_temp;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Amount']//..//preceding-sibling::*)+1]"));
					try {
						actual_Amount = el.get(temp).getText();
						actual_Amount = actual_Amount.replace(",", "");
						actual_Amount = actual_Amount.replace("$", "");
						actual_Amount_temp = Float.parseFloat(actual_Amount);
					} catch (Exception e) {
						temp = 0;
						actual_Amount = el.get(0).getText();
						actual_Amount = actual_Amount.replace(",", "");
						actual_Amount = actual_Amount.replace("$", "");
						actual_Amount_temp = Float.parseFloat(actual_Amount);
					}

					try {
						String expected_Amount = amount[k].trim();
						expected_Amount = expected_Amount.replace("Null", " ");
						expected_Amount = expected_Amount.replace(",", "");
						expected_Amount = expected_Amount.replace("$", "");
						Float expected_Amount_temp = Float.parseFloat(expected_Amount);
						List<String> amount1=new ArrayList<String>(Arrays.asList(amount));
						if (amount1.contains(actual_Amount_temp)
								|| actual_Amount_temp.toString().trim().contains(expected_Amount_temp.toString().trim())) {
							passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
									"Amount Should be displayed as " + expected_Amount,
									"Amount is displayed as " + actual_Amount);
						}
					} catch (Exception e) {
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'" + gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Net Revised Amount']//..//preceding-sibling::*)+1]")) {
					String actual_NetRevisedAmount;
					Float actual_NetRevisedAmount_temp;
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//tr[contains(@class,'uir-machine-row')]//td[contains(text(),'"
							+ gLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Net Revised Amount']//..//preceding-sibling::*)+1]"));
					try {
						actual_NetRevisedAmount = el.get(temp).getText();
						actual_NetRevisedAmount = actual_NetRevisedAmount.replace(",", "");
						actual_NetRevisedAmount = actual_NetRevisedAmount.replace("$", "");
						actual_NetRevisedAmount_temp = Float.parseFloat(actual_NetRevisedAmount);
					} catch (Exception e) {
						temp = 0;
						actual_NetRevisedAmount = el.get(0).getText();
						actual_NetRevisedAmount = actual_NetRevisedAmount.replace(",", "");
						actual_NetRevisedAmount = actual_NetRevisedAmount.replace("$", "");
						actual_NetRevisedAmount_temp = Float.parseFloat(actual_NetRevisedAmount);
					}

					try {
						String expected_NetRevisedAmount = netRevisedAmount[k].trim();
						expected_NetRevisedAmount = expected_NetRevisedAmount.replace("Null", " ");
						expected_NetRevisedAmount = expected_NetRevisedAmount.replace(",", "");
						expected_NetRevisedAmount = expected_NetRevisedAmount.replace("$", "");
						Float expected_NetRevisedAmount_temp = Float.parseFloat(expected_NetRevisedAmount);
						List<String> netRevisedAmount1=new ArrayList<String>(Arrays.asList(netRevisedAmount));
						if (netRevisedAmount1.contains(actual_NetRevisedAmount_temp)
								|| actual_NetRevisedAmount_temp.toString().trim()
										.contains(expected_NetRevisedAmount_temp.toString().trim())) {
							passed("ValidateLineitemsinNS-"+i+"" + "-Line Item for GLPN " + gLPN[k],
									"NetRevisedAmount Should be displayed as " + expected_NetRevisedAmount,
									"NetRevisedAmount is displayed as " + actual_NetRevisedAmount);
						} 
					} catch (Exception e) {
					}
				}

				el = uiDriver.webDr.findElements(By.xpath(xpath));
				if (el.size() > 1) {
					temp++;
				} else {
					temp = 0;
				}

				k++;
			
			}
		}

		
		
	    public void ValidateAllInvoiceData(DataRow input, DataRow output) throws InterruptedException {
			try {
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.setValue("//input[@id='_searchstring']", input.get("conf"));
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.click("//a[contains(text(),'Sales Order:')]");
				SleepUtils.sleep(TimeSlab.LOW);
				if (uiDriver.checkElementPresent("//h1[text()='Sales Order']")) {
					passed("ValidateAllInvoiceData", "Sales Order Should be displayed", "Sales Order is displayed");
				} else {
					failed("ValidateAllInvoiceData", "Sales Order Should be displayed", "Sales Order is not displayed");
				}
				uiDriver.click("//a[@id='rlrcdstabtxt']");
				SleepUtils.sleep(TimeSlab.LOW);

				String TotalAmounts = input.get("TotalAmount");
				String TotalAmount[] = TotalAmounts.split(";");

				String Items = input.get("Item");
				String Item[] = Items.split(";");

				String Quantities = input.get("Quantity");
				String Quantity[] = Quantities.split(";");

				String Rates = input.get("Rate");
				String Rate[] = Rates.split(";");

				String Amounts = input.get("Amount");
				String Amount[] = Amounts.split(";");

				String TaxCodes = input.get("Tax Code");
				String TaxCode[] = TaxCodes.split(";");

				String MarketCodes = input.get("Market Code");
				String MarketCode[] = MarketCodes.split(";");

				String Territories = input.get("Territory");
				String Territory[] = Territories.split(";");

				String TitleIDs = input.get("Title ID");
				String TitleID[] = TitleIDs.split(";");

				String GLPNs = input.get("GLPN");
				String GLPN[] = GLPNs.split(";");

				String ProductOwners = input.get("Product Owner");
				String ProductOwner[] = ProductOwners.split(";");

//				String Rights = input.get("Right");
//				String Right[] = Rights.split(";");

				String UnbilledRevenueAccounts = input.get("Unbilled Revenue Account");
				String UnbilledRevenueAccount[] = UnbilledRevenueAccounts.split(";");

				String BilledRevenueAccounts = input.get("Billed Revenue Account");
				String BilledRevenueAccount[] = BilledRevenueAccounts.split(";");

				String BilledARAccounts = input.get("Billed AR Account");
				String BilledARAccount[] = BilledARAccounts.split(";");

				String UnbilledARAccounts = input.get("Unbilled AR Account");
				String UnbilledARAccount[] = UnbilledARAccounts.split(";");

				String PaidDeferredRevenueAccounts = input.get("Paid Deferred Revenue Account");
				String PaidDeferredRevenueAccount[] = PaidDeferredRevenueAccounts.split(";");

				String UnpaidDeferredRevenueAccounts = input.get("Unpaid Deferred Revenue Account");
				String UnpaidDeferredRevenueAccount[] = UnpaidDeferredRevenueAccounts.split(";");

				String BadDebtRevenueAccounts = input.get("Bad Debt Revenue Account");
				String BadDebtRevenueAccount[] = BadDebtRevenueAccounts.split(";");

				List<WebElement> Invoices = uiDriver.webDr.findElements(By.xpath("//td[text()='Invoice']//..//a"));
				int total_Invoices = Invoices.size();

				int k = 0, flag = 0;
				for (int i = 0; i < TotalAmount.length; i++) {
					uiDriver.click("//a[@id='rlrcdstabtxt']");
					SleepUtils.sleep(TimeSlab.LOW);

					String InvAmount = TotalAmount[i];
					String Exchange = text_ExchangeNumber;

					InvAmount = InvAmount.replace(",", "");
					Exchange = Exchange.replace(",", "");

					Float temp1 = Float.parseFloat(InvAmount);
					Float temp2 = Float.parseFloat(Exchange);

					Float temp3 = temp1 * temp2;
					String temp4 = temp3.toString();

					int end = temp4.indexOf(".");
					String temp5 = temp4.substring(0, end);
					// String temp5 = "4595029";
					System.out.println(temp5);

					int length = temp5.length();

					ArrayList<String> t1 = new ArrayList<String>();
					for (int x = (length - 1); x >= 0; x--) {
						String t2 = temp5.substring(x, x + 1);
						t1.add(t2);
					}
					System.out.println(t1);
					System.out.println(t1.size());

					String finalAmount = "";
					for (int x = 0; x < t1.size(); x++) {
						finalAmount = t1.get(x) + finalAmount;

						if (x != t1.size() - 1) {
							if (x % 3 == 2) {
								finalAmount = "," + finalAmount;
							}
						}
					}
					System.out.println(finalAmount);

					String xpath_Invoice = "//td[text()='Invoice']//..//td[contains(text(),'" + finalAmount.trim()
							+ "')]//..//a";
					// uiDriver.click(xpath_Invoice);
					List<WebElement> element = uiDriver.webDr.findElements(By.xpath(xpath_Invoice));
					if (element.size() > 1) {
						((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView(true);",
								element.get(flag));
						((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();", element.get(flag));
						flag++;
					} else {
						((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView(true);",
								element.get(0));
						((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();", element.get(0));
					}
					SleepUtils.sleep(TimeSlab.LOW);
					if (uiDriver.checkElementPresent("//h1[text()='Invoice']")) {
						passed("ValidateAllInvoiceData", "Invoice Should be displayed", "Invoice is displayed");
					} else {
						failed("ValidateAllInvoiceData", "Invoice Should be displayed", "Invoice is not displayed");
					}

					String actual_Customer = uiDriver
							.getValue("//span[@id='entity_fs_lbl_uir_label']//following-sibling::span//a");
					String actual_DueDate = uiDriver
							.getValue("//span[@id='duedate_fs_lbl_uir_label']//following-sibling::span");
					String actual_ApprovalStatus = uiDriver
							.getValue("//span[@id='approvalstatus_fs_lbl_uir_label']//following-sibling::span//span");
					String actual_Status = uiDriver.getValue("//div[@class='uir-record-status']");
					String actual_Subsidiary = uiDriver
							.getValue("//span[@id='subsidiary_lbl_uir_label']//following-sibling::span//span");
					String actual_RevisionNumber = uiDriver.getValue(
							"//span[@id='custbody_nbcu_revision_number_fs_lbl_uir_label']//following-sibling::span");
					String actual_InvoiceType = uiDriver.getValue(
							"//span[@id='custbody_nbcu_inv_type_fs_lbl_uir_label']//following-sibling::span//span");

					String Customer = input.get("Customer");
					String[] expected_Customer = Customer.split(";");
					String DueDate = input.get("DueDate");
					String[] expected_DueDate = DueDate.split(";");
					String ApprovalStatus = input.get("ApprovalStatus");
					String[] expected_ApprovalStatus = ApprovalStatus.split(";");
					String Status = input.get("Status");
					String[] expected_Status = Status.split(";");
					String Subsidiary = input.get("Subsidiary");
					String[] expected_Subsidiary = Subsidiary.split(";");
					String RevisionNumber = input.get("RevisionNumber");
					String[] expected_RevisionNumber = RevisionNumber.split(";");
					String InvoiceType = input.get("InvoiceType");
					String[] expected_InvoiceType = InvoiceType.split(";");

					if (actual_Customer.toLowerCase().trim().contains(expected_Customer[i].toLowerCase().trim())
							|| expected_Customer[i].toLowerCase().trim().contains(actual_Customer.toLowerCase().trim())) {
						passed("Verify Invoice Details", "Customer should be displayed as : " + expected_Customer[i].trim(),
								"Customer is displayed as : " + actual_Customer.trim());
					} else {
						failed("Verify Invoice Details", "Customer should be displayed as : " + expected_Customer[i].trim(),
								"Customer is not displayed as : " + actual_Customer.trim());
					}

					if (actual_DueDate.toLowerCase().trim().contains(expected_DueDate[i].toLowerCase().trim())
							|| expected_DueDate[i].toLowerCase().trim().contains(actual_DueDate.toLowerCase().trim())) {
						passed("Verify Invoice Details", "DueDate should be displayed as : " + expected_DueDate[i].trim(),
								"DueDate is displayed as : " + actual_DueDate.trim());
					} else {
						failed("Verify Invoice Details", "DueDate should be displayed as : " + expected_DueDate[i].trim(),
								"DueDate is not displayed as : " + actual_DueDate.trim());
					}

					if (actual_ApprovalStatus.toLowerCase().trim().contains(expected_ApprovalStatus[i].toLowerCase().trim())
							|| expected_ApprovalStatus[i].toLowerCase().trim()
									.contains(actual_ApprovalStatus.toLowerCase().trim())) {
						passed("Verify Invoice Details",
								"ApprovalStatus should be displayed as : " + expected_ApprovalStatus[i].trim(),
								"ApprovalStatus is displayed as : " + actual_ApprovalStatus.trim());
					} else {
						failed("Verify Invoice Details",
								"ApprovalStatus should be displayed as : " + expected_ApprovalStatus[i].trim(),
								"ApprovalStatus is not displayed as : " + actual_ApprovalStatus.trim());
					}

					if (actual_Status.toLowerCase().trim().contains(expected_Status[i].toLowerCase().trim())
							|| expected_Status[i].toLowerCase().trim().contains(actual_Status.toLowerCase().trim())) {
						passed("Verify Invoice Details", "Status should be displayed as : " + expected_Status[i].trim(),
								"Status is displayed as : " + actual_Status.trim());
					} else {
						failed("Verify Invoice Details", "Status should be displayed as : " + expected_Status[i].trim(),
								"Status is not displayed as : " + actual_Status.trim());
					}

					if (actual_Subsidiary.toLowerCase().trim().contains(expected_Subsidiary[i].toLowerCase().trim())
							|| expected_Subsidiary[i].toLowerCase().trim()
									.contains(actual_Subsidiary.toLowerCase().trim())) {
						passed("Verify Invoice Details",
								"Subsidiary should be displayed as : " + expected_Subsidiary[i].trim(),
								"Subsidiary is displayed as : " + actual_Subsidiary.trim());
					} else {
						failed("Verify Invoice Details",
								"Subsidiary should be displayed as : " + expected_Subsidiary[i].trim(),
								"Subsidiary is not displayed as : " + actual_Subsidiary.trim());
					}

					if (actual_RevisionNumber.toLowerCase().trim().contains(expected_RevisionNumber[i].toLowerCase().trim())
							|| expected_RevisionNumber[i].toLowerCase().trim()
									.contains(actual_RevisionNumber.toLowerCase().trim())) {
						passed("Verify Invoice Details",
								"RevisionNumber should be displayed as : " + expected_RevisionNumber[i].trim(),
								"RevisionNumber is displayed as : " + actual_RevisionNumber.trim());
					} else {
						failed("Verify Invoice Details",
								"RevisionNumber should be displayed as : " + expected_RevisionNumber[i].trim(),
								"RevisionNumber is not displayed as : " + actual_RevisionNumber.trim());
					}

					if (actual_InvoiceType.toLowerCase().trim().contains(expected_InvoiceType[i].toLowerCase().trim())
							|| expected_InvoiceType[i].toLowerCase().trim()
									.contains(actual_InvoiceType.toLowerCase().trim())) {
						passed("Verify Invoice Details",
								"InvoiceType should be displayed as : " + expected_InvoiceType[i].trim(),
								"InvoiceType is displayed as : " + actual_InvoiceType.trim());
					} else {
						failed("Verify Invoice Details",
								"InvoiceType should be displayed as : " + expected_InvoiceType[i].trim(),
								"InvoiceType is not displayed as : " + actual_InvoiceType.trim());
					}

					uiDriver.executeJavaScript("scroll(0,500)");

					List<WebElement> LineItems = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tr"));
					int total_LineItems = LineItems.size(), temp = 0;

					for (int j = 2; j <= total_LineItems; j++) {
						List<WebElement> el;
						if(k < GLPN.length) {
						String xpath = "//table[@id='item_splits']//td[contains(text(),'" + GLPN[k].trim() + "')]";

						if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
								+ GLPN[k].trim()
								+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title']//..//preceding-sibling::*)+1]")) {
							String actual_Item;
							el = uiDriver.webDr.findElements(
									By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
											+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title']//..//preceding-sibling::*)+1]"));
							try {
								actual_Item = el.get(temp).getText();
							} catch (Exception e) {
								temp = 0;
								actual_Item = el.get(0).getText();
							}

							String expected_Item = Item[k].trim();
							expected_Item = expected_Item.replace("Null", " ");

							if (expected_Item.toLowerCase().trim().contains(actual_Item.toLowerCase().trim())
									|| actual_Item.toLowerCase().trim().contains(expected_Item.toLowerCase().trim())) {
								passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"Item Should be displayed as " + expected_Item,
										"Item is displayed as " + actual_Item);
							} else {
								failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"Item Should be displayed as " + expected_Item,
										"Item is not displayed as " + actual_Item);
							}
						}

						if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
								+ GLPN[k].trim()
								+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Rate']//..//preceding-sibling::*)+1]")) {
							String actual_Rate;
							Float actual_Rate_temp;
							el = uiDriver.webDr.findElements(
									By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
											+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Rate']//..//preceding-sibling::*)+1]"));
							try {
								actual_Rate = el.get(temp).getText();
								actual_Rate = actual_Rate.replace(",", "");
								actual_Rate_temp = Float.parseFloat(actual_Rate);
							} catch (Exception e) {
								temp = 0;
								actual_Rate = el.get(0).getText();
								actual_Rate = actual_Rate.replace(",", "");
								actual_Rate_temp = Float.parseFloat(actual_Rate);
							}

							String expected_Rate = Rate[k].trim();
							expected_Rate = expected_Rate.replace("Null", " ");
							expected_Rate = expected_Rate.replace(",", "");
							Float expected_Rate_temp = Float.parseFloat(actual_Rate);

							if (expected_Rate_temp.toString().trim().contains(actual_Rate_temp.toString().trim())
									|| actual_Rate_temp.toString().trim().contains(expected_Rate_temp.toString().trim())) {
								passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"Rate Should be displayed as " + expected_Rate,
										"Rate is displayed as " + actual_Rate);
							} else {
								failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"Rate Should be displayed as " + expected_Rate,
										"Rate is not displayed as " + actual_Rate);
							}
						}

						if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
								+ GLPN[k].trim()
								+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Tax Code']//..//preceding-sibling::*)+1]")) {
							String actual_TaxCode;
							el = uiDriver.webDr.findElements(
									By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
											+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Tax Code']//..//preceding-sibling::*)+1]"));
							try {
								actual_TaxCode = el.get(temp).getText();
							} catch (Exception e) {
								temp = 0;
								actual_TaxCode = el.get(0).getText();
							}

							String expected_TaxCode = TaxCode[k].trim();
							expected_TaxCode = expected_TaxCode.replace("Null", " ");

							if (expected_TaxCode.toLowerCase().trim().contains(actual_TaxCode.toLowerCase().trim())
									|| actual_TaxCode.toLowerCase().trim()
											.contains(expected_TaxCode.toLowerCase().trim())) {
								passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"TaxCode Should be displayed as " + expected_TaxCode,
										"TaxCode is displayed as " + actual_TaxCode);
							} else {
								failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"TaxCode Should be displayed as " + expected_TaxCode,
										"TaxCode is not displayed as " + actual_TaxCode);
							}
						}

						if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
								+ GLPN[k].trim()
								+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Market Code']//..//preceding-sibling::*)+1]")) {
							String actual_MarketCode;
							el = uiDriver.webDr.findElements(
									By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
											+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Market Code']//..//preceding-sibling::*)+1]"));
							try {
								actual_MarketCode = el.get(temp).getText();
							} catch (Exception e) {
								temp = 0;
								actual_MarketCode = el.get(0).getText();
							}

							String expected_MarketCode = MarketCode[k].trim();
							expected_MarketCode = expected_MarketCode.replace("Null", " ");

							if (expected_MarketCode.toLowerCase().trim().contains(actual_MarketCode.toLowerCase().trim())
									|| actual_MarketCode.toLowerCase().trim()
											.contains(expected_MarketCode.toLowerCase().trim())) {
								passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"MarketCode Should be displayed as " + expected_MarketCode,
										"MarketCode is displayed as " + actual_MarketCode);
							} else {
								failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"MarketCode Should be displayed as " + expected_MarketCode,
										"MarketCode is not displayed as " + actual_MarketCode);
							}
						}

						if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
								+ GLPN[k].trim()
								+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title ID']//..//preceding-sibling::*)+1]")) {
							String actual_TitleID;
							el = uiDriver.webDr.findElements(
									By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
											+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title ID']//..//preceding-sibling::*)+1]"));
							try {
								actual_TitleID = el.get(temp).getText();
							} catch (Exception e) {
								temp = 0;
								actual_TitleID = el.get(0).getText();
							}

							String expected_TitleID = TitleID[k].trim();
							expected_TitleID = expected_TitleID.replace("Null", " ");

							if (expected_TitleID.toLowerCase().trim().contains(actual_TitleID.toLowerCase().trim())
									|| actual_TitleID.toLowerCase().trim()
											.contains(expected_TitleID.toLowerCase().trim())) {
								passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"TitleID Should be displayed as " + expected_TitleID,
										"TitleID is displayed as " + actual_TitleID);
							} else {
								failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"TitleID Should be displayed as " + expected_TitleID,
										"TitleID is not displayed as " + actual_TitleID);
							}
						}

						if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
								+ GLPN[k].trim()
								+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]")) {
							String actual_GLPN;
							el = uiDriver.webDr.findElements(
									By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
											+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]"));
							try {
								actual_GLPN = el.get(temp).getText();
							} catch (Exception e) {
								temp = 0;
								actual_GLPN = el.get(0).getText();
							}

							String expected_GLPN = GLPN[k].trim();
							expected_GLPN = expected_GLPN.replace("Null", " ");

							if (expected_GLPN.toLowerCase().trim().contains(actual_GLPN.toLowerCase().trim())
									|| actual_GLPN.toLowerCase().trim().contains(expected_GLPN.toLowerCase().trim())) {
								passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"GLPN Should be displayed as " + expected_GLPN,
										"GLPN is displayed as " + actual_GLPN);
							} else {
								failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"GLPN Should be displayed as " + expected_GLPN,
										"GLPN is not displayed as " + actual_GLPN);
							}
						}

						if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
								+ GLPN[k].trim()
								+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Owner']//..//preceding-sibling::*)+1]")) {
							String actual_ProductOwner;
							el = uiDriver.webDr.findElements(
									By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
											+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Owner']//..//preceding-sibling::*)+1]"));
							try {
								actual_ProductOwner = el.get(temp).getText();
							} catch (Exception e) {
								temp = 0;
								actual_ProductOwner = el.get(0).getText();
							}

							String expected_ProductOwner = ProductOwner[k].trim();
							expected_ProductOwner = expected_ProductOwner.replace("Null", " ");

							if (expected_ProductOwner.toLowerCase().trim()
									.contains(actual_ProductOwner.toLowerCase().trim())
									|| actual_ProductOwner.toLowerCase().trim()
											.contains(expected_ProductOwner.toLowerCase().trim())) {
								passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"ProductOwner Should be displayed as " + expected_ProductOwner,
										"ProductOwner is displayed as " + actual_ProductOwner);
							} else {
								failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"ProductOwner Should be displayed as " + expected_ProductOwner,
										"ProductOwner is not displayed as " + actual_ProductOwner);
							}
						}

//						if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
//								+ GLPN[k].trim()
//								+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Right']//..//preceding-sibling::*)+1]")) {
//							String actual_Right;
//							el = uiDriver.webDr.findElements(
//									By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
//											+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Right']//..//preceding-sibling::*)+1]"));
//							try {
//								actual_Right = el.get(temp).getText();
//							} catch (Exception e) {
//								temp = 0;
//								actual_Right = el.get(0).getText();
//							}
	//
//							String expected_Right = Right[k].trim();
//							expected_Right = expected_Right.replace("Null", " ");
	//
//							if (expected_Right.toLowerCase().trim().contains(actual_Right.toLowerCase().trim())
//									|| actual_Right.toLowerCase().trim().contains(expected_Right.toLowerCase().trim())) {
//								passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
//										"Right Should be displayed as " + expected_Right,
//										"Right is displayed as " + actual_Right);
//							} else {
//								failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
//										"Right Should be displayed as " + expected_Right,
//										"Right is displayed as " + actual_Right);
//							}
//						}

						if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
								+ GLPN[k].trim()
								+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled Revenue Account']//..//preceding-sibling::*)+1]")) {
							String actual_UnbilledRevenueAccount;
							el = uiDriver.webDr.findElements(
									By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
											+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled Revenue Account']//..//preceding-sibling::*)+1]"));
							try {
								actual_UnbilledRevenueAccount = el.get(temp).getText();
							} catch (Exception e) {
								temp = 0;
								actual_UnbilledRevenueAccount = el.get(0).getText();
							}

							String expected_UnbilledRevenueAccount = UnbilledRevenueAccount[k].trim();
							expected_UnbilledRevenueAccount = expected_UnbilledRevenueAccount.replace("Null", " ");

							if (expected_UnbilledRevenueAccount.toLowerCase().trim()
									.contains(actual_UnbilledRevenueAccount.toLowerCase().trim())
									|| actual_UnbilledRevenueAccount.toLowerCase().trim()
											.contains(expected_UnbilledRevenueAccount.toLowerCase().trim())) {
								passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"UnbilledRevenueAccount Should be displayed as " + expected_UnbilledRevenueAccount,
										"UnbilledRevenueAccount is displayed as " + actual_UnbilledRevenueAccount);
							} else {
								failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"UnbilledRevenueAccount Should be displayed as " + expected_UnbilledRevenueAccount,
										"UnbilledRevenueAccount is not displayed as " + actual_UnbilledRevenueAccount);
							}
						}

						if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
								+ GLPN[k].trim()
								+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed Revenue Account']//..//preceding-sibling::*)+1]")) {
							String actual_BilledRevenueAccount;
							el = uiDriver.webDr.findElements(
									By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
											+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed Revenue Account']//..//preceding-sibling::*)+1]"));
							try {
								actual_BilledRevenueAccount = el.get(temp).getText();
							} catch (Exception e) {
								temp = 0;
								actual_BilledRevenueAccount = el.get(0).getText();
							}

							String expected_BilledRevenueAccount = BilledRevenueAccount[k].trim();
							expected_BilledRevenueAccount = expected_BilledRevenueAccount.replace("Null", " ");

							if (expected_BilledRevenueAccount.toLowerCase().trim()
									.contains(actual_BilledRevenueAccount.toLowerCase().trim())
									|| actual_BilledRevenueAccount.toLowerCase().trim()
											.contains(expected_BilledRevenueAccount.toLowerCase().trim())) {
								passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"BilledRevenueAccount Should be displayed as " + expected_BilledRevenueAccount,
										"BilledRevenueAccount is displayed as " + actual_BilledRevenueAccount);
							} else {
								failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"BilledRevenueAccount Should be displayed as " + expected_BilledRevenueAccount,
										"BilledRevenueAccount is not displayed as " + actual_BilledRevenueAccount);
							}
						}

						if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
								+ GLPN[k].trim()
								+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed AR Account']//..//preceding-sibling::*)+1]")) {
							String actual_BilledARAccount;
							el = uiDriver.webDr.findElements(
									By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
											+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed AR Account']//..//preceding-sibling::*)+1]"));
							try {
								actual_BilledARAccount = el.get(temp).getText();
							} catch (Exception e) {
								temp = 0;
								actual_BilledARAccount = el.get(0).getText();
							}

							String expected_BilledARAccount = BilledARAccount[k].trim();
							expected_BilledARAccount = expected_BilledARAccount.replace("Null", " ");

							if (expected_BilledARAccount.toLowerCase().trim()
									.contains(actual_BilledARAccount.toLowerCase().trim())
									|| actual_BilledARAccount.toLowerCase().trim()
											.contains(expected_BilledARAccount.toLowerCase().trim())) {
								passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"BilledARAccount Should be displayed as " + expected_BilledARAccount,
										"BilledARAccount is displayed as " + actual_BilledARAccount);
							} else {
								failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"BilledARAccount Should be displayed as " + expected_BilledARAccount,
										"BilledARAccount is not displayed as " + actual_BilledARAccount);
							}
						}

						if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
								+ GLPN[k].trim()
								+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled AR Account']//..//preceding-sibling::*)+1]")) {
							String actual_UnbilledARAccount;
							el = uiDriver.webDr.findElements(
									By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
											+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled AR Account']//..//preceding-sibling::*)+1]"));
							try {
								actual_UnbilledARAccount = el.get(temp).getText();
							} catch (Exception e) {
								temp = 0;
								actual_UnbilledARAccount = el.get(0).getText();
							}

							String expected_UnbilledARAccount = UnbilledARAccount[k].trim();
							expected_UnbilledARAccount = expected_UnbilledARAccount.replace("Null", " ");

							if (expected_UnbilledARAccount.toLowerCase().trim()
									.contains(actual_UnbilledARAccount.toLowerCase().trim())
									|| actual_UnbilledARAccount.toLowerCase().trim()
											.contains(expected_UnbilledARAccount.toLowerCase().trim())) {
								passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"UnbilledARAccount Should be displayed as " + expected_UnbilledARAccount,
										"UnbilledARAccount is displayed as " + actual_UnbilledARAccount);
							} else {
								failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"UnbilledARAccount Should be displayed as " + expected_UnbilledARAccount,
										"UnbilledARAccount is not displayed as " + actual_UnbilledARAccount);
							}
						}

						if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
								+ GLPN[k].trim()
								+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Paid Deferred Account']//..//preceding-sibling::*)+1]")) {
							String actual_PaidDeferredRevenueAccount;
							el = uiDriver.webDr.findElements(
									By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
											+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Paid Deferred Account']//..//preceding-sibling::*)+1]"));
							try {
								actual_PaidDeferredRevenueAccount = el.get(temp).getText();
							} catch (Exception e) {
								temp = 0;
								actual_PaidDeferredRevenueAccount = el.get(0).getText();
							}

							String expected_PaidDeferredRevenueAccount = PaidDeferredRevenueAccount[k].trim();
							expected_PaidDeferredRevenueAccount = expected_PaidDeferredRevenueAccount.replace("Null", " ");

							if (expected_PaidDeferredRevenueAccount.toLowerCase().trim()
									.contains(actual_PaidDeferredRevenueAccount.toLowerCase().trim())
									|| actual_PaidDeferredRevenueAccount.toLowerCase().trim()
											.contains(expected_PaidDeferredRevenueAccount.toLowerCase().trim())) {
								passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"PaidDeferredRevenueAccount Should be displayed as "
												+ expected_PaidDeferredRevenueAccount,
										"PaidDeferredRevenueAccount is displayed as " + actual_PaidDeferredRevenueAccount);
							} else {
								failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"PaidDeferredRevenueAccount Should be displayed as "
												+ expected_PaidDeferredRevenueAccount,
										"PaidDeferredRevenueAccount is not displayed as " + actual_PaidDeferredRevenueAccount);
							}
						}

						if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
								+ GLPN[k].trim()
								+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unpaid Deferred Account']//..//preceding-sibling::*)+1]")) {
							String actual_UnpaidDeferredRevenueAccount;
							el = uiDriver.webDr.findElements(
									By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
											+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unpaid Deferred Account']//..//preceding-sibling::*)+1]"));
							try {
								actual_UnpaidDeferredRevenueAccount = el.get(temp).getText();
							} catch (Exception e) {
								temp = 0;
								actual_UnpaidDeferredRevenueAccount = el.get(0).getText();
							}

							String expected_UnpaidDeferredRevenueAccount = UnpaidDeferredRevenueAccount[k].trim();
							expected_UnpaidDeferredRevenueAccount = expected_UnpaidDeferredRevenueAccount.replace("Null",
									" ");

							if (expected_UnpaidDeferredRevenueAccount.toLowerCase().trim()
									.contains(actual_UnpaidDeferredRevenueAccount.toLowerCase().trim())
									|| actual_UnpaidDeferredRevenueAccount.toLowerCase().trim()
											.contains(expected_UnpaidDeferredRevenueAccount.toLowerCase().trim())) {
								passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"UnpaidDeferredRevenueAccount Should be displayed as "
												+ expected_UnpaidDeferredRevenueAccount,
										"UnpaidDeferredRevenueAccount is displayed as "
												+ actual_UnpaidDeferredRevenueAccount);
							} else {
								failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"UnpaidDeferredRevenueAccount Should be displayed as "
												+ expected_UnpaidDeferredRevenueAccount,
										"UnpaidDeferredRevenueAccount is not displayed as "
												+ actual_UnpaidDeferredRevenueAccount);
							}
						}

						if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
								+ GLPN[k].trim()
								+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Bad Debt Revenue Account']//..//preceding-sibling::*)+1]")) {
							String actual_BadDebtRevenueAccount;
							el = uiDriver.webDr.findElements(
									By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
											+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Bad Debt Revenue Account']//..//preceding-sibling::*)+1]"));
							try {
								actual_BadDebtRevenueAccount = el.get(temp).getText();
							} catch (Exception e) {
								temp = 0;
								actual_BadDebtRevenueAccount = el.get(0).getText();
							}

							String expected_BadDebtRevenueAccount = BadDebtRevenueAccount[k].trim();
							expected_BadDebtRevenueAccount = expected_BadDebtRevenueAccount.replace("Null", " ");

							if (expected_BadDebtRevenueAccount.toLowerCase().trim()
									.contains(actual_BadDebtRevenueAccount.toLowerCase().trim())
									|| actual_BadDebtRevenueAccount.toLowerCase().trim()
											.contains(expected_BadDebtRevenueAccount.toLowerCase().trim())) {
								passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"BadDebtRevenueAccount Should be displayed as " + expected_BadDebtRevenueAccount,
										"BadDebtRevenueAccount is displayed as " + actual_BadDebtRevenueAccount);
							} else {
								failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
										"BadDebtRevenueAccount Should be displayed as " + expected_BadDebtRevenueAccount,
										"BadDebtRevenueAccount is not displayed as " + actual_BadDebtRevenueAccount);
							}
						}

						if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
								+ GLPN[k].trim()
								+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Quantity']//..//preceding-sibling::*)+1]")) {
							String actual_Quantity;
							Float actual_Quantity_temp;
							el = uiDriver.webDr.findElements(
									By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
											+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Quantity']//..//preceding-sibling::*)+1]"));
							try {
								actual_Quantity = el.get(temp).getText();
								actual_Quantity = actual_Quantity.replace(",", "");
								actual_Quantity = actual_Quantity.replace("$", "");
								actual_Quantity_temp = Float.parseFloat(actual_Quantity);
							} catch (Exception e) {
								temp = 0;
								actual_Quantity = el.get(0).getText();
								actual_Quantity = actual_Quantity.replace(",", "");
								actual_Quantity = actual_Quantity.replace("$", "");
								actual_Quantity_temp = Float.parseFloat(actual_Quantity);
							}

							try {
								String expected_Quantity = Quantity[k].trim();
								expected_Quantity = expected_Quantity.replace("Null", " ");
								expected_Quantity = expected_Quantity.replace(",", "");
								expected_Quantity = expected_Quantity.replace("$", "");
								Float expected_Quantity_temp = Float.parseFloat(expected_Quantity);

								if (expected_Quantity_temp.toString().trim()
										.contains(actual_Quantity_temp.toString().trim())
										|| actual_Quantity_temp.toString().trim()
												.contains(expected_Quantity_temp.toString().trim())) {
									passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN "
											+ GLPN[k], "Quantity Should be displayed as " + expected_Quantity,
											"Quantity is not displayed as " + actual_Quantity);
								} 
							} catch (Exception e) {
							}
						}

						if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
								+ GLPN[k].trim()
								+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Amount']//..//preceding-sibling::*)+1]")) {
							String actual_Amount;
							Float actual_Amount_temp;
							el = uiDriver.webDr.findElements(
									By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
											+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Amount']//..//preceding-sibling::*)+1]"));
							try {
								actual_Amount = el.get(temp).getText();
								actual_Amount = actual_Amount.replace(",", "");
								actual_Amount_temp = Float.parseFloat(actual_Amount);
							} catch (Exception e) {
								temp = 0;
								actual_Amount = el.get(0).getText();
								actual_Amount = actual_Amount.replace(",", "");
								actual_Amount_temp = Float.parseFloat(actual_Amount);
							}

							try {
								String expected_Amount = Amount[k].trim();
								expected_Amount = expected_Amount.replace("Null", " ");
								expected_Amount = expected_Amount.replace(",", "");
								Float expected_Amount_temp = Float.parseFloat(expected_Amount);

								if (expected_Amount_temp.toString().trim().contains(actual_Amount_temp.toString().trim())
										|| actual_Amount_temp.toString().trim()
												.contains(expected_Amount_temp.toString().trim())) {
									passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN "
											+ GLPN[k], "Amount Should be displayed as " + expected_Amount,
											"Amount is displayed as " + actual_Amount);
								} 
							} catch (Exception e) {
							}
						}

						el = uiDriver.webDr.findElements(By.xpath(xpath));
						if (el.size() > 1) {
							temp++;
						} else {
							temp = 0;
						}

						k++;
						
					}
					}

					if (uiDriver.checkElementPresent("//input[@id='_back']")) {
						uiDriver.executeJavaScript("scroll(0,-1000)");
						uiDriver.click("//input[@id='_back']");
					} else {
						uiDriver.back();
					}
				}
			} catch (Exception e) {
				failed("ValidateAllInvoiceData", "Error in ValidateAllInvoiceData method", "Error : " + e.toString());
			}
		}

	    
	    public void VerifyGlAccountDatascen28(DataRow input, DataRow output) {
	    
	    String debit=input.get("DEBIT");
	    String credit=input.get("CREDIT");
	    String customer=input.get("Name");
	    String subsidiary=input.get("Subsidiary");
	    String marketcode=input.get("MarketCode");
	    String territory=input.get("Territory");
	    String account1=input.get("ACCOUNT1");
	    String account2=input.get("ACCOUNT2");
	    
	    
	    if(uiDriver.checkElementPresent("//*[contains(text(),'"+debit+"')]"))
	    {
	    	passed("VerifyGLImpactData", "debit Should be displayed as " + debit,
				      "Account is displayed as " + debit);
				   } else {
				    failed("VerifyGLImpactData", "debit Should be displayed as " + debit,
				      "Account is not displayed as " + debit);
				   }
	    
	    if(uiDriver.checkElementPresent("//*[contains(text(),'"+credit+"')]"))
	    {
	    	passed("VerifyGLImpactData", "credit Should be displayed as " + credit,
				      "Account is displayed as " + credit);
				   } else {
				    failed("VerifyGLImpactData", "credit Should be displayed as " + credit,
				      "Account is not displayed as " + credit);
				   }
	    
	    
	    if(uiDriver.checkElementPresent("//*[contains(text(),'"+customer+"')]"))
	    {
	    	passed("VerifyGLImpactData", "customer Should be displayed as " + customer,
				      "Account is displayed as " + customer);
				   } else {
				    failed("VerifyGLImpactData", "customer Should be displayed as " + customer,
				      "Account is not displayed as " + customer);
				   }
	    
	    
	    if(uiDriver.checkElementPresent("//*[contains(text(),'"+subsidiary+"')]"))
	    {
	    	passed("VerifyGLImpactData", "subsidiary Should be displayed as " + subsidiary,
				      "Account is displayed as " + subsidiary);
				   } else {
				    failed("VerifyGLImpactData", "Account Should be displayed as " + subsidiary,
				      "Account is not displayed as " + subsidiary);
				   }
	    
	    
	    if(uiDriver.checkElementPresent("//*[contains(text(),'"+marketcode+"')]"))
	    {
	    	passed("VerifyGLImpactData", "debit Should be displayed as " + marketcode,
				      "Account is displayed as " + marketcode);
				   } else {
				    failed("VerifyGLImpactData", "Account Should be displayed as " + marketcode,
				      "Account is not displayed as " + marketcode);
				   }
	    
	    
	    if(uiDriver.checkElementPresent("//*[contains(text(),'"+territory+"')]"))
	    {
	    	passed("VerifyGLImpactData", "territory Should be displayed as " + territory,
				      "Account is displayed as " + territory);
				   } else {
				    failed("VerifyGLImpactData", "Account Should be displayed as " + territory,
				      "Account is not displayed as " + territory);
				   }
	    
	    
	    if(uiDriver.checkElementPresent("//*[contains(text(),'"+account1+"')]"))
	    {
	    	passed("VerifyGLImpactData", "account1 Should be displayed as " + account1,
				      "Account is displayed as " + account1);
				   } else {
				    failed("VerifyGLImpactData", "Account Should be displayed as " + account1,
				      "Account is not displayed as " + account1);
				   }
	    if(uiDriver.checkElementPresent("//*[contains(text(),'"+account2+"')]"))
	    {
	    	passed("VerifyGLImpactData", "account1 Should be displayed as " + account2,
				      "Account is displayed as " + account2);
				   } else {
				    failed("VerifyGLImpactData", "Account Should be displayed as " + account2,
				      "Account is not displayed as " + account2);
				   }
	    
	    
	    uiDriver.back();
	    SleepUtils.sleep(10);
	    
	    }
	    
	    
	    
	    public void VerifypayglDatascen28(DataRow input, DataRow output) {
		    SleepUtils.sleep(10);
		    String debit=input.get("DEBIT");
		    String credit=input.get("CREDIT");
		    String customer=input.get("Name");
		    String subsidiary=input.get("Subsidiary");
		   
		    String account1=input.get("ACCOUNT1");
		    String account2=input.get("ACCOUNT2");
		    
		    
		    if(uiDriver.checkElementPresent("//*[contains(text(),'"+debit+"')]"))
		    {
		    	passed("VerifyGLImpactData", "debit Should be displayed as " + debit,
					      "Account is displayed as " + debit);
					   } else {
					    failed("VerifyGLImpactData", "debit Should be displayed as " + debit,
					      "Account is not displayed as " + debit);
					   }
		    
		    if(uiDriver.checkElementPresent("//*[contains(text(),'"+credit+"')]"))
		    {
		    	passed("VerifyGLImpactData", "credit Should be displayed as " + credit,
					      "Account is displayed as " + credit);
					   } else {
					    failed("VerifyGLImpactData", "credit Should be displayed as " + credit,
					      "Account is not displayed as " + credit);
					   }
		    
		    
		    if(uiDriver.checkElementPresent("//*[contains(text(),'"+customer+"')]"))
		    {
		    	passed("VerifyGLImpactData", "customer Should be displayed as " + customer,
					      "Account is displayed as " + customer);
					   } else {
					    failed("VerifyGLImpactData", "customer Should be displayed as " + customer,
					      "Account is not displayed as " + customer);
					   }
		    
		    
		    if(uiDriver.checkElementPresent("//*[contains(text(),'"+subsidiary+"')]"))
		    {
		    	passed("VerifyGLImpactData", "subsidiary Should be displayed as " + subsidiary,
					      "Account is displayed as " + subsidiary);
					   } else {
					    failed("VerifyGLImpactData", "Account Should be displayed as " + subsidiary,
					      "Account is not displayed as " + subsidiary);
					   }
		    
		    
		    
		    
		    
		    if(uiDriver.checkElementPresent("//*[contains(text(),'"+account1+"')]"))
		    {
		    	passed("VerifyGLImpactData", "account1 Should be displayed as " + account1,
					      "Account is displayed as " + account1);
					   } else {
					    failed("VerifyGLImpactData", "Account Should be displayed as " + account1,
					      "Account is not displayed as " + account1);
					   }
		    if(uiDriver.checkElementPresent("//*[contains(text(),'"+account2+"')]"))
		    {
		    	passed("VerifyGLImpactData", "account1 Should be displayed as " + account2,
					      "Account is displayed as " + account2);
					   } else {
					    failed("VerifyGLImpactData", "Account Should be displayed as " + account2,
					      "Account is not displayed as " + account2);
					   }
		    }
		    
	    
	    
	    
	    
	    
	    public void VerifyGlAccountData(DataRow input, DataRow output) {

			 SleepUtils.sleep(TimeSlab.HIGH);

			 try {
			 String ACCOUNT = input.get("ACCOUNT");
			 String ACCOUNTS[] = ACCOUNT.split(";");

			 String DEBIT = input.get("DEBIT");
			 String DEBITS[] = DEBIT.split(";");

			 String CREDIT = input.get("CREDIT");
			 String CREDITS[] = CREDIT.split(";");

			 String Name = input.get("Name");
			 String Names[] = Name.split(";");

			 String Subsidiary = input.get("Subsidiary");
			 String Subsidiarys[] = Subsidiary.split(";");

			 String MarketCode = input.get("MarketCode");
			 String MarketCodes[] = MarketCode.split(";");

			 String Territory = input.get("Territory");
			 String Territorys[] = Territory.split(";");

			 String GLPN = input.get("GLPN");
			 String GLPNS[] = GLPN.split(";");

			 System.out.println(ACCOUNTS.length);
			 
			 String text_ExchangeNumber = input.get("ExchangeNumbe");

			 int temp = 0;

			 for (int k = 0; k < GLPNS.length; k++) {
			 
			  int NoPgaes = uiDriver.webDr.findElements(By.xpath("//*[@class='navig-prev']/preceding::a[contains(text(),'(none)')]")).size();
			 
			  for(int j=0;j<NoPgaes;j++){
			 
			 
			  if(uiDriver.checkElementPresent_dynamic("//table[@id='div__bodytab']//td[contains(text(),'" + GLPNS[k].trim() + "')]")){
			   //Do nothing
			   break;
			  }
			  else{
			   uiDriver.click("//*[@class='navig-next']");
			 
			  }
			  }
			  String xpath = "//table[@id='div__bodytab']//td[contains(text(),'" + GLPNS[k].trim() + "')]";

			  if (uiDriver.checkElementPresent("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
			    + GLPNS[k].trim().replace("NULL", " ")
			    + "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Account']//..//preceding-sibling::*)+1]")) {
			  List<WebElement> el = uiDriver.webDr
			    .findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
			      + GLPNS[k].trim().replace("NULL", " ")
			      + "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Account']//..//preceding-sibling::*)+1]"));

			  String actual_Account;

			  try {
			   actual_Account = el.get(temp).getText();
			  } catch (Exception e) {
			   temp = 0;
			   actual_Account = el.get(temp).getText();
			  }

			  String expected_Account = ACCOUNTS[k].trim();
			  if (actual_Account != null && !actual_Account.equals(" ") && !actual_Account.equals("")) {
			   if (expected_Account.toLowerCase().contains(actual_Account.toLowerCase())
			     || actual_Account.toLowerCase().contains(expected_Account.toLowerCase())) {
			    passed("VerifyGLImpactData", "Account Should be displayed as " + expected_Account,
			      "Account is displayed as " + actual_Account);
			   } else {
			    failed("VerifyGLImpactData", "Account Should be displayed as " + expected_Account,
			      "Account is not displayed as " + actual_Account);
			   }
			  } else {
			   // nothing
			  }
			  }
			     
			  if (uiDriver.checkElementPresent("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
			    + GLPNS[k].trim().replace("NULL", " ")
			    + "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Name']//..//preceding-sibling::*)-6]")) {
			   List<WebElement> el = uiDriver.webDr.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
			    + GLPNS[k].trim().replace("NULL", " ")
			    + "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Name']//..//preceding-sibling::*)-6]"));

			  String actual_Name;

			  try {
			   actual_Name = el.get(temp).getText();
			  } catch (Exception e) {
			   temp = 0;
			   actual_Name = el.get(temp).getText();
			  }

			  String expected_Name = Names[k].trim();

			  if (actual_Name != null && !actual_Name.equals(" ") && !actual_Name.equals("")) {
			   if (expected_Name.toLowerCase().contains(actual_Name.toLowerCase())
			     || actual_Name.toLowerCase().contains(expected_Name.toLowerCase())) {
			    passed("VerifyGLImpactData", "Name Should be displayed as " + expected_Name,
			      "Name is displayed as " + actual_Name);
			   } else {
			    failed("VerifyGLImpactData", "Name Should be displayed as " + expected_Name,
			      "Name should not be displayed as " + actual_Name);
			   }
			  } else {
			   // nothing
			  }
			  }

			  if (uiDriver.checkElementPresent("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
			    + GLPNS[k].trim().replace("NULL", " ")
			    + "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Subsidiary']//..//preceding-sibling::*)-5]")) {
			  List<WebElement> el = uiDriver.webDr.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
			    + GLPNS[k].trim().replace("NULL", " ")
			    + "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Subsidiary']//..//preceding-sibling::*)-5]"));

			  String actual_Subsidiary;

			  try {
			   actual_Subsidiary = el.get(temp).getText();
			  } catch (Exception e) {
			   temp = 0;
			   actual_Subsidiary = el.get(temp).getText();
			  }

			  String expected_Subsidiary = Subsidiarys[k].trim();

			  if (actual_Subsidiary != null && !actual_Subsidiary.equals(" ") && !actual_Subsidiary.equals("")) {
			   if (expected_Subsidiary.toLowerCase().contains(actual_Subsidiary.toLowerCase())
			     || actual_Subsidiary.toLowerCase().contains(expected_Subsidiary.toLowerCase())) {
			    passed("VerifyGLImpactData", "Subsidiary Should be displayed as " + expected_Subsidiary,
			      "Subsidiary is displayed as " + actual_Subsidiary);
			   } else {
			    failed("VerifyGLImpactData", "Subsidiary Should be displayed as " + expected_Subsidiary,
			      "Subsidiary should not be displayed as " + actual_Subsidiary);
			   }
			  } else {
			   // nothing
			  }
			  }
			     
			  if (uiDriver.checkElementPresent("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
			    + GLPNS[k].trim().replace("NULL", " ")
			    + "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Market Code']//..//preceding-sibling::*)-6]")) {
			   List<WebElement> el = uiDriver.webDr.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
			    + GLPNS[k].trim().replace("NULL", " ")
			    + "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Market Code']//..//preceding-sibling::*)-6]"));

			  String actual_MarketCode;

			  try {
			   actual_MarketCode = el.get(temp).getText();
			  } catch (Exception e) {
			   temp = 0;
			   actual_MarketCode = el.get(temp).getText();
			  }

			 

			  if (actual_MarketCode != null && !actual_MarketCode.equals(" ") && !actual_MarketCode.equals("")) {
			   String expected_MarketCode = MarketCodes[k].trim();
			   if (expected_MarketCode.toLowerCase().contains(actual_MarketCode.toLowerCase())
			     || actual_MarketCode.toLowerCase().contains(expected_MarketCode.toLowerCase())) {
			    passed("VerifyGLImpactData", "MarketCode Should be displayed as " + expected_MarketCode,
			      "MarketCode is displayed as " + actual_MarketCode);
			   } else {
			    failed("VerifyGLImpactData", "MarketCode Should be displayed as " + expected_MarketCode,
			      "MarketCode should not be displayed as " + actual_MarketCode);
			   }
			  } else {
			   // nothing
			  }
			  }

			  if (uiDriver.checkElementPresent("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
			    + GLPNS[k].trim().replace("NULL", " ")
			    + "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Territory']//..//preceding-sibling::*)-7]")) {
			  List<WebElement> el = uiDriver.webDr.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
			    + GLPNS[k].trim().replace("NULL", " ")
			    + "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Territory']//..//preceding-sibling::*)-7]"));

			  String actual_Territory;

			  try {
			   actual_Territory = el.get(temp).getText();
			  } catch (Exception e) {
			   temp = 0;
			   actual_Territory = el.get(temp).getText();
			  }

			  String expected_Territory = Territorys[k].trim();

			  if (actual_Territory != null && !actual_Territory.equals(" ") && !actual_Territory.equals("")) {
			   if (expected_Territory.toLowerCase().contains(actual_Territory.toLowerCase())
			     || actual_Territory.toLowerCase().contains(expected_Territory.toLowerCase())) {
			    passed("VerifyGLImpactData", "Territory Should be displayed as " + expected_Territory,
			      "Territory is displayed as " + actual_Territory);
			   } else {
			    failed("VerifyGLImpactData", "Territory Should be displayed as " + expected_Territory,
			      "Territory should not be displayed as " + actual_Territory);
			   }
			  } else {
			   // nothing
			  }
			  }
			 
			  if (uiDriver.checkElementPresent("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
			    + GLPNS[k].trim().replace("NULL", " ")
			    + "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Amount (Debit)']/../preceding-sibling::*)]")) {
			  List<WebElement> el = uiDriver.webDr.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
			    + GLPNS[k].trim().replace("NULL", " ")
			    + "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Amount (Debit)']/../preceding-sibling::*)]"));
			  String actual_Debit;
			  try {
			   actual_Debit = el.get(temp).getText();
			  } catch (Exception e) {
			   temp = 0;
			   actual_Debit = el.get(temp).getText();
			  }
			 
			 
			  if (actual_Debit != null && !actual_Debit.equals(" ") && !actual_Debit.equals("")) {
			   try {
			   String expected_Debit = DEBITS[k].trim();
			   expected_Debit = expected_Debit.replace(",", "");
			   expected_Debit = expected_Debit.replace("$", "");
			   
			   actual_Debit = actual_Debit.replace(",", "");
			   actual_Debit = actual_Debit.replace("$", "");

			   Float exp_Debit_exchanged = Float.parseFloat(expected_Debit) * Float.parseFloat(text_ExchangeNumber);
			   Float act_Debit_exchanged = Float.parseFloat(actual_Debit) * Float.parseFloat(text_ExchangeNumber);
			   exp_Debit_exchanged = (float) Math.round(exp_Debit_exchanged);
			   act_Debit_exchanged = (float) Math.round(act_Debit_exchanged);
			   
			   Float exp_Debit = Float.parseFloat(expected_Debit);
			   Float act_Debit = Float.parseFloat(actual_Debit);
			   exp_Debit = (float) Math.round(exp_Debit);
			   act_Debit = (float) Math.round(act_Debit);

			   if (exp_Debit_exchanged.toString().trim().contains(act_Debit_exchanged.toString().trim())
			     || act_Debit_exchanged.toString().trim().contains(exp_Debit_exchanged.toString().trim())
			     || exp_Debit.toString().trim().contains(act_Debit.toString().trim())
			     || act_Debit.toString().trim().contains(exp_Debit.toString().trim())
			     || exp_Debit_exchanged.toString().trim().contains(act_Debit.toString().trim())
			     || act_Debit.toString().trim().contains(exp_Debit_exchanged.toString().trim())
			     || exp_Debit.toString().trim().contains(act_Debit_exchanged.toString().trim())
			     || act_Debit_exchanged.toString().trim().contains(exp_Debit.toString().trim())) {
			    passed("VerifyGLImpactData", "Debit Amount Should be displayed as " + expected_Debit,
			      "Debit Amount is displayed as " + actual_Debit);
			   } else {
			    failed("VerifyGLImpactData", "Debit Amount Should be displayed as " + expected_Debit,
			      "Debit Amount should not be displayed as " + actual_Debit);
			   }
			   } catch (Exception e) {    
			   }
			  }
			  else {
			   // Null
			  }
			  }
			 
			  if (uiDriver.checkElementPresent("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
			    + GLPNS[k].trim().replace("NULL", " ")
			    + "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Amount (Credit)']//..//preceding-sibling::*)-1]")) {
			  List<WebElement> el = uiDriver.webDr.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
			    + GLPNS[k].trim().replace("NULL", " ")
			    + "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Amount (Credit)']//..//preceding-sibling::*)-1]"));
			  String actual_Credit;
			  try {
			   actual_Credit = el.get(temp).getText();
			  } catch (Exception e) {
			   temp = 0;
			   actual_Credit = el.get(temp).getText();
			  }
			 
			  String expected_Credit = CREDITS[k].trim();
			  if (actual_Credit != null && !actual_Credit.equals(" ") && !actual_Credit.equals("")) {
			   try {
			   expected_Credit = expected_Credit.replace(",", "");
			   expected_Credit = expected_Credit.replace("$", "");
			   
			   actual_Credit = actual_Credit.replace(",", "");
			   actual_Credit = actual_Credit.replace("$", "");

			   Float exp_Credit_exchanged = Float.parseFloat(expected_Credit) * Float.parseFloat(text_ExchangeNumber);
			   Float act_Credit_exchanged = Float.parseFloat(actual_Credit) * Float.parseFloat(text_ExchangeNumber);
			   exp_Credit_exchanged = (float) Math.round(exp_Credit_exchanged);
			   act_Credit_exchanged = (float) Math.round(act_Credit_exchanged);
			   
			   Float exp_Credit = Float.parseFloat(expected_Credit);
			   Float act_Credit = Float.parseFloat(actual_Credit);
			   exp_Credit = (float) Math.round(exp_Credit);
			   act_Credit = (float) Math.round(act_Credit);

			   if (exp_Credit_exchanged.toString().trim().contains(act_Credit_exchanged.toString().trim())
			     || act_Credit_exchanged.toString().trim().contains(exp_Credit_exchanged.toString().trim())
			     || exp_Credit.toString().trim().contains(act_Credit.toString().trim())
			     || act_Credit.toString().trim().contains(exp_Credit.toString().trim())
			     || exp_Credit_exchanged.toString().trim().contains(act_Credit.toString().trim())
			     || act_Credit.toString().trim().contains(exp_Credit_exchanged.toString().trim())
			     || exp_Credit.toString().trim().contains(act_Credit_exchanged.toString().trim())
			     || act_Credit_exchanged.toString().trim().contains(exp_Credit.toString().trim())) {
			    passed("VerifyGLImpactData", "Credit Amount Should be displayed as " + expected_Credit,
			      "Credit Amount is displayed as " + actual_Credit);
			   } else {
			    failed("VerifyGLImpactData", "Credit Amount Should be displayed as " + expected_Credit,
			      "Credit Amount should not be displayed as " + actual_Credit);
			   }
			   } catch (Exception e) {    
			   }
			  }
			  else {
			   // Null
			  }
			  }

			  List<WebElement> el = uiDriver.webDr.findElements(By.xpath(xpath));

			  if (el.size() > 1) {
			   temp++;
			  } else {
			   temp = 0;
			  }
			 
			  try {
			  SleepUtils.sleep(TimeSlab.YIELD);
			  uiDriver.mouseOver("//*[@class='navig-prev']/preceding::span[1]");
			  SleepUtils.sleep(TimeSlab.YIELD);
			  uiDriver.click("//*[@title='(none)(1)']");
			  } catch(Exception e) {    
				  //
			  }
			 
			 }//end
			 
			 
			  while (true) {
			  if (uiDriver.checkElementPresent("//h1[text()='Invoice' or text()='Payment' "
			    + "or text()='Title Allocation Parent' or text()='Revenue Arrangement' "
			    + "or text()='Customer Credit'  or text()='Credit Memo' or contains(text(),'Sales Order')]")) {
			  break;
			  } else {
			  uiDriver.back();
			  SleepUtils.sleep(TimeSlab.YIELD);
			  }
			  }

			 } catch(Exception e) {
			  
			    uiDriver.back();
			    SleepUtils.sleep(TimeSlab.YIELD);
			    }
			    
			 }

			//End of method
	    
	    public void ValidateRevenueArrangementInCC(DataRow input, DataRow output) throws InterruptedException {
	   		String contractId = input.get("conf"); // conf should pass
	   		uiDriver.setValue("//*[@id='_searchstring']", contractId);
	   		SleepUtils.sleep(TimeSlab.LOW);
	   		uiDriver.click("//a[contains(text(),'Sales Order:')]");
	   		SleepUtils.sleep(TimeSlab.MEDIUM);
	   		String SalesorderId = uiDriver.getValue("//div[@class='uir-record-id']");
	   		uiDriver.click("//a[contains(text(),'elated Records')]");
	   		SleepUtils.sleep(TimeSlab.LOW);
	   		//uiDriver.click("//*[text()='Customer Credit']/preceding-sibling::td[1]/a");
	   		//SleepUtils.sleep(TimeSlab.LOW);
	   		//uiDriver.click("//a[contains(text(),'elated Records')]");
	   		SleepUtils.sleep(TimeSlab.LOW);
	   		uiDriver.click("//td[text()='Revenue Arrangement']//..//a");
	   		SleepUtils.sleep(TimeSlab.LOW);
	   		List<WebElement> title = uiDriver.webDr.findElements(By.xpath("//*[@id='revenueelement_splits']/tbody/tr"));
	   		int titlesize = title.size();
	   		// int data = 0;
	   		for (int j = 0; j < titlesize - 1; j++) {
	   			String title1 = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)
	   					+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Title')]/../preceding-sibling::*)+1]");

	   			String AcutalTitles = input.get("AcutalTitle");
	   			String AcutalTitle[] = AcutalTitles.split(";");
	   			for (int i = 0; i < AcutalTitle.length; i++) {
	   				if (title1.contains(input.get("AcutalTitle" + i))) {

	   					String DeferralAccount = input.get("DeferralAccount");
	   					String deferralAccount[] = DeferralAccount.split(";");

	   					// for(int i=0;i<=deferralAccount.length;i++){
	   					String actual_item = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)
	   							+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Deferral Account')]/../preceding-sibling::*)+1]");
	   					String expected_item = deferralAccount[i].trim();
	   					if (actual_item.toLowerCase().trim().contains(expected_item.toLowerCase().trim())
	   							|| expected_item.toLowerCase().trim().contains(actual_item.toLowerCase().trim())) {

	   						passed("ValidateRevenueArrangement",
	   								"Deferral account should be dispalyed " + expected_item.trim(),
	   								"Deferral account is displayed" + actual_item.trim());
	   					} else {
	   						failed("ValidateRevenueArrangement ",
	   								"Deferral account should be dispalyed" + expected_item.trim(),
	   								"Deferral account is dispalyed " + actual_item.trim());
	   					}
	   					
	   					String RevenuePlanStatus = input.get("RevenuePlanStatus");
	   					String revenuePlanStatus[] = RevenuePlanStatus.split(";");

	   					String actual_status = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)
	   							+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Revenue Plan Status')]/../preceding-sibling::*)+1]");
	   					String expected_status = revenuePlanStatus[i].trim();
	   					if (actual_status.toLowerCase().trim().contains(expected_status.toLowerCase().trim())
	   							|| expected_status.toLowerCase().trim().contains(actual_status.toLowerCase().trim())) {

	   						passed("ValidateRevenueArrangement",
	   								"Revenue plan Status should be displayed " + expected_status.trim(),
	   								"Revenue plan Status is displayed" + actual_status.trim());
	   					} else {
	   						failed("ValidateRevenueArrangement ",
	   								"Revenue plan Status should be displayed" + expected_status.trim(),
	   								"Revenue plan Status is displayed" + actual_status.trim());
	   					}

	   					String RevenueStartDate = input.get("RevenueStartDate");
	   					String revenueStartDate[] = RevenueStartDate.split(";");
	   					String actual_StartDate = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr["
	   							+ (j + 2)
	   							+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Start Date')]/../preceding-sibling::*)+1]");
	   					String expected_StartDate = revenueStartDate[i].trim();
	   					if (actual_StartDate.toLowerCase().trim().contains(expected_StartDate.toLowerCase().trim())
	   							|| expected_StartDate.toLowerCase().trim().contains(actual_StartDate.toLowerCase().trim())) {

	   						passed("ValidateRevenueArrangement",
	   								"Revenue start date should be displayed " + expected_StartDate.trim(),
	   								"Revenue start date is displayed" + actual_StartDate.trim());
	   					} else {
	   						failed("ValidateRevenueArrangement ",
	   								"Revenue start date should be displayed" + expected_StartDate.trim(),
	   								"Revenue start date is displayed" + actual_StartDate.trim());
	   					}

	   					String RevenueEndDate = input.get("RevenueEndDate");
	   					String revenueEndDate[] = RevenueEndDate.split(";");
	   					String actual_EndDate = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)
	   							+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'End Date')]/../preceding-sibling::*)+1]");
	   					String expected_EndDate = revenueEndDate[i].trim();
	   					if (actual_EndDate.toLowerCase().trim().contains(expected_EndDate.toLowerCase().trim())
	   							|| expected_EndDate.toLowerCase().trim().contains(actual_EndDate.toLowerCase().trim())) {

	   						passed("ValidateRevenueArrangement",
	   								"Revenue End date should be displayed " + expected_EndDate.trim(),
	   								"Revenue End date is displayed" + actual_EndDate.trim());
	   					} else {
	   						failed("ValidateRevenueArrangement ",
	   								"Revenue End date should be displayed" + expected_EndDate.trim(),
	   								"Revenue End date is displayed" + actual_EndDate.trim());
	   					}

	   					String RevenueAmount = input.get("RevenueAmount");
	   					String revenueAmount[] = RevenueAmount.split(";");
	   					String actual_Amount = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)
	   							+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Revenue Amount')]/../preceding-sibling::*)+1]");
	   					actual_Amount = actual_Amount.replace(",", "");
	   					actual_Amount = actual_Amount.replace("$", "");
	   					
	   					String expected_Amount = revenueAmount[i].trim();
	   					expected_Amount = expected_Amount.replace(",", "");
	   					expected_Amount = expected_Amount.replace("$", "");
	   					
	   					Float exp_Amount = Float.parseFloat(expected_Amount);
	   					Float act_Amount = Float.parseFloat(actual_Amount);
	   					exp_Amount = (float) Math.round(exp_Amount);
	   					act_Amount = (float) Math.round(act_Amount);
	   							
	   					Float act_Amount_exchanged = Float.parseFloat(actual_Amount)*Float.parseFloat(text_ExchangeNumber);				
	   					Float exp_Amount_exchanged = Float.parseFloat(expected_Amount)*Float.parseFloat(text_ExchangeNumber);
	   					exp_Amount_exchanged = (float) Math.round(exp_Amount_exchanged);
	   					act_Amount_exchanged = (float) Math.round(act_Amount_exchanged);
	   					
	   					if (exp_Amount_exchanged.toString().trim().contains(act_Amount_exchanged.toString().trim()) 
	   							|| act_Amount_exchanged.toString().trim().contains(exp_Amount_exchanged.toString().trim())
	   							|| exp_Amount.toString().trim().contains(act_Amount.toString().trim()) 
	   							|| act_Amount.toString().trim().contains(exp_Amount.toString().trim())
	   							|| exp_Amount_exchanged.toString().trim().contains(act_Amount.toString().trim())
	   							|| act_Amount.toString().trim().contains(exp_Amount_exchanged.toString().trim())
	   							|| exp_Amount.toString().trim().contains(act_Amount_exchanged.toString().trim())
	   							|| act_Amount_exchanged.toString().trim().contains(exp_Amount.toString().trim())) {
	   						passed("ValidateRevenueArrangement",
	   								"Revenue Amount should be displayed " + expected_Amount.trim(),
	   								"Revenue Amount is displayed" + actual_Amount.trim());
	   					} else {
	   						failed("ValidateRevenueArrangement ",
	   								"Revenue Amount should be displayed" + expected_Amount.trim(),
	   								"Revenue Amount is displayed" + actual_Amount.trim());
	   					}
	   					
	   					SleepUtils.sleep(TimeSlab.LOW);
	   					WebElement element = uiDriver.webDr
	   							.findElement(By.xpath("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)
	   									+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Revenue Recognition Plan')]/../preceding-sibling::*)+1]//a"));
	   					((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView();", element);
	   					((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();",element);
//	   					// element.click();*/
//	   					SleepUtils.sleep(TimeSlab.HIGH);
//	   					// uiDriver.ScrollPageUp();
//	   					SleepUtils.sleep(TimeSlab.LOW);
//	   					uiDriver.click("//*[@id='revenueelement_splits']/tbody/tr[" + (j + 2) + "]/td[15]/a/img");
	   					SleepUtils.sleep(TimeSlab.HIGH);
	   					uiDriver.setFrame("//iframe[@name='updaterevenuerecognitionplans_frame']");
	   					SleepUtils.sleep(TimeSlab.LOW);
	   					uiDriver.click("//*[text()='Actual']/..//td[3]//a");
	   					SleepUtils.sleep(TimeSlab.HIGH);

	   					String PlannedPeriod = input.get("PlannedPeriod");
	   					String plannedPeriod[] = PlannedPeriod.split(";");
	   					String actual_PlannedPeriod = uiDriver
	   							.getValue("//*[@id='plannedrevenue_splits']/tbody/tr[2]/td[1]");
	   					String expected_PlannedPeriod = plannedPeriod[i].trim();

	   					if (actual_PlannedPeriod.toLowerCase().trim().contains(expected_PlannedPeriod.toLowerCase().trim()) 
	   							|| expected_PlannedPeriod.toLowerCase().trim().contains(actual_PlannedPeriod.toLowerCase().trim())) {

	   						passed("ValidateRevenueArrangement",
	   								"Planing Period should be displayed " + expected_PlannedPeriod.trim(),
	   								"Planing Period is displayed" + actual_PlannedPeriod.trim());
	   					} else {
	   						failed("ValidateRevenueArrangement ",
	   								"PlannedPeriod should be displayed" + expected_PlannedPeriod.trim(),
	   								"PlannedPeriod is displayed" + actual_PlannedPeriod.trim());
	   					}
	   					
	   					// uiDriver.click("//div[@id='innerwrapper']//*[@id='secondary_back']");
	   					try {
							((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView();",
									uiDriver.webDr.findElement(By.xpath("//div[@id='innerwrapper']//*[@id='secondary_back']")));
							((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();",
									uiDriver.webDr.findElement(By.xpath("//div[@id='innerwrapper']//*[@id='secondary_back']")));
							SleepUtils.sleep(TimeSlab.MEDIUM);
							((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView();",
									uiDriver.webDr.findElement(By.xpath("//td[@id='tdbody_secondary_cancel']//input")));
							((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();",
									uiDriver.webDr.findElement(By.xpath("//td[@id='tdbody_secondary_cancel']//input")));
							SleepUtils.sleep(TimeSlab.LOW);
							uiDriver.resetFrame();
		 				} catch(Exception e) { 
		 					uiDriver.resetFrame();
		 				}

	   				}

	   				// data++;
	   			}
	   		}
	   	}
	   	

	    public void ValidateRevenueArrangement(DataRow input, DataRow output) throws InterruptedException {
	 		String contractId = input.get("conf"); // conf should pass
	 		uiDriver.setValue("//*[@id='_searchstring']", contractId);
	 		uiDriver.click("//a[contains(text(),'Sales Order:')]");
	 		SleepUtils.sleep(TimeSlab.MEDIUM);
	 		String SalesorderId = uiDriver.getValue("//div[@class='uir-record-id']");
	 		if (contractId.equals(SalesorderId)) {
	 			passed("ValidateRevenueArrangement", "SalesOrderId should be displayed successfully" + contractId,
	 					"SalesOrderId is displayed successfully" + SalesorderId);
	 		} else {
	 			failed("ValidateRevenueArrangement ", "SalesOrderId should be validated successfully" + contractId,
	 					"SalesOrderId is not  displayed" + SalesorderId);
	 		}

	 		uiDriver.click("//a[contains(text(),'elated Records')]");
	 		SleepUtils.sleep(TimeSlab.LOW);
	 		uiDriver.click("//td[text()='Revenue Arrangement']//..//a");
	 		SleepUtils.sleep(TimeSlab.LOW);
	 		List<WebElement> title = uiDriver.webDr.findElements(By.xpath("//*[@id='revenueelement_splits']/tbody/tr"));
	 		int titlesize = title.size();
	 		// int data = 0;
	 		for (int j = 0; j < titlesize - 1; j++) {
	 			String title1 = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)
	 					+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Title')]/../preceding-sibling::*)+1]");

	 			String AcutalTitles = input.get("AcutalTitle");
	 			String AcutalTitle[] = AcutalTitles.split(";");
	 			for (int i = 0; i < AcutalTitle.length; i++) {
	 				if (title1.contains(input.get("AcutalTitle" + i))) {

	 					String DeferralAccount = input.get("DeferralAccount");
	 					String deferralAccount[] = DeferralAccount.split(";");

	 					// for(int i=0;i<=deferralAccount.length;i++){
	 					String actual_item = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)
	 							+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Deferral Account')]/../preceding-sibling::*)+1]");
	 					String expected_item = deferralAccount[i].trim();
	 					if (actual_item.toLowerCase().trim().contains(expected_item.toLowerCase().trim())
	 							|| expected_item.toLowerCase().trim().contains(actual_item.toLowerCase().trim())) {

	 						passed("ValidateRevenueArrangement",
	 								"Deferral account should be dispalyed " + expected_item.trim(),
	 								"Deferral account is displayed" + actual_item.trim());
	 					} else {
	 						failed("ValidateRevenueArrangement ",
	 								"Deferral account should be dispalyed" + expected_item.trim(),
	 								"Deferral account is dispalyed " + actual_item.trim());
	 					}

	 					String RevenuePlanStatus = input.get("RevenuePlanStatus");
	 					String revenuePlanStatus[] = RevenuePlanStatus.split(";");

	 					String actual_status = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)
	 							+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Revenue Plan Status')]/../preceding-sibling::*)+1]");
	 					String expected_status = revenuePlanStatus[i].trim();
	 					if (actual_status.toLowerCase().trim().contains(expected_status.toLowerCase().trim())
	 							|| expected_status.toLowerCase().trim().contains(actual_status.toLowerCase().trim())) {

	 						passed("ValidateRevenueArrangement",
	 								"Revenue plan Status should be displayed " + expected_status.trim(),
	 								"Revenue plan Status is displayed" + actual_status.trim());
	 					} else {
	 						failed("ValidateRevenueArrangement ",
	 								"Revenue plan Status should be displayed" + expected_status.trim(),
	 								"Revenue plan Status is displayed" + actual_status.trim());
	 					}

	 					String RevenueStartDate = input.get("RevenueStartDate");
	 					String revenueStartDate[] = RevenueStartDate.split(";");
	 					String actual_StartDate = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr["
	 							+ (j + 2)
	 							+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Start Date')]/../preceding-sibling::*)+1]");
	 					String expected_StartDate = revenueStartDate[i].trim();
	 					if (actual_StartDate.toLowerCase().trim().contains(expected_StartDate.toLowerCase().trim())
	 							|| expected_StartDate.toLowerCase().trim()
	 									.contains(actual_StartDate.toLowerCase().trim())) {

	 						passed("ValidateRevenueArrangement",
	 								"Revenue start date should be displayed " + expected_StartDate.trim(),
	 								"Revenue start date is displayed" + actual_StartDate.trim());
	 					} else {
	 						failed("ValidateRevenueArrangement ",
	 								"Revenue start date should be displayed" + expected_StartDate.trim(),
	 								"Revenue start date is displayed" + actual_StartDate.trim());
	 					}

	 					String RevenueEndDate = input.get("RevenueEndDate");
	 					String revenueEndDate[] = RevenueEndDate.split(";");
	 					String actual_EndDate = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)
	 							+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'End Date')]/../preceding-sibling::*)+1]");
	 					String expected_EndDate = revenueEndDate[i].trim();
	 					if (actual_EndDate.toLowerCase().trim().contains(expected_EndDate.toLowerCase().trim())
	 							|| expected_EndDate.toLowerCase().trim().contains(actual_EndDate.toLowerCase().trim())) {

	 						passed("ValidateRevenueArrangement",
	 								"Revenue End date should be displayed " + expected_EndDate.trim(),
	 								"Revenue End date is displayed" + actual_EndDate.trim());
	 					} else {
	 						failed("ValidateRevenueArrangement ",
	 								"Revenue End date should be displayed" + expected_EndDate.trim(),
	 								"Revenue End date is displayed" + actual_EndDate.trim());
	 					}

	 					String RevenueAmount = input.get("RevenueAmount");
	 					String revenueAmount[] = RevenueAmount.split(";");
	 					String actual_Amount = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)
	 							+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Revenue Amount')]/../preceding-sibling::*)+1]");
	 					actual_Amount = actual_Amount.replace(",", "");
	 					actual_Amount = actual_Amount.replace("$", "");

	 					String expected_Amount = revenueAmount[i].trim();
	 					expected_Amount = expected_Amount.replace(",", "");
	 					expected_Amount = expected_Amount.replace("$", "");

	 					Float exp_Amount = Float.parseFloat(expected_Amount);
	 					Float act_Amount = Float.parseFloat(actual_Amount);
	 					exp_Amount = (float) Math.round(exp_Amount);
	 					act_Amount = (float) Math.round(act_Amount);

	 					Float act_Amount_exchanged = Float.parseFloat(actual_Amount)
	 							* Float.parseFloat(text_ExchangeNumber);
	 					Float exp_Amount_exchanged = Float.parseFloat(expected_Amount)
	 							* Float.parseFloat(text_ExchangeNumber);
	 					exp_Amount_exchanged = (float) Math.round(exp_Amount_exchanged);
	 					act_Amount_exchanged = (float) Math.round(act_Amount_exchanged);

	 					if (exp_Amount_exchanged.toString().trim().contains(act_Amount_exchanged.toString().trim())
	 							|| act_Amount_exchanged.toString().trim().contains(exp_Amount_exchanged.toString().trim())
	 							|| exp_Amount.toString().trim().contains(act_Amount.toString().trim())
	 							|| act_Amount.toString().trim().contains(exp_Amount.toString().trim())
	 							|| exp_Amount_exchanged.toString().trim().contains(act_Amount.toString().trim())
	 							|| act_Amount.toString().trim().contains(exp_Amount_exchanged.toString().trim())
	 							|| exp_Amount.toString().trim().contains(act_Amount_exchanged.toString().trim())
	 							|| act_Amount_exchanged.toString().trim().contains(exp_Amount.toString().trim())) {
	 						passed("ValidateRevenueArrangement",
	 								"Revenue Amount should be displayed " + expected_Amount.trim(),
	 								"Revenue Amount is displayed" + actual_Amount.trim());
	 					} else {
	 						failed("ValidateRevenueArrangement ",
	 								"Revenue Amount should be displayed" + expected_Amount.trim(),
	 								"Revenue Amount is displayed" + actual_Amount.trim());
	 					}

	 					SleepUtils.sleep(TimeSlab.LOW);
	 					WebElement element = uiDriver.webDr
	 							.findElement(By.xpath("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)
	 									+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Revenue Recognition Plan')]/../preceding-sibling::*)+1]//a"));
	 					((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView();", element);
	 					((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();", element);
	 					// // element.click();*/
	 					// SleepUtils.sleep(TimeSlab.HIGH);
	 					// // uiDriver.ScrollPageUp();
	 					// SleepUtils.sleep(TimeSlab.LOW);
	 					// uiDriver.click("//*[@id='revenueelement_splits']/tbody/tr["
	 					// + (j + 2) + "]/td[15]/a/img");
	 					SleepUtils.sleep(TimeSlab.HIGH);
	 					uiDriver.setFrame("//iframe[@name='updaterevenuerecognitionplans_frame']");
	 					SleepUtils.sleep(TimeSlab.LOW);
	 					element = uiDriver.webDr
	 							.findElement(By.xpath("//*[text()='Actual']/..//td[3]//a"));
//	 					uiDriver.click("//*[text()='Actual']/..//td[3]//a");
	 					((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();", element);
	 					SleepUtils.sleep(TimeSlab.HIGH);

	 					String PlannedPeriod = input.get("PlannedPeriod");
	 					String plannedPeriod[] = PlannedPeriod.split(";");
	 					String actual_PlannedPeriod = uiDriver
	 							.getValue("//*[@id='plannedrevenue_splits']/tbody/tr[2]/td[1]");
	 					String expected_PlannedPeriod = plannedPeriod[i].trim();

	 					if (actual_PlannedPeriod.toLowerCase().trim().contains(expected_PlannedPeriod.toLowerCase().trim())
	 							|| expected_PlannedPeriod.toLowerCase().trim()
	 									.contains(actual_PlannedPeriod.toLowerCase().trim())) {

	 						passed("ValidateRevenueArrangement",
	 								"Planing Period should be displayed " + expected_PlannedPeriod.trim(),
	 								"Planing Period is displayed" + actual_PlannedPeriod.trim());
	 					} else {
	 						failed("ValidateRevenueArrangement ",
	 								"PlannedPeriod should be displayed" + expected_PlannedPeriod.trim(),
	 								"PlannedPeriod is displayed" + actual_PlannedPeriod.trim());
	 					}

	 				try {
						((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView();",
								uiDriver.webDr.findElement(By.xpath("//div[@id='innerwrapper']//*[@id='secondary_back']")));
						((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();",
								uiDriver.webDr.findElement(By.xpath("//div[@id='innerwrapper']//*[@id='secondary_back']")));
						SleepUtils.sleep(TimeSlab.MEDIUM);
						((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView();",
								uiDriver.webDr.findElement(By.xpath("//td[@id='tdbody_secondary_cancel']//input")));
						((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();",
								uiDriver.webDr.findElement(By.xpath("//td[@id='tdbody_secondary_cancel']//input")));
						SleepUtils.sleep(TimeSlab.LOW);
						uiDriver.resetFrame();
	 				} catch(Exception e) {
	 				}
	 				}

	 				// data++;
	 			}
	 		}
	 	}
	    public void ValidateRevenueArrangement28(DataRow input, DataRow output) throws InterruptedException {
	 		String contractId = input.get("conf"); // conf should pass
	 		uiDriver.setValue("//*[@id='_searchstring']", contractId);
	 		uiDriver.click("//a[contains(text(),'Sales Order:')]");
	 		SleepUtils.sleep(TimeSlab.MEDIUM);
	 		String SalesorderId = uiDriver.getValue("//div[@class='uir-record-id']");
	 		if (contractId.equals(SalesorderId)) {
	 			passed("ValidateRevenueArrangement", "SalesOrderId should be displayed successfully" + contractId,
	 					"SalesOrderId is displayed successfully" + SalesorderId);
	 		} else {
	 			failed("ValidateRevenueArrangement ", "SalesOrderId should be validated successfully" + contractId,
	 					"SalesOrderId is not  displayed" + SalesorderId);
	 		}

	 		uiDriver.click("//a[contains(text(),'elated Records')]");
	 		SleepUtils.sleep(TimeSlab.LOW);
	 		uiDriver.click("//td[text()='Revenue Arrangement']//..//a");
	 		SleepUtils.sleep(TimeSlab.LOW); 
	 		List<WebElement> title = uiDriver.webDr.findElements(By.xpath("//*[@id='revenueelement_splits']/tbody/tr"));
	 		int titlesize = title.size();
	 		 int data = 0;
	 		for (int j = 0; j < titlesize - 1; j++) {
	 			if(data>0){
	 				break;
	 			}
	 			String title1 = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)
	 					+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Title')]/../preceding-sibling::*)+1]");

	 			String AcutalTitles = input.get("AcutalTitle");
	 			String AcutalTitle[] = AcutalTitles.split(";");
	 			for (int i = 0; i < AcutalTitle.length; i++) {
	 				if (title1.contains(input.get("AcutalTitle" + i))) {
data = data+1;

	 					String DeferralAccount = input.get("DeferralAccount");
	 					String deferralAccount[] = DeferralAccount.split(";");

	 					// for(int i=0;i<=deferralAccount.length;i++){
	 					String actual_item = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)
	 							+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Deferral Account')]/../preceding-sibling::*)+1]");
	 					String expected_item = deferralAccount[i].trim();
	 					if (actual_item.toLowerCase().trim().contains(expected_item.toLowerCase().trim())
	 							|| expected_item.toLowerCase().trim().contains(actual_item.toLowerCase().trim())) {

	 						passed("ValidateRevenueArrangement",
	 								"Deferral account should be dispalyed " + expected_item.trim(),
	 								"Deferral account is displayed" + actual_item.trim());
	 					} else {
	 						failed("ValidateRevenueArrangement ",
	 								"Deferral account should be dispalyed" + expected_item.trim(),
	 								"Deferral account is dispalyed " + actual_item.trim());
	 					}

	 					String RevenuePlanStatus = input.get("RevenuePlanStatus");
	 					String revenuePlanStatus[] = RevenuePlanStatus.split(";");

	 					String actual_status = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)
	 							+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Revenue Plan Status')]/../preceding-sibling::*)+1]");
	 					String expected_status = revenuePlanStatus[i].trim();
	 					if (actual_status.toLowerCase().trim().contains(expected_status.toLowerCase().trim())
	 							|| expected_status.toLowerCase().trim().contains(actual_status.toLowerCase().trim())) {

	 						passed("ValidateRevenueArrangement",
	 								"Revenue plan Status should be displayed " + expected_status.trim(),
	 								"Revenue plan Status is displayed" + actual_status.trim());
	 					} else {
	 						failed("ValidateRevenueArrangement ",
	 								"Revenue plan Status should be displayed" + expected_status.trim(),
	 								"Revenue plan Status is displayed" + actual_status.trim());
	 					}

	 					String RevenueStartDate = input.get("RevenueStartDate");
	 					String revenueStartDate[] = RevenueStartDate.split(";");
	 					String actual_StartDate = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr["
	 							+ (j + 2)
	 							+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Start Date')]/../preceding-sibling::*)+1]");
	 					String expected_StartDate = revenueStartDate[i].trim();
	 					if (actual_StartDate.toLowerCase().trim().contains(expected_StartDate.toLowerCase().trim())
	 							|| expected_StartDate.toLowerCase().trim()
	 									.contains(actual_StartDate.toLowerCase().trim())) {

	 						passed("ValidateRevenueArrangement",
	 								"Revenue start date should be displayed " + expected_StartDate.trim(),
	 								"Revenue start date is displayed" + actual_StartDate.trim());
	 					} else {
	 						failed("ValidateRevenueArrangement ",
	 								"Revenue start date should be displayed" + expected_StartDate.trim(),
	 								"Revenue start date is displayed" + actual_StartDate.trim());
	 					}

	 					String RevenueEndDate = input.get("RevenueEndDate");
	 					String revenueEndDate[] = RevenueEndDate.split(";");
	 					String actual_EndDate = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)
	 							+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'End Date')]/../preceding-sibling::*)+1]");
	 					String expected_EndDate = revenueEndDate[i].trim();
	 					if (actual_EndDate.toLowerCase().trim().contains(expected_EndDate.toLowerCase().trim())
	 							|| expected_EndDate.toLowerCase().trim().contains(actual_EndDate.toLowerCase().trim())) {

	 						passed("ValidateRevenueArrangement",
	 								"Revenue End date should be displayed " + expected_EndDate.trim(),
	 								"Revenue End date is displayed" + actual_EndDate.trim());
	 					} else {
	 						failed("ValidateRevenueArrangement ",
	 								"Revenue End date should be displayed" + expected_EndDate.trim(),
	 								"Revenue End date is displayed" + actual_EndDate.trim());
	 					}

	 					String RevenueAmount = input.get("RevenueAmount");
	 					String revenueAmount[] = RevenueAmount.split(";");
	 					String actual_Amount = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)
	 							+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Revenue Amount')]/../preceding-sibling::*)+1]");
	 					actual_Amount = actual_Amount.replace(",", "");
	 					actual_Amount = actual_Amount.replace("$", "");

	 					String expected_Amount = revenueAmount[i].trim();
	 					expected_Amount = expected_Amount.replace(",", "");
	 					expected_Amount = expected_Amount.replace("$", "");

	 					Float exp_Amount = Float.parseFloat(expected_Amount);
	 					Float act_Amount = Float.parseFloat(actual_Amount);
	 					exp_Amount = (float) Math.round(exp_Amount);
	 					act_Amount = (float) Math.round(act_Amount);

	 					Float act_Amount_exchanged = Float.parseFloat(actual_Amount)
	 							* Float.parseFloat(text_ExchangeNumber);
	 					Float exp_Amount_exchanged = Float.parseFloat(expected_Amount)
	 							* Float.parseFloat(text_ExchangeNumber);
	 					exp_Amount_exchanged = (float) Math.round(exp_Amount_exchanged);
	 					act_Amount_exchanged = (float) Math.round(act_Amount_exchanged);

	 					if (exp_Amount_exchanged.toString().trim().contains(act_Amount_exchanged.toString().trim())
	 							|| act_Amount_exchanged.toString().trim().contains(exp_Amount_exchanged.toString().trim())
	 							|| exp_Amount.toString().trim().contains(act_Amount.toString().trim())
	 							|| act_Amount.toString().trim().contains(exp_Amount.toString().trim())
	 							|| exp_Amount_exchanged.toString().trim().contains(act_Amount.toString().trim())
	 							|| act_Amount.toString().trim().contains(exp_Amount_exchanged.toString().trim())
	 							|| exp_Amount.toString().trim().contains(act_Amount_exchanged.toString().trim())
	 							|| act_Amount_exchanged.toString().trim().contains(exp_Amount.toString().trim())) {
	 						passed("ValidateRevenueArrangement",
	 								"Revenue Amount should be displayed " + expected_Amount.trim(),
	 								"Revenue Amount is displayed" + actual_Amount.trim());
	 					} else {
	 						failed("ValidateRevenueArrangement ",
	 								"Revenue Amount should be displayed" + expected_Amount.trim(),
	 								"Revenue Amount is displayed" + actual_Amount.trim());
	 					}

	 					SleepUtils.sleep(TimeSlab.LOW);
	 					WebElement element = uiDriver.webDr
	 							.findElement(By.xpath("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)
	 									+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Revenue Recognition Plan')]/../preceding-sibling::*)+1]//a"));
	 					((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView();", element);
	 					((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();", element);
	 					// // element.click();*/
	 					// SleepUtils.sleep(TimeSlab.HIGH);
	 					// // uiDriver.ScrollPageUp();
	 					// SleepUtils.sleep(TimeSlab.LOW);
	 					// uiDriver.click("//*[@id='revenueelement_splits']/tbody/tr["
	 					// + (j + 2) + "]/td[15]/a/img");
	 					SleepUtils.sleep(TimeSlab.HIGH);
	 					uiDriver.setFrame("//iframe[@name='updaterevenuerecognitionplans_frame']");
	 					SleepUtils.sleep(TimeSlab.LOW);
	 					element = uiDriver.webDr
	 							.findElement(By.xpath("//*[text()='Actual']/..//td[3]//a"));
//	 					uiDriver.click("//*[text()='Actual']/..//td[3]//a");
	 					((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();", element);
	 					SleepUtils.sleep(TimeSlab.HIGH);

	 					String PlannedPeriod = input.get("PlannedPeriod");
	 					String plannedPeriod[] = PlannedPeriod.split(";");
	 					String actual_PlannedPeriod = uiDriver
	 							.getValue("//*[@id='plannedrevenue_splits']/tbody/tr[2]/td[1]");
	 					String expected_PlannedPeriod = plannedPeriod[i].trim();

	 					if (actual_PlannedPeriod.toLowerCase().trim().contains(expected_PlannedPeriod.toLowerCase().trim())
	 							|| expected_PlannedPeriod.toLowerCase().trim()
	 									.contains(actual_PlannedPeriod.toLowerCase().trim())) {

	 						passed("ValidateRevenueArrangement",
	 								"Planing Period should be displayed " + expected_PlannedPeriod.trim(),
	 								"Planing Period is displayed" + actual_PlannedPeriod.trim());
	 					} else {
	 						failed("ValidateRevenueArrangement ",
	 								"PlannedPeriod should be displayed" + expected_PlannedPeriod.trim(),
	 								"PlannedPeriod is displayed" + actual_PlannedPeriod.trim());
	 					}

	 				try {
						((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView();",
								uiDriver.webDr.findElement(By.xpath("//div[@id='innerwrapper']//*[@id='secondary_back']")));
						((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();",
								uiDriver.webDr.findElement(By.xpath("//div[@id='innerwrapper']//*[@id='secondary_back']")));
						SleepUtils.sleep(TimeSlab.MEDIUM);
						((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView();",
								uiDriver.webDr.findElement(By.xpath("//td[@id='tdbody_secondary_cancel']//input")));
						((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();",
								uiDriver.webDr.findElement(By.xpath("//td[@id='tdbody_secondary_cancel']//input")));
						SleepUtils.sleep(TimeSlab.LOW);
						uiDriver.resetFrame();
						break;
	 				} catch(Exception e) {
	 				}
	 				}
	 				break;
	 				// data++;
	 			}
	 			
	 		}
	 	}

}
	

