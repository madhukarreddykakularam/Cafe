package moduledrivers;

import static cbf.engine.TestResultLogger.*;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import cbf.utils.DataRow;
import cbf.utils.SleepUtils;
import cbf.utils.SleepUtils.TimeSlab;
import cbfx.basedrivers.BaseWebModuleDriver;

public class UpdatedMethods extends BaseWebModuleDriver {

	String text_ExchangeNumber;

	public void ValidatethefieldsinFT(DataRow input, DataRow output) {

		String contractid = uiDriver
				.getValue("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_ContractCodeEdit']");

		String dealtype = uiDriver.getValue(
				"//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_ContractDealTypeEdit_Input']");

		String licensor = uiDriver
				.getValue("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_LicensorEdit_Input']");

		String licensee = uiDriver
				.getValue("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_LicenseeEdit_Input']");

		String amount = uiDriver.getValue("//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_GrossEdit']");

		String currency = uiDriver.getValue(
				"//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_CurrencyEdit_CurrencyEdit_Input']");

		String Rights = uiDriver.getValue(
				"//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentHeader_ContractSummaryHeader1_ContractGrantRightsValue']");

		String Titlestatus = uiDriver.getValue(
				"//*[@id='ctl00_ctl00_ctl00_contentBody_contentBody_contentBody_ContractCardSummary1_ContractCardSummaryGrid_ctl00']//tr[1]/td[7]");

		if (contractid.toLowerCase().trim().contains(input.get("contract").toLowerCase().trim())
				|| input.get("contract").toLowerCase().trim().contains(contractid.toLowerCase().trim())) {
			passed("Verifying the  Contractid",
					"Contract id Status should be displayed as " + input.get("contract") + "'",
					"Contract id Status is displayed as " + contractid + "'");
		} else {
			failed("Verifying the  Contractid",
					"Contract id Status should be displayed as " + input.get("contract") + "'",
					"Contract id Status is not displayed as " + contractid + "'");
		}

		if (dealtype.toLowerCase().trim().contains(input.get("dealtype").toLowerCase().trim())
				|| input.get("dealtype").toLowerCase().trim().contains(dealtype.toLowerCase().trim())) {
			passed("Verifying the  dealtype", "dealtype should be displayed as " + input.get("dealtype") + "'",
					"dealtype is displayed as " + dealtype + "'");
		} else {
			failed("Verifying the  dealtype", "dealtype should be displayed as " + input.get("dealtype") + "'",
					"dealtype is displayed as " + dealtype + "'");
		}

		if (licensor.toLowerCase().trim().contains(input.get("licensor").toLowerCase().trim())
				|| input.get("licensor").toLowerCase().trim().contains(licensor.toLowerCase().trim())) {
			passed("Verifying the  licensee", "licensor should be displayed as " + input.get("licensor") + "'",
					"licensor is displayed as " + licensor + "'");
		} else {
			failed("Verifying the  licensee", "licensor should be displayed as " + input.get("licensor") + "'",
					"licensor is displayed as " + licensor + "'");
		}

		if (licensee.toLowerCase().trim().contains(input.get("licensee").toLowerCase().trim())
				|| input.get("licensee").toLowerCase().trim().contains(licensee.toLowerCase().trim())) {
			passed("Verifying the  licensee", "licensee should be displayed as " + input.get("licensee") + "'",
					"licensee is displayed as " + licensee + "'");
		} else {
			failed("Verifying the  licensee", "licensee should be displayed as " + input.get("licensee") + "'",
					"licensee is displayed as " + licensee + "'");
		}

		if (amount.toLowerCase().trim().contains(input.get("amount").toLowerCase().trim())
				|| input.get("amount").toLowerCase().trim().contains(amount.toLowerCase().trim())) {
			passed("Verifying the  amount", "amount should be displayed as " + input.get("amount") + "'",
					"amount is displayed as " + amount + "'");
		} else {
			failed("Verifying the  amount", "amount Status should be displayed as " + input.get("amount") + "'",
					"amount Status is displayed as " + amount + "'");
		}

		if (currency.toLowerCase().trim().contains(input.get("currency").toLowerCase().trim())
				|| input.get("currency").toLowerCase().trim().contains(currency.toLowerCase().trim())) {
			passed("Verifying the  currency", "currency should be displayed as " + input.get("currency") + "'",
					"currency is displayed as " + currency + "'");
		} else {
			failed("Verifying the  currency", "currency should be displayed as " + input.get("currency") + "'",
					"currency is displayed as " + currency + "'");
		}

		if (Rights.toLowerCase().trim().contains(input.get("Rights").toLowerCase().trim())
				|| input.get("Rights").toLowerCase().trim().contains(Rights.toLowerCase().trim())) {
			passed("Verifying the  Rights", "Rights should be displayed as " + input.get("Rights") + "'",
					"Rights is displayed as " + Rights + "'");
		} else {
			failed("Verifying the  Rights", "Rights should be displayed as " + input.get("Rights") + "'",
					"Rights is displayed as " + Rights + "'");
		}

		if (Titlestatus.toLowerCase().trim().contains(input.get("Titlestatus").toLowerCase().trim())
				|| input.get("Titlestatus").toLowerCase().trim().contains(Titlestatus.toLowerCase().trim())) {
			passed("Verifying the  Titlestatus", "Titlestatus should be displayed as " + input.get("Titlestatus") + "'",
					"Titlestatus is displayed as " + Titlestatus + "'");
		} else {
			failed("Verifying the  Titlestatus", "Titlestatus should be displayed as " + input.get("Titlestatus") + "'",
					"Titlestatus is displayed as " + Titlestatus + "'");
		}
	}

	public void NavigateToRevisedInvoice(DataRow input, DataRow output) throws InterruptedException {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("//input[@id='_searchstring']", input.get("conf"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//a[contains(text(),'Sales Order:')]");
		SleepUtils.sleep(TimeSlab.LOW);
		if (uiDriver.checkElementPresent("//h1[text()='Sales Order']")) {
			passed("getExchangeNumber", "Sales Order Should be displayed", "Sales Order is displayed");
		} else {
			failed("getExchangeNumber", "Sales Order Should be displayed", "Sales Order is not displayed");
		}

		uiDriver.click("//a[@id='accntingtabtxt']");
		SleepUtils.sleep(TimeSlab.LOW);
		String ExchangeNumber = uiDriver.getValue("//span[@id='exchangerate_fs_lbl']//..//following-sibling::span");

		if (ExchangeNumber == null) {
			failed("getExchangeNumber", "Exchange Number should be stored successfully",
					"Exchange Number is not stored successfully");
		} else {
			passed("getExchangeNumber", "Exchange Number should be stored successfully",
					"Exchange Number is stored successfully as : " + ExchangeNumber);
		}

		uiDriver.click("//a[@id='itemstxt']");
		SleepUtils.sleep(TimeSlab.LOW);

		SleepUtils.sleep(TimeSlab.MEDIUM);
		String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully", "SalesOrder is displayed Successfully");
		SleepUtils.sleep(5);
		uiDriver.refresh();
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("relatedRecord");
		String invoice = uiDriver.getDyanmicData("invoice");

		System.out.println("--START--");

		String InvAmount = input.get("amount");
		String Exchange = ExchangeNumber;

		InvAmount = InvAmount.replace(",", "");
		Exchange = Exchange.replace(",", "");

		Float temp1 = Float.parseFloat(InvAmount);
		Float temp2 = Float.parseFloat(Exchange);

		Float temp3 = temp1 * temp2;
		String temp4 = temp3.toString();

		int end = temp4.indexOf(".");
		String temp5 = temp4.substring(0, end);
		// String temp5 = "4595029";
		System.out.println(temp5);

		int length = temp5.length();

		ArrayList<String> t1 = new ArrayList<String>();
		for (int i = (length - 1); i >= 0; i--) {
			String t2 = temp5.substring(i, i + 1);
			t1.add(t2);
		}
		System.out.println(t1);
		System.out.println(t1.size());

		String finalAmount = "";
		for (int i = 0; i < t1.size(); i++) {
			finalAmount = t1.get(i) + finalAmount;

			if (i != t1.size() - 1) {
				if (i % 3 == 2) {
					finalAmount = "," + finalAmount;
				}
			}
		}
		System.out.println(finalAmount);
		System.out.println("--END--");

		String invoice1 = invoice.replace("#", finalAmount);
		uiDriver.click_dynamic(invoice1);

		// uiDriver.click("invoiceNo");
		passed("InvoiceNo", "InvoiceNo Should be Clicked Successfully", "InvoiceNo is Clicked Successfully");
		String invoicenumber = uiDriver.getValue("Invoicenum");
		output.put("InvoiceNum", invoicenumber);
		String Masterinvoice = invoicenumber.substring(0, invoicenumber.length() - 1);
		output.put("MasterInvoice", Masterinvoice);
	}

	public void ValidateTheFieldsInNetSuite(DataRow input, DataRow output) {
		String tableRows = uiDriver.getObjMap("tableRows");

		uiDriver.executeJavaScript("scroll(0,500)");
		/* *********Uncomment for scenario 9**** */
		/*
		 * String actualMARKETCODE = uiDriver.getValue(tableRows + nextRow +
		 * uiDriver.getObjMap("marketcode")); String actualItemType =
		 * uiDriver.getValue(tableRows + nextRow+
		 * uiDriver.getObjMap("Itemtype")); String actualRevRecMethod =
		 * uiDriver.getValue(tableRows + nextRow+
		 * uiDriver.getObjMap("RevRecMethod")); String
		 * actualContinuousProduction = uiDriver.getValue(tableRows + nextRow +
		 * uiDriver.getObjMap("ContinuousProduction")); String actualOnNetwork =
		 * uiDriver.getValue(tableRows + nextRow+
		 * uiDriver.getObjMap("OnNetwork"));
		 */
		String Customer = uiDriver.getValue("Customer");
		String Subsidairy = uiDriver.getValue("Subsidairy");
		String Payship = uiDriver.getValue("PayShip");
		String RevisionNumber = uiDriver.getValue("RevisionNumber");
		String InterCompanyFlag = uiDriver.getValue("InterCompanyFlag");
		String LicenseFeeType = uiDriver.getValue("LicenseFeeType");
		String CashBasis = uiDriver.getValue("CashBasis");
		String Status = uiDriver.getValue("Status");

		/*
		 * String Marketcode = input.get("marketCode");
		 * SleepUtils.sleep(TimeSlab.YIELD); if
		 * (Marketcode.contains(actualMARKETCODE.trim())) { passed(
		 * "Verifying the  marketCode", "marketCode should be displayed as '" +
		 * Marketcode + "' Successfully", "marketCode " + actualMARKETCODE +
		 * " is displayed Successfully"); } else { failed(
		 * "Verifying the  marketCode", "marketCode should be displayed as '" +
		 * Marketcode + "' Successfully", "marketCode " + actualMARKETCODE +
		 * " is not displayed Successfully"); }
		 */

		/*
		 * String Itemtype = input.get("Itemtype");
		 * SleepUtils.sleep(TimeSlab.YIELD); if
		 * (Itemtype.contains(actualItemType.trim())) { passed(
		 * "Verifying the  Itemtype", "Itemtype should be displayed as '" +
		 * Itemtype+ "' Successfully", "Itemtype " + actualItemType+
		 * " is displayed Successfully"); } else { failed(
		 * "Verifying the  Itemtype", "Itemtype should be displayed as '" +
		 * Itemtype+ "' Successfully", "Itemtype " + actualItemType+
		 * " is not displayed Successfully"); }
		 * 
		 * String RevRecMethod = input.get("RevRecMethod");
		 * SleepUtils.sleep(TimeSlab.YIELD); if
		 * (RevRecMethod.contains(actualRevRecMethod.trim())) { passed(
		 * "Verifying the  RevRecMethod",
		 * "RevRecMethod should be displayed as '" + RevRecMethod+
		 * "' Successfully", "RevRecMethod " + actualRevRecMethod +
		 * " is displayed Successfully"); } else { failed(
		 * "Verifying the  RevRecMethod",
		 * "RevRecMethod should be displayed as '" + RevRecMethod+
		 * "' Successfully", "RevRecMethod "+ actualRevRecMethod+
		 * " is not displayed Successfully"); }
		 * 
		 * String ContinuousProduction = input.get("ContinuousProduction"); if
		 * (ContinuousProduction.contains(actualContinuousProduction.trim())) {
		 * passed("Verifying the  ContinuousProduction",
		 * "ContinuousProduction should be displayed as '" +
		 * ContinuousProduction + "' Successfully", "ContinuousProduction " +
		 * ContinuousProduction+ " is displayed Successfully"); } else { failed(
		 * "Verifying the  ContinuousProduction",
		 * "ContinuousProduction should be displayed as '" +
		 * ContinuousProduction + "' Successfully", "ContinuousProduction " +
		 * actualContinuousProduction+ " is not displayed Successfully"); }
		 * 
		 * String OnNetwork = input.get("OnNetwork");
		 * SleepUtils.sleep(TimeSlab.YIELD); if
		 * (OnNetwork.contains(actualOnNetwork.trim())) { passed(
		 * "Verifying the  OnNetwork", "OnNetwork should be displayed as '" +
		 * OnNetwork+ "' Successfully", "OnNetwork " + OnNetwork+
		 * " is displayed Successfully"); } else { failed(
		 * "Verifying the  OnNetwork", "OnNetwork should be displayed as '" +
		 * OnNetwork+ "' Successfully", "OnNetwork " + actualOnNetwork+
		 * " is not displayed Successfully"); }
		 */

		SleepUtils.sleep(TimeSlab.YIELD);
		if (input.get("Customer").toLowerCase().trim().contains(Customer.toLowerCase().trim())
				|| Customer.toLowerCase().trim().contains(input.get("Customer").toLowerCase().trim())) {
			passed("Verifying the  Customer", "Customer should be displayed as : " + input.get("Customer"),
					"Customer is displayed as : " + Customer);
		} else {
			failed("Verifying the  Customer", "Customer should be displayed as : " + input.get("Customer"),
					"Customer is displayed as : " + Customer);
		}

		SleepUtils.sleep(TimeSlab.YIELD);
		if (input.get("Subsidairy").toLowerCase().trim().contains(Subsidairy.toLowerCase().trim())
				|| Subsidairy.toLowerCase().trim().contains(input.get("Subsidairy").toLowerCase().trim())) {
			passed("Verifying the  Subsidairy", "Subsidairy should be displayed as : " + input.get("Subsidairy"),
					"Subsidairy is displayed as : " + Subsidairy);
		} else {
			failed("Verifying the  Subsidairy", "Subsidairy should be displayed as : " + input.get("Subsidairy"),
					"Subsidairy is displayed as : " + Subsidairy);
		}

		SleepUtils.sleep(TimeSlab.YIELD);
		if (input.get("Payship").toLowerCase().trim().contains(Payship.toLowerCase().trim())
				|| Payship.toLowerCase().trim().contains(input.get("Payship").toLowerCase().trim())) {
			passed("Verifying the  Payship", "Payship should be displayed as : " + input.get("Payship"),
					"Payship is displayed as : " + Payship);
		} else {
			failed("Verifying the  Payship", "Payship should be displayed as : " + input.get("Payship"),
					"Payship is displayed as : " + Payship);
		}

		SleepUtils.sleep(TimeSlab.YIELD);
		if (input.get("RevisionNumber").toLowerCase().trim().contains(RevisionNumber.toLowerCase().trim())
				|| RevisionNumber.toLowerCase().trim().contains(input.get("RevisionNumber").toLowerCase().trim())) {
			passed("Verifying the  RevisionNumber",
					"RevisionNumber should be displayed as : " + input.get("RevisionNumber"),
					"RevisionNumber is displayed as : " + RevisionNumber);
		} else {
			failed("Verifying the  RevisionNumber",
					"RevisionNumber should be displayed as : " + input.get("RevisionNumber"),
					"RevisionNumber is displayed as : " + RevisionNumber);
		}

		SleepUtils.sleep(TimeSlab.YIELD);
		if (input.get("InterCompanyFlag").toLowerCase().trim().contains(InterCompanyFlag.toLowerCase().trim())
				|| InterCompanyFlag.toLowerCase().trim().contains(input.get("InterCompanyFlag").toLowerCase().trim())) {
			passed("Verifying the  InterCompanyFlag",
					"InterCompanyFlag should be displayed as : " + input.get("InterCompanyFlag"),
					"InterCompanyFlag is displayed as : " + InterCompanyFlag);
		} else {
			failed("Verifying the  InterCompanyFlag",
					"InterCompanyFlag should be displayed as : " + input.get("InterCompanyFlag"),
					"InterCompanyFlag is displayed as : " + InterCompanyFlag);
		}

		SleepUtils.sleep(TimeSlab.YIELD);
		if (input.get("LicenseFeeType").toLowerCase().trim().contains(LicenseFeeType.toLowerCase().trim())
				|| LicenseFeeType.toLowerCase().trim().contains(input.get("LicenseFeeType").toLowerCase().trim())) {
			passed("Verifying the  LicenseFeeType",
					"LicenseFeeType should be displayed as : " + input.get("LicenseFeeType"),
					"LicenseFeeType is displayed as : " + LicenseFeeType);
		} else {
			failed("Verifying the  LicenseFeeType",
					"LicenseFeeType should be displayed as : " + input.get("LicenseFeeType"),
					"LicenseFeeType is displayed as : " + LicenseFeeType);
		}

		SleepUtils.sleep(TimeSlab.YIELD);
		if (input.get("Status").toLowerCase().trim().contains(Status.toLowerCase().trim())
				|| Status.toLowerCase().trim().contains(input.get("Status").toLowerCase().trim())) {
			passed("Verifying the  Status", "Status should be displayed as : " + input.get("Status"),
					"Status is displayed as : " + Status);
		} else {
			failed("Verifying the  Status", "Status should be displayed as : " + input.get("Status"),
					"Status is displayed as : " + Status);
		}

		SleepUtils.sleep(TimeSlab.YIELD);
		if (input.get("CashBasis").toLowerCase().trim().contains(CashBasis.toLowerCase().trim())
				|| CashBasis.toLowerCase().trim().contains(input.get("CashBasis").toLowerCase().trim())) {
			passed("Verifying the  CashBasis", "CashBasis should be displayed as : " + input.get("CashBasis"),
					"CashBasis is displayed as : " + CashBasis);
		} else {
			failed("Verifying the  CashBasis", "CashBasis should be displayed as : " + input.get("CashBasis"),
					"CashBasis is displayed as : " + CashBasis);
		}

	}

	public void ValidateLineitemsinNS(DataRow input, DataRow output) {

		String Item = input.get("Item");

		String item[] = Item.split(";");

		String revrecmethod = input.get("Rev Rec Method");

		String Revrecmethod[] = revrecmethod.split(";");

		String subtype = input.get("Sub Type");

		String Subtype[] = subtype.split(";");

		String Onnetwork = input.get("On Network");

		String onnetwork[] = Onnetwork.split(";");

		String Continuousproduction = input.get("Continuous Production");

		String continuousproduction[] = Continuousproduction.split(";");

		String MarketCode = input.get("Market Code");

		String marketCode[] = MarketCode.split(";");

		String Right = input.get("Right");

		String right[] = Right.split(";");

		String Territory = input.get("Territory");

		String territory[] = Territory.split(";");

		String TitleID = input.get("Title ID");

		String titleID[] = TitleID.split(";");

		String Quantity = input.get("Quantity");

		String quantity[] = Quantity.split(";");

		String Rate = input.get("Rate");

		String rate[] = Rate.split(";");

		String Amount = input.get("Amount");

		String amount[] = Amount.split(";");

		String NetRevisedAmount = input.get("Net Revised Amount");

		String netRevisedAmount[] = NetRevisedAmount.split(";");

		String Productowner = input.get("Product Owner");

		String productowner[] = Productowner.split(";");

		String GLPN = input.get("GLPN");

		String gLPN[] = GLPN.split(";");

		String ProductType = input.get("Product Type");

		String productType[] = ProductType.split(";");

		String RevRecStartDate = input.get("Rev Rec Start Date");

		String revRecStartDate[] = RevRecStartDate.split(";");

		String RevRecEndDate = input.get("Rev Rec End Date");

		String revRecEndDate[] = RevRecEndDate.split(";");

		String TaxCode = input.get("Tax Code");

		String taxCode[] = TaxCode.split(";");

		String SplitWindowNumber = input.get("Split Window Number");

		String splitWindowNumber[] = SplitWindowNumber.split(";");

		String UnbilledRevenueAccount = input.get("Unbilled Revenue Account");

		String unbilledRevenueAccount[] = UnbilledRevenueAccount.split(";");

		String BilledRevenueAccount = input.get("Billed Revenue Account");

		String billedRevenueAccount[] = BilledRevenueAccount.split(";");

		String BilledARAccount = input.get("Billed AR Account");

		String billedARAccount[] = BilledARAccount.split(";");

		String UnbilledARAccount = input.get("Unbilled AR Account");

		String unbilledARAccount[] = UnbilledARAccount.split(";");

		String PaidDeferredRevenueAccount = input.get("Paid Deferred Revenue Account");

		String paidDeferredRevenueAccount[] = PaidDeferredRevenueAccount.split(";");

		String UnpaidDeferredRevenueAccount = input.get("Unpaid Deferred Revenue Account");

		String unpaidDeferredRevenueAccount[] = UnpaidDeferredRevenueAccount.split(";");

		String BadDebtRevenueAccount = input.get("Bad Debt Revenue Account");

		String badDebtRevenueAccount[] = BadDebtRevenueAccount.split(";");

		List<WebElement> LineItems = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tr"));
		int total_LineItems = LineItems.size();
		int k = 0, temp = 0;
		for (int i = 0; i < gLPN.length; i++) {

			List<WebElement> el;
			String xpath = "//table[@id='item_splits']//td[contains(text(),'" + gLPN[k].trim() + "')]";

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Item']//..//preceding-sibling::*)+1]")) {
				String actual_Item;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Item']//..//preceding-sibling::*)+1]"));
				try {
					actual_Item = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_Item = el.get(0).getText();
				}

				String expected_Item = item[k].trim();
				expected_Item = expected_Item.replace("Null", " ");

				if (expected_Item.toLowerCase().trim().contains(actual_Item.toLowerCase().trim())
						|| actual_Item.toLowerCase().trim().contains(expected_Item.toLowerCase().trim())) {
					passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"Item Should be displayed as " + expected_Item, "Item is displayed as " + actual_Item);
				} else {
					failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"Item Should be displayed as " + expected_Item, "Item is displayed as " + actual_Item);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Revenue Recognition Method']//..//preceding-sibling::*)+1]")) {
				String actual_Revrecmethod;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Revenue Recognition Method']//..//preceding-sibling::*)+1]"));
				try {
					actual_Revrecmethod = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_Revrecmethod = el.get(0).getText();
				}

				String expected_Revrecmethod = Revrecmethod[k].trim();
				expected_Revrecmethod = expected_Revrecmethod.replace("Null", " ");

				if (expected_Revrecmethod.toLowerCase().trim().contains(actual_Revrecmethod.toLowerCase().trim())
						|| actual_Revrecmethod.toLowerCase().trim()
								.contains(expected_Revrecmethod.toLowerCase().trim())) {
					passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"Revrecmethod Should be displayed as " + expected_Revrecmethod,
							"Revrecmethod is displayed as " + actual_Revrecmethod);
				} else {
					failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"Revrecmethod Should be displayed as " + expected_Revrecmethod,
							"Revrecmethod is displayed as " + actual_Revrecmethod);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='On Network']//..//preceding-sibling::*)+1]")) {
				String actual_onnetwork;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='On Network']//..//preceding-sibling::*)+1]"));
				try {
					actual_onnetwork = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_onnetwork = el.get(0).getText();
				}

				String expected_onnetwork = onnetwork[k].trim();
				expected_onnetwork = expected_onnetwork.replace("Null", " ");

				if (expected_onnetwork.toLowerCase().trim().contains(actual_onnetwork.toLowerCase().trim())
						|| actual_onnetwork.toLowerCase().trim().contains(expected_onnetwork.toLowerCase().trim())) {
					passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"onnetwork Should be displayed as " + expected_onnetwork,
							"onnetwork is displayed as " + actual_onnetwork);
				} else {
					failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"onnetwork Should be displayed as " + expected_onnetwork,
							"onnetwork is displayed as " + actual_onnetwork);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Continuous Production']//..//preceding-sibling::*)+1]")) {
				String actual_continuousproduction;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Continuous Production']//..//preceding-sibling::*)+1]"));
				try {
					actual_continuousproduction = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_continuousproduction = el.get(0).getText();
				}

				String expected_continuousproduction = continuousproduction[k].trim();
				expected_continuousproduction = expected_continuousproduction.replace("Null", " ");

				if (expected_continuousproduction.toLowerCase().trim()
						.contains(actual_continuousproduction.toLowerCase().trim())
						|| actual_continuousproduction.toLowerCase().trim()
								.contains(expected_continuousproduction.toLowerCase().trim())) {
					passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"continuousproduction Should be displayed as " + expected_continuousproduction,
							"continuousproduction is displayed as " + actual_continuousproduction);
				} else {
					failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"continuousproduction Should be displayed as " + expected_continuousproduction,
							"continuousproduction is displayed as " + actual_continuousproduction);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Rate']//..//preceding-sibling::*)+1]")) {
				String actual_Rate;
				Float actual_Rate_temp;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Rate']//..//preceding-sibling::*)+1]"));
				try {
					actual_Rate = el.get(temp).getText();
					actual_Rate = actual_Rate.replace(",", "");
					actual_Rate = actual_Rate.replace("$", "");
					actual_Rate_temp = Float.parseFloat(actual_Rate);
				} catch (Exception e) {
					temp = 0;
					actual_Rate = el.get(0).getText();
					actual_Rate = actual_Rate.replace(",", "");
					actual_Rate = actual_Rate.replace("$", "");
					actual_Rate_temp = Float.parseFloat(actual_Rate);
				}

				String expected_Rate = rate[k].trim();
				expected_Rate = expected_Rate.replace("Null", " ");
				expected_Rate = expected_Rate.replace(",", "");
				expected_Rate = expected_Rate.replace("$", "");
				Float expected_Rate_temp = Float.parseFloat(actual_Rate);

				if (expected_Rate_temp.toString().trim().contains(actual_Rate_temp.toString().trim())
						|| actual_Rate_temp.toString().trim().contains(expected_Rate_temp.toString().trim())) {
					passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"Rate Should be displayed as " + expected_Rate, "Rate is displayed as " + actual_Rate);
				} else {
					failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"Rate Should be displayed as " + expected_Rate, "Rate is displayed as " + actual_Rate);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Owner']//..//preceding-sibling::*)+1]")) {
				String actual_ProductOwner;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Owner']//..//preceding-sibling::*)+1]"));
				try {
					actual_ProductOwner = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_ProductOwner = el.get(0).getText();
				}

				String expected_ProductOwner = productowner[k].trim();
				expected_ProductOwner = expected_ProductOwner.replace("Null", " ");

				if (expected_ProductOwner.toLowerCase().trim().contains(actual_ProductOwner.toLowerCase().trim())
						|| actual_ProductOwner.toLowerCase().trim()
								.contains(expected_ProductOwner.toLowerCase().trim())) {
					passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"ProductOwner Should be displayed as " + expected_ProductOwner,
							"ProductOwner is displayed as " + actual_ProductOwner);
				} else {
					failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"ProductOwner Should be displayed as " + expected_ProductOwner,
							"ProductOwner is displayed as " + actual_ProductOwner);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]")) {
				String actual_GLPN;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]"));
				try {
					actual_GLPN = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_GLPN = el.get(0).getText();
				}

				String expected_GLPN = gLPN[k].trim();
				expected_GLPN = expected_GLPN.replace("Null", " ");

				if (expected_GLPN.toLowerCase().trim().contains(actual_GLPN.toLowerCase().trim())
						|| actual_GLPN.toLowerCase().trim().contains(expected_GLPN.toLowerCase().trim())) {
					passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"GLPN Should be displayed as " + expected_GLPN, "GLPN is displayed as " + actual_GLPN);
				} else {
					failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"GLPN Should be displayed as " + expected_GLPN, "GLPN is displayed as " + actual_GLPN);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Type']//..//preceding-sibling::*)+1]")) {
				String actual_ProductType;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Type']//..//preceding-sibling::*)+1]"));
				try {
					actual_ProductType = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_ProductType = el.get(0).getText();
				}

				String expected_ProductType = productType[k].trim();
				expected_ProductType = expected_ProductType.replace("Null", " ");

				if (expected_ProductType.toLowerCase().trim().contains(actual_ProductType.toLowerCase().trim())
						|| actual_ProductType.toLowerCase().trim()
								.contains(expected_ProductType.toLowerCase().trim())) {
					passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"ProductType Should be displayed as " + expected_ProductType,
							"ProductType is displayed as " + actual_ProductType);
				} else {
					failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"ProductType Should be displayed as " + expected_ProductType,
							"ProductType is displayed as " + actual_ProductType);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Revenue Recognition Start Date']//..//preceding-sibling::*)+1]")) {
				String actual_RevenueRecognitionStartDate;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Revenue Recognition Start Date']//..//preceding-sibling::*)+1]"));
				try {
					actual_RevenueRecognitionStartDate = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_RevenueRecognitionStartDate = el.get(0).getText();
				}

				String expected_RevenueRecognitionStartDate = revRecStartDate[k].trim();
				expected_RevenueRecognitionStartDate = expected_RevenueRecognitionStartDate.replace("Null", " ");

				if (expected_RevenueRecognitionStartDate.toLowerCase().trim()
						.contains(actual_RevenueRecognitionStartDate.toLowerCase().trim())
						|| actual_RevenueRecognitionStartDate.toLowerCase().trim()
								.contains(expected_RevenueRecognitionStartDate.toLowerCase().trim())) {
					passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"RevenueRecognitionStartDate Should be displayed as "
									+ expected_RevenueRecognitionStartDate,
							"RevenueRecognitionStartDate is displayed as " + actual_RevenueRecognitionStartDate);
				} else {
					failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"RevenueRecognitionStartDate Should be displayed as "
									+ expected_RevenueRecognitionStartDate,
							"RevenueRecognitionStartDate is displayed as " + actual_RevenueRecognitionStartDate);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Revenue Recognition End Date']//..//preceding-sibling::*)+1]")) {
				String actual_RevenueRecognitionEndDate;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Revenue Recognition End Date']//..//preceding-sibling::*)+1]"));
				try {
					actual_RevenueRecognitionEndDate = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_RevenueRecognitionEndDate = el.get(0).getText();
				}

				String expected_RevenueRecognitionEndDate = revRecEndDate[k].trim();
				expected_RevenueRecognitionEndDate = expected_RevenueRecognitionEndDate.replace("Null", " ");

				if (expected_RevenueRecognitionEndDate.toLowerCase().trim()
						.contains(actual_RevenueRecognitionEndDate.toLowerCase().trim())
						|| actual_RevenueRecognitionEndDate.toLowerCase().trim()
								.contains(expected_RevenueRecognitionEndDate.toLowerCase().trim())) {
					passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"RevenueRecognitionEndDate Should be displayed as " + expected_RevenueRecognitionEndDate,
							"RevenueRecognitionEndDate is displayed as " + actual_RevenueRecognitionEndDate);
				} else {
					failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"RevenueRecognitionEndDate Should be displayed as " + expected_RevenueRecognitionEndDate,
							"RevenueRecognitionEndDate is displayed as " + actual_RevenueRecognitionEndDate);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Tax Code']//..//preceding-sibling::*)+1]")) {
				String actual_TaxCode;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Tax Code']//..//preceding-sibling::*)+1]"));
				try {
					actual_TaxCode = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_TaxCode = el.get(0).getText();
				}

				String expected_TaxCode = taxCode[k].trim();
				expected_TaxCode = expected_TaxCode.replace("Null", " ");

				if (expected_TaxCode.toLowerCase().trim().contains(actual_TaxCode.toLowerCase().trim())
						|| actual_TaxCode.toLowerCase().trim().contains(expected_TaxCode.toLowerCase().trim())) {
					passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"TaxCode Should be displayed as " + expected_TaxCode,
							"TaxCode is displayed as " + actual_TaxCode);
				} else {
					failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"TaxCode Should be displayed as " + expected_TaxCode,
							"TaxCode is displayed as " + actual_TaxCode);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Split Window Number']//..//preceding-sibling::*)+1]")) {
				String actual_splitWindowNumber;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Split Window Number']//..//preceding-sibling::*)+1]"));
				try {
					actual_splitWindowNumber = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_splitWindowNumber = el.get(0).getText();
				}

				String expected_splitWindowNumber = splitWindowNumber[k].trim();
				expected_splitWindowNumber = expected_splitWindowNumber.replace("Null", " ");

				if (expected_splitWindowNumber.toLowerCase().trim()
						.contains(actual_splitWindowNumber.toLowerCase().trim())
						|| actual_splitWindowNumber.toLowerCase().trim()
								.contains(expected_splitWindowNumber.toLowerCase().trim())) {
					passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"splitWindowNumber Should be displayed as " + expected_splitWindowNumber,
							"splitWindowNumber is displayed as " + actual_splitWindowNumber);
				} else {
					failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"splitWindowNumber Should be displayed as " + expected_splitWindowNumber,
							"splitWindowNumber is displayed as " + actual_splitWindowNumber);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Market Code']//..//preceding-sibling::*)+1]")) {
				String actual_MarketCode;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Market Code']//..//preceding-sibling::*)+1]"));
				try {
					actual_MarketCode = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_MarketCode = el.get(0).getText();
				}

				String expected_MarketCode = marketCode[k].trim();
				expected_MarketCode = expected_MarketCode.replace("Null", " ");

				if (expected_MarketCode.toLowerCase().trim().contains(actual_MarketCode.toLowerCase().trim())
						|| actual_MarketCode.toLowerCase().trim().contains(expected_MarketCode.toLowerCase().trim())) {
					passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"MarketCode Should be displayed as " + expected_MarketCode,
							"MarketCode is displayed as " + actual_MarketCode);
				} else {
					failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"MarketCode Should be displayed as " + expected_MarketCode,
							"MarketCode is displayed as " + actual_MarketCode);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Territory']//..//preceding-sibling::*)+1]")) {
				String actual_Territory;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Territory']//..//preceding-sibling::*)+1]"));
				try {
					actual_Territory = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_Territory = el.get(0).getText();
				}

				String expected_Territory = territory[k].trim();
				expected_Territory = expected_Territory.replace("Null", " ");

				if (expected_Territory.toLowerCase().trim().contains(actual_Territory.toLowerCase().trim())
						|| actual_Territory.toLowerCase().trim().contains(expected_Territory.toLowerCase().trim())) {
					passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"Territory Should be displayed as " + expected_Territory,
							"Territory is displayed as " + actual_Territory);
				} else {
					failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"Territory Should be displayed as " + expected_Territory,
							"Territory is displayed as " + actual_Territory);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title']//..//preceding-sibling::*)+1]")) {
				String actual_Title;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title']//..//preceding-sibling::*)+1]"));
				try {
					actual_Title = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_Title = el.get(0).getText();
				}

				String expected_Title = titleID[k].trim();
				expected_Title = expected_Title.replace("Null", " ");

				if (expected_Title.toLowerCase().trim().contains(actual_Title.toLowerCase().trim())
						|| actual_Title.toLowerCase().trim().contains(expected_Title.toLowerCase().trim())) {
					passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"Title Should be displayed as " + expected_Title, "Title is displayed as " + actual_Title);
				} else {
					failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"Title Should be displayed as " + expected_Title, "Title is displayed as " + actual_Title);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Right']//..//preceding-sibling::*)+1]")) {
				String actual_Right;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Right']//..//preceding-sibling::*)+1]"));
				try {
					actual_Right = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_Right = el.get(0).getText();
				}

				String expected_Right = right[k].trim();
				expected_Right = expected_Right.replace("Null", " ");

				if (expected_Right.toLowerCase().trim().contains(actual_Right.toLowerCase().trim())
						|| actual_Right.toLowerCase().trim().contains(expected_Right.toLowerCase().trim())) {
					passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"Right Should be displayed as " + expected_Right, "Right is displayed as " + actual_Right);
				} else {
					failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"Right Should be displayed as " + expected_Right, "Right is displayed as " + actual_Right);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled Revenue Account']//..//preceding-sibling::*)+1]")) {
				String actual_unbilledRevenueAccount;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled Revenue Account']//..//preceding-sibling::*)+1]"));
				try {
					actual_unbilledRevenueAccount = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_unbilledRevenueAccount = el.get(0).getText();
				}

				String expected_unbilledRevenueAccount = unbilledRevenueAccount[k].trim();
				expected_unbilledRevenueAccount = expected_unbilledRevenueAccount.replace("Null", " ");

				if (expected_unbilledRevenueAccount.toLowerCase().trim()
						.contains(actual_unbilledRevenueAccount.toLowerCase().trim())
						|| actual_unbilledRevenueAccount.toLowerCase().trim()
								.contains(expected_unbilledRevenueAccount.toLowerCase().trim())) {
					passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"unbilledRevenueAccount Should be displayed as " + expected_unbilledRevenueAccount,
							"unbilledRevenueAccount is displayed as " + actual_unbilledRevenueAccount);
				} else {
					failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"unbilledRevenueAccount Should be displayed as " + expected_unbilledRevenueAccount,
							"unbilledRevenueAccount is displayed as " + actual_unbilledRevenueAccount);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed Revenue Account']//..//preceding-sibling::*)+1]")) {
				String actual_BilledRevenueAccount;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed Revenue Account']//..//preceding-sibling::*)+1]"));
				try {
					actual_BilledRevenueAccount = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_BilledRevenueAccount = el.get(0).getText();
				}

				String expected_BilledRevenueAccount = billedRevenueAccount[k].trim();
				expected_BilledRevenueAccount = expected_BilledRevenueAccount.replace("Null", " ");

				if (expected_BilledRevenueAccount.toLowerCase().trim()
						.contains(actual_BilledRevenueAccount.toLowerCase().trim())
						|| actual_BilledRevenueAccount.toLowerCase().trim()
								.contains(expected_BilledRevenueAccount.toLowerCase().trim())) {
					passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"BilledRevenueAccount Should be displayed as " + expected_BilledRevenueAccount,
							"BilledRevenueAccount is displayed as " + actual_BilledRevenueAccount);
				} else {
					failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"BilledRevenueAccount Should be displayed as " + expected_BilledRevenueAccount,
							"BilledRevenueAccount is displayed as " + actual_BilledRevenueAccount);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled AR']//..//preceding-sibling::*)+1]")) {
				String actual_unbilledARAccount;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled AR']//..//preceding-sibling::*)+1]"));
				try {
					actual_unbilledARAccount = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_unbilledARAccount = el.get(0).getText();
				}

				String expected_unbilledARAccount = unbilledARAccount[k].trim();
				expected_unbilledARAccount = expected_unbilledARAccount.replace("Null", " ");

				if (expected_unbilledARAccount.toLowerCase().trim()
						.contains(actual_unbilledARAccount.toLowerCase().trim())
						|| actual_unbilledARAccount.toLowerCase().trim()
								.contains(expected_unbilledARAccount.toLowerCase().trim())) {
					passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"unbilledARAccount Should be displayed as " + expected_unbilledARAccount,
							"unbilledARAccount is displayed as " + actual_unbilledARAccount);
				} else {
					failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"unbilledARAccount Should be displayed as " + expected_unbilledARAccount,
							"unbilledARAccount is displayed as " + actual_unbilledARAccount);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed AR Account']//..//preceding-sibling::*)+1]")) {
				String actual_BilledARAccount;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed AR Account']//..//preceding-sibling::*)+1]"));
				try {
					actual_BilledARAccount = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_BilledARAccount = el.get(0).getText();
				}

				String expected_BilledARAccount = billedARAccount[k].trim();
				expected_BilledARAccount = expected_BilledARAccount.replace("Null", " ");

				if (expected_BilledARAccount.toLowerCase().trim().contains(actual_BilledARAccount.toLowerCase().trim())
						|| actual_BilledARAccount.toLowerCase().trim()
								.contains(expected_BilledARAccount.toLowerCase().trim())) {
					passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"BilledARAccount Should be displayed as " + expected_BilledARAccount,
							"BilledARAccount is displayed as " + actual_BilledARAccount);
				} else {
					failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"BilledARAccount Should be displayed as " + expected_BilledARAccount,
							"BilledARAccount is displayed as " + actual_BilledARAccount);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Paid Deferred']//..//preceding-sibling::*)+1]")) {
				String actual_PaidDeferred;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Paid Deferred']//..//preceding-sibling::*)+1]"));
				try {
					actual_PaidDeferred = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_PaidDeferred = el.get(0).getText();
				}

				String expected_PaidDeferred = paidDeferredRevenueAccount[k].trim();
				expected_PaidDeferred = expected_PaidDeferred.replace("Null", " ");

				if (expected_PaidDeferred.toLowerCase().trim().contains(actual_PaidDeferred.toLowerCase().trim())
						|| actual_PaidDeferred.toLowerCase().trim()
								.contains(expected_PaidDeferred.toLowerCase().trim())) {
					passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"PaidDeferred Should be displayed as " + expected_PaidDeferred,
							"PaidDeferred is displayed as " + actual_PaidDeferred);
				} else {
					failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"PaidDeferred Should be displayed as " + expected_PaidDeferred,
							"PaidDeferred is displayed as " + actual_PaidDeferred);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Bad Debt Revenue']//..//preceding-sibling::*)+1]")) {
				String actual_BadDebtRevenue;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Bad Debt Revenue']//..//preceding-sibling::*)+1]"));
				try {
					actual_BadDebtRevenue = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_BadDebtRevenue = el.get(0).getText();
				}

				String expected_BadDebtRevenue = badDebtRevenueAccount[k].trim();
				expected_BadDebtRevenue = expected_BadDebtRevenue.replace("Null", " ");

				if (expected_BadDebtRevenue.toLowerCase().trim().contains(actual_BadDebtRevenue.toLowerCase().trim())
						|| actual_BadDebtRevenue.toLowerCase().trim()
								.contains(expected_BadDebtRevenue.toLowerCase().trim())) {
					passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"BadDebtRevenue Should be displayed as " + expected_BadDebtRevenue,
							"BadDebtRevenue is displayed as " + actual_BadDebtRevenue);
				} else {
					failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
							"BadDebtRevenue Should be displayed as " + expected_BadDebtRevenue,
							"BadDebtRevenue is displayed as " + actual_BadDebtRevenue);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Quantity']//..//preceding-sibling::*)+1]")) {
				String actual_Quantity;
				Float actual_Quantity_temp;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Quantity']//..//preceding-sibling::*)+1]"));
				try {
					actual_Quantity = el.get(temp).getText();
					actual_Quantity = actual_Quantity.replace(",", "");
					actual_Quantity = actual_Quantity.replace("$", "");
					actual_Quantity_temp = Float.parseFloat(actual_Quantity);
				} catch (Exception e) {
					temp = 0;
					actual_Quantity = el.get(0).getText();
					actual_Quantity = actual_Quantity.replace(",", "");
					actual_Quantity = actual_Quantity.replace("$", "");
					actual_Quantity_temp = Float.parseFloat(actual_Quantity);
				}

				try {
					String expected_Quantity = quantity[k].trim();
					expected_Quantity = expected_Quantity.replace("Null", " ");
					expected_Quantity = expected_Quantity.replace(",", "");
					expected_Quantity = expected_Quantity.replace("$", "");
					Float expected_Quantity_temp = Float.parseFloat(expected_Quantity);

					if (expected_Quantity_temp.toString().trim().contains(actual_Quantity_temp.toString().trim())
							|| actual_Quantity_temp.toString().trim()
									.contains(expected_Quantity_temp.toString().trim())) {
						passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
								"Quantity Should be displayed as " + expected_Quantity,
								"Quantity is displayed as " + actual_Quantity);
					} else {
						failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
								"Quantity Should be displayed as " + expected_Quantity,
								"Quantity is displayed as " + actual_Quantity);
					}
				} catch (Exception e) {
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Amount']//..//preceding-sibling::*)+1]")) {
				String actual_Amount;
				Float actual_Amount_temp;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Amount']//..//preceding-sibling::*)+1]"));
				try {
					actual_Amount = el.get(temp).getText();
					actual_Amount = actual_Amount.replace(",", "");
					actual_Amount = actual_Amount.replace("$", "");
					actual_Amount_temp = Float.parseFloat(actual_Amount);
				} catch (Exception e) {
					temp = 0;
					actual_Amount = el.get(0).getText();
					actual_Amount = actual_Amount.replace(",", "");
					actual_Amount = actual_Amount.replace("$", "");
					actual_Amount_temp = Float.parseFloat(actual_Amount);
				}

				try {
					String expected_Amount = amount[k].trim();
					expected_Amount = expected_Amount.replace("Null", " ");
					expected_Amount = expected_Amount.replace(",", "");
					expected_Amount = expected_Amount.replace("$", "");
					Float expected_Amount_temp = Float.parseFloat(expected_Amount);

					if (expected_Amount_temp.toString().trim().contains(actual_Amount_temp.toString().trim())
							|| actual_Amount_temp.toString().trim().contains(expected_Amount_temp.toString().trim())) {
						passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
								"Amount Should be displayed as " + expected_Amount,
								"Amount is displayed as " + actual_Amount);
					} else {
						failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
								"Amount Should be displayed as " + expected_Amount,
								"Amount is displayed as " + actual_Amount);
					}
				} catch (Exception e) {
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + gLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Net Revised Amount']//..//preceding-sibling::*)+1]")) {
				String actual_NetRevisedAmount;
				Float actual_NetRevisedAmount_temp;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ gLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Net Revised Amount']//..//preceding-sibling::*)+1]"));
				try {
					actual_NetRevisedAmount = el.get(temp).getText();
					actual_NetRevisedAmount = actual_NetRevisedAmount.replace(",", "");
					actual_NetRevisedAmount = actual_NetRevisedAmount.replace("$", "");
					actual_NetRevisedAmount_temp = Float.parseFloat(actual_NetRevisedAmount);
				} catch (Exception e) {
					temp = 0;
					actual_NetRevisedAmount = el.get(0).getText();
					actual_NetRevisedAmount = actual_NetRevisedAmount.replace(",", "");
					actual_NetRevisedAmount = actual_NetRevisedAmount.replace("$", "");
					actual_NetRevisedAmount_temp = Float.parseFloat(actual_NetRevisedAmount);
				}

				try {
					String expected_NetRevisedAmount = netRevisedAmount[k].trim();
					expected_NetRevisedAmount = expected_NetRevisedAmount.replace("Null", " ");
					expected_NetRevisedAmount = expected_NetRevisedAmount.replace(",", "");
					expected_NetRevisedAmount = expected_NetRevisedAmount.replace("$", "");
					Float expected_NetRevisedAmount_temp = Float.parseFloat(expected_NetRevisedAmount);

					if (expected_NetRevisedAmount_temp.toString().trim()
							.contains(actual_NetRevisedAmount_temp.toString().trim())
							|| actual_NetRevisedAmount_temp.toString().trim()
									.contains(expected_NetRevisedAmount_temp.toString().trim())) {
						passed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
								"NetRevisedAmount Should be displayed as " + expected_NetRevisedAmount,
								"NetRevisedAmount is displayed as " + actual_NetRevisedAmount);
					} else {
						failed("ValidateLineitemsinNS-" + "-Line Item for GLPN " + gLPN[k],
								"NetRevisedAmount Should be displayed as " + expected_NetRevisedAmount,
								"NetRevisedAmount is displayed as " + actual_NetRevisedAmount);
					}
				} catch (Exception e) {
				}
			}

			el = uiDriver.webDr.findElements(By.xpath(xpath));
			if (el.size() > 1) {
				temp++;
			} else {
				temp = 0;
			}

			k++;
		}

	}

	public void ValidateAllInvoiceData(DataRow input, DataRow output) throws InterruptedException {
		try {
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.setValue("//input[@id='_searchstring']", input.get("conf"));
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//a[contains(text(),'Sales Order:')]");
			SleepUtils.sleep(TimeSlab.LOW);
			if (uiDriver.checkElementPresent("//h1[text()='Sales Order']")) {
				passed("ValidateAllInvoiceData", "Sales Order Should be displayed", "Sales Order is displayed");
			} else {
				failed("ValidateAllInvoiceData", "Sales Order Should be displayed", "Sales Order is not displayed");
			}
			uiDriver.click("//a[@id='rlrcdstabtxt']");
			SleepUtils.sleep(TimeSlab.LOW);

			String TotalAmounts = input.get("TotalAmount");
			String TotalAmount[] = TotalAmounts.split(";");

			String Items = input.get("Item");
			String Item[] = Items.split(";");

			String Quantities = input.get("Quantity");
			String Quantity[] = Quantities.split(";");

			String Rates = input.get("Rate");
			String Rate[] = Rates.split(";");

			String Amounts = input.get("Amount");
			String Amount[] = Amounts.split(";");

			String TaxCodes = input.get("Tax Code");
			String TaxCode[] = TaxCodes.split(";");

			String MarketCodes = input.get("Market Code");
			String MarketCode[] = MarketCodes.split(";");

			String Territories = input.get("Territory");
			String Territory[] = Territories.split(";");

			String TitleIDs = input.get("Title ID");
			String TitleID[] = TitleIDs.split(";");

			String GLPNs = input.get("GLPN");
			String GLPN[] = GLPNs.split(";");

			String ProductOwners = input.get("Product Owner");
			String ProductOwner[] = ProductOwners.split(";");

			String Rights = input.get("Right");
			String Right[] = Rights.split(";");

			String UnbilledRevenueAccounts = input.get("Unbilled Revenue Account");
			String UnbilledRevenueAccount[] = UnbilledRevenueAccounts.split(";");

			String BilledRevenueAccounts = input.get("Billed Revenue Account");
			String BilledRevenueAccount[] = BilledRevenueAccounts.split(";");

			String BilledARAccounts = input.get("Billed AR Account");
			String BilledARAccount[] = BilledARAccounts.split(";");

			String UnbilledARAccounts = input.get("Unbilled AR Account");
			String UnbilledARAccount[] = UnbilledARAccounts.split(";");

			String PaidDeferredRevenueAccounts = input.get("Paid Deferred Revenue Account");
			String PaidDeferredRevenueAccount[] = PaidDeferredRevenueAccounts.split(";");

			String UnpaidDeferredRevenueAccounts = input.get("Unpaid Deferred Revenue Account");
			String UnpaidDeferredRevenueAccount[] = UnpaidDeferredRevenueAccounts.split(";");

			String BadDebtRevenueAccounts = input.get("Bad Debt Revenue Account");
			String BadDebtRevenueAccount[] = BadDebtRevenueAccounts.split(";");

			List<WebElement> Invoices = uiDriver.webDr.findElements(By.xpath("//td[text()='Invoice']//..//a"));
			int total_Invoices = Invoices.size();

			int k = 0, flag = 0;
			for (int i = 0; i < TotalAmount.length; i++) {
				uiDriver.click("//a[@id='rlrcdstabtxt']");
				SleepUtils.sleep(TimeSlab.LOW);

				String InvAmount = TotalAmount[i];
				String Exchange = text_ExchangeNumber;

				InvAmount = InvAmount.replace(",", "");
				Exchange = Exchange.replace(",", "");

				Float temp1 = Float.parseFloat(InvAmount);
				Float temp2 = Float.parseFloat(Exchange);

				Float temp3 = temp1 * temp2;
				String temp4 = temp3.toString();

				int end = temp4.indexOf(".");
				String temp5 = temp4.substring(0, end);
				// String temp5 = "4595029";
				System.out.println(temp5);

				int length = temp5.length();

				ArrayList<String> t1 = new ArrayList<String>();
				for (int x = (length - 1); x >= 0; x--) {
					String t2 = temp5.substring(x, x + 1);
					t1.add(t2);
				}
				System.out.println(t1);
				System.out.println(t1.size());

				String finalAmount = "";
				for (int x = 0; x < t1.size(); x++) {
					finalAmount = t1.get(x) + finalAmount;

					if (x != t1.size() - 1) {
						if (x % 3 == 2) {
							finalAmount = "," + finalAmount;
						}
					}
				}
				System.out.println(finalAmount);

				String xpath_Invoice = "//td[text()='Invoice']//..//td[contains(text(),'" + finalAmount.trim()
						+ "')]//..//a";
				// uiDriver.click(xpath_Invoice);
				List<WebElement> element = uiDriver.webDr.findElements(By.xpath(xpath_Invoice));
				if (element.size() > 1) {
					((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView(true);",
							element.get(flag));
					((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();", element.get(flag));
					flag++;
				} else {
					((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView(true);",
							element.get(0));
					((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();", element.get(0));
				}
				SleepUtils.sleep(TimeSlab.LOW);
				if (uiDriver.checkElementPresent("//h1[text()='Invoice']")) {
					passed("ValidateAllInvoiceData", "Invoice Should be displayed", "Invoice is displayed");
				} else {
					failed("ValidateAllInvoiceData", "Invoice Should be displayed", "Invoice is not displayed");
				}

				String actual_Customer = uiDriver
						.getValue("//span[@id='entity_fs_lbl_uir_label']//following-sibling::span//a");
				String actual_DueDate = uiDriver
						.getValue("//span[@id='duedate_fs_lbl_uir_label']//following-sibling::span");
				String actual_ApprovalStatus = uiDriver
						.getValue("//span[@id='approvalstatus_fs_lbl_uir_label']//following-sibling::span//span");
				String actual_Status = uiDriver.getValue("//div[@class='uir-record-status']");
				String actual_Subsidiary = uiDriver
						.getValue("//span[@id='subsidiary_lbl_uir_label']//following-sibling::span//span");
				String actual_RevisionNumber = uiDriver.getValue(
						"//span[@id='custbody_nbcu_revision_number_fs_lbl_uir_label']//following-sibling::span");
				String actual_InvoiceType = uiDriver.getValue(
						"//span[@id='custbody_nbcu_inv_type_fs_lbl_uir_label']//following-sibling::span//span");

				String Customer = input.get("Customer");
				String[] expected_Customer = Customer.split(";");
				String DueDate = input.get("DueDate");
				String[] expected_DueDate = DueDate.split(";");
				String ApprovalStatus = input.get("ApprovalStatus");
				String[] expected_ApprovalStatus = ApprovalStatus.split(";");
				String Status = input.get("Status");
				String[] expected_Status = Status.split(";");
				String Subsidiary = input.get("Subsidiary");
				String[] expected_Subsidiary = Subsidiary.split(";");
				String RevisionNumber = input.get("RevisionNumber");
				String[] expected_RevisionNumber = RevisionNumber.split(";");
				String InvoiceType = input.get("InvoiceType");
				String[] expected_InvoiceType = InvoiceType.split(";");

				if (actual_Customer.toLowerCase().trim().contains(expected_Customer[i].toLowerCase().trim())
						|| expected_Customer[i].toLowerCase().trim().contains(actual_Customer.toLowerCase().trim())) {
					passed("Verify Invoice Details", "Customer should be displayed as : " + expected_Customer[i].trim(),
							"Customer is displayed as : " + actual_Customer.trim());
				} else {
					failed("Verify Invoice Details", "Customer should be displayed as : " + expected_Customer[i].trim(),
							"Customer is displayed as : " + actual_Customer.trim());
				}

				if (actual_DueDate.toLowerCase().trim().contains(expected_DueDate[i].toLowerCase().trim())
						|| expected_DueDate[i].toLowerCase().trim().contains(actual_DueDate.toLowerCase().trim())) {
					passed("Verify Invoice Details", "DueDate should be displayed as : " + expected_DueDate[i].trim(),
							"DueDate is displayed as : " + actual_DueDate.trim());
				} else {
					failed("Verify Invoice Details", "DueDate should be displayed as : " + expected_DueDate[i].trim(),
							"DueDate is displayed as : " + actual_DueDate.trim());
				}

				if (actual_ApprovalStatus.toLowerCase().trim().contains(expected_ApprovalStatus[i].toLowerCase().trim())
						|| expected_ApprovalStatus[i].toLowerCase().trim()
								.contains(actual_ApprovalStatus.toLowerCase().trim())) {
					passed("Verify Invoice Details",
							"ApprovalStatus should be displayed as : " + expected_ApprovalStatus[i].trim(),
							"ApprovalStatus is displayed as : " + actual_ApprovalStatus.trim());
				} else {
					failed("Verify Invoice Details",
							"ApprovalStatus should be displayed as : " + expected_ApprovalStatus[i].trim(),
							"ApprovalStatus is displayed as : " + actual_ApprovalStatus.trim());
				}

				if (actual_Status.toLowerCase().trim().contains(expected_Status[i].toLowerCase().trim())
						|| expected_Status[i].toLowerCase().trim().contains(actual_Status.toLowerCase().trim())) {
					passed("Verify Invoice Details", "Status should be displayed as : " + expected_Status[i].trim(),
							"Status is displayed as : " + actual_Status.trim());
				} else {
					failed("Verify Invoice Details", "Status should be displayed as : " + expected_Status[i].trim(),
							"Status is displayed as : " + actual_Status.trim());
				}

				if (actual_Subsidiary.toLowerCase().trim().contains(expected_Subsidiary[i].toLowerCase().trim())
						|| expected_Subsidiary[i].toLowerCase().trim()
								.contains(actual_Subsidiary.toLowerCase().trim())) {
					passed("Verify Invoice Details",
							"Subsidiary should be displayed as : " + expected_Subsidiary[i].trim(),
							"Subsidiary is displayed as : " + actual_Subsidiary.trim());
				} else {
					failed("Verify Invoice Details",
							"Subsidiary should be displayed as : " + expected_Subsidiary[i].trim(),
							"Subsidiary is displayed as : " + actual_Subsidiary.trim());
				}

				if (actual_RevisionNumber.toLowerCase().trim().contains(expected_RevisionNumber[i].toLowerCase().trim())
						|| expected_RevisionNumber[i].toLowerCase().trim()
								.contains(actual_RevisionNumber.toLowerCase().trim())) {
					passed("Verify Invoice Details",
							"RevisionNumber should be displayed as : " + expected_RevisionNumber[i].trim(),
							"RevisionNumber is displayed as : " + actual_RevisionNumber.trim());
				} else {
					failed("Verify Invoice Details",
							"RevisionNumber should be displayed as : " + expected_RevisionNumber[i].trim(),
							"RevisionNumber is displayed as : " + actual_RevisionNumber.trim());
				}

				if (actual_InvoiceType.toLowerCase().trim().contains(expected_InvoiceType[i].toLowerCase().trim())
						|| expected_InvoiceType[i].toLowerCase().trim()
								.contains(actual_InvoiceType.toLowerCase().trim())) {
					passed("Verify Invoice Details",
							"InvoiceType should be displayed as : " + expected_InvoiceType[i].trim(),
							"InvoiceType is displayed as : " + actual_InvoiceType.trim());
				} else {
					failed("Verify Invoice Details",
							"InvoiceType should be displayed as : " + expected_InvoiceType[i].trim(),
							"InvoiceType is displayed as : " + actual_InvoiceType.trim());
				}

				uiDriver.executeJavaScript("scroll(0,500)");

				List<WebElement> LineItems = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tr"));
				int total_LineItems = LineItems.size(), temp = 0;

				for (int j = 2; j <= total_LineItems; j++) {
					List<WebElement> el;
					String xpath = "//table[@id='item_splits']//td[contains(text(),'" + GLPN[k].trim() + "')]";

					if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
							+ GLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title']//..//preceding-sibling::*)+1]")) {
						String actual_Item;
						el = uiDriver.webDr.findElements(
								By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
										+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title']//..//preceding-sibling::*)+1]"));
						try {
							actual_Item = el.get(temp).getText();
						} catch (Exception e) {
							temp = 0;
							actual_Item = el.get(0).getText();
						}

						String expected_Item = Item[k].trim();
						expected_Item = expected_Item.replace("Null", " ");

						if (expected_Item.toLowerCase().trim().contains(actual_Item.toLowerCase().trim())
								|| actual_Item.toLowerCase().trim().contains(expected_Item.toLowerCase().trim())) {
							passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"Item Should be displayed as " + expected_Item,
									"Item is displayed as " + actual_Item);
						} else {
							failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"Item Should be displayed as " + expected_Item,
									"Item is displayed as " + actual_Item);
						}
					}

					if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
							+ GLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Rate']//..//preceding-sibling::*)+1]")) {
						String actual_Rate;
						Float actual_Rate_temp;
						el = uiDriver.webDr.findElements(
								By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
										+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Rate']//..//preceding-sibling::*)+1]"));
						try {
							actual_Rate = el.get(temp).getText();
							actual_Rate = actual_Rate.replace(",", "");
							actual_Rate_temp = Float.parseFloat(actual_Rate);
						} catch (Exception e) {
							temp = 0;
							actual_Rate = el.get(0).getText();
							actual_Rate = actual_Rate.replace(",", "");
							actual_Rate_temp = Float.parseFloat(actual_Rate);
						}

						String expected_Rate = Rate[k].trim();
						expected_Rate = expected_Rate.replace("Null", " ");
						expected_Rate = expected_Rate.replace(",", "");
						Float expected_Rate_temp = Float.parseFloat(actual_Rate);

						if (expected_Rate_temp.toString().trim().contains(actual_Rate_temp.toString().trim())
								|| actual_Rate_temp.toString().trim().contains(expected_Rate_temp.toString().trim())) {
							passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"Rate Should be displayed as " + expected_Rate,
									"Rate is displayed as " + actual_Rate);
						} else {
							failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"Rate Should be displayed as " + expected_Rate,
									"Rate is displayed as " + actual_Rate);
						}
					}

					if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
							+ GLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Tax Code']//..//preceding-sibling::*)+1]")) {
						String actual_TaxCode;
						el = uiDriver.webDr.findElements(
								By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
										+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Tax Code']//..//preceding-sibling::*)+1]"));
						try {
							actual_TaxCode = el.get(temp).getText();
						} catch (Exception e) {
							temp = 0;
							actual_TaxCode = el.get(0).getText();
						}

						String expected_TaxCode = TaxCode[k].trim();
						expected_TaxCode = expected_TaxCode.replace("Null", " ");

						if (expected_TaxCode.toLowerCase().trim().contains(actual_TaxCode.toLowerCase().trim())
								|| actual_TaxCode.toLowerCase().trim()
										.contains(expected_TaxCode.toLowerCase().trim())) {
							passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"TaxCode Should be displayed as " + expected_TaxCode,
									"TaxCode is displayed as " + actual_TaxCode);
						} else {
							failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"TaxCode Should be displayed as " + expected_TaxCode,
									"TaxCode is displayed as " + actual_TaxCode);
						}
					}

					if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
							+ GLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Market Code']//..//preceding-sibling::*)+1]")) {
						String actual_MarketCode;
						el = uiDriver.webDr.findElements(
								By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
										+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Market Code']//..//preceding-sibling::*)+1]"));
						try {
							actual_MarketCode = el.get(temp).getText();
						} catch (Exception e) {
							temp = 0;
							actual_MarketCode = el.get(0).getText();
						}

						String expected_MarketCode = MarketCode[k].trim();
						expected_MarketCode = expected_MarketCode.replace("Null", " ");

						if (expected_MarketCode.toLowerCase().trim().contains(actual_MarketCode.toLowerCase().trim())
								|| actual_MarketCode.toLowerCase().trim()
										.contains(expected_MarketCode.toLowerCase().trim())) {
							passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"MarketCode Should be displayed as " + expected_MarketCode,
									"MarketCode is displayed as " + actual_MarketCode);
						} else {
							failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"MarketCode Should be displayed as " + expected_MarketCode,
									"MarketCode is displayed as " + actual_MarketCode);
						}
					}

					if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
							+ GLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title ID']//..//preceding-sibling::*)+1]")) {
						String actual_TitleID;
						el = uiDriver.webDr.findElements(
								By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
										+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title ID']//..//preceding-sibling::*)+1]"));
						try {
							actual_TitleID = el.get(temp).getText();
						} catch (Exception e) {
							temp = 0;
							actual_TitleID = el.get(0).getText();
						}

						String expected_TitleID = TitleID[k].trim();
						expected_TitleID = expected_TitleID.replace("Null", " ");

						if (expected_TitleID.toLowerCase().trim().contains(actual_TitleID.toLowerCase().trim())
								|| actual_TitleID.toLowerCase().trim()
										.contains(expected_TitleID.toLowerCase().trim())) {
							passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"TitleID Should be displayed as " + expected_TitleID,
									"TitleID is displayed as " + actual_TitleID);
						} else {
							failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"TitleID Should be displayed as " + expected_TitleID,
									"TitleID is displayed as " + actual_TitleID);
						}
					}

					if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
							+ GLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]")) {
						String actual_GLPN;
						el = uiDriver.webDr.findElements(
								By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
										+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]"));
						try {
							actual_GLPN = el.get(temp).getText();
						} catch (Exception e) {
							temp = 0;
							actual_GLPN = el.get(0).getText();
						}

						String expected_GLPN = GLPN[k].trim();
						expected_GLPN = expected_GLPN.replace("Null", " ");

						if (expected_GLPN.toLowerCase().trim().contains(actual_GLPN.toLowerCase().trim())
								|| actual_GLPN.toLowerCase().trim().contains(expected_GLPN.toLowerCase().trim())) {
							passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"GLPN Should be displayed as " + expected_GLPN,
									"GLPN is displayed as " + actual_GLPN);
						} else {
							failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"GLPN Should be displayed as " + expected_GLPN,
									"GLPN is displayed as " + actual_GLPN);
						}
					}

					if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
							+ GLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Owner']//..//preceding-sibling::*)+1]")) {
						String actual_ProductOwner;
						el = uiDriver.webDr.findElements(
								By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
										+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Owner']//..//preceding-sibling::*)+1]"));
						try {
							actual_ProductOwner = el.get(temp).getText();
						} catch (Exception e) {
							temp = 0;
							actual_ProductOwner = el.get(0).getText();
						}

						String expected_ProductOwner = ProductOwner[k].trim();
						expected_ProductOwner = expected_ProductOwner.replace("Null", " ");

						if (expected_ProductOwner.toLowerCase().trim()
								.contains(actual_ProductOwner.toLowerCase().trim())
								|| actual_ProductOwner.toLowerCase().trim()
										.contains(expected_ProductOwner.toLowerCase().trim())) {
							passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"ProductOwner Should be displayed as " + expected_ProductOwner,
									"ProductOwner is displayed as " + actual_ProductOwner);
						} else {
							failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"ProductOwner Should be displayed as " + expected_ProductOwner,
									"ProductOwner is displayed as " + actual_ProductOwner);
						}
					}

					if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
							+ GLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Right']//..//preceding-sibling::*)+1]")) {
						String actual_Right;
						el = uiDriver.webDr.findElements(
								By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
										+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Right']//..//preceding-sibling::*)+1]"));
						try {
							actual_Right = el.get(temp).getText();
						} catch (Exception e) {
							temp = 0;
							actual_Right = el.get(0).getText();
						}

						String expected_Right = Right[k].trim();
						expected_Right = expected_Right.replace("Null", " ");

						if (expected_Right.toLowerCase().trim().contains(actual_Right.toLowerCase().trim())
								|| actual_Right.toLowerCase().trim().contains(expected_Right.toLowerCase().trim())) {
							passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"Right Should be displayed as " + expected_Right,
									"Right is displayed as " + actual_Right);
						} else {
							failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"Right Should be displayed as " + expected_Right,
									"Right is displayed as " + actual_Right);
						}
					}

					if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
							+ GLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled Revenue Account']//..//preceding-sibling::*)+1]")) {
						String actual_UnbilledRevenueAccount;
						el = uiDriver.webDr.findElements(
								By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
										+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled Revenue Account']//..//preceding-sibling::*)+1]"));
						try {
							actual_UnbilledRevenueAccount = el.get(temp).getText();
						} catch (Exception e) {
							temp = 0;
							actual_UnbilledRevenueAccount = el.get(0).getText();
						}

						String expected_UnbilledRevenueAccount = UnbilledRevenueAccount[k].trim();
						expected_UnbilledRevenueAccount = expected_UnbilledRevenueAccount.replace("Null", " ");

						if (expected_UnbilledRevenueAccount.toLowerCase().trim()
								.contains(actual_UnbilledRevenueAccount.toLowerCase().trim())
								|| actual_UnbilledRevenueAccount.toLowerCase().trim()
										.contains(expected_UnbilledRevenueAccount.toLowerCase().trim())) {
							passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"UnbilledRevenueAccount Should be displayed as " + expected_UnbilledRevenueAccount,
									"UnbilledRevenueAccount is displayed as " + actual_UnbilledRevenueAccount);
						} else {
							failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"UnbilledRevenueAccount Should be displayed as " + expected_UnbilledRevenueAccount,
									"UnbilledRevenueAccount is displayed as " + actual_UnbilledRevenueAccount);
						}
					}

					if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
							+ GLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed Revenue Account']//..//preceding-sibling::*)+1]")) {
						String actual_BilledRevenueAccount;
						el = uiDriver.webDr.findElements(
								By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
										+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed Revenue Account']//..//preceding-sibling::*)+1]"));
						try {
							actual_BilledRevenueAccount = el.get(temp).getText();
						} catch (Exception e) {
							temp = 0;
							actual_BilledRevenueAccount = el.get(0).getText();
						}

						String expected_BilledRevenueAccount = BilledRevenueAccount[k].trim();
						expected_BilledRevenueAccount = expected_BilledRevenueAccount.replace("Null", " ");

						if (expected_BilledRevenueAccount.toLowerCase().trim()
								.contains(actual_BilledRevenueAccount.toLowerCase().trim())
								|| actual_BilledRevenueAccount.toLowerCase().trim()
										.contains(expected_BilledRevenueAccount.toLowerCase().trim())) {
							passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"BilledRevenueAccount Should be displayed as " + expected_BilledRevenueAccount,
									"BilledRevenueAccount is displayed as " + actual_BilledRevenueAccount);
						} else {
							failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"BilledRevenueAccount Should be displayed as " + expected_BilledRevenueAccount,
									"BilledRevenueAccount is displayed as " + actual_BilledRevenueAccount);
						}
					}

					if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
							+ GLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed AR Account']//..//preceding-sibling::*)+1]")) {
						String actual_BilledARAccount;
						el = uiDriver.webDr.findElements(
								By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
										+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed AR Account']//..//preceding-sibling::*)+1]"));
						try {
							actual_BilledARAccount = el.get(temp).getText();
						} catch (Exception e) {
							temp = 0;
							actual_BilledARAccount = el.get(0).getText();
						}

						String expected_BilledARAccount = BilledARAccount[k].trim();
						expected_BilledARAccount = expected_BilledARAccount.replace("Null", " ");

						if (expected_BilledARAccount.toLowerCase().trim()
								.contains(actual_BilledARAccount.toLowerCase().trim())
								|| actual_BilledARAccount.toLowerCase().trim()
										.contains(expected_BilledARAccount.toLowerCase().trim())) {
							passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"BilledARAccount Should be displayed as " + expected_BilledARAccount,
									"BilledARAccount is displayed as " + actual_BilledARAccount);
						} else {
							failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"BilledARAccount Should be displayed as " + expected_BilledARAccount,
									"BilledARAccount is displayed as " + actual_BilledARAccount);
						}
					}

					if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
							+ GLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled AR Account']//..//preceding-sibling::*)+1]")) {
						String actual_UnbilledARAccount;
						el = uiDriver.webDr.findElements(
								By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
										+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled AR Account']//..//preceding-sibling::*)+1]"));
						try {
							actual_UnbilledARAccount = el.get(temp).getText();
						} catch (Exception e) {
							temp = 0;
							actual_UnbilledARAccount = el.get(0).getText();
						}

						String expected_UnbilledARAccount = UnbilledARAccount[k].trim();
						expected_UnbilledARAccount = expected_UnbilledARAccount.replace("Null", " ");

						if (expected_UnbilledARAccount.toLowerCase().trim()
								.contains(actual_UnbilledARAccount.toLowerCase().trim())
								|| actual_UnbilledARAccount.toLowerCase().trim()
										.contains(expected_UnbilledARAccount.toLowerCase().trim())) {
							passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"UnbilledARAccount Should be displayed as " + expected_UnbilledARAccount,
									"UnbilledARAccount is displayed as " + actual_UnbilledARAccount);
						} else {
							failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"UnbilledARAccount Should be displayed as " + expected_UnbilledARAccount,
									"UnbilledARAccount is displayed as " + actual_UnbilledARAccount);
						}
					}

					if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
							+ GLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Paid Deferred Account']//..//preceding-sibling::*)+1]")) {
						String actual_PaidDeferredRevenueAccount;
						el = uiDriver.webDr.findElements(
								By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
										+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Paid Deferred Account']//..//preceding-sibling::*)+1]"));
						try {
							actual_PaidDeferredRevenueAccount = el.get(temp).getText();
						} catch (Exception e) {
							temp = 0;
							actual_PaidDeferredRevenueAccount = el.get(0).getText();
						}

						String expected_PaidDeferredRevenueAccount = PaidDeferredRevenueAccount[k].trim();
						expected_PaidDeferredRevenueAccount = expected_PaidDeferredRevenueAccount.replace("Null", " ");

						if (expected_PaidDeferredRevenueAccount.toLowerCase().trim()
								.contains(actual_PaidDeferredRevenueAccount.toLowerCase().trim())
								|| actual_PaidDeferredRevenueAccount.toLowerCase().trim()
										.contains(expected_PaidDeferredRevenueAccount.toLowerCase().trim())) {
							passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"PaidDeferredRevenueAccount Should be displayed as "
											+ expected_PaidDeferredRevenueAccount,
									"PaidDeferredRevenueAccount is displayed as " + actual_PaidDeferredRevenueAccount);
						} else {
							failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"PaidDeferredRevenueAccount Should be displayed as "
											+ expected_PaidDeferredRevenueAccount,
									"PaidDeferredRevenueAccount is displayed as " + actual_PaidDeferredRevenueAccount);
						}
					}

					if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
							+ GLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unpaid Deferred Account']//..//preceding-sibling::*)+1]")) {
						String actual_UnpaidDeferredRevenueAccount;
						el = uiDriver.webDr.findElements(
								By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
										+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unpaid Deferred Account']//..//preceding-sibling::*)+1]"));
						try {
							actual_UnpaidDeferredRevenueAccount = el.get(temp).getText();
						} catch (Exception e) {
							temp = 0;
							actual_UnpaidDeferredRevenueAccount = el.get(0).getText();
						}

						String expected_UnpaidDeferredRevenueAccount = UnpaidDeferredRevenueAccount[k].trim();
						expected_UnpaidDeferredRevenueAccount = expected_UnpaidDeferredRevenueAccount.replace("Null",
								" ");

						if (expected_UnpaidDeferredRevenueAccount.toLowerCase().trim()
								.contains(actual_UnpaidDeferredRevenueAccount.toLowerCase().trim())
								|| actual_UnpaidDeferredRevenueAccount.toLowerCase().trim()
										.contains(expected_UnpaidDeferredRevenueAccount.toLowerCase().trim())) {
							passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"UnpaidDeferredRevenueAccount Should be displayed as "
											+ expected_UnpaidDeferredRevenueAccount,
									"UnpaidDeferredRevenueAccount is displayed as "
											+ actual_UnpaidDeferredRevenueAccount);
						} else {
							failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"UnpaidDeferredRevenueAccount Should be displayed as "
											+ expected_UnpaidDeferredRevenueAccount,
									"UnpaidDeferredRevenueAccount is displayed as "
											+ actual_UnpaidDeferredRevenueAccount);
						}
					}

					if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
							+ GLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Bad Debt Revenue Account']//..//preceding-sibling::*)+1]")) {
						String actual_BadDebtRevenueAccount;
						el = uiDriver.webDr.findElements(
								By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
										+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Bad Debt Revenue Account']//..//preceding-sibling::*)+1]"));
						try {
							actual_BadDebtRevenueAccount = el.get(temp).getText();
						} catch (Exception e) {
							temp = 0;
							actual_BadDebtRevenueAccount = el.get(0).getText();
						}

						String expected_BadDebtRevenueAccount = BadDebtRevenueAccount[k].trim();
						expected_BadDebtRevenueAccount = expected_BadDebtRevenueAccount.replace("Null", " ");

						if (expected_BadDebtRevenueAccount.toLowerCase().trim()
								.contains(actual_BadDebtRevenueAccount.toLowerCase().trim())
								|| actual_BadDebtRevenueAccount.toLowerCase().trim()
										.contains(expected_BadDebtRevenueAccount.toLowerCase().trim())) {
							passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"BadDebtRevenueAccount Should be displayed as " + expected_BadDebtRevenueAccount,
									"BadDebtRevenueAccount is displayed as " + actual_BadDebtRevenueAccount);
						} else {
							failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN " + GLPN[k],
									"BadDebtRevenueAccount Should be displayed as " + expected_BadDebtRevenueAccount,
									"BadDebtRevenueAccount is displayed as " + actual_BadDebtRevenueAccount);
						}
					}

					if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
							+ GLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Quantity']//..//preceding-sibling::*)+1]")) {
						String actual_Quantity;
						Float actual_Quantity_temp;
						el = uiDriver.webDr.findElements(
								By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
										+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Quantity']//..//preceding-sibling::*)+1]"));
						try {
							actual_Quantity = el.get(temp).getText();
							actual_Quantity = actual_Quantity.replace(",", "");
							actual_Quantity = actual_Quantity.replace("$", "");
							actual_Quantity_temp = Float.parseFloat(actual_Quantity);
						} catch (Exception e) {
							temp = 0;
							actual_Quantity = el.get(0).getText();
							actual_Quantity = actual_Quantity.replace(",", "");
							actual_Quantity = actual_Quantity.replace("$", "");
							actual_Quantity_temp = Float.parseFloat(actual_Quantity);
						}

						try {
							String expected_Quantity = Quantity[k].trim();
							expected_Quantity = expected_Quantity.replace("Null", " ");
							expected_Quantity = expected_Quantity.replace(",", "");
							expected_Quantity = expected_Quantity.replace("$", "");
							Float expected_Quantity_temp = Float.parseFloat(expected_Quantity);

							if (expected_Quantity_temp.toString().trim()
									.contains(actual_Quantity_temp.toString().trim())
									|| actual_Quantity_temp.toString().trim()
											.contains(expected_Quantity_temp.toString().trim())) {
								passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN "
										+ GLPN[k], "Quantity Should be displayed as " + expected_Quantity,
										"Quantity is displayed as " + actual_Quantity);
							} else {
								failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN "
										+ GLPN[k], "Quantity Should be displayed as " + expected_Quantity,
										"Quantity is displayed as " + actual_Quantity);
							}
						} catch (Exception e) {
						}
					}

					if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'"
							+ GLPN[k].trim()
							+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Amount']//..//preceding-sibling::*)+1]")) {
						String actual_Amount;
						Float actual_Amount_temp;
						el = uiDriver.webDr.findElements(
								By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
										+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Amount']//..//preceding-sibling::*)+1]"));
						try {
							actual_Amount = el.get(temp).getText();
							actual_Amount = actual_Amount.replace(",", "");
							actual_Amount_temp = Float.parseFloat(actual_Amount);
						} catch (Exception e) {
							temp = 0;
							actual_Amount = el.get(0).getText();
							actual_Amount = actual_Amount.replace(",", "");
							actual_Amount_temp = Float.parseFloat(actual_Amount);
						}

						try {
							String expected_Amount = Amount[k].trim();
							expected_Amount = expected_Amount.replace("Null", " ");
							expected_Amount = expected_Amount.replace(",", "");
							Float expected_Amount_temp = Float.parseFloat(expected_Amount);

							if (expected_Amount_temp.toString().trim().contains(actual_Amount_temp.toString().trim())
									|| actual_Amount_temp.toString().trim()
											.contains(expected_Amount_temp.toString().trim())) {
								passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN "
										+ GLPN[k], "Amount Should be displayed as " + expected_Amount,
										"Amount is displayed as " + actual_Amount);
							} else {
								failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1) + "-Line Item for GLPN "
										+ GLPN[k], "Amount Should be displayed as " + expected_Amount,
										"Amount is displayed as " + actual_Amount);
							}
						} catch (Exception e) {
						}
					}

					el = uiDriver.webDr.findElements(By.xpath(xpath));
					if (el.size() > 1) {
						temp++;
					} else {
						temp = 0;
					}

					k++;
				}

				if (uiDriver.checkElementPresent("//input[@id='_back']")) {
					uiDriver.executeJavaScript("scroll(0,-1000)");
					uiDriver.click("//input[@id='_back']");
				} else {
					uiDriver.back();
				}
			}
		} catch (Exception e) {
			failed("ValidateAllInvoiceData", "Error in ValidateAllInvoiceData method", "Error : " + e.toString());
		}
	}

	public void VerifyGlAccountData(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.HIGH);

		String ACCOUNT = input.get("ACCOUNT");
		String ACCOUNTS[] = ACCOUNT.split(";");

		String DEBIT = input.get("DEBIT");
		String DEBITS[] = DEBIT.split(";");

		String CREDIT = input.get("CREDIT");
		String CREDITS[] = CREDIT.split(";");

		String Name = input.get("Name");
		String Names[] = Name.split(";");

		String Subsidiary = input.get("Subsidiary");
		String Subsidiarys[] = Subsidiary.split(";");

		String MarketCode = input.get("MarketCode");
		String MarketCodes[] = MarketCode.split(";");

		String Territory = input.get("Territory");
		String Territorys[] = Territory.split(";");

		String GLPN = input.get("GLPN");
		String GLPNS[] = GLPN.split(";");

		System.out.println(ACCOUNTS.length);

		int temp = 0;

		try {
			for (int k = 0; k < GLPNS.length; k++) {

				String xpath = "//table[@id='div__bodytab']//td[contains(text(),'" + GLPNS[k].trim() + "')]";

				if (uiDriver.checkElementPresent("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
						+ GLPNS[k].trim().replace("NULL", " ")
						+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Account']//..//preceding-sibling::*)+1]")) {
					List<WebElement> el = uiDriver.webDr
							.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
									+ GLPNS[k].trim().replace("NULL",
											" ")
									+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Account']//..//preceding-sibling::*)+1]"));

					String actual_Account;

					try {
						actual_Account = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_Account = el.get(temp).getText();
					}

					String expected_Account = ACCOUNTS[k].trim();
					if (actual_Account != null && !actual_Account.equals(" ") && !actual_Account.equals("")) {
						if (expected_Account.toLowerCase().contains(actual_Account.toLowerCase())
								|| actual_Account.toLowerCase().contains(expected_Account.toLowerCase())) {
							passed("VerifyGLImpactData", "Account Should be displayed as " + expected_Account,
									"Account is displayed as " + actual_Account);
						} else {
							failed("VerifyGLImpactData", "Account Should be displayed as " + expected_Account,
									"Account is not displayed as " + actual_Account);
						}
					} else {
						// nothing
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
						+ GLPNS[k].trim().replace("NULL", " ")
						+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Name']//..//preceding-sibling::*)-6]")) {
					List<WebElement> el = uiDriver.webDr
							.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
									+ GLPNS[k].trim().replace("NULL",
											" ")
									+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Name']//..//preceding-sibling::*)-6]"));

					String actual_Name;

					try {
						actual_Name = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_Name = el.get(temp).getText();
					}

					String expected_Name = Names[k].trim();

					if (actual_Name != null && !actual_Name.equals(" ") && !actual_Name.equals("")) {
						if (expected_Name.toLowerCase().contains(actual_Name.toLowerCase())
								|| actual_Name.toLowerCase().contains(expected_Name.toLowerCase())) {
							passed("VerifyGLImpactData", "Name Should be displayed as " + expected_Name,
									"Name is displayed as " + actual_Name);
						} else {
							failed("VerifyGLImpactData", "Name Should be displayed as " + expected_Name,
									"Name should not be displayed as " + actual_Name);
						}
					} else {
						// nothing
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
						+ GLPNS[k].trim().replace("NULL", " ")
						+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Subsidiary']//..//preceding-sibling::*)-5]")) {
					List<WebElement> el = uiDriver.webDr
							.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
									+ GLPNS[k].trim().replace("NULL",
											" ")
									+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Subsidiary']//..//preceding-sibling::*)-5]"));

					String actual_Subsidiary;

					try {
						actual_Subsidiary = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_Subsidiary = el.get(temp).getText();
					}

					String expected_Subsidiary = Subsidiarys[k].trim();

					if (actual_Subsidiary != null && !actual_Subsidiary.equals(" ") && !actual_Subsidiary.equals("")) {
						if (expected_Subsidiary.toLowerCase().contains(actual_Subsidiary.toLowerCase())
								|| actual_Subsidiary.toLowerCase().contains(expected_Subsidiary.toLowerCase())) {
							passed("VerifyGLImpactData", "Subsidiary Should be displayed as " + expected_Subsidiary,
									"Subsidiary is displayed as " + actual_Subsidiary);
						} else {
							failed("VerifyGLImpactData", "Subsidiary Should be displayed as " + expected_Subsidiary,
									"Subsidiary should not be displayed as " + actual_Subsidiary);
						}
					} else {
						// nothing
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
						+ GLPNS[k].trim().replace("NULL", " ")
						+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Market Code']//..//preceding-sibling::*)-6]")) {
					List<WebElement> el = uiDriver.webDr
							.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
									+ GLPNS[k].trim().replace("NULL",
											" ")
									+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Market Code']//..//preceding-sibling::*)-6]"));

					String actual_MarketCode;

					try {
						actual_MarketCode = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_MarketCode = el.get(temp).getText();
					}

					String expected_MarketCode = MarketCodes[k].trim();

					if (actual_MarketCode != null && !actual_MarketCode.equals(" ") && !actual_MarketCode.equals("")) {
						if (expected_MarketCode.toLowerCase().contains(actual_MarketCode.toLowerCase())
								|| actual_MarketCode.toLowerCase().contains(expected_MarketCode.toLowerCase())) {
							passed("VerifyGLImpactData", "MarketCode Should be displayed as " + expected_MarketCode,
									"MarketCode is displayed as " + actual_MarketCode);
						} else {
							failed("VerifyGLImpactData", "MarketCode Should be displayed as " + expected_MarketCode,
									"MarketCode should not be displayed as " + actual_MarketCode);
						}
					} else {
						// nothing
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
						+ GLPNS[k].trim().replace("NULL", " ")
						+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Territory']//..//preceding-sibling::*)-7]")) {
					List<WebElement> el = uiDriver.webDr
							.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
									+ GLPNS[k].trim().replace("NULL",
											" ")
									+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Territory']//..//preceding-sibling::*)-7]"));

					String actual_Territory;

					try {
						actual_Territory = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_Territory = el.get(temp).getText();
					}

					String expected_Territory = Territorys[k].trim();

					if (actual_Territory != null && !actual_Territory.equals(" ") && !actual_Territory.equals("")) {
						if (expected_Territory.toLowerCase().contains(actual_Territory.toLowerCase())
								|| actual_Territory.toLowerCase().contains(expected_Territory.toLowerCase())) {
							passed("VerifyGLImpactData", "Territory Should be displayed as " + expected_Territory,
									"Territory is displayed as " + actual_Territory);
						} else {
							failed("VerifyGLImpactData", "Territory Should be displayed as " + expected_Territory,
									"Territory should not be displayed as " + actual_Territory);
						}
					} else {
						// nothing
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
						+ GLPNS[k].trim().replace("NULL", " ")
						+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Amount (Debit)']/../preceding-sibling::*)]")) {
					List<WebElement> el = uiDriver.webDr
							.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
									+ GLPNS[k].trim().replace("NULL",
											" ")
									+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Amount (Debit)']/../preceding-sibling::*)]"));
					String actual_Debit;
					try {
						actual_Debit = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_Debit = el.get(temp).getText();
					}

					String expected_Debit = DEBITS[k].trim();
					if (actual_Debit != null && !actual_Debit.equals(" ") && !actual_Debit.equals("")) {
						try {
							expected_Debit = expected_Debit.replace(",", "");
							expected_Debit = expected_Debit.replace("$", "");

							actual_Debit = actual_Debit.replace(",", "");
							actual_Debit = actual_Debit.replace("$", "");

							Float exp_Debit_exchanged = Float.parseFloat(expected_Debit)
									* Float.parseFloat(text_ExchangeNumber);
							Float act_Debit_exchanged = Float.parseFloat(actual_Debit)
									* Float.parseFloat(text_ExchangeNumber);
							exp_Debit_exchanged = (float) Math.round(exp_Debit_exchanged);
							act_Debit_exchanged = (float) Math.round(act_Debit_exchanged);

							Float exp_Debit = Float.parseFloat(expected_Debit);
							Float act_Debit = Float.parseFloat(actual_Debit);
							exp_Debit = (float) Math.round(exp_Debit);
							act_Debit = (float) Math.round(act_Debit);

							if (exp_Debit_exchanged.toString().trim().contains(act_Debit_exchanged.toString().trim())
									|| act_Debit_exchanged.toString().trim()
											.contains(exp_Debit_exchanged.toString().trim())
									|| exp_Debit.toString().trim().contains(act_Debit.toString().trim())
									|| act_Debit.toString().trim().contains(exp_Debit.toString().trim())
									|| exp_Debit_exchanged.toString().trim().contains(act_Debit.toString().trim())
									|| act_Debit.toString().trim().contains(exp_Debit_exchanged.toString().trim())
									|| exp_Debit.toString().trim().contains(act_Debit_exchanged.toString().trim())
									|| act_Debit_exchanged.toString().trim().contains(exp_Debit.toString().trim())) {
								passed("VerifyGLImpactData", "Debit Amount Should be displayed as " + expected_Debit,
										"Debit Amount is displayed as " + actual_Debit);
							} else {
								failed("VerifyGLImpactData", "Debit Amount Should be displayed as " + expected_Debit,
										"Debit Amount should not be displayed as " + actual_Debit);
							}
						} catch (Exception e) {
						}
					} else {
						// Null
					}
				}

				if (uiDriver.checkElementPresent("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
						+ GLPNS[k].trim().replace("NULL", " ")
						+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Amount (Credit)']//..//preceding-sibling::*)-1]")) {
					List<WebElement> el = uiDriver.webDr
							.findElements(By.xpath("//table[@id='div__bodytab']//tbody//td[contains(text(),'"
									+ GLPNS[k].trim().replace("NULL",
											" ")
									+ "')]//..//td[count(//table[@id='div__bodytab']//td//div[text()='Amount (Credit)']//..//preceding-sibling::*)-1]"));
					String actual_Credit;
					try {
						actual_Credit = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						actual_Credit = el.get(temp).getText();
					}

					String expected_Credit = CREDITS[k].trim();
					if (actual_Credit != null && !actual_Credit.equals(" ") && !actual_Credit.equals("")) {
						try {
							expected_Credit = expected_Credit.replace(",", "");
							expected_Credit = expected_Credit.replace("$", "");

							actual_Credit = actual_Credit.replace(",", "");
							actual_Credit = actual_Credit.replace("$", "");

							Float exp_Credit_exchanged = Float.parseFloat(expected_Credit)
									* Float.parseFloat(text_ExchangeNumber);
							Float act_Credit_exchanged = Float.parseFloat(actual_Credit)
									* Float.parseFloat(text_ExchangeNumber);
							exp_Credit_exchanged = (float) Math.round(exp_Credit_exchanged);
							act_Credit_exchanged = (float) Math.round(act_Credit_exchanged);

							Float exp_Credit = Float.parseFloat(expected_Credit);
							Float act_Credit = Float.parseFloat(actual_Credit);
							exp_Credit = (float) Math.round(exp_Credit);
							act_Credit = (float) Math.round(act_Credit);

							if (exp_Credit_exchanged.toString().trim().contains(act_Credit_exchanged.toString().trim())
									|| act_Credit_exchanged.toString().trim()
											.contains(exp_Credit_exchanged.toString().trim())
									|| exp_Credit.toString().trim().contains(act_Credit.toString().trim())
									|| act_Credit.toString().trim().contains(exp_Credit.toString().trim())
									|| exp_Credit_exchanged.toString().trim().contains(act_Credit.toString().trim())
									|| act_Credit.toString().trim().contains(exp_Credit_exchanged.toString().trim())
									|| exp_Credit.toString().trim().contains(act_Credit_exchanged.toString().trim())
									|| act_Credit_exchanged.toString().trim().contains(exp_Credit.toString().trim())) {
								passed("VerifyGLImpactData", "Credit Amount Should be displayed as " + expected_Credit,
										"Credit Amount is displayed as " + actual_Credit);
							} else {
								failed("VerifyGLImpactData", "Credit Amount Should be displayed as " + expected_Credit,
										"Credit Amount should not be displayed as " + actual_Credit);
							}
						} catch (Exception e) {
						}
					} else {
						// Null
					}
				}

				List<WebElement> el = uiDriver.webDr.findElements(By.xpath(xpath));

				if (el.size() > 1) {
					temp++;
				} else {
					temp = 0;
				}
			}

			while (true) {
				if (uiDriver.checkElementPresent("//h1[text()='Invoice' or text()='Payment' "
						+ "or text()='Title Allocation Parent' or text()='Revenue Arrangement' "
						+ "or text()='Customer Credit'  or text()='Credit Memo']")) {
					break;
				} else {
					uiDriver.back();
					SleepUtils.sleep(TimeSlab.YIELD);
				}
			}
		} catch (Exception e) {
			while (true) {
				if (uiDriver.checkElementPresent("//h1[text()='Invoice' or text()='Payment' "
						+ "or text()='Title Allocation Parent' or text()='Revenue Arrangement' "
						+ "or text()='Customer Credit'  or text()='Credit Memo']")) {
					break;
				} else {
					uiDriver.back();
					SleepUtils.sleep(TimeSlab.YIELD);
				}
			}

			error("VerifyGlAccountData", "Error in VerifyGlAccountData method", "Error : " + e.toString());
		}

	}

	public void VeryfyJeGeneric(DataRow input, DataRow output) {

		SleepUtils.sleep(TimeSlab.HIGH);

		String ACCOUNT = input.get("ACCOUNT");
		String ACCOUNTS[] = ACCOUNT.split(";");

		String DEBIT = input.get("DEBIT");
		String DEBITS[] = DEBIT.split(";");

		String CREDIT = input.get("CREDIT");
		String CREDITS[] = CREDIT.split(";");

		String Name = input.get("Name");
		String Names[] = Name.split(";");

		String Subsidiary = input.get("Subsidiary");
		String Subsidiarys[] = Subsidiary.split(";");

		String MarketCode = input.get("MarketCode");
		String MarketCodes[] = MarketCode.split(";");

		String Territory = input.get("Territory");
		String Territorys[] = Territory.split(";");

		String GLPN = input.get("GLPN");
		String GLPNS[] = GLPN.split(";");

		System.out.println(ACCOUNTS.length);

		try {
			List<WebElement> NoRows = uiDriver.webDr.findElements(By.xpath("//*[@id='line_splits']/tbody/tr"));
			int temp = 0, k = 0;
			for (int i = 0; i < NoRows.size() - 1; i++) {

				String xpath = "//table[@id='line_splits']//td[contains(text(),'" + GLPNS[k].trim() + "')]";

				String xpath_Project = "//*[contains(text(),'Generic') or contains(text(),'Deferred Rev -Unpaid - Intl') "
						+ "or contains(text(),'Clearing') or contains(text(),'Expense')]";

				if (uiDriver.checkElementPresent(xpath_Project)) {

					// Account
					List<WebElement> el = uiDriver.webDr.findElements(
							By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'" + GLPNS[k].trim()
									+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Account']//..//preceding-sibling::*)+1]"));

					String Account;
					try {
						Account = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						Account = el.get(temp).getText();
					}

					String actual_ACCOUNTS = Account;
					if (actual_ACCOUNTS != null && !actual_ACCOUNTS.equals(" ") && !actual_ACCOUNTS.equals("")) {

						String expected_ACCOUNTS = ACCOUNTS[k].trim();
						if (expected_ACCOUNTS.toLowerCase().trim().contains(actual_ACCOUNTS.toLowerCase().trim())
								|| actual_ACCOUNTS.toLowerCase().trim()
										.contains(expected_ACCOUNTS.toLowerCase().trim())) {

							passed("Validate Journal",
									ACCOUNTS[k].trim() + " Account should be displayed as " + ACCOUNTS[k].trim(),
									ACCOUNTS[k].trim() + " Account is displayed as " + actual_ACCOUNTS.trim());
						} else {
							failed("Validate Journal",
									ACCOUNTS[k].trim() + " Account should be displayed as " + ACCOUNTS[k].trim(),
									ACCOUNTS[k].trim() + " Account is displayed as " + actual_ACCOUNTS.trim());
						}
					} else {
					}

					el = uiDriver.webDr.findElements(By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'"
							+ GLPNS[k].trim()
							+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Name']//..//preceding-sibling::*)+1]"));

					String name;
					try {
						name = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						name = el.get(temp).getText();
					}

					String actual_name = name;
					if (actual_name != null && !actual_name.equals(" ") && !actual_name.equals("")) {

						String expected_name = Names[k].trim();
						if (expected_name.toLowerCase().trim().contains(actual_name.toLowerCase().trim())
								|| actual_name.toLowerCase().trim().contains(expected_name.toLowerCase().trim())) {

							passed("Validate Journal",
									Names[k].trim() + " Names should be displayed as " + Names[k].trim(),
									Names[k].trim() + " Names is displayed as " + actual_name.trim());
						} else {
							failed("Validate Journal",
									Names[k].trim() + " Names should be displayed as " + Names[k].trim(),
									Names[k].trim() + " Names is displayed as " + actual_name.trim());
						}
					} else {
					}

					// Market code
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'"
							+ GLPNS[k].trim()
							+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Market Code']//..//preceding-sibling::*)+1]"));

					String Marketcode;
					try {
						Marketcode = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						Marketcode = el.get(temp).getText();
					}

					String actual_Marketcode = Marketcode;
					if (actual_Marketcode != null && !actual_Marketcode.equals(" ") && !actual_Marketcode.equals("")) {

						String expected_Marketcode = MarketCodes[k].trim();
						if (expected_Marketcode.toLowerCase().trim().contains(actual_Marketcode.toLowerCase().trim())
								|| actual_Marketcode.toLowerCase().trim()
										.contains(expected_Marketcode.toLowerCase().trim())) {

							passed("Validate Journal",
									MarketCodes[k].trim() + " MarketCode should be displayed as "
											+ MarketCodes[k].trim(),
									MarketCodes[k].trim() + " MarketCode is displayed as " + actual_Marketcode.trim());
						} else {
							failed("Validate Journal",
									MarketCodes[k].trim() + " MarketCode should be displayed as "
											+ MarketCodes[k].trim(),
									MarketCodes[k].trim() + " MarketCode is displayed as " + actual_Marketcode.trim());
						}
					} else {
					}

					// Territory
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'"
							+ GLPNS[k].trim()
							+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Territory']//..//preceding-sibling::*)+1]"));

					String territory;
					try {
						territory = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						territory = el.get(temp).getText();
					}

					String actual_territory = territory;
					if (actual_territory != null && !actual_territory.equals(" ") && !actual_territory.equals("")) {

						String expected_territory = Territorys[k].trim();
						if (expected_territory.toLowerCase().trim().contains(actual_territory.toLowerCase().trim())
								|| actual_territory.toLowerCase().trim()
										.contains(expected_territory.toLowerCase().trim())) {

							passed("Validate Journal",
									Territorys[k].trim() + " Territorys should be displayed as " + Territorys[k].trim(),
									Territorys[k].trim() + " Territorys is displayed as " + actual_territory.trim());
						} else {
							failed("Validate Journal",
									Territorys[k].trim() + " Territorys should be displayed as " + Territorys[k].trim(),
									Territorys[k].trim() + " Territorys is displayed as " + actual_territory.trim());
						}
					} else {
					}

					// GLPN
					el = uiDriver.webDr.findElements(By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'"
							+ GLPNS[k].trim()
							+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]"));

					String GLPn;
					try {
						GLPn = el.get(temp).getText();
					} catch (Exception e) {
						temp = 0;
						GLPn = el.get(temp).getText();
					}

					String actual_GLPN = GLPn;
					if (actual_GLPN != null && !actual_GLPN.equals(" ") && !actual_GLPN.equals("")) {

						String expected_GLPN = GLPNS[k].trim();
						if (expected_GLPN.toLowerCase().trim().contains(actual_GLPN.toLowerCase().trim())
								|| actual_GLPN.toLowerCase().trim().contains(expected_GLPN.toLowerCase().trim())) {

							passed("Validate Journal",
									GLPNS[k].trim() + " GLPNS should be displayed as " + GLPNS[k].trim(),
									GLPNS[k].trim() + " GLPNS is displayed as " + actual_GLPN.trim());
						} else {
							failed("Validate Journal",
									GLPNS[k].trim() + " GLPNS should be displayed as " + GLPNS[k].trim(),
									GLPNS[k].trim() + " GLPNS is displayed as " + actual_GLPN.trim());
						}
					} else {
					}

					String actual_Subsidiary = uiDriver.getValue("//*[text()='Subsidiary']/following::span[1]");

					if (actual_Subsidiary != null && !actual_Subsidiary.equals(" ") && !actual_Subsidiary.equals("")) {

						String expected_Subsidiary = Subsidiarys[i].trim();
						if (expected_Subsidiary.toLowerCase().trim().contains(actual_Subsidiary.toLowerCase().trim())
								|| actual_Subsidiary.toLowerCase().trim()
										.contains(expected_Subsidiary.toLowerCase().trim())) {

							passed("Validate Journal",
									Subsidiarys[i].trim() + " Subsidiary should be displayed as "
											+ Subsidiarys[i].trim(),
									Subsidiarys[i].trim() + " Subsidiary is displayed as " + actual_Subsidiary.trim());
						} else {
							failed("Validate Journal",
									Subsidiarys[i].trim() + " Subsidiary should be displayed as "
											+ Subsidiarys[i].trim(),
									Subsidiarys[i].trim() + " Subsidiary is displayed as " + actual_Subsidiary.trim());
						}
					} else {
					}

					// Debit
					if (uiDriver.checkElementPresent("//table[@id='line_splits']//tbody//td[contains(text(),'"
							+ GLPNS[k].trim()
							+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Debit']//..//preceding-sibling::*)+1]")) {
						el = uiDriver.webDr.findElements(
								By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'" + GLPNS[k].trim()
										+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Debit']//..//preceding-sibling::*)+1]"));

						String actual_Debit;
						try {
							actual_Debit = el.get(temp).getText();
						} catch (Exception e) {
							temp = 0;
							actual_Debit = el.get(temp).getText();
						}

						String expected_Debit = DEBITS[k].trim();
						if (actual_Debit != null && !actual_Debit.equals(" ") && !actual_Debit.equals("")) {
							try {
								expected_Debit = expected_Debit.replace(",", "");
								expected_Debit = expected_Debit.replace("$", "");

								actual_Debit = actual_Debit.replace(",", "");
								actual_Debit = actual_Debit.replace("$", "");

								Float exp_Debit_exchanged = Float.parseFloat(expected_Debit)
										* Float.parseFloat(text_ExchangeNumber);
								Float act_Debit_exchanged = Float.parseFloat(actual_Debit)
										* Float.parseFloat(text_ExchangeNumber);
								exp_Debit_exchanged = (float) Math.round(exp_Debit_exchanged);
								act_Debit_exchanged = (float) Math.round(act_Debit_exchanged);

								Float exp_Debit = Float.parseFloat(expected_Debit);
								Float act_Debit = Float.parseFloat(actual_Debit);
								exp_Debit = (float) Math.round(exp_Debit);
								act_Debit = (float) Math.round(act_Debit);

								if (exp_Debit_exchanged.toString().trim()
										.contains(act_Debit_exchanged.toString().trim())
										|| act_Debit_exchanged.toString().trim()
												.contains(exp_Debit_exchanged.toString().trim())
										|| exp_Debit.toString().trim().contains(act_Debit.toString().trim())
										|| act_Debit.toString().trim().contains(exp_Debit.toString().trim())
										|| exp_Debit_exchanged.toString().trim().contains(act_Debit.toString().trim())
										|| act_Debit.toString().trim().contains(exp_Debit_exchanged.toString().trim())
										|| exp_Debit.toString().trim().contains(act_Debit_exchanged.toString().trim())
										|| act_Debit_exchanged.toString().trim()
												.contains(exp_Debit.toString().trim())) {
									passed("Validate Journal", "Debit Amount Should be displayed as " + expected_Debit,
											"Debit Amount is displayed as " + actual_Debit);
								} else {
									failed("Validate Journal", "Debit Amount Should be displayed as " + expected_Debit,
											"Debit Amount should not be displayed as " + actual_Debit);
								}
							} catch (Exception e) {
							}
						} else {
							// Null
						}
					}

					// Credit
					if (uiDriver.checkElementPresent("//table[@id='line_splits']//tbody//td[contains(text(),'"
							+ GLPNS[k].trim()
							+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Credit']//..//preceding-sibling::*)+1]")) {
						el = uiDriver.webDr.findElements(
								By.xpath("//table[@id='line_splits']//tbody//td[contains(text(),'" + GLPNS[k].trim()
										+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Credit']//..//preceding-sibling::*)+1]"));

						String actual_Credit;
						try {
							actual_Credit = el.get(temp).getText();
						} catch (Exception e) {
							temp = 0;
							actual_Credit = el.get(temp).getText();
						}

						String expected_Credit = DEBITS[k].trim();
						if (actual_Credit != null && !actual_Credit.equals(" ") && !actual_Credit.equals("")) {
							try {
								expected_Credit = expected_Credit.replace(",", "");
								expected_Credit = expected_Credit.replace("$", "");

								actual_Credit = actual_Credit.replace(",", "");
								actual_Credit = actual_Credit.replace("$", "");

								Float exp_Credit_exchanged = Float.parseFloat(expected_Credit)
										* Float.parseFloat(text_ExchangeNumber);
								Float act_Credit_exchanged = Float.parseFloat(actual_Credit)
										* Float.parseFloat(text_ExchangeNumber);
								exp_Credit_exchanged = (float) Math.round(exp_Credit_exchanged);
								act_Credit_exchanged = (float) Math.round(act_Credit_exchanged);

								Float exp_Credit = Float.parseFloat(expected_Credit);
								Float act_Credit = Float.parseFloat(actual_Credit);
								exp_Credit = (float) Math.round(exp_Credit);
								act_Credit = (float) Math.round(act_Credit);

								if (exp_Credit_exchanged.toString().trim()
										.contains(act_Credit_exchanged.toString().trim())
										|| act_Credit_exchanged.toString().trim()
												.contains(exp_Credit_exchanged.toString().trim())
										|| exp_Credit.toString().trim().contains(act_Credit.toString().trim())
										|| act_Credit.toString().trim().contains(exp_Credit.toString().trim())
										|| exp_Credit_exchanged.toString().trim().contains(act_Credit.toString().trim())
										|| act_Credit.toString().trim().contains(exp_Credit_exchanged.toString().trim())
										|| exp_Credit.toString().trim().contains(act_Credit_exchanged.toString().trim())
										|| act_Credit_exchanged.toString().trim()
												.contains(exp_Credit.toString().trim())) {
									passed("Validate Journal",
											"Credit Amount Should be displayed as " + expected_Credit,
											"Credit Amount is displayed as " + actual_Credit);
								} else {
									failed("Validate Journal",
											"Credit Amount Should be displayed as " + expected_Credit,
											"Credit Amount should not be displayed as " + actual_Credit);
								}
							} catch (Exception e) {
							}
						} else {
							// Null
						}
					}

					if (el.size() > 1) {
						temp++;
					} else {
						temp = 0;
					}
					k++;
				}

			}

			while (true) {
				if (uiDriver.checkElementPresent("//h1[text()='Invoice' or text()='Payment' "
						+ "or text()='Title Allocation Parent' or text()='Revenue Arrangement' "
						+ "or text()='Customer Credit'  or text()='Credit Memo']")) {
					break;
				} else {
					uiDriver.back();
					SleepUtils.sleep(TimeSlab.YIELD);
				}
			}
		} catch (Exception e) {
			while (true) {
				if (uiDriver.checkElementPresent("//h1[text()='Invoice' or text()='Payment' "
						+ "or text()='Title Allocation Parent' or text()='Revenue Arrangement' "
						+ "or text()='Customer Credit'  or text()='Credit Memo']")) {
					break;
				} else {
					uiDriver.back();
					SleepUtils.sleep(TimeSlab.YIELD);
				}
			}

			error("VeryfyJeGeneric", "Error in VeryfyJeGeneric method", "Error : " + e.toString());
		}

	}

	public void ValidateRevenueArrangement(DataRow input, DataRow output) throws InterruptedException {
		String contractId = input.get("conf"); // conf should pass
		uiDriver.setValue("//*[@id='_searchstring']", contractId);
		uiDriver.click("//a[contains(text(),'Sales Order:')]");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		String SalesorderId = uiDriver.getValue("//div[@class='uir-record-id']");
		if (contractId.equals(SalesorderId)) {
			passed("ValidateRevenueArrangement", "SalesOrderId should be displayed successfully" + contractId,
					"SalesOrderId is displayed successfully" + SalesorderId);
		} else {
			failed("ValidateRevenueArrangement ", "SalesOrderId should be validated successfully" + contractId,
					"SalesOrderId is not  displayed" + SalesorderId);
		}

		uiDriver.click("//a[contains(text(),'elated Records')]");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//td[text()='Revenue Arrangement']//..//a");
		SleepUtils.sleep(TimeSlab.LOW);
		List<WebElement> title = uiDriver.webDr.findElements(By.xpath("//*[@id='revenueelement_splits']/tbody/tr"));
		int titlesize = title.size();
		// int data = 0;
		for (int j = 0; j < titlesize - 1; j++) {
			String title1 = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)
					+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Title')]/../preceding-sibling::*)+1]");

			String AcutalTitles = input.get("AcutalTitle");
			String AcutalTitle[] = AcutalTitles.split(";");
			for (int i = 0; i < AcutalTitle.length; i++) {
				if (title1.contains(input.get("AcutalTitle" + i))) {

					String DeferralAccount = input.get("DeferralAccount");
					String deferralAccount[] = DeferralAccount.split(";");

					// for(int i=0;i<=deferralAccount.length;i++){
					String actual_item = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)
							+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Deferral Account')]/../preceding-sibling::*)+1]");
					String expected_item = deferralAccount[i].trim();
					if (actual_item.toLowerCase().trim().contains(expected_item.toLowerCase().trim())
							|| expected_item.toLowerCase().trim().contains(actual_item.toLowerCase().trim())) {

						passed("ValidateRevenueArrangement",
								"Deferral account should be dispalyed " + expected_item.trim(),
								"Deferral account is displayed" + actual_item.trim());
					} else {
						failed("ValidateRevenueArrangement ",
								"Deferral account should be dispalyed" + expected_item.trim(),
								"Deferral account is dispalyed " + actual_item.trim());
					}

					String RevenuePlanStatus = input.get("RevenuePlanStatus");
					String revenuePlanStatus[] = RevenuePlanStatus.split(";");

					String actual_status = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)
							+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Revenue Plan Status')]/../preceding-sibling::*)+1]");
					String expected_status = revenuePlanStatus[i].trim();
					if (actual_status.toLowerCase().trim().contains(expected_status.toLowerCase().trim())
							|| expected_status.toLowerCase().trim().contains(actual_status.toLowerCase().trim())) {

						passed("ValidateRevenueArrangement",
								"Revenue plan Status should be displayed " + expected_status.trim(),
								"Revenue plan Status is displayed" + actual_status.trim());
					} else {
						failed("ValidateRevenueArrangement ",
								"Revenue plan Status should be displayed" + expected_status.trim(),
								"Revenue plan Status is displayed" + actual_status.trim());
					}

					String RevenueStartDate = input.get("RevenueStartDate");
					String revenueStartDate[] = RevenueStartDate.split(";");
					String actual_StartDate = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr["
							+ (j + 2)
							+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Start Date')]/../preceding-sibling::*)+1]");
					String expected_StartDate = revenueStartDate[i].trim();
					if (actual_StartDate.toLowerCase().trim().contains(expected_StartDate.toLowerCase().trim())
							|| expected_StartDate.toLowerCase().trim()
									.contains(actual_StartDate.toLowerCase().trim())) {

						passed("ValidateRevenueArrangement",
								"Revenue start date should be displayed " + expected_StartDate.trim(),
								"Revenue start date is displayed" + actual_StartDate.trim());
					} else {
						failed("ValidateRevenueArrangement ",
								"Revenue start date should be displayed" + expected_StartDate.trim(),
								"Revenue start date is displayed" + actual_StartDate.trim());
					}

					String RevenueEndDate = input.get("RevenueEndDate");
					String revenueEndDate[] = RevenueEndDate.split(";");
					String actual_EndDate = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)
							+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'End Date')]/../preceding-sibling::*)+1]");
					String expected_EndDate = revenueEndDate[i].trim();
					if (actual_EndDate.toLowerCase().trim().contains(expected_EndDate.toLowerCase().trim())
							|| expected_EndDate.toLowerCase().trim().contains(actual_EndDate.toLowerCase().trim())) {

						passed("ValidateRevenueArrangement",
								"Revenue End date should be displayed " + expected_EndDate.trim(),
								"Revenue End date is displayed" + actual_EndDate.trim());
					} else {
						failed("ValidateRevenueArrangement ",
								"Revenue End date should be displayed" + expected_EndDate.trim(),
								"Revenue End date is displayed" + actual_EndDate.trim());
					}

					String RevenueAmount = input.get("RevenueAmount");
					String revenueAmount[] = RevenueAmount.split(";");
					String actual_Amount = uiDriver.getValue("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)
							+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Revenue Amount')]/../preceding-sibling::*)+1]");
					actual_Amount = actual_Amount.replace(",", "");
					actual_Amount = actual_Amount.replace("$", "");

					String expected_Amount = revenueAmount[i].trim();
					expected_Amount = expected_Amount.replace(",", "");
					expected_Amount = expected_Amount.replace("$", "");

					Float exp_Amount = Float.parseFloat(expected_Amount);
					Float act_Amount = Float.parseFloat(actual_Amount);
					exp_Amount = (float) Math.round(exp_Amount);
					act_Amount = (float) Math.round(act_Amount);

					Float act_Amount_exchanged = Float.parseFloat(actual_Amount)
							* Float.parseFloat(text_ExchangeNumber);
					Float exp_Amount_exchanged = Float.parseFloat(expected_Amount)
							* Float.parseFloat(text_ExchangeNumber);
					exp_Amount_exchanged = (float) Math.round(exp_Amount_exchanged);
					act_Amount_exchanged = (float) Math.round(act_Amount_exchanged);

					if (exp_Amount_exchanged.toString().trim().contains(act_Amount_exchanged.toString().trim())
							|| act_Amount_exchanged.toString().trim().contains(exp_Amount_exchanged.toString().trim())
							|| exp_Amount.toString().trim().contains(act_Amount.toString().trim())
							|| act_Amount.toString().trim().contains(exp_Amount.toString().trim())
							|| exp_Amount_exchanged.toString().trim().contains(act_Amount.toString().trim())
							|| act_Amount.toString().trim().contains(exp_Amount_exchanged.toString().trim())
							|| exp_Amount.toString().trim().contains(act_Amount_exchanged.toString().trim())
							|| act_Amount_exchanged.toString().trim().contains(exp_Amount.toString().trim())) {
						passed("ValidateRevenueArrangement",
								"Revenue Amount should be displayed " + expected_Amount.trim(),
								"Revenue Amount is displayed" + actual_Amount.trim());
					} else {
						failed("ValidateRevenueArrangement ",
								"Revenue Amount should be displayed" + expected_Amount.trim(),
								"Revenue Amount is displayed" + actual_Amount.trim());
					}

					SleepUtils.sleep(TimeSlab.LOW);
					WebElement element = uiDriver.webDr
							.findElement(By.xpath("//table[@id='revenueelement_splits']/tbody/tr[" + (j + 2)
									+ "]//td[count(//table[@id='revenueelement_splits']//td/div[contains(text(),'Revenue Recognition Plan')]/../preceding-sibling::*)+1]//a"));
					((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView();", element);
					((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();", element);
					// // element.click();*/
					// SleepUtils.sleep(TimeSlab.HIGH);
					// // uiDriver.ScrollPageUp();
					// SleepUtils.sleep(TimeSlab.LOW);
					// uiDriver.click("//*[@id='revenueelement_splits']/tbody/tr["
					// + (j + 2) + "]/td[15]/a/img");
					SleepUtils.sleep(TimeSlab.HIGH);
					uiDriver.setFrame("//iframe[@name='updaterevenuerecognitionplans_frame']");
					SleepUtils.sleep(TimeSlab.LOW);
					uiDriver.click("//*[text()='Actual']/..//td[3]//a");
					SleepUtils.sleep(TimeSlab.HIGH);

					String PlannedPeriod = input.get("PlannedPeriod");
					String plannedPeriod[] = PlannedPeriod.split(";");
					String actual_PlannedPeriod = uiDriver
							.getValue("//*[@id='plannedrevenue_splits']/tbody/tr[2]/td[1]");
					String expected_PlannedPeriod = plannedPeriod[i].trim();

					if (actual_PlannedPeriod.toLowerCase().trim().contains(expected_PlannedPeriod.toLowerCase().trim())
							|| expected_PlannedPeriod.toLowerCase().trim()
									.contains(actual_PlannedPeriod.toLowerCase().trim())) {

						passed("ValidateRevenueArrangement",
								"Planing Period should be displayed " + expected_PlannedPeriod.trim(),
								"Planing Period is displayed" + actual_PlannedPeriod.trim());
					} else {
						failed("ValidateRevenueArrangement ",
								"PlannedPeriod should be displayed" + expected_PlannedPeriod.trim(),
								"PlannedPeriod is displayed" + actual_PlannedPeriod.trim());
					}

					uiDriver.click("//div[@id='innerwrapper']//*[@id='secondary_back']");
					SleepUtils.sleep(TimeSlab.MEDIUM);
					uiDriver.click("//td[@id='tdbody_secondary_cancel']//input");
					SleepUtils.sleep(TimeSlab.LOW);
					uiDriver.resetFrame();
				}

				// data++;
			}
		}
	}

	public void VerifyTitleAllocationJournal(DataRow input, DataRow output) throws InterruptedException {
		try {
			// Navigating to Sales Order
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.setValue("//input[@id='_searchstring']", input.get("conf"));
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("//a[contains(text(),'Sales Order:')]");
			SleepUtils.sleep(TimeSlab.LOW);
			if (uiDriver.checkElementPresent("//h1[text()='Sales Order']")) {
				passed("VerifyTitleAllocationJoural", "Sales Order Should be displayed", "Sales Order is displayed");
			} else {
				failed("VerifyTitleAllocationJoural", "Sales Order Should be displayed",
						"Sales Order is not displayed");
			}
			uiDriver.click("//a[@id='rlrcdstabtxt']");
			SleepUtils.sleep(TimeSlab.LOW);

			String TotalAmounts = input.get("TotalAmount");
			String TotalAmount[] = TotalAmounts.split(";");

			String JETypes = input.get("JEType");
			String JEType[] = JETypes.split(";");

			String Accounts = input.get("Account");
			String Account[] = Accounts.split(";");

			String Amounts = input.get("Amount");
			String Amount[] = Amounts.split(";");

			String Names = input.get("Name");
			String Name[] = Names.split(";");

			String Territories = input.get("Territory");
			String Territory[] = Territories.split(";");

			String MarketCodes = input.get("MarketCode");
			String MarketCode[] = MarketCodes.split(";");

			String GLPNs = input.get("GLPN");
			String GLPN[] = GLPNs.split(";");

			List<WebElement> Invoices = uiDriver.webDr.findElements(By.xpath("//td[text()='Invoice']//..//a"));
			int total_Invoices = Invoices.size();

			int flag = 0, x = 0;
			for (int i = 0; i < TotalAmount.length; i++) {
				// Navigating to Invoice matched with Amount specified in Test
				// Data
				((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView(true);",
						uiDriver.webDr.findElement(By.xpath("//a[@id='rlrcdstabtxt']")));
				((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();",
						uiDriver.webDr.findElement(By.xpath("//a[@id='rlrcdstabtxt']")));
				SleepUtils.sleep(TimeSlab.LOW);

				String InvAmount = TotalAmount[i];
				String Exchange = text_ExchangeNumber;

				InvAmount = InvAmount.replace(",", "");
				Exchange = Exchange.replace(",", "");

				Float temp1 = Float.parseFloat(InvAmount);
				Float temp2 = Float.parseFloat(Exchange);

				Float temp3 = temp1 * temp2;
				String temp4 = temp3.toString();

				int end = temp4.indexOf(".");
				String temp5 = temp4.substring(0, end);
				// String temp5 = "4595029";
				System.out.println(temp5);

				int length = temp5.length();

				ArrayList<String> t1 = new ArrayList<String>();
				for (int z = (length - 1); z >= 0; z--) {
					String t2 = temp5.substring(z, z + 1);
					t1.add(t2);
				}
				System.out.println(t1);
				System.out.println(t1.size());

				String finalAmount = "";
				for (int z = 0; z < t1.size(); z++) {
					finalAmount = t1.get(z) + finalAmount;

					if (z != t1.size() - 1) {
						if (z % 3 == 2) {
							finalAmount = "," + finalAmount;
						}
					}
				}
				System.out.println(finalAmount);

				String xpath_Invoice = "//td[text()='Invoice']//..//td[contains(text(),'" + finalAmount.trim()
						+ "')]//..//a";
				// uiDriver.click(xpath_Invoice);
				List<WebElement> element = uiDriver.webDr.findElements(By.xpath(xpath_Invoice));
				if (element.size() > 1) {
					((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView(true);",
							element.get(flag));
					((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();", element.get(flag));
					flag++;
				} else {
					((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].scrollIntoView(true);",
							element.get(0));
					((JavascriptExecutor) uiDriver.webDr).executeScript("arguments[0].click();", element.get(0));
				}
				SleepUtils.sleep(TimeSlab.LOW);
				if (uiDriver.checkElementPresent("//h1[text()='Invoice']")) {
					passed("VerifyTitleAllocationJoural", "Invoice Should be displayed", "Invoice is displayed");
				} else {
					failed("VerifyTitleAllocationJoural", "Invoice Should be displayed", "Invoice is not displayed");
				}
				uiDriver.executeJavaScript("scroll(0,500)");

				// Navigating to Title Allocation Parent
				uiDriver.click("//a[@id='customtxt']");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.executeJavaScript("scroll(0,1000)");
				uiDriver.click("//a[@id='recmachcustrecord_nbcu_titleallocpa_invoicetxt']");
				SleepUtils.sleep(TimeSlab.YIELD);
				String number_TitleAllocationParent = uiDriver
						.getValue("(//table[@id='recmachcustrecord_nbcu_titleallocpa_invoice__tab']//a)[1]");
				uiDriver.click("(//table[@id='recmachcustrecord_nbcu_titleallocpa_invoice__tab']//a)[1]");
				if (uiDriver.checkElementPresent("//h1[text()='Title Allocation Parent']")) {
					passed("VerifyTitleAllocationJoural", "Title Allocation Parent Should be displayed",
							"Title Allocation Parent is displayed");
				} else {
					failed("VerifyTitleAllocationJoural", "Title Allocation Parent Should be displayed",
							"Title Allocation Parent is not displayed");
				}
				uiDriver.executeJavaScript("scroll(0,500)");

				// Navigating to Allocation Transaction Details
				uiDriver.click("//a[text()='llocation Detail']");
				SleepUtils.sleep(TimeSlab.LOW);
				uiDriver.click("//a[@id='recmachcustbody_nbcu_titleallocationtxt']");
				SleepUtils.sleep(TimeSlab.YIELD);

				// Navigating to and validating Journals
				for (int j = 0; j < JEType.length; j++) {
					uiDriver.click("//a[text()='llocation Detail']");
					SleepUtils.sleep(TimeSlab.LOW);
					uiDriver.click("//a[@id='recmachcustbody_nbcu_titleallocationtxt']");
					SleepUtils.sleep(TimeSlab.YIELD);

					if (uiDriver.checkElementPresent("//td[text()='" + JEType[j].trim() + "']")) {
						passed("VerifyTitleAllocationJoural", JEType[j].trim() + " Journal Should be present",
								JEType[j].trim() + " Journal is present");
					} else {
						failed("VerifyTitleAllocationJoural", JEType[j].trim() + " Journal Should be present",
								JEType[j].trim() + " Journal is not present");
					}

					uiDriver.click("(//td[text()='" + JEType[j].trim() + "']//..//a)[1]");
					if (uiDriver.checkElementPresent("//h1[text()='Journal']")) {
						passed("VerifyTitleAllocationJoural", "Journal Should be displayed", "Journal is displayed");
					} else {
						failed("VerifyTitleAllocationJoural", "Journal Should be displayed",
								"Journal is not displayed");
					}

					try {
						List<WebElement> LineItems = uiDriver.webDr
								.findElements(By.xpath("//table[@id='line_splits']//tr"));
						int total_LineItems = LineItems.size();

						int temp = 0;
						for (int k = 2; k < total_LineItems; k++) {

							String xpath = "//table[@id='line_splits']//td[contains(text(),'" + GLPN[x].trim() + "')]";
							List<WebElement> el;

							if (uiDriver.checkElementPresent("//table[@id='line_splits']//tbody//td[contains(text(),'"
									+ GLPN[x].trim()
									+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Account']//..//preceding-sibling::*)+1]")) {

								el = uiDriver.webDr.findElements(By.xpath(
										"//table[@id='line_splits']//tbody//td[contains(text(),'" + GLPN[x].trim()
												+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Account']//..//preceding-sibling::*)+1]"));

								String actual_Account;
								try {
									actual_Account = el.get(temp).getText();
								} catch (Exception e) {
									temp = 0;
									actual_Account = el.get(temp).getText();
								}

								String expected_Account = Account[x].trim();
								expected_Account = expected_Account.replace("Null", " ");

								if (actual_Account != null && !actual_Account.equals(" ")
										&& !actual_Account.equals("")) {
									if (expected_Account.toLowerCase().trim()
											.contains(actual_Account.toLowerCase().trim())
											|| expected_Account.toLowerCase().trim()
													.contains(actual_Account.toLowerCase().trim())) {
										passed("VerifyTitleAllocationJoural-" + "-Invoice" + (i + 1) + "-Journal "
												+ JEType[j] + "-Line Item for GLPN " + GLPN[x],
												"Account Should be displayed as " + expected_Account,
												"Account is displayed as " + actual_Account);
									} else {
										failed("VerifyTitleAllocationJoural-" + "-Invoice" + (i + 1) + "-Journal "
												+ JEType[j] + "-Line Item for GLPN " + GLPN[x],
												"Account Should be displayed as " + expected_Account,
												"Account is displayed as " + actual_Account);
									}
								}
							}

							if (uiDriver.checkElementPresent("//table[@id='line_splits']//tbody//td[contains(text(),'"
									+ GLPN[x].trim()
									+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Name']//..//preceding-sibling::*)+1]")) {
								el = uiDriver.webDr.findElements(By.xpath(
										"//table[@id='line_splits']//tbody//td[contains(text(),'" + GLPN[x].trim()
												+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Name']//..//preceding-sibling::*)+1]"));

								String actual_Name;
								try {
									actual_Name = el.get(temp).getText();
								} catch (Exception e) {
									temp = 0;
									actual_Name = el.get(temp).getText();
								}

								String expected_Name = Name[x].trim();
								expected_Name = expected_Name.replace("Null", " ");

								if (expected_Name.toLowerCase().trim().contains(actual_Name.toLowerCase().trim())
										|| actual_Name.toLowerCase().trim()
												.contains(expected_Name.toLowerCase().trim())) {
									passed("VerifyTitleAllocationJoural-" + "-Invoice" + (i + 1) + "-Journal "
											+ JEType[j] + "-Line Item for GLPN " + GLPN[x],
											"Name Should be displayed as " + expected_Name,
											"Name is displayed as " + actual_Name);
								} else {
									failed("VerifyTitleAllocationJoural-" + "-Invoice" + (i + 1) + "-Journal "
											+ JEType[j] + "-Line Item for GLPN " + GLPN[x],
											"Name Should be displayed as " + expected_Name,
											"Name is displayed as " + actual_Name);
								}
							}

							if (uiDriver.checkElementPresent("//table[@id='line_splits']//tbody//td[contains(text(),'"
									+ GLPN[x].trim()
									+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Territory']//..//preceding-sibling::*)+1]")) {
								el = uiDriver.webDr.findElements(By.xpath(
										"//table[@id='line_splits']//tbody//td[contains(text(),'" + GLPN[x].trim()
												+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Territory']//..//preceding-sibling::*)+1]"));

								String actual_Territory;
								try {
									actual_Territory = el.get(temp).getText();
								} catch (Exception e) {
									temp = 0;
									actual_Territory = el.get(temp).getText();
								}

								String expected_Territory = Territory[x].trim();
								expected_Territory = expected_Territory.replace("Null", " ");

								if (actual_Territory != null && !actual_Territory.equals(" ")
										&& !actual_Territory.equals("")) {
									if (expected_Territory.toLowerCase().trim()
											.contains(actual_Territory.toLowerCase().trim())
											|| actual_Territory.toLowerCase().trim()
													.contains(expected_Territory.toLowerCase().trim())) {
										passed("VerifyTitleAllocationJoural-" + "-Invoice" + (i + 1) + "-Journal "
												+ JEType[j] + "-Line Item for GLPN " + GLPN[x],
												"Territory Should be displayed as " + expected_Territory,
												"Territory is displayed as " + actual_Territory);
									} else {
										failed("VerifyTitleAllocationJoural-" + "-Invoice" + (i + 1) + "-Journal "
												+ JEType[j] + "-Line Item for GLPN " + GLPN[x],
												"Territory Should be displayed as " + expected_Territory,
												"Territory is displayed as " + actual_Territory);
									}
								}
							}

							if (uiDriver.checkElementPresent("//table[@id='line_splits']//tbody//td[contains(text(),'"
									+ GLPN[x].trim()
									+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Market Code']//..//preceding-sibling::*)+1]")) {
								el = uiDriver.webDr.findElements(By.xpath(
										"//table[@id='line_splits']//tbody//td[contains(text(),'" + GLPN[x].trim()
												+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Market Code']//..//preceding-sibling::*)+1]"));

								String actual_MarketCode;
								try {
									actual_MarketCode = el.get(temp).getText();
								} catch (Exception e) {
									temp = 0;
									actual_MarketCode = el.get(temp).getText();
								}

								String expected_MarketCode = MarketCode[x].trim();
								expected_MarketCode = expected_MarketCode.replace("Null", " ");

								if (actual_MarketCode != null && !actual_MarketCode.equals(" ")
										&& !actual_MarketCode.equals("")) {
									if (expected_MarketCode.toLowerCase().trim()
											.contains(actual_MarketCode.toLowerCase().trim())
											|| actual_MarketCode.toLowerCase().trim()
													.contains(expected_MarketCode.toLowerCase().trim())) {
										passed("VerifyTitleAllocationJoural-" + "-Invoice" + (i + 1) + "-Journal "
												+ JEType[j] + "-Line Item for GLPN " + GLPN[x],
												"MarketCode Should be displayed as " + expected_MarketCode,
												"MarketCode is displayed as " + actual_MarketCode);
									} else {
										failed("VerifyTitleAllocationJoural-" + "-Invoice" + (i + 1) + "-Journal "
												+ JEType[j] + "-Line Item for GLPN " + GLPN[x],
												"MarketCode Should be displayed as " + expected_MarketCode,
												"MarketCode is displayed as " + actual_MarketCode);
									}
								}
							}

							if (uiDriver.checkElementPresent("//table[@id='line_splits']//tbody//td[contains(text(),'"
									+ GLPN[x].trim()
									+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]")) {
								el = uiDriver.webDr.findElements(By.xpath(
										"//table[@id='line_splits']//tbody//td[contains(text(),'" + GLPN[x].trim()
												+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]"));

								String actual_GLPN;
								try {
									actual_GLPN = el.get(temp).getText();
								} catch (Exception e) {
									temp = 0;
									actual_GLPN = el.get(temp).getText();
								}

								String expected_GLPN = GLPN[x].trim();
								expected_GLPN = expected_GLPN.replace("Null", "");

								if (actual_GLPN != null && !actual_GLPN.equals(" ") && !actual_GLPN.equals("")) {
									if (expected_GLPN.toLowerCase().trim().contains(actual_GLPN.toLowerCase().trim())
											|| actual_GLPN.toLowerCase().trim()
													.contains(expected_GLPN.toLowerCase().trim())) {
										passed("VerifyTitleAllocationJoural-" + "-Invoice" + (i + 1) + "-Journal "
												+ JEType[j] + "-Line Item for GLPN " + GLPN[x],
												"GLPN Should be displayed as " + expected_GLPN,
												"GLPN is displayed as " + actual_GLPN);
									} else {
										failed("VerifyTitleAllocationJoural-" + "-Invoice" + (i + 1) + "-Journal "
												+ JEType[j] + "-Line Item for GLPN " + GLPN[x],
												"GLPN Should be displayed as " + expected_GLPN,
												"GLPN is displayed as " + actual_GLPN);
									}
								}
							}

							if (uiDriver.checkElementPresent("//table[@id='line_splits']//tbody//td[contains(text(),'"
									+ GLPN[x].trim()
									+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Debit']//..//preceding-sibling::*)+1]")) {

								el = uiDriver.webDr.findElements(By.xpath(
										"//table[@id='line_splits']//tbody//td[contains(text(),'" + GLPN[x].trim()
												+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Debit']//..//preceding-sibling::*)+1]"));

								String actual_Amount;
								try {
									actual_Amount = el.get(temp).getText();
								} catch (Exception e) {
									temp = 0;
									actual_Amount = el.get(temp).getText();
								}
								if (actual_Amount != null || !actual_Amount.equals(" ") || !actual_Amount.equals("")) {
									el = uiDriver.webDr.findElements(By.xpath(
											"//table[@id='line_splits']//tbody//td[contains(text(),'" + GLPN[x].trim()
													+ "')]//..//td[count(//table[@id='line_splits']//td//div[text()='Credit']//..//preceding-sibling::*)+1]"));
									try {
										actual_Amount = el.get(temp).getText();
									} catch (Exception e) {
										temp = 0;
										actual_Amount = el.get(temp).getText();
									}
								}

								String expected_Amount = Amount[k].trim();
								expected_Amount = expected_Amount.replace("Null", " ");

								if (actual_Amount != null && !actual_Amount.equals(" ") && !actual_Amount.equals("")) {
									try {
										expected_Amount = expected_Amount.replace(",", "");
										expected_Amount = expected_Amount.replace("$", "");

										actual_Amount = actual_Amount.replace(",", "");
										actual_Amount = actual_Amount.replace("$", "");

										Float exp_Amount_exchanged = Float.parseFloat(expected_Amount)
												* Float.parseFloat(text_ExchangeNumber);
										Float act_Amount_exchanged = Float.parseFloat(actual_Amount)
												* Float.parseFloat(text_ExchangeNumber);
										exp_Amount_exchanged = (float) Math.round(exp_Amount_exchanged);
										act_Amount_exchanged = (float) Math.round(act_Amount_exchanged);

										Float exp_Amount = Float.parseFloat(expected_Amount);
										Float act_Amount = Float.parseFloat(actual_Amount);
										exp_Amount = (float) Math.round(exp_Amount);
										act_Amount = (float) Math.round(act_Amount);

										if (exp_Amount_exchanged.toString().trim()
												.contains(act_Amount_exchanged.toString().trim())
												|| act_Amount_exchanged.toString().trim()
														.contains(exp_Amount_exchanged.toString().trim())
												|| exp_Amount.toString().trim().contains(act_Amount.toString().trim())
												|| act_Amount.toString().trim().contains(exp_Amount.toString().trim())
												|| exp_Amount_exchanged.toString().trim()
														.contains(act_Amount.toString().trim())
												|| act_Amount.toString().trim()
														.contains(exp_Amount_exchanged.toString().trim())
												|| exp_Amount.toString().trim()
														.contains(act_Amount_exchanged.toString().trim())
												|| act_Amount_exchanged.toString().trim()
														.contains(exp_Amount.toString().trim())) {
											passed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1)
													+ "-Line Item for GLPN " + GLPN[x],
													"Amount Should be displayed as " + exp_Amount,
													"Amount is displayed as " + act_Amount);
										} else {
											failed("ValidateAllInvoiceData-" + "-Invoice" + (i + 1)
													+ "-Line Item for GLPN " + GLPN[x],
													"Amount Should be displayed as " + exp_Amount,
													"Amount is displayed as " + act_Amount);
										}
									} catch (Exception e) {
									}
								} else {
									// Null
								}
							}

							el = uiDriver.webDr.findElements(By.xpath(xpath));
							if (el.size() > 1) {
								temp++;
							} else {
								temp = 0;
							}

							x++;

						}

						while (true) {
							if (uiDriver.checkElementPresent("//h1[text()='Title Allocation Parent']")) {
								break;
							} else {
								uiDriver.back();
								SleepUtils.sleep(TimeSlab.YIELD);
							}
						}
					} catch (Exception e) {

					}
				}

				while (true) {
					if (uiDriver.checkElementPresent("//h1[text()='Invoice' or text()='Payment' "
							+ "or text()='Title Allocation Parent' or text()='Revenue Arrangement' "
							+ "or text()='Customer Credit'  or text()='Credit Memo']")) {
						break;
					} else {
						uiDriver.back();
						SleepUtils.sleep(TimeSlab.YIELD);
					}
				}
			}

		} catch (Exception e) {
			while (true) {
				if (uiDriver.checkElementPresent("//h1[text()='Invoice' or text()='Payment' "
						+ "or text()='Title Allocation Parent' or text()='Revenue Arrangement' "
						+ "or text()='Customer Credit'  or text()='Credit Memo']")) {
					break;
				} else {
					uiDriver.back();
					SleepUtils.sleep(TimeSlab.YIELD);
				}
			}

			error("VerifyTitleAllocationJoural", "Error in VerifyTitleAllocationJoural method",
					"Error : " + e.toString());
		}
	}

	public void validateCreditMemo(DataRow input, DataRow output) {

		uiDriver.click("//*[text()='elated Records']");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("//*[text()='Credit Memo']/preceding::a[1]");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.executeJavaScript("scroll(0,5000)");

		String actual_Customer = uiDriver.getValue("//span[@id='entity_fs_lbl_uir_label']//following-sibling::span//a");
		String actual_Status = uiDriver.getValue("//div[@class='uir-record-status']");
		String actual_Subsidiary = uiDriver
				.getValue("//span[@id='subsidiary_lbl_uir_label']//following-sibling::span//span");
		String actual_RevisionNumber = uiDriver
				.getValue("//span[@id='custbody_nbcu_revision_number_fs_lbl_uir_label']//following-sibling::span");
		String actual_CreditMemoType = uiDriver
				.getValue("//span[@id='custbody_nbcu_cm_type_fs_lbl_uir_label']//following-sibling::span//span");

		String expected_Customer = input.get("Customer");
		String expected_Status = input.get("Status");
		String expected_Subsidiary = input.get("Subsidiary");
		String expected_RevisionNumber = input.get("RevisionNumber");
		String expected_CreditMemoType = input.get("CreditMemoType");

		if (actual_Customer.toLowerCase().trim().contains(expected_Customer.toLowerCase().trim())
				|| expected_Customer.toLowerCase().trim().contains(actual_Customer.toLowerCase().trim())) {
			passed("validateCreditMemo", "Customer should be displayed as : " + expected_Customer.trim(),
					"Customer is displayed as : " + actual_Customer.trim());
		} else {
			failed("validateCreditMemo", "Customer should be displayed as : " + expected_Customer.trim(),
					"Customer is displayed as : " + actual_Customer.trim());
		}

		if (actual_Status.toLowerCase().trim().contains(expected_Status.toLowerCase().trim())
				|| expected_Status.toLowerCase().trim().contains(actual_Status.toLowerCase().trim())) {
			passed("validateCreditMemo", "Status should be displayed as : " + expected_Status.trim(),
					"Status is displayed as : " + actual_Status.trim());
		} else {
			failed("validateCreditMemo", "Status should be displayed as : " + expected_Status.trim(),
					"Status is displayed as : " + actual_Status.trim());
		}

		if (actual_Subsidiary.toLowerCase().trim().contains(expected_Subsidiary.toLowerCase().trim())
				|| expected_Subsidiary.toLowerCase().trim().contains(actual_Subsidiary.toLowerCase().trim())) {
			passed("validateCreditMemo", "Subsidiary should be displayed as : " + expected_Subsidiary.trim(),
					"Subsidiary is displayed as : " + actual_Subsidiary.trim());
		} else {
			failed("validateCreditMemo", "Subsidiary should be displayed as : " + expected_Subsidiary.trim(),
					"Subsidiary is displayed as : " + actual_Subsidiary.trim());
		}

		if (actual_RevisionNumber.toLowerCase().trim().contains(expected_RevisionNumber.toLowerCase().trim())
				|| expected_RevisionNumber.toLowerCase().trim().contains(actual_RevisionNumber.toLowerCase().trim())) {
			passed("validateCreditMemo", "RevisionNumber should be displayed as : " + expected_RevisionNumber.trim(),
					"RevisionNumber is displayed as : " + actual_RevisionNumber.trim());
		} else {
			failed("validateCreditMemo", "RevisionNumber should be displayed as : " + expected_RevisionNumber.trim(),
					"RevisionNumber is displayed as : " + actual_RevisionNumber.trim());
		}

		if (actual_CreditMemoType.toLowerCase().trim().contains(expected_CreditMemoType.toLowerCase().trim())
				|| expected_CreditMemoType.toLowerCase().trim().contains(actual_CreditMemoType.toLowerCase().trim())) {
			passed("validateCreditMemo", "InvoiceType should be displayed as : " + expected_CreditMemoType.trim(),
					"InvoiceType is displayed as : " + actual_CreditMemoType.trim());
		} else {
			failed("validateCreditMemo", "InvoiceType should be displayed as : " + expected_CreditMemoType.trim(),
					"InvoiceType is displayed as : " + actual_CreditMemoType.trim());
		}

		String Items = input.get("Item");
		String Item[] = Items.split(";");

		String Quantities = input.get("Quantity");
		String Quantity[] = Quantities.split(";");

		String Rates = input.get("Rate");
		String Rate[] = Rates.split(";");

		String Amounts = input.get("Amount");
		String Amount[] = Amounts.split(";");

		String TaxCodes = input.get("Tax Code");
		String TaxCode[] = TaxCodes.split(";");

		String MarketCodes = input.get("Market Code");
		String MarketCode[] = MarketCodes.split(";");

		String Territories = input.get("Territory");
		String Territory[] = Territories.split(";");

		String TitleIDs = input.get("Title ID");
		String TitleID[] = TitleIDs.split(";");

		String GLPNs = input.get("GLPN");
		String GLPN[] = GLPNs.split(";");

		String ProductOwners = input.get("Product Owner");
		String ProductOwner[] = ProductOwners.split(";");

		String Rights = input.get("Right");
		String Right[] = Rights.split(";");

		String UnbilledRevenueAccounts = input.get("Unbilled Revenue Account");
		String UnbilledRevenueAccount[] = UnbilledRevenueAccounts.split(";");

		String BilledRevenueAccounts = input.get("Billed Revenue Account");
		String BilledRevenueAccount[] = BilledRevenueAccounts.split(";");

		String BilledARAccounts = input.get("Billed AR Account");
		String BilledARAccount[] = BilledARAccounts.split(";");

		String UnbilledARAccounts = input.get("Unbilled AR Account");
		String UnbilledARAccount[] = UnbilledARAccounts.split(";");

		String PaidDeferredRevenueAccounts = input.get("Paid Deferred Revenue Account");
		String PaidDeferredRevenueAccount[] = PaidDeferredRevenueAccounts.split(";");

		String UnpaidDeferredRevenueAccounts = input.get("Unpaid Deferred Revenue Account");
		String UnpaidDeferredRevenueAccount[] = UnpaidDeferredRevenueAccounts.split(";");

		String BadDebtRevenueAccounts = input.get("Bad Debt Revenue Account");
		String BadDebtRevenueAccount[] = BadDebtRevenueAccounts.split(";");

		List<WebElement> LineItems = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tr"));
		int total_LineItems = LineItems.size();

		int k = 0, temp = 0;
		for (int j = 2; j <= total_LineItems; j++) {

			List<WebElement> el;
			String xpath = "//table[@id='item_splits']//td[contains(text(),'" + GLPN[k].trim() + "')]";

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title']//..//preceding-sibling::*)+1]")) {
				String actual_Item;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title']//..//preceding-sibling::*)+1]"));
				try {
					actual_Item = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_Item = el.get(0).getText();
				}

				String expected_Item = Item[k].trim();
				expected_Item = expected_Item.replace("Null", " ");

				if (expected_Item.contains(actual_Item) || actual_Item.contains(expected_Item)) {
					passed("validateCreditMemo", "Item Should be displayed as " + expected_Item,
							"Item is displayed as " + actual_Item);
				} else {
					failed("validateCreditMemo", "Item Should be displayed as " + expected_Item,
							"Item is displayed as " + actual_Item);
				}

			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Rate']//..//preceding-sibling::*)+1]")) {
				String actual_Rate;
				Float actual_Rate_temp;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Rate']//..//preceding-sibling::*)+1]"));
				try {
					actual_Rate = el.get(temp).getText();
					actual_Rate = actual_Rate.replace(",", "");
					actual_Rate_temp = Float.parseFloat(actual_Rate);
				} catch (Exception e) {
					temp = 0;
					actual_Rate = el.get(0).getText();
					actual_Rate = actual_Rate.replace(",", "");
					actual_Rate_temp = Float.parseFloat(actual_Rate);
				}

				String expected_Rate = Rate[k].trim();
				expected_Rate = expected_Rate.replace("Null", " ");
				expected_Rate = expected_Rate.replace(",", "");
				Float expected_Rate_temp = Float.parseFloat(actual_Rate);

				if (expected_Rate_temp.toString().trim().contains(actual_Rate_temp.toString().trim())
						|| actual_Rate_temp.toString().trim().contains(expected_Rate_temp.toString().trim())) {
					passed("validateCreditMemo", "Rate Should be displayed as " + expected_Rate,
							"Rate is displayed as " + actual_Rate);
				} else {
					failed("validateCreditMemo", "Rate Should be displayed as " + expected_Rate,
							"Rate is displayed as " + actual_Rate);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Tax Code']//..//preceding-sibling::*)+1]")) {
				String actual_TaxCode;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Tax Code']//..//preceding-sibling::*)+1]"));
				try {
					actual_TaxCode = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_TaxCode = el.get(0).getText();
				}

				String expected_TaxCode = TaxCode[k].trim();
				expected_TaxCode = expected_TaxCode.replace("Null", " ");

				if (expected_TaxCode.contains(actual_TaxCode) || actual_TaxCode.contains(expected_TaxCode)) {
					passed("validateCreditMemo", "TaxCode Should be displayed as " + expected_TaxCode,
							"TaxCode is displayed as " + actual_TaxCode);
				} else {
					failed("validateCreditMemo", "TaxCode Should be displayed as " + expected_TaxCode,
							"TaxCode is displayed as " + actual_TaxCode);
				}

			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Market Code']//..//preceding-sibling::*)+1]")) {
				String actual_MarketCode;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Market Code']//..//preceding-sibling::*)+1]"));
				try {
					actual_MarketCode = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_MarketCode = el.get(0).getText();
				}

				String expected_MarketCode = MarketCode[k].trim();
				expected_MarketCode = expected_MarketCode.replace("Null", " ");

				if (expected_MarketCode.contains(actual_MarketCode)
						|| actual_MarketCode.contains(expected_MarketCode)) {
					passed("validateCreditMemo", "MarketCode Should be displayed as " + expected_MarketCode,
							"MarketCode is displayed as " + actual_MarketCode);
				} else {
					failed("validateCreditMemo", "MarketCode Should be displayed as " + expected_MarketCode,
							"MarketCode is displayed as " + actual_MarketCode);
				}

			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Territory']//..//preceding-sibling::*)+1]")) {
				String actual_Territory;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Territory']//..//preceding-sibling::*)+1]"));
				try {
					actual_Territory = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_Territory = el.get(0).getText();
				}

				String expected_Territory = Territory[k].trim();
				expected_Territory = expected_Territory.replace("Null", " ");

				if (expected_Territory.contains(actual_Territory) || actual_Territory.contains(expected_Territory)) {
					passed("validateCreditMemo", "Territory Should be displayed as " + expected_Territory,
							"Territory is displayed as " + actual_Territory);
				} else {
					failed("validateCreditMemo", "Territory Should be displayed as " + expected_Territory,
							"Territory is displayed as " + actual_Territory);
				}

			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title ID']//..//preceding-sibling::*)+1]")) {
				String actual_TitleID;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Title ID']//..//preceding-sibling::*)+1]"));
				try {
					actual_TitleID = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_TitleID = el.get(0).getText();
				}

				String expected_TitleID = TitleID[k].trim();
				expected_TitleID = expected_TitleID.replace("Null", " ");

				if (expected_TitleID.contains(actual_TitleID) || actual_TitleID.contains(expected_TitleID)) {
					passed("validateCreditMemo", "TitleID Should be displayed as " + expected_TitleID,
							"TitleID is displayed as " + actual_TitleID);
				} else {
					failed("validateCreditMemo", "TitleID Should be displayed as " + expected_TitleID,
							"TitleID is displayed as " + actual_TitleID);
				}

			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]")) {
				String actual_GLPN;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='GLPN']//..//preceding-sibling::*)+1]"));
				try {
					actual_GLPN = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_GLPN = el.get(0).getText();
				}

				String expected_GLPN = GLPN[k].trim();
				expected_GLPN = expected_GLPN.replace("Null", " ");

				if (expected_GLPN.contains(actual_GLPN) || actual_GLPN.contains(expected_GLPN)) {
					passed("validateCreditMemo", "GLPN Should be displayed as " + expected_GLPN,
							"GLPN is displayed as " + actual_GLPN);
				} else {
					failed("validateCreditMemo", "GLPN Should be displayed as " + expected_GLPN,
							"GLPN is displayed as " + actual_GLPN);
				}

			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Owner']//..//preceding-sibling::*)+1]")) {
				String actual_ProductOwner;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Product Owner']//..//preceding-sibling::*)+1]"));
				try {
					actual_ProductOwner = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_ProductOwner = el.get(0).getText();
				}

				String expected_ProductOwner = ProductOwner[k].trim();
				expected_ProductOwner = expected_ProductOwner.replace("Null", " ");

				if (expected_ProductOwner.contains(actual_ProductOwner)
						|| actual_ProductOwner.contains(expected_ProductOwner)) {
					passed("validateCreditMemo", "ProductOwner Should be displayed as " + expected_ProductOwner,
							"ProductOwner is displayed as " + actual_ProductOwner);
				} else {
					failed("validateCreditMemo", "ProductOwner Should be displayed as " + expected_ProductOwner,
							"ProductOwner is displayed as " + actual_ProductOwner);
				}

			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Right']//..//preceding-sibling::*)+1]")) {
				String actual_Right;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Right']//..//preceding-sibling::*)+1]"));
				try {
					actual_Right = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_Right = el.get(0).getText();
				}

				String expected_Right = Right[k].trim();
				expected_Right = expected_Right.replace("Null", " ");

				if (expected_Right.contains(actual_Right) || actual_Right.contains(expected_Right)) {
					passed("validateCreditMemo", "Right Should be displayed as " + expected_Right,
							"Right is displayed as " + actual_Right);
				} else {
					failed("validateCreditMemo", "Right Should be displayed as " + expected_Right,
							"Right is displayed as " + actual_Right);
				}

			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled Revenue Account']//..//preceding-sibling::*)+1]")) {
				String actual_UnbilledRevenueAccount;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled Revenue Account']//..//preceding-sibling::*)+1]"));
				try {
					actual_UnbilledRevenueAccount = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_UnbilledRevenueAccount = el.get(0).getText();
				}

				String expected_UnbilledRevenueAccount = UnbilledRevenueAccount[k].trim();
				expected_UnbilledRevenueAccount = expected_UnbilledRevenueAccount.replace("Null", " ");

				if (expected_UnbilledRevenueAccount.contains(actual_UnbilledRevenueAccount)
						|| actual_UnbilledRevenueAccount.contains(expected_UnbilledRevenueAccount)) {
					passed("validateCreditMemo",
							"UnbilledRevenueAccount Should be displayed as " + expected_UnbilledRevenueAccount,
							"UnbilledRevenueAccount is displayed as " + actual_UnbilledRevenueAccount);
				} else {
					failed("validateCreditMemo",
							"UnbilledRevenueAccount Should be displayed as " + expected_UnbilledRevenueAccount,
							"UnbilledRevenueAccount is displayed as " + actual_UnbilledRevenueAccount);
				}

			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed Revenue Account']//..//preceding-sibling::*)+1]")) {
				String actual_BilledRevenueAccount;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed Revenue Account']//..//preceding-sibling::*)+1]"));
				try {
					actual_BilledRevenueAccount = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_BilledRevenueAccount = el.get(0).getText();
				}

				String expected_BilledRevenueAccount = BilledRevenueAccount[k].trim();
				expected_BilledRevenueAccount = expected_BilledRevenueAccount.replace("Null", " ");

				if (expected_BilledRevenueAccount.contains(actual_BilledRevenueAccount)
						|| actual_BilledRevenueAccount.contains(expected_BilledRevenueAccount)) {
					passed("validateCreditMemo",
							"BilledRevenueAccount Should be displayed as " + expected_BilledRevenueAccount,
							"BilledRevenueAccount is displayed as " + actual_BilledRevenueAccount);
				} else {
					failed("validateCreditMemo",
							"BilledRevenueAccount Should be displayed as " + expected_BilledRevenueAccount,
							"BilledRevenueAccount is displayed as " + actual_BilledRevenueAccount);
				}

			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed AR Account']//..//preceding-sibling::*)+1]")) {
				String actual_BilledARAccount;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Billed AR Account']//..//preceding-sibling::*)+1]"));
				try {
					actual_BilledARAccount = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_BilledARAccount = el.get(0).getText();
				}

				String expected_BilledARAccount = BilledARAccount[k].trim();
				expected_BilledARAccount = expected_BilledARAccount.replace("Null", " ");

				if (expected_BilledARAccount.contains(actual_BilledARAccount)
						|| actual_BilledARAccount.contains(expected_BilledARAccount)) {
					passed("validateCreditMemo", "BilledARAccount Should be displayed as " + expected_BilledARAccount,
							"BilledARAccount is displayed as " + actual_BilledARAccount);
				} else {
					failed("validateCreditMemo", "BilledARAccount Should be displayed as " + expected_BilledARAccount,
							"BilledARAccount is displayed as " + actual_BilledARAccount);
				}

			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled AR Account']//..//preceding-sibling::*)+1]")) {
				String actual_UnbilledARAccount;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unbilled AR Account']//..//preceding-sibling::*)+1]"));
				try {
					actual_UnbilledARAccount = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_UnbilledARAccount = el.get(0).getText();
				}

				String expected_UnbilledARAccount = UnbilledARAccount[k].trim();
				expected_UnbilledARAccount = expected_UnbilledARAccount.replace("Null", " ");

				if (expected_UnbilledARAccount.contains(actual_UnbilledARAccount)
						|| actual_UnbilledARAccount.contains(expected_UnbilledARAccount)) {
					passed("validateCreditMemo",
							"UnbilledARAccount Should be displayed as " + expected_UnbilledARAccount,
							"UnbilledARAccount is displayed as " + actual_UnbilledARAccount);
				} else {
					failed("validateCreditMemo",
							"UnbilledARAccount Should be displayed as " + expected_UnbilledARAccount,
							"UnbilledARAccount is displayed as " + actual_UnbilledARAccount);
				}

			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Paid Deferred Account']//..//preceding-sibling::*)+1]")) {
				String actual_PaidDeferredRevenueAccount;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Paid Deferred Account']//..//preceding-sibling::*)+1]"));
				try {
					actual_PaidDeferredRevenueAccount = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_PaidDeferredRevenueAccount = el.get(0).getText();
				}

				String expected_PaidDeferredRevenueAccount = PaidDeferredRevenueAccount[k].trim();
				expected_PaidDeferredRevenueAccount = expected_PaidDeferredRevenueAccount.replace("Null", " ");

				if (expected_PaidDeferredRevenueAccount.contains(actual_PaidDeferredRevenueAccount)
						|| actual_PaidDeferredRevenueAccount.contains(expected_PaidDeferredRevenueAccount)) {
					passed("validateCreditMemo",
							"PaidDeferredRevenueAccount Should be displayed as " + expected_PaidDeferredRevenueAccount,
							"PaidDeferredRevenueAccount is displayed as " + actual_PaidDeferredRevenueAccount);
				} else {
					failed("validateCreditMemo",
							"PaidDeferredRevenueAccount Should be displayed as " + expected_PaidDeferredRevenueAccount,
							"PaidDeferredRevenueAccount is displayed as " + actual_PaidDeferredRevenueAccount);
				}

			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unpaid Deferred Account']//..//preceding-sibling::*)+1]")) {
				String actual_UnpaidDeferredRevenueAccount;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Unpaid Deferred Account']//..//preceding-sibling::*)+1]"));
				try {
					actual_UnpaidDeferredRevenueAccount = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_UnpaidDeferredRevenueAccount = el.get(0).getText();
				}

				String expected_UnpaidDeferredRevenueAccount = UnpaidDeferredRevenueAccount[k].trim();
				expected_UnpaidDeferredRevenueAccount = expected_UnpaidDeferredRevenueAccount.replace("Null", " ");

				if (expected_UnpaidDeferredRevenueAccount.contains(actual_UnpaidDeferredRevenueAccount)
						|| actual_UnpaidDeferredRevenueAccount.contains(expected_UnpaidDeferredRevenueAccount)) {
					passed("validateCreditMemo",
							"UnpaidDeferredRevenueAccount Should be displayed as "
									+ expected_UnpaidDeferredRevenueAccount,
							"UnpaidDeferredRevenueAccount is displayed as " + actual_UnpaidDeferredRevenueAccount);
				} else {
					failed("validateCreditMemo",
							"UnpaidDeferredRevenueAccount Should be displayed as "
									+ expected_UnpaidDeferredRevenueAccount,
							"UnpaidDeferredRevenueAccount is displayed as " + actual_UnpaidDeferredRevenueAccount);
				}

			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Bad Debt Revenue Account']//..//preceding-sibling::*)+1]")) {
				String actual_BadDebtRevenueAccount;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Bad Debt Revenue Account']//..//preceding-sibling::*)+1]"));
				try {
					actual_BadDebtRevenueAccount = el.get(temp).getText();
				} catch (Exception e) {
					temp = 0;
					actual_BadDebtRevenueAccount = el.get(0).getText();
				}

				String expected_BadDebtRevenueAccount = BadDebtRevenueAccount[k].trim();
				expected_BadDebtRevenueAccount = expected_BadDebtRevenueAccount.replace("Null", " ");

				if (expected_BadDebtRevenueAccount.contains(actual_BadDebtRevenueAccount)
						|| actual_BadDebtRevenueAccount.contains(expected_BadDebtRevenueAccount)) {
					passed("validateCreditMemo",
							"BadDebtRevenueAccount Should be displayed as " + expected_BadDebtRevenueAccount,
							"BadDebtRevenueAccount is displayed as " + actual_BadDebtRevenueAccount);
				} else {
					failed("validateCreditMemo",
							"BadDebtRevenueAccount Should be displayed as " + expected_BadDebtRevenueAccount,
							"BadDebtRevenueAccount is displayed as " + actual_BadDebtRevenueAccount);
				}

			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Quantity']//..//preceding-sibling::*)+1]")) {
				String actual_Quantity;
				Float actual_Quantity_temp;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Quantity']//..//preceding-sibling::*)+1]"));
				try {
					actual_Quantity = el.get(temp).getText();
					actual_Quantity = actual_Quantity.replace(",", "");
					actual_Quantity = actual_Quantity.replace("$", "");
					actual_Quantity_temp = Float.parseFloat(actual_Quantity);
				} catch (Exception e) {
					temp = 0;
					actual_Quantity = el.get(0).getText();
					actual_Quantity = actual_Quantity.replace(",", "");
					actual_Quantity = actual_Quantity.replace("$", "");
					actual_Quantity_temp = Float.parseFloat(actual_Quantity);
				}

				String expected_Quantity = Quantity[k].trim();
				expected_Quantity = expected_Quantity.replace("Null", " ");
				expected_Quantity = expected_Quantity.replace(",", "");
				expected_Quantity = expected_Quantity.replace("$", "");
				Float expected_Quantity_temp = Float.parseFloat(expected_Quantity);

				if (expected_Quantity_temp.toString().trim().contains(actual_Quantity_temp.toString().trim())
						|| actual_Quantity_temp.toString().trim().contains(expected_Quantity_temp.toString().trim())) {
					passed("validateCreditMemo", "Quantity Should be displayed as " + expected_Quantity,
							"Quantity is displayed as " + actual_Quantity);
				} else {
					failed("validateCreditMemo", "Quantity Should be displayed as " + expected_Quantity,
							"Quantity is displayed as " + actual_Quantity);
				}
			}

			if (uiDriver.checkElementPresent("//table[@id='item_splits']//tbody//td[contains(text(),'" + GLPN[k].trim()
					+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Amount']//..//preceding-sibling::*)+1]")) {
				String actual_Amount;
				Float actual_Amount_temp;
				el = uiDriver.webDr.findElements(By.xpath("//table[@id='item_splits']//tbody//td[contains(text(),'"
						+ GLPN[k].trim()
						+ "')]//..//td[count(//table[@id='item_splits']//td//div[text()='Amount']//..//preceding-sibling::*)+1]"));
				try {
					actual_Amount = el.get(temp).getText();
					actual_Amount = actual_Amount.replace(",", "");
					actual_Amount = actual_Amount.replace("$", "");
					actual_Amount_temp = Float.parseFloat(actual_Amount);
				} catch (Exception e) {
					temp = 0;
					actual_Amount = el.get(0).getText();
					actual_Amount = actual_Amount.replace(",", "");
					actual_Amount = actual_Amount.replace("$", "");
					actual_Amount_temp = Float.parseFloat(actual_Amount);
				}

				String expected_Amount = Amount[k].trim();
				expected_Amount = expected_Amount.replace("Null", " ");
				expected_Amount = expected_Amount.replace(",", "");
				expected_Amount = expected_Amount.replace("$", "");
				Float expected_Amount_temp = Float.parseFloat(expected_Amount);

				if (expected_Amount_temp.toString().trim().contains(actual_Amount_temp.toString().trim())
						|| actual_Amount_temp.toString().trim().contains(expected_Amount_temp.toString().trim())) {
					passed("validateCreditMemo", "Amount Should be displayed as " + expected_Amount,
							"Amount is displayed as " + actual_Amount);
				} else {
					failed("validateCreditMemo", "Amount Should be displayed as " + expected_Amount,
							"Amount is displayed as " + actual_Amount);
				}
			}

			k++;
		}

		// if(uiDriver.checkElementPresent("//input[@id='_back']")) {
		// uiDriver.executeJavaScript("scroll(0,-1000)");
		// uiDriver.click("//input[@id='_back']");
		// } else {
		// uiDriver.back();
		// }
	}

}
