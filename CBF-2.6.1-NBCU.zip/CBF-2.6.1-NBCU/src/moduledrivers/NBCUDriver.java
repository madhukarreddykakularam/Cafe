package moduledrivers;

import static cbf.engine.TestResultLogger.*;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.apache.james.mime4j.field.datetime.DateTime;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.python.antlr.PythonParser.continue_stmt_return;
import org.apache.poi.ss.usermodel.DataFormatter;

import cbf.engine.TestResult.ResultType;
import cbf.utils.DataRow;
import cbf.utils.SleepUtils;
import cbf.utils.SleepUtils.TimeSlab;
import cbfx.basedrivers.BaseWebModuleDriver;
import cbfx.objectmaps.ObjectMap;

public class NBCUDriver extends BaseWebModuleDriver {

	/**
	 * Logs Procedure in Application
	 * 
	 * @param input
	 *            DataRow of input parameters
	 * @param output
	 *            empty DataRow passed to capture any runtime output during
	 *            execution of component
	 */

	/****************************************
	 * Name: salesOrder
	 * Description: salesOrder 
	 * Date: 30-Nov-2017
	 ****************************************/

	public void salesOrder(DataRow input, DataRow output)
			throws InterruptedException {
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setFrame("frame");
		uiDriver.mouseOver("transactions");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("sales");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("enterSalesOrder");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("list");
		passed("Verify the ListPage",
				"ListPage should be displayed successfully",
				"ListPage is displayed successfully");

	}

	/****************************************
	 * Name: selectCustomer 
	 * Description: Method to select the Customer
	 * Date: 30-Nov-2017
	 ****************************************/
	public void selectCustomer(DataRow input, DataRow output)
			throws InterruptedException {
		i = 2;
		uiDriver.click("newSalesOrder");
		String customer = input.get("customer");
		output.put("customer1", customer);
		uiDriver.setValue("customer", input.get("customer"));
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("licensefeetype");
		passed("SelectCustomer",
				"Customer name should be selected successfully",
				"Customer name " + input.get("customer")+ " is selected successfully");

		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("licensefeetype", input.get("licensefeetype"));
		uiDriver.click("licensefeetype");
		passed("Select licensefeetype",
				"licensefeetype should be set successfully", 
				"licensefeetype "+ input.get("licensefeetype") + " is set successfully");
		SleepUtils.sleep(2);
	}

	/****************************************
	 * Name: addSalesOrder
	 * Description: addSalesOrder
	 * Date: 30-Nov-2017
	 ****************************************/
	public void NavigateToItemMenu(DataRow input, DataRow output)
	
	{
		
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("Item");
		SleepUtils.sleep(TimeSlab.HIGH);
	}
	

		
	
	/****************************************
	 * Name: addSalesOrder
	 * Description: addSalesOrder
	 * Date: 30-Nov-2017
	 ****************************************/
	public void addSalesOrder(DataRow input, DataRow output)
			throws InterruptedException {
		uiDriver.executeJavaScript("scroll(0,500)");
		String row = "";
		SleepUtils.sleep(TimeSlab.HIGH);
		row = uiDriver.getObjMap("addListTable");
		row = row + "//" + "tr" + "[" + i + "]" + "";
		i++;
		uiDriver.click("SoLineNum");
		uiDriver.setValue("SoLineNum","");
		String Item = uiDriver.getDyanmicData("item");
		String ItemColumn = Integer.toString(ItemCol);
		String ItemCols = Item.replace("#", ItemColumn);
		uiDriver.click_dynamic(ItemCols);
		ItemCol++;
		
		List<WebElement> ele = uiDriver.webDr.findElements(By.xpath("//*[@id='item_headerrow']/td"));
		uiDriver.setValue("item1", input.get("item"));
		uiDriver.click("item1");
		String dataLable = "";

		for (int i = 0; i <= ele.size() - 1; i++) {
			try {
				dataLable = ele.get(i).getAttribute("data-label");
				switch (dataLable) {
				case "Market Code":

					if (!input.get("marketCode").equalsIgnoreCase("yes")) {

						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.click("marketCodeSet");
						SleepUtils.sleep(TimeSlab.YIELD);
						// uiDriver.setValue("marketCodeSet",
						// input.get("marketCode"));
						String MarketCode = uiDriver.getDyanmicData("marketCodeSet1");
						String marcode = MarketCode.replace("#",input.get("marketCode"));
						uiDriver.click(marcode);
						// uiDriver.click("market");
						// uiDriver.sendKey("enter");
						SleepUtils.sleep(TimeSlab.YIELD);
					}
					break;

				case "PTMG":

					if (input.get("ptmg").equalsIgnoreCase("yes")) {
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.executeJavaScript("document.getElementById('item_custcol_nbcu_ptmg_fs_inp').click();");
					}

					break;

				case "On Network":

					if (input.get("onNetwork").equalsIgnoreCase("yes")) {
						SleepUtils.sleep(TimeSlab.YIELD);

						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.executeJavaScript("document.getElementById('item_custcol_nbcu_on_network_fs_inp').click()");
					}
					break;
				case "Continuous Production":

					if (input.get("continuousProduction").equalsIgnoreCase("yes")) {
						SleepUtils.sleep(TimeSlab.YIELD);

						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.executeJavaScript("document.getElementById('item_custcol_nbcu_cont_prod_fs_inp').click()");
					}
					break;
				case "Rev Rec Method":

					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click("revRecMthdSet");
					uiDriver.setValue("revRecMthdSet",input.get("revRecMthdSet"));
					SleepUtils.sleep(TimeSlab.YIELD);

					break;
				case "Sub Type":

					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click("Subtypevalue");
					uiDriver.setValue("Subtypevalue",input.get("SubType"));
					SleepUtils.sleep(TimeSlab.YIELD);

					break;
				case "Title ID":
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click("titleSet");
					uiDriver.setValue("titleSet", input.get("titleSet"));
					SleepUtils.sleep(TimeSlab.YIELD);
					break;

				case "Territory":

					uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[9].click();");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.setValue("territorySet", input.get("territorySet"));
					uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[16].click();");
					break;

				case "Allocation Group":
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click("allocationGroupSet");
					uiDriver.setValue("allocationGroupSet",input.get("allocationGroupSet"));
					SleepUtils.sleep(TimeSlab.YIELD);
					break;

				case "License Fee Type":
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[18].click();");
					uiDriver.click("licenseFeeTypeSet");
					uiDriver.setValue("licenseFeeTypeSet",input.get("licenseFeeTypeSet"));
					SleepUtils.sleep(TimeSlab.YIELD);
					break;

				case "Product Category":
					SleepUtils.sleep(TimeSlab.HIGH);
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[19].click();");
					uiDriver.clear("productCategorySet");
					uiDriver.click("productCategorySet");
					uiDriver.setValue("productCategorySet",input.get("productCategorySet"));
					break;

				case "Product Type":
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[20].click();");
					uiDriver.click("productTypeSet");
					uiDriver.setValue("productTypeSet",input.get("productTypeSet"));
					SleepUtils.sleep(TimeSlab.YIELD);

					break;
				case "Right":

					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[21].click();");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click("rightSet");
					String right = uiDriver.getDyanmicData("right1");
					String Right = right.replace("#", input.get("rightSet"));
					uiDriver.click(Right);
					// uiDriver.setValue("rightSet", input.get("rightSet"));
					SleepUtils.sleep(TimeSlab.YIELD);
					break;

				/*case "GLPN":

					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[21].click();");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.clear("GLPNSet");
					uiDriver.click("GLPNSet");
					uiDriver.setValue("GLPNSet", input.get("GLPNSet"));
					SleepUtils.sleep(TimeSlab.YIELD);
					break;*/

				case "Quantity":
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[25].click();");
					uiDriver.click("quantitySet");		
					uiDriver.executeJavaScript("document.getElementById('quantity_formattedValue').value = ''");
					SleepUtils.sleep(5);
					uiDriver.setValue("quantitySet", input.get("quantitySet"));
					SleepUtils.sleep(TimeSlab.YIELD);

					break;

				case "Rate":
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[26].click();");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("rateSet");
					uiDriver.setValue("rateSet", input.get("rateSet"));
					break;
				case "Licensing Status":
					if(input.get("Licensing Status").equalsIgnoreCase("Licensed"))
					{
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[28].click();");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("licensingstatus");					
					uiDriver.setValue("licensingstatus",input.get("Licensing Status"));
					}
					else
					{
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[28].click();");
						SleepUtils.sleep(TimeSlab.YIELD);
						uiDriver.click("licensingstatus");					
						uiDriver.setValue("licensingstatus",input.get("Licensing Status"));
						
					}
					break;

				case "License Fee":
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[28].click();");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("licensefeeSet");
					uiDriver.setValue("licensefeeSet",input.get("licensefeeSet"));
					break;

				case "License Period Start Date":
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[33].click();");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("licenseStartDateSet");
					uiDriver.setValue("licenseStartDateSet",
							input.get("licenseStartDateSet"));
					SleepUtils.sleep(TimeSlab.YIELD);
					break;

				case "License Period End Date":
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[34].click();");
					uiDriver.click("licenseEndDateSet");
					uiDriver.setValue("licenseEndDateSet",
							input.get("licenseEndDateSet"));
					break;

				case "Delivery Date":

					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[35].click();");
					uiDriver.click("deliveryDateSet");
					uiDriver.setValue("deliveryDateSet",
							input.get("deliveryDateSet"));
					SleepUtils.sleep(TimeSlab.YIELD);
					break;

				/*
				 * case "Amount": uiDriver.click(row + "/td[" + (i + 1) + "]");
				 * uiDriver.click(row + "/td[" + (i + 1) + "]"); //
				 * uiDriver.executeJavaScript(
				 * "document.getElementsByClassName('listinlinefocusedrowcell')[35].click();"
				 * ); uiDriver.click("amountSet");
				 * uiDriver.setValue("amountSet", input.get("amountSet"));
				 * SleepUtils.sleep(TimeSlab.YIELD); break;
				 */

				case "Air / Release Date":
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[36].click();");
					uiDriver.click("airDateSet");
					uiDriver.setValue("airDateSet", input.get("airDateSet"));
					break;
					
				case "Offered Date":
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[36].click();");
					uiDriver.click("offerDateSet");
					uiDriver.setValue("offerDateSet", input.get("offerDateSet"));
					uiDriver.click("addBtn");
					break;

				case "XPG FLAG":

					break;
				case "Late Night":

					break;
				case "FMV Dimension":

					break;

				}
			}
catch (org.openqa.selenium.UnhandledAlertException e) {

				break;
			}




			 catch (org.openqa.selenium.StaleElementReferenceException e) {
				continue;
			}

		}

		int ActualLength = i - 3;
		String ActualLen = Integer.toString(ActualLength);
		output.put("ActualSize", ActualLen);
		SleepUtils.sleep(TimeSlab.YIELD);
		String postingPeriod = input.get("postingPeriod");
		output.put("posting1", postingPeriod);
		String deliveryDate = input.get("deliveryDateSet");
		output.put("Date", deliveryDate);
		String ValueA = input.get("UNBILLED REVENUE ACCOUNT");//
		output.put("VALUE1", ValueA);
		String ValueB = input.get("BILLED REVENUE ACCOUNT");
		output.put("VALUE2", ValueB);
		String ValueC = input.get("BILLED AR ACCOUNT");
		output.put("VALUE3", ValueC);
		String ValueD = input.get("UNBILLED AR ACCOUNT");
		output.put("VALUE4", ValueD);
		String ValueE = input.get("PAID DEFERRED ACCOUNT");
		output.put("VALUE5", ValueE);
		String ValueF = input.get("UNPAID DEFERRED ACCOUNT");//
		output.put("VALUE6", ValueF);
		String ValueG = input.get("BAD DEBT REVENUE ACCOUNT");
		output.put("VALUE7", ValueG);
		String ValueH = input.get("Recognition Account");		output.put("VALUE8", ValueH);
		/* String[] arrValue = ValueA;
		String[] strArray = new String[] {ValueH};
		 output.put("VALUE8[]",strArray[0]);
		 output.put("VALUE9[]",strArray[1]);
		SleepUtils.sleep(TimeSlab.YIELD);*/

	}
	/****************************************
	 * Name: addSalesOrder
	 * Description: addSalesOrder
	 * Date: 30-Nov-2017
	 ****************************************/
	public void addSalesOrderdefaultmarketcode(DataRow input, DataRow output)
			throws InterruptedException {
		String row = "";
		SleepUtils.sleep(TimeSlab.HIGH);
		row = uiDriver.getObjMap("addListTable");
		row = row + "//" + "tr" + "[" + i + "]" + "";
		i++;
		uiDriver.click("SoLineNum");
		uiDriver.setValue("SoLineNum","");
		String Item = uiDriver.getDyanmicData("item");
		String ItemColumn = Integer.toString(ItemCol);
		String ItemCols = Item.replace("#", ItemColumn);
		uiDriver.click_dynamic(ItemCols);
		ItemCol++;
		
		List<WebElement> ele = uiDriver.webDr.findElements(By.xpath("//*[@id='item_headerrow']/td"));
		uiDriver.setValue("item1", input.get("item"));
		uiDriver.click("item1");
		String dataLable = "";

		for (int i = 0; i <= ele.size() - 1; i++) {
			try {
				dataLable = ele.get(i).getAttribute("data-label");
				switch (dataLable) {
				/*case "Market Code":

					if (!input.get("marketCode").equalsIgnoreCase("yes")) {

						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.click("marketCodeSet");
						SleepUtils.sleep(TimeSlab.YIELD);
						// uiDriver.setValue("marketCodeSet",
						// input.get("marketCode"));
						String MarketCode = uiDriver.getDyanmicData("marketCodeSet1");
						String marcode = MarketCode.replace("#",input.get("marketCode"));
						uiDriver.click(marcode);
						// uiDriver.click("market");
						// uiDriver.sendKey("enter");
						SleepUtils.sleep(TimeSlab.YIELD);
					}
					break;*/

				case "PTMG":

					if (input.get("ptmg").equalsIgnoreCase("yes")) {
						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.executeJavaScript("document.getElementById('item_custcol_nbcu_ptmg_fs_inp').click();");
					}

					break;

				case "On Network":

					if (input.get("onNetwork").equalsIgnoreCase("yes")) {
						SleepUtils.sleep(TimeSlab.YIELD);

						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.executeJavaScript("document.getElementById('item_custcol_nbcu_on_network_fs_inp').click()");
					}
					break;
				case "Continuous Production":

					if (input.get("continuousProduction").equalsIgnoreCase("yes")) {
						SleepUtils.sleep(TimeSlab.YIELD);

						uiDriver.click(row + "/td[" + (i + 1) + "]");
						uiDriver.executeJavaScript("document.getElementById('item_custcol_nbcu_cont_prod_fs_inp').click()");
					}
					break;

				case "Rev Rec Method":

					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click("revRecMthdSet");
					uiDriver.setValue("revRecMthdSet",input.get("revRecMthdSet"));
					SleepUtils.sleep(TimeSlab.YIELD);

					break;

				case "Title ID":
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click("titleSet");
					uiDriver.setValue("titleSet", input.get("titleSet"));
					SleepUtils.sleep(TimeSlab.YIELD);
					break;

				case "Territory":

					uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[9].click();");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.setValue("territorySet", input.get("territorySet"));
					uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[16].click();");
					break;

				case "Allocation Group":
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click("allocationGroupSet");
					uiDriver.setValue("allocationGroupSet",input.get("allocationGroupSet"));
					SleepUtils.sleep(TimeSlab.YIELD);
					break;

				case "License Fee Type":
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[18].click();");
					uiDriver.click("licenseFeeTypeSet");
					uiDriver.setValue("licenseFeeTypeSet",input.get("licenseFeeTypeSet"));
					SleepUtils.sleep(TimeSlab.YIELD);
					break;

				case "Product Category":
					SleepUtils.sleep(TimeSlab.HIGH);
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[19].click();");
					uiDriver.clear("productCategorySet");
					uiDriver.click("productCategorySet");
					uiDriver.setValue("productCategorySet",input.get("productCategorySet"));
					break;

				case "Product Type":
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[20].click();");
					uiDriver.click("productTypeSet");
					uiDriver.setValue("productTypeSet",input.get("productTypeSet"));
					SleepUtils.sleep(TimeSlab.YIELD);

					break;
				case "Right":

					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[21].click();");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click("rightSet");
					String right = uiDriver.getDyanmicData("right1");
					String Right = right.replace("#", input.get("rightSet"));
					uiDriver.click(Right);
					// uiDriver.setValue("rightSet", input.get("rightSet"));
					SleepUtils.sleep(TimeSlab.YIELD);
					break;

				/*case "GLPN":

					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[21].click();");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.clear("GLPNSet");
					uiDriver.click("GLPNSet");
					uiDriver.setValue("GLPNSet", input.get("GLPNSet"));
					SleepUtils.sleep(TimeSlab.YIELD);
					break;*/

				case "Quantity":
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[25].click();");
					uiDriver.click("quantitySet");		
					uiDriver.executeJavaScript("document.getElementById('quantity_formattedValue').value = ''");
					SleepUtils.sleep(5);
					uiDriver.setValue("quantitySet", input.get("quantitySet"));
					SleepUtils.sleep(TimeSlab.YIELD);

					break;

				case "Rate":
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[26].click();");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("rateSet");
					uiDriver.setValue("rateSet", input.get("rateSet"));
					break;
					
				case "Licensing Status":
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[28].click();");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("licensingstatus");
					uiDriver.setValue("licensingstatus",input.get("Licensing Status"));
					break;


				case "License Fee":
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[28].click();");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("licensefeeSet");
					uiDriver.setValue("licensefeeSet",input.get("licensefeeSet"));
					break;

				case "License Period Start Date":
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[33].click();");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("licenseStartDateSet");
					uiDriver.setValue("licenseStartDateSet",
							input.get("licenseStartDateSet"));
					SleepUtils.sleep(TimeSlab.YIELD);
					break;

				case "License Period End Date":
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[34].click();");
					uiDriver.click("licenseEndDateSet");
					uiDriver.setValue("licenseEndDateSet",
							input.get("licenseEndDateSet"));
					break;

				case "Delivery Date":

					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[35].click();");
					uiDriver.click("deliveryDateSet");
					uiDriver.setValue("deliveryDateSet",
							input.get("deliveryDateSet"));
					SleepUtils.sleep(TimeSlab.YIELD);
					break;

				/*
				 * case "Amount": uiDriver.click(row + "/td[" + (i + 1) + "]");
				 * uiDriver.click(row + "/td[" + (i + 1) + "]"); //
				 * uiDriver.executeJavaScript(
				 * "document.getElementsByClassName('listinlinefocusedrowcell')[35].click();"
				 * ); uiDriver.click("amountSet");
				 * uiDriver.setValue("amountSet", input.get("amountSet"));
				 * SleepUtils.sleep(TimeSlab.YIELD); break;
				 */

				case "Air / Release Date":
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[36].click();");
					uiDriver.click("airDateSet");
					uiDriver.setValue("airDateSet", input.get("airDateSet"));
					break;
					
				case "Offered Date":
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					uiDriver.click(row + "/td[" + (i + 1) + "]");
					// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[36].click();");
					uiDriver.click("offerDateSet");
					uiDriver.setValue("offerDateSet", input.get("offerDateSet"));
					uiDriver.click("addBtn");
					break;

				case "XPG FLAG":

					break;
				case "Late Night":

					break;
				case "FMV Dimension":

					break;

				}
			} catch (org.openqa.selenium.StaleElementReferenceException e) {

				continue;
			}

		}

		int ActualLength = i - 3;
		String ActualLen = Integer.toString(ActualLength);
		output.put("ActualSize", ActualLen);
		SleepUtils.sleep(TimeSlab.YIELD);
		String postingPeriod = input.get("postingPeriod");
		output.put("posting1", postingPeriod);
		String deliveryDate = input.get("deliveryDateSet");
		output.put("Date", deliveryDate);
		String ValueA = input.get("UNBILLED REVENUE ACCOUNT");//
		output.put("VALUE1", ValueA);
		String ValueB = input.get("BILLED REVENUE ACCOUNT");
		output.put("VALUE2", ValueB);
		String ValueC = input.get("BILLED AR ACCOUNT");
		output.put("VALUE3", ValueC);
		String ValueD = input.get("UNBILLED AR ACCOUNT");
		output.put("VALUE4", ValueD);
		String ValueE = input.get("PAID DEFERRED ACCOUNT");
		output.put("VALUE5", ValueE);
		String ValueF = input.get("UNPAID DEFERRED ACCOUNT");//
		output.put("VALUE6", ValueF);
		String ValueG = input.get("BAD DEBT REVENUE ACCOUNT");
		output.put("VALUE7", ValueG);
		String ValueH = input.get("Recognition Account");		output.put("VALUE8", ValueH);
		/* String[] arrValue = ValueA;
		String[] strArray = new String[] {ValueH};
		 output.put("VALUE8[]",strArray[0]);
		 output.put("VALUE9[]",strArray[1]);
		SleepUtils.sleep(TimeSlab.YIELD);*/

	}


	/****************************************
	 * Name: Change 
	 * Description: Method to Change Currency Type
	 * Date:30-Nov-2017
	 ****************************************/
	public void ChangeCurrencyType(DataRow input, DataRow output) {
		/*if (uiDriver.checkElementPresent("newSalesOrder")) {
			uiDriver.click("newSalesOrder");	
		}
		else
		{
		
		}*/
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Accounting");
		passed("Click On Accounting button",
				"Should click  on Accounting button",
				"Successfully clicked on Accounting button");
		
		SleepUtils.sleep(TimeSlab.LOW);
		
		uiDriver.setValue("CurrencyType", input.get("CurrencyType"));
		//uiDriver.click("CurrencyType");
		passed("Select CurrencyType",
				"CurrencyType should be set successfully", 
				"CurrencyType "+ input.get("CurrencyType") + " is set successfully");
		//SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("exchangeRate");
		uiDriver.handleAlert("", "OK");
		//SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("document.getElementById('exchangerate_formattedValue').value='"+input.get("exchangeRate")+"';");
		//SleepUtils.sleep(TimeSlab.LOW);
		//uiDriver.setValue("exchangeRate", input.get("exchangeRate"));
		String exchangeRate = uiDriver.getValue("exchangeRate");
		uiDriver.handleAlert("", "OK");
		output.put("exchangeRate", exchangeRate);
		

	}
	/****************************************
	 * Name: saveOrder 
	 * Description: Method to save the Sales Order 
	 * Date:30-Nov-2017
	 ****************************************/
	public void saveOrder(DataRow input, DataRow output) {
		uiDriver.click("saveBtn");
		passed("Click On save button",
				"Details Should be saved successfully",
				"Details is saved successfully");
		
		SleepUtils.sleep(TimeSlab.MEDIUM);
		orderId = uiDriver.getValue("orderId");
		uiDriver.drawHighlight("getFMVDimention");
		FMVDimention = input.get("FMVDimention");

		int fmvDmn = uiDriver.getEleIndex("//*[@id='item_splits']/tbody/tr[1]/td", "FMV Dimension");
		List<WebElement> percentage = uiDriver.webDr.findElements(By.xpath("//*[@class='uir-machine-row uir-machine-row-even' or @class='uir-machine-row uir-machine-row-odd']/td["+ fmvDmn + "]"));

		for (WebElement percentageElement : percentage) {

			if (percentageElement.getText().equals(FMVDimention)) {

				continue;
			} else {
				failed("create sales record and check for FMV Dimention Updation",
						"Should create the record and FMV Dimention should be updated",
						"Error in sales record creation!!");
			}
		}
		passed("create sales record and check for FMV Dimention Updation",
				"Should create the record and FMV Dimention should be updated",
				" sales record created and FMV Dimention updated successfully!");

	}

	/****************************************
	 * Name: updateRevenueArrangements
	 * Description: updateRevenueArrangements
	 * Date: 30-Nov-2017
	 ****************************************/
	public void updateRevenueArrangements(DataRow input, DataRow output) {

		uiDriver.mouseOver("transactions");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("financial");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("updateRevenueArrangement");
		SleepUtils.sleep(TimeSlab.YIELD);

		uiDriver.click("updateRevenueArrBtn");
		SleepUtils.sleep(TimeSlab.LOW);

		uiDriver.click("updateRevenuePlanBtn");
		SleepUtils.sleep(TimeSlab.LOW);

		/*
		 * uiDriver.click("refreshBtn"); SleepUtils.sleep(TimeSlab.HIGH);
		 * uiDriver.click("refreshBtn"); SleepUtils.sleep(TimeSlab.MEDIUM);
		 * uiDriver.click("refreshBtn"); SleepUtils.sleep(TimeSlab.HIGH);
		 * uiDriver.click("refreshBtn"); SleepUtils.sleep(TimeSlab.HIGH);
		 * uiDriver.click("refreshBtn"); SleepUtils.sleep(TimeSlab.HIGH);
		 * uiDriver.click("refreshBtn"); SleepUtils.sleep(TimeSlab.HIGH);
		 * uiDriver.click("refreshBtn");
		 */

		List<WebElement> percentage = uiDriver.webDr.findElements(By.xpath("//*[@class='uir-list-row-tr uir-list-row-even' or @class='uir-list-row-tr uir-list-row-odd']/td[4]"));

		for (WebElement percentageElement : percentage) {

			if (percentageElement.getText().equals("100.0%")) {

			}
		}

	}
	/****************************************
	 * Name: CheckCashbasis
	 * Description: CheckCashbasis
	 * Date: 3-July-2017
	 ****************************************/
	public void CheckCashbasis(DataRow input, DataRow output) {		
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("//*[@id='custbody_nbcu_cash_basis_fs']/img");
	}

	/****************************************
	 * Name: editContract 
	 * Description:Method to edit Contract 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void editContract(DataRow input, DataRow output)
			throws InterruptedException {

		int x = 0;
		uiDriver.webDr.findElement(By.xpath("//tr[@class='uir-list-row-tr uir-list-row-even' or @class='uir-list-row-tr uir-list-row-odd']/td[4]/a[contains(text(),'"+ orderId+ "')]/parent::td/parent::tr/td[1]/a[contains(text(),'Edit')]")).click();

		int amount = uiDriver.getEleIndex("//*[@id='item_headerrow']/td", "Amount");
		fmvValue = uiDriver.webDr.findElements(By.xpath("//*[@class='uir-machine-row uir-machine-row-even' or @class='uir-machine-row uir-machine-row-odd']/td["+ amount + "]"));
		for (WebElement fmv : fmvValue) {
			fmvVal.add(fmv.getText());
		}

		if (uiDriver.getValue("userOrderId").equals(orderId)) {
			passed("User should be on summary page",
					"Should display summary page",
					"Summary page displayed successfully!");

		} else {
			failed("User should be on summary page",
					"Should display summary page",
					"Could not display the Summary page!");

		}

		uiDriver.resetFrame();
		uiDriver.setFrame("frame");
		int fmvDim = uiDriver.getEleIndex("//*[@id='item_splits']/tbody/tr[1]/td", "FMV Dimension");

		if (uiDriver.getValue("//*[@id='item_splits']/tbody/tr[2]/td[" + fmvDim + "]").equals(FMVDimention)) {
			passed("Check for FMV Dimention Updation",
					"Should create the record and FMV Dimention should be updated",
					" sales record created and FMV Dimention updated successfully!");

		} else {
			failed("Check for FMV Dimention Updation",
					"Should create the record and FMV Dimention should be updated",
					"Error in sales record creation!!");

		}
		uiDriver.executeJavaScript("scroll(0,200)");
		uiDriver.click("relatedRecord");

		uiDriver.click("date");
		SleepUtils.sleep(TimeSlab.LOW);

		int salesAmt = uiDriver.getEleIndex("//*[@id='revenueelement_splits']/tbody/tr[1]/td","Sales Amount");

		List<WebElement> revenueAmt = uiDriver.webDr.findElements(By.xpath("//*[@class='uir-machine-row uir-machine-row-odd' or @class='uir-machine-row uir-machine-row-even']/td["+ salesAmt + "]"));
		int j = 0;
		for (WebElement revenueAmount : revenueAmt) {
			System.out.println(fmvVal.get(j));
			System.out.println(revenueAmount.getText());
			if (revenueAmount.getText().equals(fmvVal.get(j))) {
				j++;
				continue;

			} else {
				failed("Check for Revenue amount",
						"Should check the updated record for revenue amount with FMV",
						"Revenue amount is not same as FMV!!");
			}
		}
		passed("Check for Revenue amount",
				"Should check the updated record for revenue amount with FMV",
				"Revenue amount is same as FMV!");

		SleepUtils.sleep(TimeSlab.YIELD);

	}

	/****************************************
	 * Name: checkRevRec
	 * Description:Method to check Revenue Recognation 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void checkRevRec(DataRow input, DataRow output)
			throws InterruptedException {

		uiDriver.click("edit");
		if (uiDriver.checkElementPresent("dummy")) {
			uiDriver.click("dummy");
			uiDriver.click("remove");
		}

		uiDriver.click("title");
		uiDriver.click("cpyPrevious");

		String row = "";
		row = uiDriver.getObjMap("addListTable");

		row = row + "//" + "tr" + "[" + i + "]" + "";
		i++;

		int marketCode = uiDriver.getEleIndex("//*[@id='item_headerrow']/td","Market Code (Department)");
		uiDriver.click(row + "/td[" + marketCode + "]");
		uiDriver.click(row + "/td[" + marketCode + "]");
		uiDriver.setValue("marketCodeSet", input.get("marketCode"));
		SleepUtils.sleep(TimeSlab.YIELD);

		int right = uiDriver.getEleIndex("//*[@id='item_headerrow']/td","Right");
		// uiDriver.executeJavaScript("document.getElementsByClassName('listinlinefocusedrowcell')[21].click();");
		uiDriver.click(row + "/td[" + right + "]");
		uiDriver.click(row + "/td[" + right + "]");
		uiDriver.click("rightSet");
		uiDriver.setValue("rightSet", input.get("rightSet"));

		int revRec = uiDriver.getEleIndex("//*[@id='item_headerrow']/td","Rev Rec Method");
		uiDriver.click(row + "/td[" + revRec + "]");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click(row + "/td[" + revRec + "]");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("revRecMthdSet");
		uiDriver.click("//div[@class='uir-tooltip-content']/div/div[1]");
		uiDriver.click("revRecMthdSet");
		SleepUtils.sleep(TimeSlab.LOW);

		if (input.get("ptmg").equalsIgnoreCase("yes")) {
			int ptmg = uiDriver.getEleIndex("//*[@id='item_headerrow']/td",	"PTMG");
			uiDriver.click(row + "/td[" + ptmg + "]");
			uiDriver.executeJavaScript("document.getElementById('item_custcol_nbcu_ptmg_fs_inp').click();");
		}

		SleepUtils.sleep(TimeSlab.LOW);
		if (input.get("networkFlag").equalsIgnoreCase("yes")) {
			SleepUtils.sleep(TimeSlab.YIELD);
			int onNetwork = uiDriver.getEleIndex("//*[@id='item_headerrow']/td", "On Network");
			uiDriver.click(row + "/td[" + onNetwork + "]");
			SleepUtils.sleep(TimeSlab.YIELD);
     		uiDriver.executeJavaScript("document.getElementById('item_custcol_nbcu_on_network_fs_inp').click()");
		}

		if (input.get("xpgFlag").equalsIgnoreCase("yes")) {
			SleepUtils.sleep(TimeSlab.YIELD);
			int xpg = uiDriver.getEleIndex("//*[@id='item_headerrow']/td","XPG FLAG");
			uiDriver.click(row + "/td[" + xpg + "]");
			SleepUtils.sleep(TimeSlab.YIELD);

			uiDriver.executeJavaScript("document.getElementById('item_custcol_nbcu_xpg_flag_fs_inp').click()");

		}

		if (input.get("lateNight").equalsIgnoreCase("yes")) {
			SleepUtils.sleep(TimeSlab.YIELD);
			int lateNt = uiDriver.getEleIndex("//*[@id='item_headerrow']/td","Late Night");
			uiDriver.click(row + "/td[" + lateNt + "]");
			SleepUtils.sleep(TimeSlab.YIELD);

			uiDriver.executeJavaScript("document.getElementById('item_custcol_nbcu_latenight_fs_inp').click()");

		}
		if (!(input.get("paymentType") == null || input.get("paymentType")
				.equals(""))) {
			SleepUtils.sleep(TimeSlab.YIELD);
			// uiDriver.click("paymentType");
			// uiDriver.executeJavaScript("document.getElementById('inpt_custbody_nbcu_payment_type7').value='"+input.get("paymentType")+"';");
			uiDriver.setValue("paymentType", input.get("paymentType"));
			SleepUtils.sleep(TimeSlab.YIELD);
		}

		uiDriver.click("saveBtn");

		SleepUtils.sleep(TimeSlab.LOW);

		System.out.println(input.get("revRecMethod"));
		if (uiDriver.getValue(row + "/td[" + revRec + "]").equals(input.get("revRecMethod"))) {
			passed("Check for Rev Rec method Updation",
					"Should check the rev record and should be updated",
					" sales record created and Rev Rec  updated successfully!");

		} else {
			failed("Check for Rev Rec method Updation",
					"Should check the rev record  and should be updated",
					"Error in sales record updation!!");

		}

	}

	/****************************************
	 * Name: checkRevRecByManualValue 
	 * Description: Method to check Revenue Recognation By ManualValue
	 *  Date: 30-Nov-2017
	 ****************************************/
	public void checkRevRecByManualValue(DataRow input, DataRow output)
			throws InterruptedException {
		List<WebElement> revRecEleList = new ArrayList<WebElement>();
		List<String> revRecList = new ArrayList<String>();

		uiDriver.click("edit");

		String row = "";
		row = uiDriver.getObjMap("row");

		int revRec = uiDriver.getEleIndex("//*[@id='item_headerrow']/td",
				"Rev Rec Method");
		j++;
		uiDriver.click(row);
		uiDriver.click(row + "/td[" + revRec + "]");
		uiDriver.click(row + "/td[" + revRec + "]");
		revRecEleList = uiDriver.webDr.findElements(By.xpath("//div[@class='uir-tooltip-content']/div/div"));
		for (WebElement revRecEle : revRecEleList) {
			System.out.println(revRecEle.getText());
			if (!(revRecEle.getText().equals(" ") || revRecEle.getText() == null))
				revRecList.add(revRecEle.getText());
			System.out.println(revRecList);

		}

		if (input.get("rec127").equals("yes")) {
			if (revRecList.contains("Transactional Statement Processing Date")
					&& revRecList.contains("Upon Air Date")
					&& revRecList.contains("License Period Start Date")
					&& revRecList.contains("Annual Minimum Guarantee")) {
				passed("Check for Rev Rec methods",
						"Should check the rev record methods",
						" required methods are present!");
			} else {
				failed("Check for Rev Rec method Updation",
						"Should check the rev record  and should be updated",
						"required methods are not present!!");

			}

		}

		if (input.get("rec114").equals("yes")) {
			if (revRecList.contains("Subscriber Statement Processing Date")
					&& revRecList.contains("Upon Air Date")
					&& revRecList.contains("License Period Start Date")
					&& revRecList.contains("Upon Delivery Date")
					&& revRecList.contains("Upon Payment")) {
				passed("Check for Rev Rec methods",
						"Should check the rev record methods",
						" required methods are present!");
			} else {
				failed("Check for Rev Rec method Updation",
						"Should check the rev record  and should be updated",
						"required methods are not present!!");

			}

		}
		if (input.get("rec34").equals("yes")) {
			if (revRecList.contains("Upon Invoicing")
					&& revRecList.contains("Upon Air Date")
					&& revRecList.contains("License Period Start Date")
					&& revRecList.contains("Upon Delivery Date")
					&& revRecList.contains("Upon Payment")
					&& revRecList.contains("Over Time")) {
				passed("Check for Rev Rec methods",
						"Should check the rev record methods",
						" required methods are present!");
			} else {
				failed("Check for Rev Rec method Updation",
						"Should check the rev record  and should be updated",
						"required methods are not present!!");

			}

		}

		uiDriver.click(row + "/td[" + revRec + "]");
		uiDriver.click(row + "/td[" + revRec + "]");
		uiDriver.setValue("revRecMthdSet", "License Period Start Date");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("ok");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("saveBtn");
		SleepUtils.sleep(TimeSlab.LOW);

	}
	public void saveonlySalesOrder(DataRow input, DataRow output) throws InterruptedException {
		uiDriver.executeJavaScript("scroll(0,-1500)");
		uiDriver.click("saveBtn");
		if(uiDriver.isAlertPresent()){
			uiDriver.handleAlert("", "OK");
			uiDriver.executeJavaScript("scroll(0,-500)");
			uiDriver.click("saveBtn");
			uiDriver.click("DuplicateSave");		
			passed("Click On save button", "Details Should be saved successfully",
				"Details is saved successfully");
				 		
		}
		else{
			//do nothing
		}
		
		
		SleepUtils.sleep(TimeSlab.MEDIUM);
		 updateFTKey(input,output);
	}

	/****************************************
	 * Name: saveSalesOrder
	 * Description: saveSalesOrder 
	 * Date: 30-Nov-2017
	 * @throws InterruptedException 
	 ****************************************/
	public void saveSalesOrder(DataRow input, DataRow output) throws InterruptedException {
		uiDriver.executeJavaScript("scroll(0,-1500)");

		uiDriver.click("saveBtn");
		if(uiDriver.isAlertPresent()){
			uiDriver.handleAlert("", "OK");
			uiDriver.executeJavaScript("scroll(0,-500)");
			uiDriver.click("saveBtn");
			uiDriver.click("DuplicateSave");		
			passed("Click On save button", "Details Should be saved successfully",
				"Details is saved successfully");				 		
		}
		else{
			//do nothing
		}				
		SleepUtils.sleep(TimeSlab.MEDIUM);
		 updateFTKey(input,output);
		uiDriver.click("approve");
		passed("Click On approve button",
				"Details Should be approved successfully",
				"Details is approved successfully");
		
		if(input.get("PartialAmt").equals("Y")){
					
		String VAT=uiDriver.getValue("VAT").substring(0, (uiDriver.getValue("VAT").length()-1));
		String ActualVATPartial = input.get("VATAmt");
		String ActualVATPartial1 = input.get("VATAmt1");
		int VATPartial  = Integer.parseInt(ActualVATPartial);
		//int VATPartial2 = 100 - VATPartial;
		int VATPartial2 = Integer.parseInt(ActualVATPartial1);
		int VATPartial1 = Integer.parseInt(ActualVATPartial1);
		String CashlessTax = uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE");
		if(CashlessTax.contains(","))
		{
			CashlessTax=CashlessTax.replace(",", "");
		}
		double CashlessTaxAmt = Double.parseDouble(CashlessTax);
		double CashlessTaxPartial = (CashlessTaxAmt* VATPartial)/100;
		double CashlessTaxPartial2 = (CashlessTaxAmt* VATPartial2)/100;
		String PartialCashlessTax = Double.toString(CashlessTaxPartial);
		String RestPartialCashlessTax = Double.toString(CashlessTaxPartial2);
		String TaxAmt = uiDriver.getValue("TaxAmt");
		if(TaxAmt.contains(","))
		{
			TaxAmt=TaxAmt.replace(",", "");
		}
		double TaxAmount = Double.parseDouble(TaxAmt);
		double TaxAmtPartial = (TaxAmount*VATPartial)/100;
		double TaxAmtPartial2 = (TaxAmount*VATPartial2)/100;
		double TaxAmtPartial1 = (TaxAmount*VATPartial1)/100;
		String PartialTaxAmt;
		String RestPartialTaxAmt;
		String PartialTaxAmt1;
		if(TaxAmt.startsWith("0"))
		{
			PartialTaxAmt=String.format("%.2f", TaxAmtPartial);
			PartialTaxAmt1 = String.format("%.2f", TaxAmtPartial1);
			RestPartialTaxAmt=String.format("%.2f", TaxAmtPartial2);
			
		}
		else
		{
		 PartialTaxAmt = Double.toString(TaxAmtPartial);
		 PartialTaxAmt1 = Double.toString(TaxAmtPartial1);
		 RestPartialTaxAmt = Double.toString(TaxAmtPartial2);
		}
		String TotalTax= uiDriver.getValue("TaxTotal");
		double TotalAmount = CashlessTaxPartial + TaxAmtPartial ;
		 SleepUtils.sleep(TimeSlab.YIELD);
		String PartialTotalAmt = Double.toString(TotalAmount);
		
		double TotalAmount1 = CashlessTaxPartial2 + TaxAmtPartial2 ;
		String RestPartialTotalAmt = Double.toString(TotalAmount1);
		
		double totalamountwithtaxadd = CashlessTaxAmt+TaxAmount;
		String totalamountwithtax=Double.toString(totalamountwithtaxadd);
		output.put("PartialCashlessTax",PartialCashlessTax);
		output.put("PartialTaxAmt",PartialTaxAmt);
		output.put("PartialTotalAmt",PartialTotalAmt);
		output.put("VAT",VAT);
		output.put("RestPartialCashlessTax", RestPartialCashlessTax);
		output.put("RestPartialTaxAmt",RestPartialTaxAmt);
		output.put("RestPartialTotalAmt",RestPartialTotalAmt);
		output.put("totalamountwithtax",totalamountwithtax);
}	
		
		if(input.get("multipleinvoiceandpayment").equals("Y")){
			String VAT=uiDriver.getValue("VAT").substring(0, (uiDriver.getValue("VAT").length()-1));
		
		int VATPartial = 40;
		int VATPartial2 = 100 - VATPartial;
		String CashlessTax = uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE");
		if(CashlessTax.contains(","))
		{
			CashlessTax=CashlessTax.replace(",", "");
		}
		int tax1=40;
		int tax2=100-tax1;
		double CashlessTaxAmt = Double.parseDouble(CashlessTax);
		double CashlessTaxPartial = (CashlessTaxAmt* VATPartial)/100;
		double CashlessTaxPartial2 = (CashlessTaxAmt* VATPartial2)/100;
		double CashlessTaxPartialpayment1 = CashlessTaxPartial*tax1/100;
		double CashlessTaxPartialpayment2 = CashlessTaxPartial*tax2/100;
		double CashlessTaxPartialpayment3 = CashlessTaxPartial2*tax1/100;
		double CashlessTaxPartialpayment4 = CashlessTaxPartial2*tax2/100;
		String CashlessTaxPartialpayment_1=Double.toString(CashlessTaxPartialpayment1);
		String CashlessTaxPartialpayment_2=Double.toString(CashlessTaxPartialpayment2);
		String CashlessTaxPartialpayment_3=Double.toString(CashlessTaxPartialpayment3);
		String CashlessTaxPartialpayment_4=Double.toString(CashlessTaxPartialpayment4);
		
		
		String PartialCashlessTax = Double.toString(CashlessTaxPartial);
		String RestPartialCashlessTax = Double.toString(CashlessTaxPartial2);
		String TaxAmt = uiDriver.getValue("TaxAmt");
		double TaxAmount = Double.parseDouble(TaxAmt);
		double TaxAmtPartial = (TaxAmount*VATPartial)/100;
		double TaxAmtPartial2 = (TaxAmount*VATPartial2)/100;
		double TaxAmtPartialpayment1 = TaxAmtPartial*tax1/100;
		double TaxAmtPartialpayment2 = TaxAmtPartial*tax2/100;
		double TaxAmtPartialpayment3 = TaxAmtPartial2*tax1/100;
		double TaxAmtPartialpayment4 = TaxAmtPartial2*tax2/100;
		double payment1=CashlessTaxPartialpayment1+TaxAmtPartialpayment1;
		double payment2=CashlessTaxPartialpayment2+TaxAmtPartialpayment2;
		double payment3=CashlessTaxPartialpayment3+TaxAmtPartialpayment3;
		double payment4=CashlessTaxPartialpayment4+TaxAmtPartialpayment4;
		String PartialTaxAmt;
		String RestPartialTaxAmt;
		if(TaxAmt.startsWith("0"))
		{
			PartialTaxAmt=String.format("%.2f", TaxAmtPartial);
			RestPartialTaxAmt=String.format("%.2f", TaxAmtPartial2);
		}
		else
		{
		 PartialTaxAmt = Double.toString(TaxAmtPartial);
		 RestPartialTaxAmt = Double.toString(TaxAmtPartial2);
		}
		String TotalTax= uiDriver.getValue("TaxTotal");
		double TotalAmount = CashlessTaxPartial + TaxAmtPartial ;
		String PartialTotalAmt = Double.toString(TotalAmount);
		
		double TotalAmount1 = CashlessTaxPartial2 + TaxAmtPartial2 ;
		String RestPartialTotalAmt = Double.toString(TotalAmount1);
		String payment_1=Double.toString(payment1);
		String payment_2=Double.toString(payment2);
		String payment_3=Double.toString(payment3);
		String payment_4=Double.toString(payment4);
		String TaxAmtPartialpayment_1=Double.toString(TaxAmtPartialpayment1);
		String TaxAmtPartialpayment_2=Double.toString(TaxAmtPartialpayment2);
		String TaxAmtPartialpayment_3=Double.toString(TaxAmtPartialpayment3);
		String TaxAmtPartialpayment_4=Double.toString(TaxAmtPartialpayment4);
		
		output.put("PartialCashlessTax",PartialCashlessTax);
		output.put("PartialTaxAmt",PartialTaxAmt);
		output.put("PartialTotalAmt",PartialTotalAmt);
		output.put("VAT",VAT);
		output.put("RestPartialCashlessTax", RestPartialCashlessTax);
		output.put("RestPartialTaxAmt",RestPartialTaxAmt);
		output.put("RestPartialTotalAmt",RestPartialTotalAmt);
		output.put("payment_1", payment_1);
		output.put("payment_2", payment_2);
		output.put("payment_3", payment_3);
		output.put("payment_4", payment_4);
		output.put("CashlessTaxPartialpayment_1", CashlessTaxPartialpayment_1);
		output.put("CashlessTaxPartialpayment_2", CashlessTaxPartialpayment_2);
		output.put("CashlessTaxPartialpayment_3", CashlessTaxPartialpayment_3);
		output.put("CashlessTaxPartialpayment_4", CashlessTaxPartialpayment_4);
		output.put("TaxAmtPartialpayment_1", TaxAmtPartialpayment_1);
		output.put("TaxAmtPartialpayment_2", TaxAmtPartialpayment_2);
		output.put("TaxAmtPartialpayment_3", TaxAmtPartialpayment_3);
		output.put("TaxAmtPartialpayment_4", TaxAmtPartialpayment_4);
}	
		
		
		
		
		if(input.get("FullAmt").equals("Y")){	
		
			/*String CashlessTaxArr[] = uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE").split("\\.");	
			String CashlessTax  = CashlessTaxArr[0];
			String TaxAmtArr[] = uiDriver.getValue("TaxAmt").split("\\.");
			String TaxAmt = TaxAmtArr[0];
			String TotalAmountArr[] = uiDriver.getValue("TotalAmount").split("\\.");
			String TotalAmount = TotalAmountArr[0];
			String VATArr[] = uiDriver.getValue("VAT").split("\\.");
	 		String VAT= VATArr[0];
	 		int VATPartial = Integer.parseInt(VAT);
			output.put("CashlessTax",CashlessTax);
			output.put("TaxAmt",TaxAmt);
			output.put("TotalAmount",TotalAmount);
			output.put("VAT",VAT);*/
			String CashlessTax  =  uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE");
			String TaxAmt=uiDriver.getValue("TaxAmt");
			String TotalAmount= uiDriver.getValue("TotalAmount");
			String VAT=uiDriver.getValue("VAT").substring(0, (uiDriver.getValue("VAT").length()-1));
			output.put("CashlessTax",CashlessTax);
			output.put("TaxAmt",TaxAmt);
			output.put("TotalAmount",TotalAmount);
			output.put("VAT",VAT);
			
	}
		
		if(input.get("EditPayment").equals("Y")){
			String VAT=uiDriver.getValue("VAT").substring(0, (uiDriver.getValue("VAT").length()-1));
		
		int PayPartial = 90;
		
		String CashlessTax = uiDriver.getValue("TRUECASHLESSTAXAPPLIEDTOINVOICE");
		String TotalAmount= uiDriver.getValue("TotalAmount");	
		if(CashlessTax.contains(","))
		{
			CashlessTax=CashlessTax.replace(",", "");
		}
		double CashlessTaxAmt = Double.parseDouble(CashlessTax);
		double CashlessTaxPartial = (CashlessTaxAmt* PayPartial)/100;
		String PayPartialCashlessTax = Double.toString(CashlessTaxPartial);
		
		String TaxAmt = uiDriver.getValue("TaxAmt");
		double TaxAmount = Double.parseDouble(TaxAmt);
		double TaxAmtPartial = (TaxAmount*PayPartial)/100;
		
		String PayPartialTaxAmt;
		
		if(TaxAmt.startsWith("0"))
		{
			PayPartialTaxAmt=String.format("%.2f", TaxAmtPartial);
			
		}
		else
		{
			PayPartialTaxAmt = Double.toString(TaxAmtPartial);
		
		}
		String TotalTax= uiDriver.getValue("TaxTotal");
		double parTotalAmount = CashlessTaxPartial - TaxAmtPartial ;
		String payPartialTotalAmt = Double.toString(parTotalAmount);
				
		
		output.put("PayPartialCashlessTax",PayPartialCashlessTax);
		output.put("PayPartialTaxAmt",PayPartialTaxAmt);
		output.put("payPartialTotalAmt",payPartialTotalAmt);
		output.put("VAT",VAT);
		output.put("CashlessTax",CashlessTax);
		output.put("TaxAmt",TaxAmt);
		output.put("TotalAmount",TotalAmount);
		
		
		}
	}

	/****************************************
	 * Name: approveSalesOrder 
	 * Description:Method to approve the sales order
	 * Date: 30-Nov-2017
	 ****************************************/
 public void approveSalesOrder(DataRow input, DataRow output) {
		
		
		String SONum = uiDriver.getValue("SONumber");
		passed("Verify the SalesOrderNumber",
				"SalesOrderNumber Should be displayed successfully",
				"SalesOrderNumber " + SONum + " is displayed successfully");

		String tableRows = uiDriver.getObjMap("tableRows");

		uiDriver.executeJavaScript("scroll(0,500)");
		String actualMARKETCODE = uiDriver.getValue(tableRows + nextRow+ uiDriver.getObjMap("marketcode"));
		String actualRIGHTS = uiDriver.getValue(tableRows + nextRow	+ uiDriver.getObjMap("Rights"));
		String actualTERRITORY = uiDriver.getValue(tableRows + nextRow+ uiDriver.getObjMap("Territory"));
		//String actuallICENSEFEE = uiDriver.getValue("licensefee");
		// String actualGLPN=uiDriver.getValue("GLPN");

		uiDriver.executeJavaScript("scroll(400,500);");
		String Marketcode = input.get("marketCode");
		if (input.get("marketCode").contains(actualMARKETCODE.trim())) {
			passed("Verifying the  marketCode",
					"marketCode should be displayed as '" + Marketcode+ "' Successfully", "marketCode "	+ actualMARKETCODE + " is displayed Successfully");
		} else {
			failed("Verifying the  marketCode",	"marketCode should be displayed as '" + Marketcode+ "' Successfully",
					"marketCode "+ actualMARKETCODE	+ " is not displayed Successfully");
		}

		SleepUtils.sleep(5);
		String Rights = input.get("rightSet");
		if (input.get("rightSet").contains(actualRIGHTS)) {
			passed("Verifying the  rightSet",
				"rightSet should be displayed as '" + Rights+ "' Successfully",
				"rightSet " + actualRIGHTS+ " is displayed Successfully");
		} else {
			failed("Verifying the  rightSet",
					"rightSet should be displayed as '" + Rights+ "' Successfully",
					"rightSet " + actualRIGHTS+ " is not displayed Successfully");
		}

		SleepUtils.sleep(5);
		String Territory = input.get("territorySet");
		if (input.get("territorySet").contains(actualTERRITORY)) {
			passed("Verifying the  Territory",
					"Territory should be displayed as '" + Territory+ "' Successfully",
					"Territory " + actualTERRITORY+ " is displayed Successfully");
		} else {
			failed("Verifying the  Territory",
					"Territory should be displayed as '" + Territory+ "' Successfully",
					"Territory " + actualTERRITORY+ " is not displayed Successfully");
		}

		/*String LicenseFeeType = input.get("licenseFeeTypeSet");
		if (input.get("licenseFeeTypeSet").contains(actuallICENSEFEE)) {
			passed("Verifying the  LicenseFeeType",
					"LicenseFeeType should be displayed as '" + LicenseFeeType
							+ "' Successfully", "LicenseFeeType "
							+ actuallICENSEFEE + " is displayed Successfully");
		} else {
			failed("Verifying the  LicenseFeeType",
					"LicenseFeeType should be displayed as '" + LicenseFeeType
							+ "' Successfully", "LicenseFeeType "
							+ actuallICENSEFEE
							+ " is not displayed Successfully");
		}*/

		/*
		 * String GLPN=input.get("GLPNSet");
		 * if(input.get("GLPNSet").contains(actualGLPN)) {
		 * passed("Validating GLPN", "Validating GLPN should be successfull",
		 * "GLPN matched with the account details matrix"); } else {
		 * failed("Validating GLPN", "Validating GLPN should be successfull",
		 * "GLPN did not match with the account details matrix"); }
		 */

		String actualUNBILLEDREVENUEACCOUNT = uiDriver.getValue(tableRows+ nextRow + uiDriver.getObjMap("unbilledrevaccount"));
		String actualBILLEDREVENUEACCOUNT = uiDriver.getValue(tableRows	+ nextRow + uiDriver.getObjMap("billedrevaccount"));
		String actualBILLEDARACCOUNT = uiDriver.getValue(tableRows + nextRow+ uiDriver.getObjMap("billedARaccount"));
		String actualUNBILLEDARACCOUNT = uiDriver.getValue(tableRows + nextRow	+ uiDriver.getObjMap("unbilledARaccount"));
		String actualPAIDDEFERREDACCOUNT = uiDriver.getValue(tableRows+ nextRow + uiDriver.getObjMap("paiddefferedaccount"));
		String actualUNPAIDDEFERREDACCOUNT = uiDriver.getValue(tableRows+ nextRow + uiDriver.getObjMap("unpaiddefferedaccount"));
		String actualBADDEBTREVENUEACNT = uiDriver.getValue(tableRows + nextRow	+ uiDriver.getObjMap("baddebtrevaccount"));
		String actualBADDEBTREVENUEACCOUNT = actualBADDEBTREVENUEACNT.trim();
		String actualUNBILLEDARACC = actualUNBILLEDARACCOUNT.trim();
		uiDriver.executeJavaScript("scroll(500,500)");
		String unbilledrevenuaccount = input.get("UNBILLED REVENUE ACCOUNT");
		System.out.println(unbilledrevenuaccount);
		if (input.get("UNBILLED REVENUE ACCOUNT").equalsIgnoreCase(actualUNBILLEDREVENUEACCOUNT.trim())) {
			passed("Verifying the  UNBILLED REVENUE ACCOUNT",
					"UNBILLED REVENUE ACCOUNT should be displayed as '"	+ unbilledrevenuaccount + "' Successfully",
					"UNBILLED REVENUE ACCOUNT " + actualUNBILLEDREVENUEACCOUNT+ " is displayed Successfully");
		} else {
			failed("Verifying the  UNBILLED REVENUE ACCOUNT",
					"UNBILLED REVENUE ACCOUNT should be displayed as '"+ unbilledrevenuaccount + "' Successfully",
					"UNBILLED REVENUE ACCOUNT " + actualUNBILLEDREVENUEACCOUNT+ " is not displayed Successfully");
		}

		SleepUtils.sleep(5);
		if (input.get("BILLED REVENUE ACCOUNT").equalsIgnoreCase(actualBILLEDREVENUEACCOUNT.trim())) {
			passed("Verifying the  BILLED REVENUE ACCOUNT",
					"BILLED REVENUE ACCOUNT should be displayed as '"+ input.get("BILLED REVENUE ACCOUNT")+ "' Successfully", 
					"BILLED REVENUE ACCOUNT "+ actualBILLEDREVENUEACCOUNT+ " is displayed Successfully");
		} else {
			failed("Verifying the  BILLED REVENUE ACCOUNT",
					"BILLED REVENUE ACCOUNT should be displayed as '"+ input.get("BILLED REVENUE ACCOUNT")+ "' Successfully", 
					"BILLED REVENUE ACCOUNT "+ actualBILLEDREVENUEACCOUNT+ " is not displayed Successfully");
		}

		SleepUtils.sleep(5);
		if (input.get("BILLED AR ACCOUNT").equalsIgnoreCase(actualBILLEDARACCOUNT)) {
			passed("Verifying the BILLED AR ACCOUNT",
					"BILLED AR ACCOUNT should be displayed as '"+ input.get("BILLED AR ACCOUNT") + "' Successfully",
					"BILLED AR ACCOUNT " + actualBILLEDARACCOUNT+ " is displayed Successfully");
		} else {
			failed("Verifying the  BILLED AR ACCOUNT",
					"BILLED AR ACCOUNT should be displayed as '"+ input.get("BILLED AR ACCOUNT") + "' Successfully",
					"BILLED AR ACCOUNT " + actualBILLEDARACCOUNT+ " is not displayed Successfully");
		}

		SleepUtils.sleep(5);
		if (input.get("UNBILLED AR ACCOUNT").equalsIgnoreCase(actualUNBILLEDARACC)) {
			passed("Validating unbilledAR account",
					"Validating unbilledAR account should be successfull",
					"unbilledAR account matched with the account details matrix");
		} else {
			failed("Validating unbilledAR account",
					"Validating unbilledAR account should be successfull",
					"unbilledAR account did not match with the account details matrix");
		}

		SleepUtils.sleep(5);
		if (input.get("PAID DEFERRED ACCOUNT").equalsIgnoreCase(actualPAIDDEFERREDACCOUNT)) {
			passed("Verifying the PAID DEFERRED ACCOUNT",
					"PAID DEFERRED ACCOUNT should be displayed as '"+ input.get("PAID DEFERRED ACCOUNT")+ "' Successfully", 
					"PAID DEFERRED ACCOUNT "+ actualPAIDDEFERREDACCOUNT+ " is displayed Successfully");
		} else {
			failed("Verifying the  PAID DEFERRED ACCOUNT",
					"PAID DEFERRED ACCOUNT should be displayed as '"+ input.get("PAID DEFERRED ACCOUNT")+ "' Successfully", 
					"PAID DEFERRED ACCOUNT "+ actualPAIDDEFERREDACCOUNT	+ " is not displayed Successfully");
		}

		SleepUtils.sleep(5);
		if (input.get("UNPAID DEFERRED ACCOUNT").equalsIgnoreCase(actualUNPAIDDEFERREDACCOUNT)) {
			passed("Verifying the UNPAID DEFERRED ACCOUNT",
					"UNPAID DEFERRED ACCOUNT should be displayed as '"+ input.get("UNPAID DEFERRED ACCOUNT")+ "' Successfully", 
					"UNPAID DEFERRED ACCOUNT "+ actualUNPAIDDEFERREDACCOUNT	+ " is displayed Successfully");
		} else {
			failed("Verifying the UNPAID DEFERRED ACCOUNT",
					"UNPAID DEFERRED ACCOUNT should be displayed as '"+ input.get("UNPAID DEFERRED ACCOUNT")+ "' Successfully",
					"UNPAID DEFERRED ACCOUNT "+ actualUNPAIDDEFERREDACCOUNT	+ " is displayed Successfully");
		}

		/*
		 * if(input.get("BAD DEBT REVENUE ACCOUNT").contains(
		 * actualBADDEBTREVENUEACCOUNT)) {
		 * passed("Verifying the BAD DEBT REVENUE ACCOUNT",
		 * "BAD DEBT REVENUE ACCOUNT should be displayed as '"
		 * +input.get("BAD DEBT REVENUE ACCOUNT")+"' Successfully",
		 * "BAD DEBT REVENUE ACCOUNT "
		 * +actualBADDEBTREVENUEACCOUNT+" is displayed Successfully"); } else {
		 * failed("Verifying the BAD DEBT REVENUE ACCOUNT",
		 * "BAD DEBT REVENUE ACCOUNT should be displayed as '"
		 * +input.get("BAD DEBT REVENUE ACCOUNT")+"' Successfully",
		 * "BAD DEBT REVENUE ACCOUNT "
		 * +actualBADDEBTREVENUEACCOUNT+" is displayed Successfully"); }
		 */

		nextRow++;
	
		output.put("SalesOrderNum", SONum);

	}
           

	/****************************************
	 * Name: updateRevenueArreangemet 
	 * Description: updateRevenueArreangement
	 * Date: 30-Nov-2017
	 ****************************************/
	public void updateRevenueArreangement(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.LOW);
		//uiDriver.setFrame("frame");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("transactions");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("financial");
		SleepUtils.sleep(TimeSlab.YIELD);

		uiDriver.click("updateRevenueArrangement");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("updateRevenueArrBtn");
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.HIGH);
		// uiDriver.click("updateRevenuePlanBtn");
		uiDriver.click("refreshBtn");

	}

	/****************************************
	 * Name: UpdateRevenuePlans
	 * Description: UpdateRevenuePlans 
	 * Date:30-Nov-2017
	  
	 ****************************************/
	public void UpdateRevenuePlans(DataRow input, DataRow output) {
		uiDriver.click("saveBtn");
		passed("Click On save button", "Details Should be saved successfully",
				"Details is saved successfully");
	}

	/****************************************
	 * Name: UpdateViewRevPlan
	 * Description: UpdateViewRevPlan
	 * Date: 30-Nov-2017
	 ****************************************/

	public void UpdateViewRevPlan(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.LOW);

		String temp = uiDriver.getDyanmicData("WElement_DynamicData");
		String s1 = temp.replace("#", input.get("conf"));
		// String s2 = uiDriver.getValueByText(s1);
		String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		uiDriver.click("SalesOrder");
		passed("Click On SalesOrder",
				"SalesOrder Should be clicked successfully",
				"SalesOrder is clicked successfully");
		// uiDriver.click(s1);
		/*
		 * if(input.get("SalesOrderNum").equalsIgnoreCase(s1)) {
		 * passed("Validating bad debt revenue account",
		 * "Validating bad debt revenue account should be successfull",
		 * "bad debt revenue account matched with the account details matrix");
		 * } else { failed("Validating bad debt revenue account",
		 * "Validating bad debt revenue account should be successfull",
		 * "bad debt revenue account did not match with the account details matrix"
		 * ); }
		 */

		//SleepUtils.sleep(TimeSlab.YIELD);
		//SleepUtils.sleep(TimeSlab.YIELD);
		//SleepUtils.sleep(TimeSlab.YIELD);
		//SleepUtils.sleep(TimeSlab.YIELD);
		//uiDriver.refresh();
		//SleepUtils.sleep(TimeSlab.YIELD);
		//uiDriver.refresh();
		//SleepUtils.sleep(TimeSlab.YIELD);
		//uiDriver.refresh();
		//SleepUtils.sleep(TimeSlab.YIELD);
		//uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();
		// page refresh required
		uiDriver.click("relatedRecord");
		for(int i=0;i<=5;i++){
			if(uiDriver.checkElementPresent_dynamic("date")){
				uiDriver.click("date");
				if(uiDriver.checkElementPresent("//h1[text()='Revenue Arrangement']")) {
					passed("UpdateViewRevPlan", "Revenue Arrangement screen should be displayed", 
							"Revenue Arrangement screen is displayed");
				} else {
					failed("UpdateViewRevPlan", "Revenue Arrangement screen should be displayed", 
							"Revenue Arrangement screen is not displayed");
				}
				break;
			}
			else{SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.refresh();
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.refresh();
			SleepUtils.sleep(20);
			// page refresh required
			uiDriver.click("relatedRecord");
				
			}
			
		}
		SleepUtils.sleep(TimeSlab.YIELD);	
	}
	/****************************************
	 * Name: ReadRevenue 
	 * Description: ReadRevenue
	 * Date: 30-Nov-2017
	 ****************************************/
	public void ReadRevenue(DataRow input, DataRow output) {
		String Revenuenumber = uiDriver.getValue("Revenuenumber");
		passed("ReadRevenue", "Revenue Number should be displayed", 
				"Revenue Number is displayed "+Revenuenumber);
		output.put("Revenuenumber", Revenuenumber);
	
	}
		
	
	/****************************************
	 * Name: validatePlans 
	 * Description: validatePlans
	 * Date: 30-Nov-2017
	 ****************************************/
	public void validatePlans(DataRow input, DataRow output) {
		
	
		SleepUtils.sleep(TimeSlab.YIELD);
		// int		// Rows=uiDriver.webDr.findElements(By.xpath("//*[@id='revenueelement_splits']/tbody/tr")).size();
		int Rows = 6;
		
		for (i = 0; i < Rows - 1; i++) {
			String planRows = uiDriver.getObjMap("planRows");
			String actualRECOGNITIONACCOUNT = uiDriver.getValue(planRows+ firstRow + uiDriver.getObjMap("recognitionaccount"));
			String unbilledrevenureaccount = input.get("UNBILLED REVENUE ACCOUNT");
			uiDriver.executeJavaScript("scroll(0,500)");
			SleepUtils.sleep(TimeSlab.YIELD);

			if (input.get("UNBILLED REVENUE ACCOUNT").equalsIgnoreCase(actualRECOGNITIONACCOUNT)||input.get("UNBILLED REVENUE ACCOUNT").contains(actualRECOGNITIONACCOUNT)) {
				passed("Verifying the  UNBILLED REVENUE ACCOUNT",
						"UNBILLED REVENUE ACCOUNT should be displayed as '"+ input.get("UNBILLED REVENUE ACCOUNT")+ "' Successfully",
						"UNBILLED REVENUE ACCOUNT "+ actualRECOGNITIONACCOUNT+ " is displayed Successfully");
			} else {
				failed("Verifying the  UNBILLED REVENUE ACCOUNT",
						"UNBILLED REVENUE ACCOUNT should be displayed as '"+ input.get("UNBILLED REVENUE ACCOUNT")+ "' Successfully",
						"UNBILLED REVENUE ACCOUNT "	+ actualRECOGNITIONACCOUNT+ " is not displayed Successfully");
			}

			String actualDEREFERALACCOUNT = uiDriver.getValue(planRows+ firstRow + uiDriver.getObjMap("dereferralaccount"));
			String unpaiddeferalaccount = input.get("UNPAID DEFERRED ACCOUNT");
			System.out.println(unpaiddeferalaccount);
			if (input.get("UNPAID DEFERRED ACCOUNT").equalsIgnoreCase(actualDEREFERALACCOUNT)||input.get("UNPAID DEFERRED ACCOUNT").contains(actualDEREFERALACCOUNT)) {
				passed("Verifying the  UNPAID DEFERRED ACCOUNT",
						"UNPAID DEFERRED ACCOUNT should be displayed as '"+ input.get("UNPAID DEFERRED ACCOUNT")+ "' Successfully",
						"UNPAID DEFERRED ACCOUNT "+ actualDEREFERALACCOUNT+ " is displayed Successfully");
			} else {
				failed("Verifying the  UNPAID DEFERRED ACCOUNT ",
						"UNPAID DEFERRED ACCOUNT should be displayed as '"	+ input.get("UNPAID DEFERRED ACCOUNT")+ "' Successfully",
						"UNPAID DEFERRED ACCOUNT "+ actualDEREFERALACCOUNT+ " is not displayed Successfully");
			}
			// firstRow++;
		}

		firstRow++;
	}

	/****************************************
	 * Name: RevPlan 
	 * Description: RevPlan 
	 * Date: 30-Nov-2017
	 ****************************************/

	public void RevPlan(DataRow input, DataRow output) throws ParseException {
		uiDriver.click("editbtn");
		SleepUtils.sleep(TimeSlab.YIELD);

		uiDriver.click("allocationcheckbx");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("saveBtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("UpdateRevPlanBtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("submissionIDHeader");
		// uiDriver.click("completeBtn");
		// refressh
		Date date = new Date();
		DateFormat dateFormat = new SimpleDateFormat("h:mm");
		String strDate = dateFormat.format(date);
		Date d = dateFormat.parse(strDate);
		Calendar cal = Calendar.getInstance();
		cal.setTime(d);
		cal.add(Calendar.MINUTE, 0);
		String newTime = dateFormat.format(cal.getTime());
		String Complete = uiDriver.getDyanmicData("CompleteStatus1");
		String CompleteStaus = Complete.replace("#", newTime);
		cal.add(Calendar.MINUTE, 1);
		String newTime2 = dateFormat.format(cal.getTime());
		String Complete2 = uiDriver.getDyanmicData("CompleteStatus2");
		String CompleteStaus2 = Complete2.replace("#", newTime2);
		cal.add(Calendar.MINUTE, 2);
		String newTime3 = dateFormat.format(cal.getTime());
		String Complete3 = uiDriver.getDyanmicData("CompleteStatus3");
		String CompleteStaus3 = Complete3.replace("#", newTime3);
		if (uiDriver.checkElementPresent_dynamic(CompleteStaus)) {
			uiDriver.click_dynamic(CompleteStaus);
		} else {
			// do nothing
		}

		if (uiDriver.checkElementPresent_dynamic(CompleteStaus2)) {
			uiDriver.click_dynamic(CompleteStaus2);
		} else {
			// do nothing
		}
		if (uiDriver.checkElementPresent_dynamic(CompleteStaus3)) {
			uiDriver.click_dynamic(CompleteStaus3);
		} else {
			// do nothing
		}
		uiDriver.executeJavaScript("scroll(0,500)");
		passed("Verify Processed Reclassification Journal entries",
				"Processed Reclassification Journal entries page should be displayed",
				"Processed ification Journal entries page is displayed");
		int RevPlanRows = 6;
		// int
		// RevPlanRows=uiDriver.webDr.findElements(By.xpath("//*[@id='body_actions']")).size();
		for (int r = 0; r < RevPlanRows - 1; r++) {
			String s1 = uiDriver.getDyanmicData("RevenuePlanNumber1");
			String s2 = s1.replace("#", Integer.toString(r));
			if (uiDriver.checkElementPresent_dynamic(s2)) {
				uiDriver.click_dynamic(s2);
				uiDriver.executeJavaScript("scroll(0,300)");
				passed("Click On the Revenue Paln Number " + s2 + "",
						"Should be SuccessFully Clicked on Revenue Paln Number "+ s2 + "",
						"SuccessFully Clicked on Revenue Paln Number " + s2	+ "");
				
				passed("Verify the Revenue Paln Number",
						"Revenue Recognition Plan Page Should be displayed",
						"Revenue Recognition Plan Page is displayed");

				uiDriver.executeJavaScript("scroll(0,300)");
				String ActualdeferralAccnt = uiDriver.getValue("DeferralAccountRevPlan");
				String ActualRecognitionAcc = uiDriver.getValue("RecognitionAccountRevPlan");
				if (r == 0) {
					if (input.get("deferralAccount").equalsIgnoreCase(ActualdeferralAccnt)) {

						passed("Verifying the deferral account",
								"deferral account  "+ input.get("deferralAccount")+ " value should be displayed successfully",
								"deferral account value is displayed successfully"+ ActualdeferralAccnt + "");
					} else {
						failed("Verifying the deferral account",
								"deferral account   "+ input.get("deferralAccount")	+ "   value should be displayed successfully",
								"deferral account value is not displayed successfully "	+ ActualdeferralAccnt + "");
					}

					if (input.get("RecognitionAccount").equalsIgnoreCase(ActualRecognitionAcc)) {

						passed("Verifying the Recognition account",
								"Recognition account  "	+ input.get("RecognitionAccount")+ "   value should be displayed successfully",
								"Recognition account value is displayed successfully"+ ActualRecognitionAcc + "");
					} else {
						failed("Verifying the Recognition account",
								"Recognition account  "+ input.get("RecognitionAccount")+ " value should be displayed successfully",
								"Recognition account value is not displayed successfully "+ ActualRecognitionAcc + "");
					}

				} else if (r == 1) {
					if (input.get("deferralAccount1").equalsIgnoreCase(ActualdeferralAccnt)) {
						passed("Verifying the deferral account",
								"deferral account  "+ input.get("deferralAccount1")	+ "   value should be displayed successfully",
								"deferral account value is displayed successfully"+ ActualdeferralAccnt + "");
					} else {
						failed("Verifying the deferral account",
								"deferral account   "+ input.get("deferralAccount1")+ "   value should be displayed successfully",
								"deferral account value is not displayed successfully "	+ ActualdeferralAccnt + "");
					}

					if (input.get("RecognitionAccount1").equalsIgnoreCase(ActualRecognitionAcc)) {

						passed("Verifying the Recognition account",
								"Recognition account  "+ input.get("RecognitionAccount1")+ "   value should be displayed successfully",
								"Recognition account value is displayed successfully"+ ActualRecognitionAcc + "");
					} else {
						failed("Verifying the Recognition account",
								"Recognition account  "	+ input.get("RecognitionAccount1")+ " value should be displayed successfully",
								"Recognition account value is not displayed successfully "+ ActualRecognitionAcc + "");
					}

				}

				else if (r == 2) {
					if (input.get("deferralAccount2").equalsIgnoreCase(ActualdeferralAccnt)) {
						passed("Verifying the deferral account",
								"deferral account  "+ input.get("deferralAccount1")+ "   value should be displayed successfully",
								"deferral account value is displayed successfully"+ ActualdeferralAccnt + "");
					} else {
						failed("Verifying the deferral account",
								"deferral account   "+ input.get("deferralAccount1")+ "   value should be displayed successfully",
								"deferral account value is not displayed successfully "	+ ActualdeferralAccnt + "");
					}

					if (input.get("RecognitionAccount2").equalsIgnoreCase(ActualRecognitionAcc)) {

						passed("Verifying the Recognition account",
								"Recognition account  "	+ input.get("RecognitionAccount1")+ "   value should be displayed successfully",
								"Recognition account value is displayed successfully"+ ActualRecognitionAcc + "");
					} else {
						failed("Verifying the Recognition account",
								"Recognition account  "	+ input.get("RecognitionAccount1")+ " value should be displayed successfully",
								"Recognition account value is not displayed successfully "+ ActualRecognitionAcc + "");
					}

				} else if (r == 3) {
					if (input.get("deferralAccount3").equalsIgnoreCase(ActualdeferralAccnt)) {
						passed("Verifying the deferral account",
								"deferral account  "+ input.get("deferralAccount1")+ "   value should be displayed successfully",
								"deferral account value is displayed successfully"+ ActualdeferralAccnt + "");
					} else {
						failed("Verifying the deferral account",
								"deferral account   "+ input.get("deferralAccount1")+ "   value should be displayed successfully",
								"deferral account value is not displayed successfully "+ ActualdeferralAccnt + "");
					}

					if (input.get("RecognitionAccount3").equalsIgnoreCase(ActualRecognitionAcc)) {

						passed("Verifying the Recognition account",
								"Recognition account  "+ input.get("RecognitionAccount1")+ "   value should be displayed successfully",
								"Recognition account value is displayed successfully"+ ActualRecognitionAcc + "");
					} else {
						failed("Verifying the Recognition account",
								"Recognition account  "	+ input.get("RecognitionAccount1")+ " value should be displayed successfully",
								"Recognition account value is not displayed successfully "+ ActualRecognitionAcc + "");
					}

				}
				SleepUtils.sleep(5);
				uiDriver.click("Back1");
				SleepUtils.sleep(5);

			} else {
				// Do Nothing
			}

		}

		SleepUtils.sleep(10);
		uiDriver.back();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.back();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);
		String Revenuenumber = uiDriver.getValue("Revenuenumber");
	    output.put("Revenuenumber", Revenuenumber);
		
	}

	/****************************************
	 * Name: viewRevenuePlan 
	 * Description: viewRevenuePlan 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void viewRevenuePlan(DataRow input, DataRow output) {

		SleepUtils.sleep(10);
          // add view plan step here
        uiDriver.click("viewRevplanBtn");
        SleepUtils.sleep(TimeSlab.YIELD);
        // validation pendlin
        SleepUtils.sleep(TimeSlab.YIELD);
        uiDriver.setFrame("IframeWindow");
        uiDriver.setValue("Action", input.get("Action"));
        int viewRevenuePlanRows = 4;
        for (int r = 0; r < viewRevenuePlanRows; r++) {
              String s1 = uiDriver.getDyanmicData("RevenuePlanNumber");
              String s2 = s1.replace("#", Integer.toString(r));
              if (uiDriver.checkElementPresent_dynamic(s2)) {
               uiDriver.click_dynamic(s2);
               SleepUtils.sleep(TimeSlab.YIELD);
               uiDriver.executeJavaScript("scroll(0,500)");
               String ActualdeferralAccnt = uiDriver.getValue("DeferralAccountRevPlan");
               String ActualRecognitionAcc = uiDriver.getValue("RecognitionAccountRevPlan");
               if (r == 0) {
                   if (input.get("deferralAccount").equalsIgnoreCase(ActualdeferralAccnt)||input.get("deferralAccount").contains(ActualdeferralAccnt)) {
                             passed("Verifying the deferral account",
                                     "deferral account  "+ input.get("deferralAccount")+ "   value should be displayed successfully",
                                     "deferral account value is displayed successfully"+ ActualdeferralAccnt + "");
               }
                   else {
                             failed("Verifying the deferral account",
                                    "deferral account   "+ input.get("deferralAccount")       + "   value should be displayed successfully",
                                     "deferral account value is not displayed successfully "       + ActualdeferralAccnt + "");
                        }

              if (input.get("RecognitionAccount").equalsIgnoreCase(ActualRecognitionAcc)||input.get("RecognitionAccount").contains(ActualRecognitionAcc)) {
                 passed("Verifying the Recognition account",
                         "Recognition account  "    + input.get("RecognitionAccount")+ " value should be displayed successfully",
                         "Recognition account value is displayed successfully"+ ActualRecognitionAcc + "");
               } 
              else {
                    failed("Verifying the Recognition account",
                            "Recognition account  "    + input.get("RecognitionAccount")+ " value should be displayed successfully",
                            "Recognition account value is not displayed successfully "+ ActualRecognitionAcc + "");
                 }
                       } else if (r == 1) {
                                if (input.get("deferralAccount1").equalsIgnoreCase(ActualdeferralAccnt)||input.get("deferralAccount1").contains(ActualdeferralAccnt)) {
                                       passed("Verifying the deferral account",
                                               "deferral account  "+ input.get("deferralAccount1")       + "   value should be displayed successfully",
                                               "deferral account value is displayed successfully"+ ActualdeferralAccnt + "");

                                } else {

                                       failed("Verifying the deferral account",
                                               "deferral account "  + input.get("deferralAccount1")       + "   value should be displayed successfully",
                                               "deferral account value is not displayed successfully "+ ActualdeferralAccnt + "");

                                }

                               if (input.get("RecognitionAccount1").equalsIgnoreCase(ActualRecognitionAcc)||input.get("RecognitionAccount1").contains(ActualRecognitionAcc)) {

                                      passed("Verifying the Recognition account",
                                              "Recognition account  "+ input.get("RecognitionAccount1")+ "   value should be displayed successfully",
                                              "Recognition account value is displayed successfully"+ ActualRecognitionAcc + "");

                                } else {

                                       failed("Verifying the Recognition account",
                                               "Recognition account"      + input.get("RecognitionAccount1")+ " value should be displayed successfully",
                                               "Recognition account value is not displayed successfully "+ ActualRecognitionAcc + "");

                                }

                         }

                       else if (r == 2) {

                                if (input.get("deferralAccount2").equalsIgnoreCase(ActualdeferralAccnt)||input.get("deferralAccount2").contains(ActualdeferralAccnt)) {

                                       passed("Verifying the deferral account",
                                               "deferral account  " + input.get("deferralAccount2")       + "   value should be displayed successfully",
                                               "deferral account value is displayed successfully"+ ActualdeferralAccnt + "");

                                } else {

                                       failed("Verifying the deferral account",
                                               "deferral account"+ input.get("deferralAccount2")+ "   value should be displayed successfully",
                                                "deferral account value is not displayed successfully "       + ActualdeferralAccnt + "");

                                }
                               
                                if (input.get("RecognitionAccount2").equalsIgnoreCase(ActualRecognitionAcc)||input.get("RecognitionAccount2").contains(ActualRecognitionAcc)) {
                                       passed("Verifying the Recognition account",
                                              "Recognition account  "+ input.get("RecognitionAccount2")+ " value should be displayed successfully",
                                              "Recognition account value is displayed successfully"+ ActualRecognitionAcc + "");

                                } else {

                                       failed("Verifying the Recognition account",
                                               "Recognition account  "    + input.get("RecognitionAccount2")+ " value should be displayed successfully",
                                                "Recognition account value is not displayed successfully "+ ActualRecognitionAcc + "");

                                }

                         } else if (r == 3) {

                                if (input.get("deferralAccount3").equalsIgnoreCase(ActualdeferralAccnt)||input.get("deferralAccount3").contains(ActualdeferralAccnt)) {

                                       passed("Verifying the deferral account",
                                               "deferral account  "+ input.get("deferralAccount3")+ " value should be displayed successfully",
                                                "deferral account value is displayed successfully"+ ActualdeferralAccnt + "");

                                } else {

                                       failed("Verifying the deferral account",
                                              "deferral account "  + input.get("deferralAccount3")+ " value should be displayed successfully",
                                               "deferral account value is not displayed successfully "       + ActualdeferralAccnt + "");

                                }



                                if (input.get("RecognitionAccount3").equalsIgnoreCase(ActualRecognitionAcc)||input.get("RecognitionAccount3").contains(ActualRecognitionAcc)) {
                                    passed("Verifying the Recognition account",
                                            "Recognition account "+ input.get("RecognitionAccount3")+ " value should be displayed successfully",
                                             "Recognition account value is displayed successfully"+ ActualRecognitionAcc + "");

                                } else {

                                       failed("Verifying the Recognition account",
                                               "Recognition account  "    + input.get("RecognitionAccount3")+ " value should be displayed successfully",
                                               "Recognition account value is not displayed successfully "+ ActualRecognitionAcc + "");

                                }

                         }

                        uiDriver.click("Back");

                   }

            }

            uiDriver.handleAlert("", "STAY");
            SleepUtils.sleep(TimeSlab.YIELD);
            if (uiDriver.checkElementPresent("cancelbtn")) {
                  passed("Check for cancel button",
                          "Click on Cancel Button",
                           " successfully clicked on  cancel button");
            } else {

                   failed("Check for cancel button",
                           "Click on Cancel Button",
                          " failed to click on  cancel button");
           }
           uiDriver.click("cancelbtn");
           uiDriver.resetFrame();
   }


	/****************************************
	 * Name: validateRevenueRecognitionPlan
	 * Description: validateRevenueRecognitionPlan
	 Date: 30-Nov-2017
	 ****************************************/
	public void validateRevenueRecognitionPlan(DataRow input, DataRow output) {
		uiDriver.back();
		uiDriver.click("revenueplanicon");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("revenueplanno");
		// validation pending
		uiDriver.click("cancelbtn");
		passed("Click On cancelbutton",
				"cancelbutton Should be clicked successfully",
				"cancelbutton is clicked successfully");

	}

	/****************************************
	 * Name: reClassJournalEntry
	 * Description: reClassJournalEntry
	 * Date: 30-Nov-2017
	
	 ****************************************/
	public void reClassJournalEntry(DataRow input, DataRow output)
			throws ParseException {
		 
		
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.mouseOver("Customization");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.mouseOver("Scripting");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.mouseOver("Scripts");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("Scripts");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("EditBtnreclass");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("Deployments");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("reclassbatch");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.click("Edit");
			SleepUtils.sleep(TimeSlab.YIELD);
			uiDriver.mouseOver("SaveBtndropdown");
			SleepUtils.sleep(TimeSlab.YIELD);
			if(uiDriver.checkElementPresent("SaveAndExecute"))
			{	
				uiDriver.click("SaveAndExecute");
				uiDriver.handleAlert("", "OK");
			}
			else{
				for(int i=0;i<=50;i++){
					SleepUtils.sleep(30);
					uiDriver.refresh();		
					uiDriver.mouseOver("SaveBtndropdown");
					System.out.println("***********************"+i);
					if(uiDriver.checkElementPresent("SaveAndExecute"))
					{	
						uiDriver.click("SaveAndExecute");
						uiDriver.handleAlert("", "OK");
						break;
					}
						
					
				}	
				}
			uiDriver.click("refresh");	
			SleepUtils.sleep(30);
			uiDriver.click("refresh");		
			for(int i=0;i<=50;i++){
				SleepUtils.sleep(30);
				uiDriver.click("refresh");			
				System.out.println("***********************"+i);
				System.out.println(uiDriver.getValue("Status"));
				if(uiDriver.getValue("Status").equalsIgnoreCase("Complete"))
				break;
				
			}	
			
		}

		/*SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.setFrame("frame");
		uiDriver.mouseOver("transactions");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("financial");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("reclassjournalentry");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("runNow");
		SleepUtils.sleep(5);
		uiDriver.handleAlert("", "OK");
		SleepUtils.sleep(5);
		 uiDriver.click("customerdropdownimage");
  	       uiDriver.handleAlert("", "OK");
  	       SleepUtils.sleep(5);
	       uiDriver.click("customerlist");
	       SleepUtils.sleep(5);
	       uiDriver.setValue("searchcustomerinput",input.get("reclasscustomer"));
	       SleepUtils.sleep(5);
	       uiDriver.click("searchcustomerbutton");
	       SleepUtils.sleep(5);
	       uiDriver.click("cussearchresult");
	       uiDriver.handleAlert("", "OK");
           uiDriver.handleAlert("", "OK");
           uiDriver.handleAlert("", "OK");
           SleepUtils.sleep(TimeSlab.LOW);
           SleepUtils.sleep(TimeSlab.LOW);
		// Need to remove the comment
		//uiDriver.executeJavaScript("document.getElementById('entitytype_display').value = '"+ input.get("reclasscustomer") + "'");
		//SleepUtils.sleep(TimeSlab.YIELD);
           uiDriver.handleAlert("", "OK");
           uiDriver.handleAlert("", "OK");
           uiDriver.handleAlert("", "OK");
           uiDriver.handleAlert("", "OK");    
           uiDriver.click("postingperiod");
           SleepUtils.sleep(TimeSlab.YIELD);
           uiDriver.setValue("postingperiod", input.get("posting"));
           SleepUtils.sleep(2);
    	   uiDriver.click("postingperiod");
		   SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("deliveryDate");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("deliveryDate", input.get("delivery"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Subsidiary");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("Subsidiary", input.get("Subsidiary"));
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("Subsidiary");

		uiDriver.click("createjournalentry");
		uiDriver.handleAlert("", "OK");
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);

		uiDriver.refresh();
		// uiDriver.click("completebtn");
		// uiDriver.click("Journal");

		// validation

		// Create object of SimpleDateFormat class and decide the format
		Date date = new Date();
		DateFormat dateFormat = new SimpleDateFormat("h:mm");
		String strDate = dateFormat.format(date);
		Date d = dateFormat.parse(strDate);
		Calendar cal = Calendar.getInstance();
		cal.setTime(d);
		cal.add(Calendar.MINUTE, 2);
		String newTime = dateFormat.format(cal.getTime());
		String Complete = uiDriver.getDyanmicData("CompleteStatus");
		String CompleteStaus = Complete.replace("#", newTime);
		if (uiDriver.checkElementPresent_dynamic(CompleteStaus)) {
			uiDriver.click_dynamic(CompleteStaus);
		} else {
			// do nothing
		}

		cal.add(Calendar.MINUTE, 2);
		String newTime3 = dateFormat.format(cal.getTime());
		String Complete3 = uiDriver.getDyanmicData("CompleteStatus");
		String CompleteStaus3 = Complete3.replace("#", newTime3);
		if (uiDriver.checkElementPresent_dynamic(CompleteStaus3)) {
			uiDriver.click_dynamic(CompleteStaus3);
		} else {
			// do nothing
		}
		/*
		 * Date date = new Date() DateFormat dateFormat = new
		 * SimpleDateFormat("h:mm"); String strDate = dateFormat.format(date);
		 * Date d = dateFormat.parse(strDate); Calendar cal =
		 * Calendar.getInstance(); cal.setTime(d); cal.add(Calendar.MINUTE, 2);
		 * String newTime = dateFormat.format(cal.getTime()); String Complete =
		 * uiDriver.getDyanmicData("CompleteStatus"); String CompleteStaus =
		 * Complete.replace("#",newTime); uiDriver.click_dynamic(CompleteStaus);
		 */
		/*passed("Verify Processed Reclassification Journal entries",
				"Processed Reclassification Journal entries page should be displayed",
				"Processed Reclassification Journal entries page is displayed");
		uiDriver.click("completebtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		if (uiDriver.checkElementPresent("JournalId")) {
			uiDriver.click("JournalId");
		} else {
			
		}
		
		if (uiDriver.checkElementPresent("JournalId2")) {
			uiDriver.click("JournalId2");
		} else {
			
		}
	}*/

	/****************************************
	 * Name: reClassJournalEntry1 
	 * Description: reClassJournalEntry1 
	 * Date: 30-Nov-201
	 
	 ****************************************/
	public void reClassJournalEntry1(DataRow input, DataRow output)
			throws ParseException {

		SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.setFrame("frame");
		uiDriver.mouseOver("transactions");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("financial");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("reclassjournalentry");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("runNow");
		// ///

		uiDriver.handleAlert("", "OK");
		uiDriver.click("customer");
		uiDriver.handleAlert("", "OK");
		// String ActualCustomer = input.get("revreccustomer");
		uiDriver.setValue("customer", input.get("reclasscustomer"));
		uiDriver.handleAlert("", "OK");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.handleAlert("", "OK");
		uiDriver.click("postingperiod");
		uiDriver.handleAlert("", "OK");
		uiDriver.setValue("postingperiod", input.get("posting"));
		uiDriver.handleAlert("", "OK");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("postingperiod");
		uiDriver.handleAlert("", "OK");
		uiDriver.click("deliveryDate");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.handleAlert("", "OK");
		uiDriver.setValue("deliveryDate", input.get("delivery"));
		uiDriver.handleAlert("", "OK");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Subsidiary");
		uiDriver.handleAlert("", "OK");
		uiDriver.setValue("Subsidiary", input.get("Subsidiary"));
		uiDriver.handleAlert("", "OK");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("Subsidiary");
		uiDriver.handleAlert("", "OK");
		uiDriver.click("createjournalentry");
		uiDriver.handleAlert("", "OK");

		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);

		uiDriver.refresh();
		uiDriver.click("completebtn");
		uiDriver.click("Journal");

		// validation

		// Create object of SimpleDateFormat class and decide the format
		Date date = new Date();
		DateFormat dateFormat = new SimpleDateFormat("h:mm");
		String strDate = dateFormat.format(date);
        Date d = dateFormat.parse(strDate);
		Calendar cal = Calendar.getInstance();
		cal.setTime(d);
		cal.add(Calendar.MINUTE, 2);
		String newTime = dateFormat.format(cal.getTime());
		String Complete = uiDriver.getDyanmicData("CompleteStatus");
		String CompleteStaus = Complete.replace("#", newTime);
		uiDriver.click_dynamic(CompleteStaus);
		uiDriver.executeJavaScript("scroll(0,500);");

		passed("Verify Processed Reclassification Journal entries",
				"Processed Reclassification Journal entries page should be displayed",
				"Processed Reclassification Journal entries page is displayed");

		uiDriver.click("JournalId");

	}

	/****************************************
	 * Name: VerifyReclassificationJournalEntries
	 * Description: VerifyReclassificationJournalEntries
	 * Date: 30-Nov-2017
	 ****************************************/
	public void VerifyReclassificationJournalEntries(DataRow input,
			DataRow output) {
		int invoiceRow = 2;
		int accRows = uiDriver.webDr.findElements(By.xpath("//*[@id='line_splits']/tbody/tr")).size();
		for (i = 0; i < accRows - 1; i++) {

			if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Deferred Rev - Unpaid"))

			{
				String CreditAmount = uiDriver.getValue("UnpaidAMount");

				if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[2]").equals("")) {
					failed("Verify the Credit Amount",
							"Credit Amount should be displayed as '"+ CreditAmount + "'",
							"Credit Amount is not displayed as '"+ CreditAmount + "' ");
				} else {
					passed("Verify the Credit Amount",
							"Credit Amount should be displayed as '"+ CreditAmount + "'",
							"Credit Amount is displayed as '" + CreditAmount+ "' ");
				}
			}
			if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Unbilled Dom"))

			{
				String DebitAmount = uiDriver.getValue("UnBilledAMount");
				if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals("")) {
					failed("Verify the Debit Amount",
							"Debit Amount should be displayed as '"	+ DebitAmount + "'",
							"Debit Amount is not displayed as '" + DebitAmount+ "' ");
				} else {
					passed("Verify the Debit Amount",
							"Debit Amount should be displayed as '"	+ DebitAmount + "'",
							"Debit Amount is displayed as '" + DebitAmount+ "' ");
				}
			}

			invoiceRow++;
		}
	}

	/****************************************
	 * Name: boxofficeStats 
	 * Description:Method FOR boxofficeStats Date:
	 * 30-Nov-2017
	 ****************************************/
	public void boxofficeStats(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setFrame("frame");
		uiDriver.click("boxofficestats");

		/*
		 * passed("create sales record and check for FMV Dimention Updation",
		 * "Should click on boxofficeStats",
		 * " successfully clicked on  boxofficestats!");
		 */
	}

	public void transactions(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setFrame("frame");
		uiDriver.click("transactions");

		passed("Transactions Page", "Response time of Transactions Page",
				"Successfully loded the Transactions Page");
	}

	public void starttime(DataRow input, DataRow output) {
		double startTime = System.currentTimeMillis();
		String StartTime = Double.toString(startTime);
		output.put("startTime", StartTime);
	}

	public void endtime(DataRow input, DataRow output) {
		double endTime = System.currentTimeMillis();
		String STime = input.get("startTime");
		double StartTime1 = Double.parseDouble(STime);
		double totalTime = endTime - StartTime1;
		String Total = Double.toString(totalTime);
		System.out.println("Total Page Load Time: " + totalTime
				+ "milliseconds");

		passed("Time taken ", " Time in milliseconds  ", totalTime + " ms ");
	}

	public void list(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("list");
		/*
		 * passed("Check for list ", "Should click on list",
		 * " successfully clicked on  list!");
		 */
	}

	/****************************************
	 * Name: employees
	 * Description: Method to click on employees
	 *  Date: 30-Nov-2017
	 
	 ****************************************/
	public void employees(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("employees");
		passed("List page", 
				"Response time of List Page",
				" successfully loded List page");
	}

	public void report(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("report");
		/*
		 * passed("Check for Report", "Should click on report",
		 * " successfully clicked on  report!");
		 */
	}

	public void incomeStatementDetails(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("details");
		passed("Report Page", "Response time of Report Page",
				" successfully loded Report Page");
	}

	/****************************************
	 * Name: calculatePageLoadTime
	 * Description:Method to calculate Page Load
	 * Time Date: 30-Nov-2017
	 ****************************************/
	public void calculatePageLoadTime(DataRow input, DataRow output) {
		double startTime = System.currentTimeMillis();
		boxofficeStats(input, output);
		// driver.get("http://zyxware.com");
		// new WebDriverWait(driver,
		// 10).until(ExpectedConditions.presenceOfElementLocated(By.id("Calculate")));

		double endTime = System.currentTimeMillis();
		transactions(input, output);
		double totalTime = endTime - startTime;
		String Totaltime = Double.toString(totalTime);
		passed("Verify the total time " + "Totaltime+",
				"totaltime should be displayed as" + "Totaltime+",
				"totaltime is displayed as" + "Totaltime+");
		System.out.println(Totaltime);

	}

	/****************************************
	 * Name: revRecJournalEntry
	 * Description: revRecJournalEntry 
	 * Date:30-Nov-2017
	 ****************************************/
	public void revRecJournalEntry(DataRow input, DataRow output)
			throws ParseException {
		SleepUtils.sleep(TimeSlab.LOW);
		// uiDriver.setFrame("frame");
		SleepUtils.sleep(TimeSlab.LOW);
		// uiDriver.setFrame("frame");
		uiDriver.mouseOver("transactions");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("financial");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("revrecjournal");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("runNow");
		SleepUtils.sleep(TimeSlab.YIELD);
	    uiDriver.click("customerdropdownimage");
        uiDriver.handleAlert("", "OK");
        SleepUtils.sleep(5);
        uiDriver.click("customerlist");
        SleepUtils.sleep(5);
        uiDriver.setValue("searchcustomerinput", input.get("revreccustomer"));
        SleepUtils.sleep(5);
        uiDriver.click("searchcustomerbutton");
        SleepUtils.sleep(5);
        uiDriver.click("cussearchresult");
        SleepUtils.sleep(TimeSlab.LOW);
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("postingperiod");
		uiDriver.setValue("postingperiod", input.get("posting"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("postingperiod");
		uiDriver.click("deliveryDate");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("deliveryDate", input.get("delivery"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Subsidiary");
		uiDriver.setValue("Subsidiary", input.get("Subsidiary"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Subsidiary");
	
		SleepUtils.sleep(TimeSlab.LOW);
		String revreclist=uiDriver.getDyanmicData("revreclist");
		String revenuenum=input.get("revenuenum");
		String revrecchklist=revreclist.replace("#", revenuenum);
		List<WebElement> ele = uiDriver.webDr.findElements(By.xpath(revrecchklist));
	    int rowSize = ele.size();
		for (int i =0; i < rowSize; i++) {
		/*	String RevenuechkBox = uiDriver.getDyanmicData("RevenueChkBox");
			String Revenuechkbox1=RevenuechkBox.replace("$",revenuenum);
			String RevchkBox = Revenuechkbox1.replace("#", Integer.toString(i));
			if (uiDriver.checkElementPresent_dynamic(RevchkBox)) {

				uiDriver.click_dynamic(RevchkBox);
			} else {
				// do nothing
			}*/
			SleepUtils.sleep(TimeSlab.LOW);
			ele.get(i).click();
			SleepUtils.sleep(TimeSlab.LOW);
			

		}
		// uiDriver.click("JournalCk");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("createjournalentries");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();

		Date date = new Date();
		DateFormat dateFormat = new SimpleDateFormat("h:mm");
		String strDate = dateFormat.format(date);
		Date d = dateFormat.parse(strDate);
		Calendar cal = Calendar.getInstance();
		cal.setTime(d);
		cal.add(Calendar.MINUTE, 0);
		String newTime = dateFormat.format(cal.getTime());
		String Complete = uiDriver.getDyanmicData("CompleteStatus1");
		String CompleteStaus = Complete.replace("#", newTime);
		cal.add(Calendar.MINUTE, 0);
		String newTime2 = dateFormat.format(cal.getTime());
		String Complete2 = uiDriver.getDyanmicData("CompleteStatus2");
		String CompleteStaus2 = Complete2.replace("#", newTime2);
		cal.add(Calendar.MINUTE, 1);
		String newTime3 = dateFormat.format(cal.getTime());
		String Complete3 = uiDriver.getDyanmicData("CompleteStatus3");
		String CompleteStaus3 = Complete3.replace("#", newTime3);
		if (uiDriver.checkElementPresent_dynamic(CompleteStaus)) {
			uiDriver.click_dynamic(CompleteStaus);
		} else {
			// do nothing
		}

		if (uiDriver.checkElementPresent_dynamic(CompleteStaus2)) {
			uiDriver.click_dynamic(CompleteStaus2);
		} else {
			// do nothing
		}
		if (uiDriver.checkElementPresent_dynamic(CompleteStaus3)) {
			uiDriver.click_dynamic(CompleteStaus3);
		} else {
			// do nothing
		}

		passed("Verify Processed Revenue recognition Journal entries",
				"Processed Revenue recognition Journal entries page should be displayed",
				"Processed Revenue recognition Journal entries page is displayed");

		if (uiDriver.checkElementPresent("completesubmissionstatus")) {
			uiDriver.click("completesubmissionstatus");

		} else {
			// do nothing
		}

		// uiDriver.click("createjournalentries");
		// SleepUtils.sleep(TimeSlab.LOW);
		// uiDriver.click("completeBtn");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Journal");
		uiDriver.executeJavaScript("(scroll(0,500));");
		int invoiceRow = 2;
		int accRows = uiDriver.webDr.findElements(
				By.xpath("//*[@id='line_splits']/tbody/tr")).size();
		for (i = 0; i < accRows - 1; i++) {
			String creditamount = uiDriver.getValue("creditamount");
			String debitamount = uiDriver.getValue("debitamount");
			if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Deferred Rev - Unpaid"))

			{
				if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[2]").equals("")) {
					failed("Validating Credit Amount",
							"Validating Credit Amount should be successfull",
							"Credit amount is not Deferred Rev - Generic");
				} else {
					passed("Credit is Deferred Rev - Generic " + creditamount
							+ "", "Credit is Deferred Rev - Generic "+ creditamount + "",
							"Credit amount is Deferred Rev - Generic "+ creditamount + "");
				}
			}
			if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("GAAP contract revenue"))

			{
				if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals("")) {
					failed("Validating Debit Amount",
							"Validating Debit Amount should be successfull",
							"Debit amount is not GAAP contract revenue");
				} else {
					passed("Debit is Deferred Rev - Generic " + debitamount	+ "",
							"Debit is Deferred Rev - Generic "+ debitamount + "",
							"Debit amount is GAAP contract revenue "	+ debitamount + "");
				}
			}

			invoiceRow++;
		}

		// String Debitamount=uiDriver.getValue("debitamount");
		// String Creditamount=uiDriver.getValue("creditamount");
	}

	/****************************************
	 * Name: createInvoice
	 * Description:Method to create Invoice
	 *  Date:30-Nov-2017
	 ****************************************/

	public void createInvoice(DataRow input, DataRow output) throws InterruptedException 
	{
		SleepUtils.sleep(TimeSlab.LOW);
		
		String Num = input.get("conf");
		uiDriver.setValue("SearchSO",Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Bill");
		String invoicenum = uiDriver.getValue("invoicenum");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,800)");
		SleepUtils.sleep(TimeSlab.LOW);
		if(input.get("ReduceAmount").equalsIgnoreCase("Y"))
		{
			uiDriver.click("reduceqty");
			SleepUtils.sleep(TimeSlab.LOW);	
			uiDriver.sendKey("backspace");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.setValue("reduceqtyvalue", input.get("ReducedValue"));
			SleepUtils.sleep(TimeSlab.MEDIUM);
			// 
			uiDriver.click("OK");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.handleAlert("", "OK");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.handleAlert("", "OK");
		}
		//else{}
		uiDriver.click("saveBill");
		//uiDriver.executeJavaScript("document.getElementById('btn_secondarymultibutton_submitter').click();");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.handleAlert("", "OK");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.handleAlert("", "OK");
		output.put("invoicenumber", invoicenum);
		uiDriver.mouseOver("action");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Glimpact");
		
	}
	
	

	/****************************************
	 * Name: createInvoiceJEntry 
	 * Description:Method to validate Debit and Credit Amount
	 * Date: 30-Nov-2017
	 ****************************************/
	public void createInvoiceJEntry(DataRow input, DataRow output)
			throws InterruptedException {
		SleepUtils.sleep(TimeSlab.HIGH);
		String Num = input.get("conf");
		uiDriver.setValue("SearchSO", Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
				"SalesOrder is displayed Successfully");
		SleepUtils.sleep(5);
		uiDriver.refresh();
		uiDriver.executeJavaScript("scroll(0,500)");
		uiDriver.click("relatedRecord");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("invoiceNo");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("reclassJEntry");
		SleepUtils.sleep(TimeSlab.HIGH);
		List<WebElement> ele = uiDriver.webDr.findElements(By.xpath("//*[@id='recmachcustbody_nbcu_related_record__tab']/tbody/tr"));
	    int rowSize = ele.size();
		for (int r = 1; r < rowSize; r++) {
			
			uiDriver.click("reclassJEntry");
			SleepUtils.sleep(2);
			 uiDriver.executeJavaScript("scroll(0,1500)");
			String s1 = uiDriver.getDyanmicData("DocNum");
			String s2 = s1.replace("#", Integer.toString(r));
			if (uiDriver.checkElementPresent_dynamic(s2)) {

				SleepUtils.sleep(5);
				uiDriver.click(s2);
				SleepUtils.sleep(20);
				 uiDriver.executeJavaScript("scroll(0,800)");
    		     int invoiceRow = 2;
                 int transRows=uiDriver.webDr.findElements(By.xpath("//*[@id='line_splits']//tbody/tr")).size();
    		     for(i=0;i<transRows-1;i++){ 
    		       uiDriver.executeJavaScript("scroll(0,100);");
			       if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[1]").contains("Deferred Rev - Generic"))
			       {
			    	   if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[2]").equals(""))
			    	   {

						       failed("Validating Debit Amount",
						       "Validating Debit Amount should be successfull",
						       "Debit amount is not Deferred Rev - Generic");
			       }
			       else
			       {

					       passed("Debit is Deferred Rev - Generic",
					       "Debit is Deferred Rev - Generic",
					       "Debit amount is Deferred Rev - Generic");

			       }

			       }

			       if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[1]").contains("Bad Debt"))
			       {

			    	   if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[2]").equals(""))
			    	   {

						       failed("Validating Debit Amount",
						       "Validating Debit Amount should be successfull",
						       "Debit amount is not Bad Debt");

			       }
			       else
			       {
				       passed("Debit is Deferred Rev - Generic",
				       "Debit is Bad Debt",
				       "Debit amount is Bad Debt");
			       }
			       }
  

			       if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[1]").contains("Generic Billed"))
			       {
			    	   if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[3]").equals(""))
			    	   {
						       failed("Validating Credit Amount",
						       "Validating Credit Amount should be successfull",
						       "Credit amount is not Generic Billed");

			       }

			       else
			       {
				       passed("Debit is Generic Billed",
				       "Credit is Generic Billed",
				       "Credit amount is Generic Billed");

			       }

			       }

			       if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[1]").contains("Contract revenue"))
			       {
			    	   if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[2]").equals(""))
     			       {

					       failed("Validating Debit Amount",
					       "Validating Credit Amount should be successfull",
					       "Credit amount is not Contract revenue");
		       }

			       else
			       {
				       passed("Debit is Contract revenue",
				       "Credit is Contract revenue",
				       "Credit amount is Contract revenue");

			       }
			      }
	     
			       if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[1]").contains("Bad Debt Revenue"))
			       {
			    	   if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[3]").equals(""))
			    	   {

						       failed("Validating Credit Amount",
						       "Validating Credit Amount should be successfull",
						       "Credit amount is not Bad Debt Revenue");
			       }

			       else

			       {
				       passed("Credit is Generic Billed",
				       "Credit is Bad Debt Revenue",
				       "Credit amount is Bad Debt Revenue");

			       }
			       }

			       if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[1]").contains("Billed Intl"))
			       {
			    	   if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[3]").equals(""))
			   	       {

					       failed("Validating Credit Amount",
					       "Validating Credit Amount should be successfull",
					       "Credit amount is not Billed Intl");

			       }

			       else
			       {
				       passed("Debit is Billed Intl",
				       "Credit is Billed Intl",
				       "Credit amount is Billed Intl");

			       }

			       }

			       if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[1]").contains("Deferred Rev - Unpaid"))
			       {
			    	   if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[3]").equals(""))
			    	   {

						       failed("Validating CREDIT Amount",
						       "Validating CREDIT Amount should be successfull",
						       "CREDIT amount is not Deferred Rev - Unpaid");

			       }

			       else
			       {

			       passed("CREDIT is Deferred Rev - Unpaid",
			       "CREDIT is Deferred Rev - Unpaid",
			       "CREDIT amount is Deferred Rev - Unpaid");

			       }
		       }
			   invoiceRow++;
          }

			       uiDriver.executeJavaScript("scroll(0,800)");
			       SleepUtils.sleep(5);
			       uiDriver.click("Back1");
			       SleepUtils.sleep(5);
			       uiDriver.executeJavaScript("scroll(0,-500)");
			       SleepUtils.sleep(5);
			}
			
    	  else  {
    		  		//do nothindf
			     }

			       

			       }

			       }

	/*
	 * public void findSalesOrder(DataRow input, DataRow output) {
	 * if(uiDriver.checkElementPresent("")) { String SONUMBER = input.get("");
	 * 
	 * }
	 */

	/****************************************
	 * Name: verifyInvoice
	 * Description: verifyInvoice
	 *  Date: 30-Nov-2017
	 ****************************************/

	public void verifyInvoice(DataRow input, DataRow output)
			throws InterruptedException {
		int invoiceRow = 2;
		int accRows = uiDriver.webDr.findElements(By.xpath("//form[contains(@id,'body_actions')]//tbody/tr")).size();
		for (i = 0; i < accRows - 1; i++) {

			if (uiDriver.getValue("//form[contains(@id,'body_actions')]//tbody/tr["+ invoiceRow + "]/td[1]").contains("Deferred Rev - Generic"))

			{
				if (uiDriver.getValue("//form[contains(@id,'body_actions')]//tbody/tr["+ invoiceRow + "]/td[2]").equals("")) {
					failed("Validating Credit Amount",
							"Validating Credit Amount should be successfull",
							"Credit amount is not Deferred Rev - Generic");
				} else {
					passed("Credit is Deferred Rev - Generic",
							"Credit is Deferred Rev - Generic",
							"Credit amount is Deferred Rev - Generic");
				}
			}
			if (uiDriver.getValue("//form[contains(@id,'body_actions')]//tbody/tr["+ invoiceRow + "]/td[1]").contains("Generic Billed AR"))

			{
				if (uiDriver.getValue("//form[contains(@id,'body_actions')]//tbody/tr["+ invoiceRow + "]/td[3]").equals("")) {
					failed("Validating Debit Amount",
							"Validating Debit Amount should be successfull",
							"Debit amount is not Generic billed AR");
				} else {
					passed("Debit is generic billed AR",
							"Debit is generic billed AR",
							"Debit amount is Generic billed AR");
				}
			}
			
			if (uiDriver.getValue("//form[contains(@id,'body_actions')]//tbody/tr["+ invoiceRow + "]/td[1]").contains("22110043 HST ON"))

			{
				if (uiDriver.getValue("//form[contains(@id,'body_actions')]//tbody/tr["+ invoiceRow + "]/td[3]").equals("")) {
					failed("Validating Debit Amount",
							"Validating Debit Amount should be successfull",
							"Debit amount is not Generic billed AR");
				} else {
					passed("Credit is 22110043 HST ON",
							"Credit is 22110043 HST ON",
							"Credit amount is 22110043 HST ON");
				}
				
			}
			if (uiDriver.getValue("//form[contains(@id,'body_actions')]//tbody/tr["+ invoiceRow + "]/td[1]").contains("11015051 USL Cash Clearing"))

			{
				if (uiDriver.getValue("//form[contains(@id,'body_actions')]//tbody/tr["+ invoiceRow + "]/td[2]").equals("")) {
					failed("Validating Debit Amount",
							"Validating Debit Amount should be successfull",
							"Debit amount is not Generic billed AR");
				} else {
					passed("Credit is 11015051 USL Cash Clearing ON",
							"Credit is 11015051 USL Cash Clearing ON",
							"Credit amount is 11015051 USL Cash Clearing ON");
				}
			}
			if (uiDriver.getValue("//form[contains(@id,'body_actions')]//tbody/tr["+ invoiceRow + "]/td[1]").contains("110051XX Generic Billed AR"))

			{
				if (uiDriver.getValue("//form[contains(@id,'body_actions')]//tbody/tr["+ invoiceRow + "]/td[3]").equals("")) {
					failed("Validating Credit Amount",
							"Validating Credit Amount should be successfull",
							"Credit amount is not Generic billed AR");
				} else {
					passed("Debit is 110051XX Generic Billed AR ON",
							"Debit is 110051XX Generic Billed AR ON",
							"Debit amount is 110051XX Generic Billed AR ON");
				}
			}

			invoiceRow++;
		}
		uiDriver.back();
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.refresh();
	}

	/****************************************
	 * Name: validateJEafterReclass
	 * Description: validateJEafterReclass 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void validateJEafterReclass1(DataRow input, DataRow output) throws InterruptedException 

	{     

	SleepUtils.sleep(TimeSlab.HIGH);
	String Num = input.get("conf");
	uiDriver.setValue("SearchSO",Num);
	SleepUtils.sleep(TimeSlab.MEDIUM);
	uiDriver.click("SalesOrder");
	      SleepUtils.sleep(5);
	   uiDriver.refresh();
	   uiDriver.executeJavaScript("scroll(0,500)");
	int maxWait = 1; 
	    int secsWaited = 0;
	    
	    try {
	    do {

	Thread.sleep(100);
	uiDriver.refresh();
	uiDriver.click("//*[text()='lated Transactions']");
	
	//uiDriver.executeJavaScript("document.getElementById('custom59txt').click();");	//  WebElement journalNumber= uiDriver.webDr.findElement(By.xpath(""));
	secsWaited++;
	if (uiDriver.checkElementPresent("reclasslink")) {
	passed("Reclass journal displayed successfully",
	    "Reclass journal displayed successfully at "+secsWaited+"",
	    "Reclass journal displayed successfully at "+secsWaited+"");
	break;
	}
	} while (secsWaited < (maxWait * 10));
	Thread.sleep(100);
	}
	catch (TimeoutException e) {
	}
	    List<WebElement> reclasslink = uiDriver.webDr.findElements(By.xpath("//*[text()='saction']/following::table//tr/td[text()='Journal']/preceding::td[1]/a"));
	    int RowSize = reclasslink.size();
	    Thread.sleep(5);
	for(int r=0;r<RowSize-1;r++)
	{
		WebElement w = uiDriver.webDr.findElement(By.xpath("//*[text()='lated Transactions']"));
		String id = w.getAttribute("id");
	SleepUtils.sleep(TimeSlab.HIGH);
	uiDriver.executeJavaScript("scroll(0,-1000)");
	//if(uiDriver.checkElementPresent_dynamic("reclassJEntry")){
	uiDriver.executeJavaScript("document.getElementById('"+id+"').click();");
	uiDriver.executeJavaScript("scroll(0,700)");
	String s1= uiDriver.getDyanmicData("DocNum");
	String s2=s1.replace("#", Integer.toString(r));
	if(uiDriver.checkElementPresent_dynamic(s2)){
	uiDriver.click(s2);
	passed("Click On the Revenue Paln Number "+s2+"",
	    "Should be SuccessFully Clicked on Revenue Paln Number "+s2+"",
	    "SuccessFully Clicked on Revenue Paln Number "+s2+"");
	  
	uiDriver.executeJavaScript("scroll(0,500)");
	int invoiceRow = 2;
	    int transRows=uiDriver.webDr.findElements(By.xpath("//*[@id='line_splits']//tbody/tr")).size();
	for(i=0;i<transRows-1;i++){ 
	uiDriver.executeJavaScript("scroll(0,100);");
	    if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[1]").equalsIgnoreCase("GAAP contract revenue - Intl"))
	/*String planRows = uiDriver.getObjMap("planRows");
	String actualRECOGNITIONACCOUNT=uiDriver.getValue(planRows+firstRow+uiDriver.getObjMap("recognitionaccount")).trim();  
	String unbilledrevenureaccount=input.get("UNBILLED REVENUE ACCOUNT");*/
	///
	{
	if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[2]").equals(""))
	{
	failed("Validating Debit Amount",
	"Validating Debit Amount should be successfull",
	"Debit amount is not GAAP contract revenue - Intl");
	}
	else
	{
	passed("Validating Debit Amount",
	"Validating Debit Amount should be successfull",
	  "Debit amount is not GAAP contract revenue - Intl");
	}
	}
	     if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[1]").equalsIgnoreCase("Contract revenue - Intl"))
	     {
	       if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[3]").equals(""))
	       {
	failed("Validating CREDIT Amount",
	        "Validating CREDIT Amount should be successfull",
	       "CREDIT amount is not contract revenue - Intl");
	}
	else
	{
	passed("CREDIT is Deferred Rev - Unpaid",
	"CREDIT is Deferred Rev - Unpaid",
	"CREDIT amount is contract revenue - Intl");
	 
	}
	}
	          invoiceRow++;
	}
	}else
	{
	}            
	uiDriver.executeJavaScript("scroll(0,-15000)");
	WebElement w1=uiDriver.webDr.findElement(By.xpath("//*[@value='Back' and @name='_back']"));
	String s=w1.getAttribute("id");
	uiDriver.executeJavaScript("document.getElementById('"+s+"').click();");
	//uiDriver.click("Back1");
	SleepUtils.sleep(5);
	passed("CREDIT is contract revenue",
	"CREDIT is contract revenue",
	"CREDIT amount is GAAP contract revenue - Intl");
	passed("Debit is contract revenue",
	    "Debit is contract revenue",
	"Debit amount is contract revenue - Intl");
	}
	}


/****************************************
	 * Name: validateJEafterReclass10K
	 * Description: validateJEafterReclass10K
	 * Date: 30-Nov-2017
	 ****************************************/
	public void validateJEafterReclass(DataRow input, DataRow output) throws InterruptedException 

	{     

		SleepUtils.sleep(TimeSlab.HIGH);
		String Num = input.get("conf");
		uiDriver.setValue("SearchSO",Num);
		SleepUtils.sleep(TimeSlab.MEDIUM);
		uiDriver.click("SalesOrder");
     	SleepUtils.sleep(5);
	   uiDriver.refresh();
	   uiDriver.executeJavaScript("scroll(0,500)");
	 	int maxWait = 10; 
    	int secsWaited = 0;
    	try {
    		do {

    Thread.sleep(100);
    uiDriver.refresh();
    uiDriver.refresh();
    uiDriver.refresh();
    Thread.sleep(100);
    uiDriver.refresh();
    uiDriver.click("//*[text()='lated Transactions']");
    //uiDriver.executeJavaScript("document.getElementsByClassName('formtabtext formtabtextoff')[6].click();");
    //uiDriver.executeJavaScript("document.getElementById('custom59txt').click();");  //  WebElement journalNumber= uiDriver.webDr.findElement(By.xpath(""));
    secsWaited++;
    if (uiDriver.checkElementPresent("reclasslink")) {
    passed("Reclass journal displayed successfully",
        "Reclass journal displayed successfully at "+secsWaited+"",
        "Reclass journal displayed successfully at "+secsWaited+"");
    break;
    }
    } while (secsWaited < (maxWait * 10));
    Thread.sleep(100);
    }
    catch (TimeoutException e) {
    }
        List<WebElement> reclasslink = uiDriver.webDr.findElements(By.xpath("//*[text()='saction']/following::table//tr/td[text()='Journal']/preceding::td[1]/a"));
        int RowSize = reclasslink.size();
        Thread.sleep(5);
        // Changing for scenario17 added equalsto
    for(int r=0;r<=RowSize-1;r++)
    {
           WebElement w = uiDriver.webDr.findElement(By.xpath("//*[text()='lated Transactions']"));
           String id = w.getAttribute("id");
    SleepUtils.sleep(TimeSlab.HIGH);
    uiDriver.executeJavaScript("scroll(0,-1000)");
    //if(uiDriver.checkElementPresent_dynamic("reclassJEntry")){
    uiDriver.executeJavaScript("document.getElementById('"+id+"').click();");
    uiDriver.executeJavaScript("scroll(0,700)");
//    String s1= uiDriver.getDyanmicData("DocNum");
//    String s2=s1.replace("#", Integer.toString(r+2));  //(//*[text()='saction']/following::table//tr)[5]//td[1]//a
    String s2 = "(//*[text()='saction']/following::table//tr)[5]//td[1]//a";
    if(uiDriver.checkElementPresent_dynamic(s2)){
    uiDriver.click(s2);
    passed("Click On the Revenue Paln Number "+s2+"",
        "Should be SuccessFully Clicked on Revenue Paln Number "+s2+"",
        "SuccessFully Clicked on Revenue Paln Number "+s2+"");
      
    uiDriver.executeJavaScript("scroll(0,500)");
    int invoiceRow = 2;
        int transRows=uiDriver.webDr.findElements(By.xpath("//*[@id='line_splits']//tbody/tr")).size();
        //changing for Scenario17
    for(i=0;i<transRows-1;i++){ 
    uiDriver.executeJavaScript("scroll(0,100);");
        if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[1]").equalsIgnoreCase("GAAP contract revenue - Intl"))
    /*String planRows = uiDriver.getObjMap("planRows");
    String actualRECOGNITIONACCOUNT=uiDriver.getValue(planRows+firstRow+uiDriver.getObjMap("recognitionaccount")).trim();  
    String unbilledrevenureaccount=input.get("UNBILLED REVENUE ACCOUNT");*/
    ///
    {
    if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[2]").equals(""))
    {
    failed("Validating Debit Amount",
    "Validating Debit Amount should be successfull",
    "Debit amount is not GAAP contract revenue - Intl");
    }
    else
    {
    passed("Validating Debit Amount",
    "Validating Debit Amount should be successfull",
      "Debit amount is not GAAP contract revenue - Intl");
    }
    }
         if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[1]").equalsIgnoreCase("Contract revenue - Intl"))
         {
           if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[3]").equals(""))
           {
    failed("Validating CREDIT Amount",
            "Validating CREDIT Amount should be successfull",
           "CREDIT amount is not contract revenue - Intl");
    }
    else
    {
    passed("CREDIT is Deferred Rev - Unpaid",
    "CREDIT is Deferred Rev - Unpaid",
    "CREDIT amount is contract revenue - Intl");
    
    }
    }
         if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[1]").equalsIgnoreCase("11015903 Deferred Rev -Unpaid - Intl - NM (incl EST/PPV/VOD)"))
         {
           if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[2]").equals(""))
           {
    failed("Validating DEBIT Amount",
            "Validating DEBIT Amount should be successfull",
           "DEBIT amount is not contract revenue - Intl");
    }
    else
    {
    passed("DEBIT is Deferred Rev - Unpaid",
    "DEBIT is Deferred Rev - Unpaid",
    "DEBIT amount is contract revenue - Intl");
    
    }
    }
         if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[1]").equalsIgnoreCase("22310503 Deferred Rev - Paid - NM (incl EST/PPV/VOD)"))
         {
           if(uiDriver.getValue("//*[@id='line_splits']/tbody/tr["+invoiceRow+"]/td[3]").equals(""))
           {
    failed("Validating CREDIT Amount",
            "Validating CREDIT Amount should be successfull",
           "CREDIT amount is not contract revenue - Intl");
    }
    else
    {
    passed("CREDIT is Deferred Rev - Unpaid",
    "CREDIT is Deferred Rev - paid",
    "CREDIT amount is contract revenue - Intl");
    
    }
    }
         
    
         
    
              invoiceRow++;
    }
    }else
    {
    }            
    uiDriver.executeJavaScript("scroll(0,-15000)");
    try {
		WebElement w1=uiDriver.webDr.findElement(By.xpath("//*[@value='Back' and @name='_back']"));
		String s=w1.getAttribute("id");
		uiDriver.executeJavaScript("document.getElementById('"+s+"').click();");
    } catch(Exception e) {
    	uiDriver.back();
    }
    SleepUtils.sleep(5);
    passed("CREDIT is contract revenue",
    "CREDIT is contract revenue",
    "CREDIT amount is GAAP contract revenue - Intl");
    passed("Debit is contract revenue",
        "Debit is contract revenue",
    "Debit amount is contract revenue - Intl");
    }
    }

	
	
	/****************************************
	 * Name: acceptPayment
	 * Description: acceptPayment 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void acceptPayment(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.setFrame("frame");
		uiDriver.mouseOver("transactions");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("CustomerPay");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("AcceptPayment");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.YIELD);

		uiDriver.click("AcceptPayment");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.YIELD);
		String cust = input.get("customer");
		uiDriver.click("customerdropdownimage");
		//uiDriver.click("customer");
		//uiDriver.clear("customer");
		//uiDriver.click("customer");
		//uiDriver.handleAlert("", "OK");
		SleepUtils.sleep(5);
		uiDriver.click("customerlist");
		SleepUtils.sleep(5);
		 uiDriver.setValue("searchcustomerinput", cust);
		 SleepUtils.sleep(5);
		 uiDriver.click("searchcustomerbutton");
		 SleepUtils.sleep(5);
		 uiDriver.click("cussearchresult");
		//SleepUtils.sleep(100);
		//uiDriver.sendKey("tab");
		//SleepUtils.sleep(TimeSlab.MEDIUM);
		//uiDriver.click("applyinvoice");
	
		// uiDriver.sendKey("tab");//SleepUtils.sleep(TimeSlab.MEDIUM);
		// uiDriver.click("applyinvoice");
		 //uiDriver.click("acctradiobutton");
	    //SleepUtils.sleep(TimeSlab.YIELD);
			 //uiDriver.setValue("Account", "30 Undeposited Funds");
			 //SleepUtils.sleep(TimeSlab.YIELD);
		String InvoiceNum = input.get("invoicenumber");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.executeJavaScript("scroll(0,900);");
		SleepUtils.sleep(TimeSlab.YIELD);
		String ReferenceNum = uiDriver.getDyanmicData("ReferenceNum");
		SleepUtils.sleep(TimeSlab.YIELD);
		String ReferenceVal = ReferenceNum.replace("#",InvoiceNum);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click_dynamic(ReferenceVal);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.executeJavaScript("scroll(0,-800)");
		uiDriver.click("acctradiobutton");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("Account", "11015051 USL Cash Clearing");
		 SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("ContractorName", "");
		 SleepUtils.sleep(TimeSlab.LOW);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.executeJavaScript("document.getElementById('btn_multibutton_submitter').click();");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.mouseOver("action");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Glimpact");
	}

	/****************************************
	 * Name: acceptPartialPayment
	 * Description: acceptPartialPayment 
	 * Date: 30-Nov-2017
	 ****************************************/
		public void acceptPartialPayment(DataRow input, DataRow output) {
		SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.setFrame("frame");
		uiDriver.mouseOver("transactions");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("CustomerPay");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.mouseOver("AcceptPayment");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("AcceptPayment");
		SleepUtils.sleep(TimeSlab.YIELD);
		SleepUtils.sleep(TimeSlab.YIELD);
		String cust = input.get("customer");
		   uiDriver.click("customerdropdownimage");

           //uiDriver.click("customer");

           //uiDriver.clear("customer");

           //uiDriver.click("customer");

           //uiDriver.handleAlert("", "OK");

           SleepUtils.sleep(5);

           uiDriver.click("customerlist");
           SleepUtils.sleep(5);
           uiDriver.setValue("searchcustomerinput", cust);
           SleepUtils.sleep(5);
           uiDriver.click("searchcustomerbutton");
           SleepUtils.sleep(5);
           uiDriver.click("cussearchresult");
           SleepUtils.sleep(5);
		//uiDriver.setValue("CustomerName", cust);
		// uiDriver.setValue("CustomerName","2716 IMAGICA TV CORP.");
		SleepUtils.sleep(TimeSlab.MEDIUM);
uiDriver.click("acctradiobutton");
		SleepUtils.sleep(TimeSlab.YIELD);
		 uiDriver.setValue("Account", "30 Undeposited Funds");
		 SleepUtils.sleep(TimeSlab.YIELD);


	//	uiDriver.sendKey("enter");
	//	SleepUtils.sleep(100);
	//	SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.sendKey("tab");
		// SleepUtils.sleep(TimeSlab.MEDIUM);
		// uiDriver.click("applyinvoice");
		String InvoiceNum = input.get("invoicenumber");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.executeJavaScript("scroll(0,900);");
		SleepUtils.sleep(TimeSlab.YIELD);
		String ReferenceNum = uiDriver.getDyanmicData("ReferenceNum");
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.HIGH);
		SleepUtils.sleep(TimeSlab.LOW);
		String ReferenceVal = ReferenceNum.replace("#", InvoiceNum);
		uiDriver.click_dynamic(ReferenceVal);
		SleepUtils.sleep(TimeSlab.LOW);
		String partialpayment = uiDriver.getDyanmicData("partialpaymentfield");
		SleepUtils.sleep(TimeSlab.YIELD);
		String ReferenceVal1 = partialpayment.replace("#", InvoiceNum);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue(ReferenceVal1, input.get("Amount"));
		SleepUtils.sleep(TimeSlab.YIELD);
		
		SleepUtils.sleep(TimeSlab.YIELD);
	
		uiDriver.executeJavaScript("scroll(0,-800)");
		uiDriver.click("acctradiobutton");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("Account", "11015051 USL Cash Clearing");
		 SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("ContractorName", "");
		 SleepUtils.sleep(TimeSlab.LOW);
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.executeJavaScript("document.getElementById('btn_multibutton_submitter').click();");
		SleepUtils.sleep(TimeSlab.LOW);
		//uiDriver.click("saveacceptPayment");
		//SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.mouseOver("action");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Glimpact");
	}

		
	/****************************************
	 * Name: PartialRevenue
	 * Description: PartialRevenue 
	 * Date: 30-Nov-2017
	 ****************************************/	
	public void PartialRevenue(DataRow input, DataRow output)
			throws ParseException
	{
		uiDriver.click("editbtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("allocationcheckbx");
		uiDriver.click("saveBtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("UpdateRevPlanBtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("submissionIDHeader");

		// uiDriver.click("completeBtn");

		// refressh

		Date date = new Date();

		DateFormat dateFormat = new SimpleDateFormat("h:mm");

		String strDate = dateFormat.format(date);

		Date d = dateFormat.parse(strDate);

		Calendar cal = Calendar.getInstance();

		cal.setTime(d);

		cal.add(Calendar.MINUTE, 0);

		String newTime = dateFormat.format(cal.getTime());

		String Complete = uiDriver.getDyanmicData("CompleteStatus1");

		String CompleteStaus = Complete.replace("#", newTime);

		cal.add(Calendar.MINUTE, 0);

		String newTime2 = dateFormat.format(cal.getTime());

		String Complete2 = uiDriver.getDyanmicData("CompleteStatus2");

		String CompleteStaus2 = Complete2.replace("#", newTime2);

		cal.add(Calendar.MINUTE, 1);

		String newTime3 = dateFormat.format(cal.getTime());

		String Complete3 = uiDriver.getDyanmicData("CompleteStatus3");

		String CompleteStaus3 = Complete3.replace("#", newTime3);

		if (uiDriver.checkElementPresent_dynamic(CompleteStaus))

		{

			uiDriver.click_dynamic(CompleteStaus);

		}

		else

		{

			// do nothing

		}

		if (uiDriver.checkElementPresent_dynamic(CompleteStaus2))

		{

			uiDriver.click_dynamic(CompleteStaus2);

		}

		else

		{

			// do nothing

		}

		if (uiDriver.checkElementPresent_dynamic(CompleteStaus3))

		{

			uiDriver.click_dynamic(CompleteStaus3);

		}

		else

		{

			// do nothing

		}

		passed("Verify Processed Reclassification Journal entries",

		"Processed Reclassification Journal entries page should be displayed",

		"Processed Reclassification Journal entries page is displayed");

		int size = 4;

		for (int r = 0; r < size; r++)

		{

			String s1 = uiDriver.getDyanmicData("RevenuePlanNumber1");

			String s2 = s1.replace("#", Integer.toString(r));

			if (uiDriver.checkElementPresent_dynamic(s2))

			{

				uiDriver.click_dynamic(s2);

				passed("Click On the Revenue Paln Number " + s2 + "",
				"Should be SuccessFully Clicked on Revenue Paln Number " + s2+ "",
				"SuccessFully Clicked on Revenue Paln Number " + s2 + "");

				passed("Verify the Revenue Paln Number",
				"Revenue Recognition Plan Page Should be displayed",
				"Revenue Recognition Plan Page is displayed");

				uiDriver.executeJavaScript("scroll(0,300)");

				String ActualdeferralAccnt = uiDriver.getValue("DeferralAccountRevPlan").trim();
				String ActualRecognitionAcc = uiDriver.getValue("RecognitionAccountRevPlan").trim();
				
				if (r == 0) {

					if (input.get("deferralAccount").contains(ActualdeferralAccnt)) {

						passed("Verifying the deferral account","deferral account  " 
						+ input.get("deferralAccount")	+ "   value should be displayed successfully",
						"deferral account value is displayed successfully"+ ActualdeferralAccnt + "");

					}

					else {

						failed("Verifying the deferral account","deferral account   "
						+ input.get("deferralAccount")+ "   value should be displayed successfully",
						"deferral account value is not displayed successfully "+ ActualdeferralAccnt + "");

					}

					if (input.get("RecognitionAccount").contains(ActualRecognitionAcc)) {

						passed("Verifying the Recognition account",
								"Recognition account  "+ input.get("RecognitionAccount")+ "   value should be displayed successfully",
								"Recognition account value is displayed successfully"	+ ActualRecognitionAcc + "");

					}

					else {

						failed("Verifying the Recognition account",
								"Recognition account  "	+ input.get("RecognitionAccount")+ " value should be displayed successfully",
								"Recognition account value is not displayed successfully "+ ActualRecognitionAcc + "");

					}

					uiDriver.click("edit");

					uiDriver.executeJavaScript("scroll(0,1100);");

					uiDriver.click("amount");

					SleepUtils.sleep(TimeSlab.YIELD);

					uiDriver.executeJavaScript("document.getElementById('amount_formattedValue').click();");

					// uiDriver.click("amount");//does not work

					// uiDriver.executeJavaScript("document.getElementById('amount_formattedValue').click();");

					SleepUtils.sleep(TimeSlab.YIELD);

					uiDriver.executeJavaScript("document.getElementById('amount_formattedValue').value = '"	+ input.get("amount") + "'");

					// uiDriver.setValue("amount", input.get("amount"));

					SleepUtils.sleep(TimeSlab.YIELD);

					uiDriver.click("ok");

					SleepUtils.sleep(TimeSlab.YIELD);

					// uiDriver.click("postingPeriod");

					// uiDriver.executeJavaScript("document.getElementById('inpt_plannedperiod3').click();");

					uiDriver.click("dropdown");

					SleepUtils.sleep(TimeSlab.YIELD);

					String MonthCode = uiDriver.getDyanmicData("month");

					String moncode = MonthCode.replace("#",
							input.get("postingperiod"));

					uiDriver.click(moncode);

					// uiDriver.click("feb");

					// uiDriver.executeJavaScript("document.getElementById('inpt_plannedperiod3').value = '"+
					// input.get("postingperiod")+"'");

					SleepUtils.sleep(TimeSlab.YIELD);

					// uiDriver.sendKey("tab");

					// uiDriver.setValue("postingPeriod",
					// input.get("postingperiod"));

					SleepUtils.sleep(TimeSlab.YIELD);

					// uiDriver.executeJavaScript("document.getElementById('amount_formattedValue').click();");

					uiDriver.click("amount1");

					SleepUtils.sleep(TimeSlab.YIELD);

					uiDriver.executeJavaScript("document.getElementById('amount_formattedValue').click();");

					SleepUtils.sleep(TimeSlab.YIELD);

					uiDriver.executeJavaScript("document.getElementById('amount_formattedValue').value = '"
							+ input.get("amount1") + "'");

					// uiDriver.setValue("amount1", input.get("amount1"));

					// uiDriver.click("addButton");

					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("save");

				} else if (r == 1) {

					if (input.get("deferralAccount1").contains(	ActualdeferralAccnt)) {

						passed("Verifying the deferral account",
								"deferral account  " + input.get("deferralAccount1")+ "   value should be displayed successfully",
               					"deferral account value is displayed successfully"+ ActualdeferralAccnt + "");

					}

					else {

						failed("Verifying the deferral account",
						"deferral account   " + input.get("deferralAccount1")+ "   value should be displayed successfully",
     					"deferral account value is not displayed successfully "	+ ActualdeferralAccnt + "");

					}

					if (input.get("RecognitionAccount1").contains(ActualRecognitionAcc)) {

						passed("Verifying the Recognition account",	"Recognition account  "
						+ input.get("RecognitionAccount1")+ "   value should be displayed successfully",
						"Recognition account value is displayed successfully"+ ActualRecognitionAcc + "");

					}

					else {

						failed("Verifying the Recognition account",
							   "Recognition account  "+ input.get("RecognitionAccount1")									+ " value should be displayed successfully",

								"Recognition account value is not displayed successfully "
										+ ActualRecognitionAcc + "");

					}

					uiDriver.click("edit");

					uiDriver.executeJavaScript("scroll(0,1100);");

					uiDriver.click("amount");// does not work

					SleepUtils.sleep(TimeSlab.YIELD);

					uiDriver.executeJavaScript("document.getElementById('amount_formattedValue').click();");
					SleepUtils.sleep(TimeSlab.YIELD);

					uiDriver.executeJavaScript("document.getElementById('amount_formattedValue').value = '"	+ input.get("amount2") + "'");
					SleepUtils.sleep(TimeSlab.YIELD);

					uiDriver.click("ok");

					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("dropdown");

					SleepUtils.sleep(TimeSlab.YIELD);

					String MonthCode = uiDriver.getDyanmicData("month");

					String moncode = MonthCode.replace("#",input.get("postingperiod"));

					uiDriver.click(moncode);
					SleepUtils.sleep(TimeSlab.YIELD);
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("amount1");

					SleepUtils.sleep(TimeSlab.YIELD);

					uiDriver.executeJavaScript("document.getElementById('amount_formattedValue').click();");

					SleepUtils.sleep(TimeSlab.YIELD);

					uiDriver.executeJavaScript("document.getElementById('amount_formattedValue').value = '"
							+ input.get("amount3") + "'");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("save");

				}

				else if (r == 2) {

					if (input.get("deferralAccount2").contains(ActualdeferralAccnt)) {

						passed("Verifying the deferral account",
								"deferral account  "
										+ input.get("deferralAccount2")
										+ "   value should be displayed successfully",
								"deferral account value is displayed successfully"
										+ ActualdeferralAccnt + "");

					}

					else {

						failed("Verifying the deferral account",
								"deferral account   "
										+ input.get("deferralAccount2")
										+ "   value should be displayed successfully",
								"deferral account value is not displayed successfully "
										+ ActualdeferralAccnt + "");

					}

					if (input.get("RecognitionAccount2").contains(ActualRecognitionAcc)) {

						passed("Verifying the Recognition account",
								"Recognition account  "
										+ input.get("RecognitionAccount2")
										+ "   value should be displayed successfully",
								"Recognition account value is displayed successfully"
										+ ActualRecognitionAcc + "");

					}

					else {

						failed("Verifying the Recognition account",
								"Recognition account  "
										+ input.get("RecognitionAccount2")
										+ " value should be displayed successfully",
								"Recognition account value is not displayed successfully "
										+ ActualRecognitionAcc + "");

					}

					uiDriver.click("edit");

					uiDriver.executeJavaScript("scroll(0,1100);");

					uiDriver.click("amount");// does not work

					SleepUtils.sleep(TimeSlab.YIELD);

					uiDriver.executeJavaScript("document.getElementById('amount_formattedValue').click();");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.executeJavaScript("document.getElementById('amount_formattedValue').value = '"
							+ input.get("amount4") + "'");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("ok");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("dropdown");
					SleepUtils.sleep(TimeSlab.YIELD);
					String MonthCode = uiDriver.getDyanmicData("month");
					String moncode = MonthCode.replace("#",
							input.get("postingperiod"));
					uiDriver.click(moncode);
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("amount1");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.executeJavaScript("document.getElementById('amount_formattedValue').click();");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.executeJavaScript("document.getElementById('amount_formattedValue').value = '"
							+ input.get("amount5") + "'");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("save");

				}

				else if (r == 3) {

					if (input.get("deferralAccount3").contains(
							ActualdeferralAccnt)) {

						passed("Verifying the deferral account",
								"deferral account  "
										+ input.get("deferralAccount3")
										+ " value should be displayed successfully",
								"deferral account value is displayed successfully"
										+ ActualdeferralAccnt + "");

					}

					else {

						failed("Verifying the deferral account",
								"deferral account   "
										+ input.get("deferralAccount3")
										+ "   value should be displayed successfully",
								"deferral account value is not displayed successfully "
										+ ActualdeferralAccnt + "");

					}

					if (input.get("RecognitionAccount3").contains(
							ActualRecognitionAcc)) {

						passed("Verifying the Recognition account",
								"Recognition account  "
										+ input.get("RecognitionAccount1")
										+ "   value should be displayed successfully",
								"Recognition account value is displayed successfully"
										+ ActualRecognitionAcc + "");

					}

					else {

						failed("Verifying the Recognition account",
								"Recognition account  "
										+ input.get("RecognitionAccount1")
										+ " value should be displayed successfully",
								"Recognition account value is not displayed successfully "
										+ ActualRecognitionAcc + "");

					}

					uiDriver.click("edit");
					uiDriver.executeJavaScript("scroll(0,1100);");
					uiDriver.click("amount");// does not work
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.executeJavaScript("document.getElementById('amount_formattedValue').click();");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.executeJavaScript("document.getElementById('amount_formattedValue').value = '"
							+ input.get("amount6") + "'");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("ok");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("dropdown");
					SleepUtils.sleep(TimeSlab.YIELD);
					String MonthCode = uiDriver.getDyanmicData("month");
					String moncode = MonthCode.replace("#",
							input.get("postingperiod"));
					uiDriver.click(moncode);
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("amount1");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.executeJavaScript("document.getElementById('amount_formattedValue').click();");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.executeJavaScript("document.getElementById('amount_formattedValue').value = '"
							+ input.get("amount7") + "'");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("save");
				}

				SleepUtils.sleep(5);
				uiDriver.click("Back1");
				SleepUtils.sleep(5);
				uiDriver.back();
				SleepUtils.sleep(5);
				uiDriver.back();
				SleepUtils.sleep(5);
			}

			else

			{

				//

			}

		}

		SleepUtils.sleep(10);
		uiDriver.back();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.back();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);
		String Revenuenumber = uiDriver.getValue("Revenuenumber");
	    output.put("Revenuenumber", Revenuenumber);
		
		
	}

	/****************************************
	 * Name: AcceptPaymentOnInvoiceScreen
	 * Description: AcceptPaymentOnInvoiceScreen
	 * Date: 30-Nov-2017
	 ****************************************/
	public void AcceptPaymentOnInvoiceScreen(DataRow input, DataRow output) {
		
		uiDriver.back();
		SleepUtils.sleep(TimeSlab.LOW);   
        String invoicenum = uiDriver.getValue("invoicenum");
        SleepUtils.sleep(TimeSlab.LOW);                        
		uiDriver.executeJavaScript("scroll(0,-200)");
		uiDriver.click("AcceptPayment");
		passed("AcceptPayment", "Should be clicked successfully",
				"AcceptPayment button is clicked successfully");
		SleepUtils.sleep(TimeSlab.YIELD);
        String partialpayment = uiDriver.getDyanmicData("partialpaymentfield");
        SleepUtils.sleep(TimeSlab.YIELD);
        String ReferenceVal1 = partialpayment.replace("#", invoicenum);
        SleepUtils.sleep(TimeSlab.YIELD);
        uiDriver.executeJavaScript("scroll(0,500)");
        //uiDriver.click("PaymentAmt");
        //uiDriver.executeJavaScript("document.getElementById('payment_formattedValue').value = ''");
        //SleepUtils.sleep(2);
        
        //uiDriver.setValue("PaymentAmt", input.get("PartialTotalAmt"));
        SleepUtils.sleep(TimeSlab.LOW);
        
       // uiDriver.executeJavaScript("document.getElementById('payment_formattedValue').value = '"+ input.get("PartialTotalAmt") + "'");
        if(uiDriver.checkElementPresent_dynamic(ReferenceVal1)){
       	 
     	   SleepUtils.sleep(10);
     	   uiDriver.click_dynamic(ReferenceVal1);
            uiDriver.click_dynamic(ReferenceVal1);  
       }
        else{
      	   
      	   SleepUtils.sleep(TimeSlab.LOW);
      	   uiDriver.click("FilterNumber");
      	   uiDriver.click("FirstFilteringNumber");
      	   uiDriver.executeJavaScript("scroll(0,800)");
      	   SleepUtils.sleep(TimeSlab.LOW);
      	  if(uiDriver.checkElementPresent_dynamic(ReferenceVal1)){
            
      		uiDriver.click_dynamic(ReferenceVal1);
             uiDriver.click_dynamic(ReferenceVal1); 
      	    SleepUtils.sleep(TimeSlab.MEDIUM);
      	  }
      	  else{
      		  
      	   SleepUtils.sleep(TimeSlab.LOW);
      	  uiDriver.executeJavaScript("scroll(0,-800)");
        	   uiDriver.click("FilterNumber");
        	   uiDriver.click("SecondFilteringNumber");
        	   uiDriver.executeJavaScript("scroll(0,800)");
        	   SleepUtils.sleep(TimeSlab.LOW);
        	  if(uiDriver.checkElementPresent_dynamic(ReferenceVal1)){
              
        		uiDriver.click_dynamic(ReferenceVal1);
               uiDriver.click_dynamic(ReferenceVal1); 
        	    SleepUtils.sleep(TimeSlab.MEDIUM);
        	    
        	  }
        	  else{
        		  
        		 SleepUtils.sleep(TimeSlab.LOW);
        		 uiDriver.executeJavaScript("scroll(0,-800)");
          	   uiDriver.click("FilterNumber");
          	   uiDriver.click("ThirdFilteringNumber");
          	   uiDriver.executeJavaScript("scroll(0,800)");
          	   SleepUtils.sleep(TimeSlab.LOW);
          	  if(uiDriver.checkElementPresent_dynamic(ReferenceVal1)){
                
          		uiDriver.click_dynamic(ReferenceVal1);
                 uiDriver.click_dynamic(ReferenceVal1); 
          	    SleepUtils.sleep(TimeSlab.MEDIUM);
          	    
          	  }
        	  }
      		  
      	  }
      	   
         }
        
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.executeJavaScript("scroll(0,-800)");
		uiDriver.click("acctradiobutton");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("Account", "11015051 USL Cash Clearing");
		 SleepUtils.sleep(TimeSlab.YIELD);
		 uiDriver.setValue("ContractorName", "");
		 SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("SaveInvoice");
		passed("SaveInvoice", "Invoice Should be Saved successfully",
				"Invoice is Saved successfully");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.mouseOver("action");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("Glimpact");
		int invoiceRow = 2;
		int accRows = uiDriver.webDr.findElements(By.xpath("//form[contains(@id,'body_actions')]//table[contains(@id,'div__body')]/tbody/tr[contains(@class,'row')]")).size();

		for (i = 0; i < accRows - 1; i++) {

			if (uiDriver.getValue("//form[contains(@id,'body_actions')]//tbody/tr["+ invoiceRow + "]/td[1]").contains("Undeposited")) {

				if (uiDriver.getValue(
						"//form[contains(@id,'body_actions')]//tbody/tr["
								+ invoiceRow + "]/td[2]").equals(""))

				{

					failed("Validating Debit Amount",

					"Validating Debit Amount should be successfull",

					"Debit amount is not Deferred Rev - Generic");
				}

				else

				{

					passed("Debit is Deferred Rev - Generic",

					"Debit is Deferred Rev - Generic",

					"Debit amount is Undeposited Funds");
				}

			}
			if (uiDriver.getValue("//form[contains(@id,'body_actions')]//tbody/tr["	+ (invoiceRow + 1) + "]/td[1]").contains("Generic Billed AR")) {

				if (uiDriver.getValue("//form[contains(@id,'body_actions')]//tbody/tr["+ (invoiceRow + 1) + "]/td[3]").equals("")) {
					failed("Validating Credit Amount",

					"Validating Credit Amount should be successfull",

					"Credit amount is not Generic billed AR");

				} else

				{

					passed("Credit is generic billed AR",

					"Credit is generic billed AR",

					"Credit amount is Generic billed AR");

				}

			}

			invoiceRow++;

		}

	}

	/****************************************
	 * Name: editRevPlan 
	 * Description: editRevPlan 
	 * Date: 30-Nov-2017
	 ****************************************/

	public void editRevPlan(DataRow input, DataRow output)
			throws ParseException {
		uiDriver.click("editbtn");
		SleepUtils.sleep(TimeSlab.YIELD);

		uiDriver.click("allocationcheckbx");
		uiDriver.click("saveBtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("UpdateRevPlanBtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("submissionIDHeader");
		// uiDriver.click("completeBtn");
		// refressh
		Date date = new Date();
		DateFormat dateFormat = new SimpleDateFormat("h:mm");
		String strDate = dateFormat.format(date);
		Date d = dateFormat.parse(strDate);
		Calendar cal = Calendar.getInstance();
		cal.setTime(d);
		cal.add(Calendar.MINUTE, 0);
		String newTime = dateFormat.format(cal.getTime());
		String Complete = uiDriver.getDyanmicData("CompleteStatus1");
		String CompleteStaus = Complete.replace("#", newTime);
		cal.add(Calendar.MINUTE, 0);
		String newTime2 = dateFormat.format(cal.getTime());
		String Complete2 = uiDriver.getDyanmicData("CompleteStatus2");
		String CompleteStaus2 = Complete2.replace("#", newTime2);
		cal.add(Calendar.MINUTE, 1);
		String newTime3 = dateFormat.format(cal.getTime());
		String Complete3 = uiDriver.getDyanmicData("CompleteStatus3");
		String CompleteStaus3 = Complete3.replace("#", newTime3);
		if (uiDriver.checkElementPresent_dynamic(CompleteStaus)) {
			uiDriver.click_dynamic(CompleteStaus);
		} else {
			// do nothing
		}

		if (uiDriver.checkElementPresent_dynamic(CompleteStaus2)) {
			uiDriver.click_dynamic(CompleteStaus2);
		} else {
			// do nothing
		}
		if (uiDriver.checkElementPresent_dynamic(CompleteStaus3)) {
			uiDriver.click_dynamic(CompleteStaus3);
		} else {
			// do nothing
		}

		passed("Verify Processed Reclassification Journal entries",
				"Processed Reclassification Journal entries page should be displayed",
				"Processed Reclassification Journal entries page is displayed");
		int size = 4;
		for (int r = 0; r < size; r++) {
			String s1 = uiDriver.getDyanmicData("RevenuePlanNumber1");
			String s2 = s1.replace("#", Integer.toString(r));
			if (uiDriver.checkElementPresent_dynamic(s2)) {
				uiDriver.click_dynamic(s2);
				passed("Click On the Revenue Paln Number " + s2 + "",
						"Should be SuccessFully Clicked on Revenue Paln Number "
								+ s2 + "",
						"SuccessFully Clicked on Revenue Paln Number " + s2
								+ "");
				passed("Verify the Revenue Paln Number",
						"Revenue Recognition Plan Page Should be displayed",
						"Revenue Recognition Plan Page is displayed");

				uiDriver.executeJavaScript("scroll(0,300)");
				uiDriver.click("edit1");
				SleepUtils.sleep(TimeSlab.YIELD);
				// uiDriver.click("postperiod");
				uiDriver.setValue("amt", input.get("Amount"));
				uiDriver.click("OK");
				uiDriver.setValue("postperiod", input.get("Posting Period"));
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.setValue("amt", input.get("Amount"));
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.click("Save");

				String ActualdeferralAccnt = uiDriver.getValue(
						"DeferralAccountRevPlan").trim();
				String ActualRecognitionAcc = uiDriver.getValue(
						"RecognitionAccountRevPlan").trim();
				if (r == 0) {
					if (input.get("deferralAccount").contains(
							ActualdeferralAccnt)) {

						passed("Verifying the deferral account",
								"deferral account  "
										+ input.get("deferralAccount")
										+ "   value should be displayed successfully",
								"deferral account value is displayed successfully"
										+ ActualdeferralAccnt + "");
					} else {
						failed("Verifying the deferral account",
								"deferral account   "
										+ input.get("deferralAccount")
										+ "   value should be displayed successfully",
								"deferral account value is not displayed successfully "
										+ ActualdeferralAccnt + "");
					}

					if (input.get("RecognitionAccount").contains(
							ActualRecognitionAcc)) {

						passed("Verifying the Recognition account",
								"Recognition account  "
										+ input.get("RecognitionAccount")
										+ "   value should be displayed successfully",
								"Recognition account value is displayed successfully"
										+ ActualRecognitionAcc + "");
					} else {
						failed("Verifying the Recognition account",
								"Recognition account  "
										+ input.get("RecognitionAccount")
										+ " value should be displayed successfully",
								"Recognition account value is not displayed successfully "
										+ ActualRecognitionAcc + "");
					}

				} else if (r == 1) {
					if (input.get("deferralAccount1").contains(
							ActualdeferralAccnt)) {
						passed("Verifying the deferral account",
								"deferral account  "
										+ input.get("deferralAccount1")
										+ "   value should be displayed successfully",
								"deferral account value is displayed successfully"
										+ ActualdeferralAccnt + "");
					} else {
						failed("Verifying the deferral account",
								"deferral account   "
										+ input.get("deferralAccount1")
										+ "   value should be displayed successfully",
								"deferral account value is not displayed successfully "
										+ ActualdeferralAccnt + "");
					}

					if (input.get("RecognitionAccount1").contains(
							ActualRecognitionAcc)) {

						passed("Verifying the Recognition account",
								"Recognition account  "
										+ input.get("RecognitionAccount1")
										+ "   value should be displayed successfully",
								"Recognition account value is displayed successfully"
										+ ActualRecognitionAcc + "");
					} else {
						failed("Verifying the Recognition account",
								"Recognition account  "
										+ input.get("RecognitionAccount1")
										+ " value should be displayed successfully",
								"Recognition account value is not displayed successfully "
										+ ActualRecognitionAcc + "");
					}

				} else if (r == 2) {
					if (input.get("deferralAccount2").contains(
							ActualdeferralAccnt)) {
						passed("Verifying the deferral account",
								"deferral account  "
										+ input.get("deferralAccount2")
										+ "   value should be displayed successfully",
								"deferral account value is displayed successfully"
										+ ActualdeferralAccnt + "");
					} else {
						failed("Verifying the deferral account",
								"deferral account   "
										+ input.get("deferralAccount2")
										+ "   value should be displayed successfully",
								"deferral account value is not displayed successfully "
										+ ActualdeferralAccnt + "");
					}

					if (input.get("RecognitionAccount2").contains(
							ActualRecognitionAcc)) {

						passed("Verifying the Recognition account",
								"Recognition account  "
										+ input.get("RecognitionAccount2")
										+ "   value should be displayed successfully",
								"Recognition account value is displayed successfully"
										+ ActualRecognitionAcc + "");
					} else {
						failed("Verifying the Recognition account",
								"Recognition account  "
										+ input.get("RecognitionAccount2")
										+ " value should be displayed successfully",
								"Recognition account value is not displayed successfully "
										+ ActualRecognitionAcc + "");
					}

				} else if (r == 3) {
					if (input.get("deferralAccount3").contains(
							ActualdeferralAccnt)) {
						passed("Verifying the deferral account",
								"deferral account  "
										+ input.get("deferralAccount3")
										+ "   value should be displayed successfully",
								"deferral account value is displayed successfully"
										+ ActualdeferralAccnt + "");
					} else {
						failed("Verifying the deferral account",
								"deferral account   "
										+ input.get("deferralAccount3")
										+ "   value should be displayed successfully",
								"deferral account value is not displayed successfully "
										+ ActualdeferralAccnt + "");
					}

					if (input.get("RecognitionAccount3").contains(
							ActualRecognitionAcc)) {

						passed("Verifying the Recognition account",
								"Recognition account  "
										+ input.get("RecognitionAccount1")
										+ "   value should be displayed successfully",
								"Recognition account value is displayed successfully"
										+ ActualRecognitionAcc + "");
					} else {
						failed("Verifying the Recognition account",
								"Recognition account  "
										+ input.get("RecognitionAccount1")
										+ " value should be displayed successfully",
								"Recognition account value is not displayed successfully "
										+ ActualRecognitionAcc + "");
					}

				}
				SleepUtils.sleep(5);
				uiDriver.click("Back1");
				SleepUtils.sleep(5);

			} else {
				//
			}

		}

		SleepUtils.sleep(10);
		uiDriver.back();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.back();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);

	}

	/****************************************
	 * Name: partialRevenue1 
	 * Description: partialRevenue1 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void partialRevenue1(DataRow input, DataRow output) {
		SleepUtils.sleep(10);
		// add view plan step here
		uiDriver.click("viewRevplanBtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		// validation pendlin
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setFrame("IframeWindow");

		uiDriver.setValue("Action", input.get("Action"));
		int size = 5;
		for (int r = 0; r < size; r++) {
			String s1 = uiDriver.getDyanmicData("RevenuePlanNumber");
			String s2 = s1.replace("#", Integer.toString(r));
			if (uiDriver.checkElementPresent_dynamic(s2)) {
				uiDriver.click_dynamic(s2);
				SleepUtils.sleep(TimeSlab.YIELD);

				uiDriver.executeJavaScript("scroll(0,300)");
				String ActualdeferralAccnt = uiDriver
						.getValue("DeferralAccountRevPlan");
				String ActualdeferralAccount = ActualdeferralAccnt.trim();
				String ActualRecognitionAcc = uiDriver
						.getValue("RecognitionAccountRevPlan");
				String ActualRecognitionAccount = ActualRecognitionAcc.trim();

				if (r == 0) {
					if (input.get("deferralAccount").contains(
							ActualdeferralAccount)) {

						passed("Verifying the deferral account",
								"deferral account  "
										+ input.get("deferralAccount")
										+ "   value should be displayed successfully",
								"deferral account value is displayed successfully"
										+ ActualdeferralAccnt + "");
					} else {
						failed("Verifying the deferral account",
								"deferral account   "
										+ input.get("deferralAccount")
										+ "   value should be displayed successfully",
								"deferral account value is not displayed successfully "
										+ ActualdeferralAccnt + "");
					}

					if (input.get("RecognitionAccount").contains(
							ActualRecognitionAccount)) {

						passed("Verifying the Recognition account",
								"Recognition account  "
										+ input.get("RecognitionAccount")
										+ "   value should be displayed successfully",
								"Recognition account value is displayed successfully"
										+ ActualRecognitionAcc + "");
					} else {
						failed("Verifying the Recognition account",
								"Recognition account  "
										+ input.get("RecognitionAccount")
										+ " value should be displayed successfully",
								"Recognition account value is not displayed successfully "
										+ ActualRecognitionAcc + "");
					}

					uiDriver.click("edit");
					uiDriver.executeJavaScript("scroll(0,1100);");
					// uiDriver.executeJavaScript("document.getElementById('amount_formattedValue').click();");
					uiDriver.click("amount");// does not work
					// uiDriver.executeJavaScript("document.getElementById('amount_formattedValue').click();");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.executeJavaScript("document.getElementById('amount_formattedValue').value = '"
							+ input.get("amount") + "'");
					// uiDriver.setValue("amount", input.get("amount"));
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.click("ok");
					SleepUtils.sleep(TimeSlab.YIELD);

					// uiDriver.click("postingPeriod");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.executeJavaScript("document.getElementById('inpt_plannedperiod3').value = '"
							+ input.get("postingperiod") + "'");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.sendKey("enter");
					// uiDriver.setValue("postingPeriod",
					// input.get("postingperiod"));
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.executeJavaScript("document.getElementById('amount_formattedValue').click();");
					// uiDriver.click("amount1");
					SleepUtils.sleep(TimeSlab.YIELD);
					uiDriver.executeJavaScript("document.getElementById('amount_formattedValue').value = '"
							+ input.get("amount1") + "'");
					// uiDriver.setValue("amount1", input.get("amount1"));
					uiDriver.click("addButton");
					SleepUtils.sleep(TimeSlab.YIELD);

					uiDriver.click("save");
				}
				/*
				 * uiDriver.setValue("postingPeriod",
				 * input.get("postingperiod1"));
				 * SleepUtils.sleep(TimeSlab.YIELD); uiDriver.click("amount");
				 * SleepUtils.sleep(TimeSlab.YIELD); uiDriver.click("ok");
				 * uiDriver.setValue("amount", input.get("amount1"));
				 * uiDriver.click("addButton");
				 * SleepUtils.sleep(TimeSlab.YIELD);
				 * uiDriver.setValue("postingPeriod",
				 * input.get("postingperiod2"));
				 * SleepUtils.sleep(TimeSlab.YIELD); uiDriver.setValue("amount",
				 * input.get("amount2")); uiDriver.click("save");
				 */

				else if (r == 1) {
					if (input.get("deferralAccount1").contains(
							ActualdeferralAccount)) {
						passed("Verifying the deferral account",
								"deferral account  "
										+ input.get("deferralAccount1")
										+ "   value should be displayed successfully",
								"deferral account value is displayed successfully"
										+ ActualdeferralAccnt + "");
					} else {
						failed("Verifying the deferral account",
								"deferral account   "
										+ input.get("deferralAccount1")
										+ "   value should be displayed successfully",
								"deferral account value is not displayed successfully "
										+ ActualdeferralAccnt + "");
					}

					if (input.get("RecognitionAccount1").contains(
							ActualRecognitionAccount)) {

						passed("Verifying the Recognition account",
								"Recognition account  "
										+ input.get("RecognitionAccount1")
										+ "   value should be displayed successfully",
								"Recognition account value is displayed successfully"
										+ ActualRecognitionAcc + "");
					} else {
						failed("Verifying the Recognition account",
								"Recognition account  "
										+ input.get("RecognitionAccount1")
										+ " value should be displayed successfully",
								"Recognition account value is not displayed successfully "
										+ ActualRecognitionAcc + "");
					}
				} else if (r == 2) {
					if (input.get("deferralAccount2").contains(
							ActualdeferralAccount)) {
						passed("Verifying the deferral account",
								"deferral account  "
										+ input.get("deferralAccount2")
										+ "   value should be displayed successfully",
								"deferral account value is displayed successfully"
										+ ActualdeferralAccnt + "");
					} else {
						failed("Verifying the deferral account",
								"deferral account   "
										+ input.get("deferralAccount2")
										+ "   value should be displayed successfully",
								"deferral account value is not displayed successfully "
										+ ActualdeferralAccnt + "");
					}

					if (input.get("RecognitionAccount2").contains(
							ActualRecognitionAccount)) {

						passed("Verifying the Recognition account",
								"Recognition account  "
										+ input.get("RecognitionAccount2")
										+ "   value should be displayed successfully",
								"Recognition account value is displayed successfully"
										+ ActualRecognitionAcc + "");
					} else {
						failed("Verifying the Recognition account",
								"Recognition account  "
										+ input.get("RecognitionAccount2")
										+ " value should be displayed successfully",
								"Recognition account value is not displayed successfully "
										+ ActualRecognitionAcc + "");
					}
				} else if (r == 3) {
					if (input.get("deferralAccount3").contains(
							ActualdeferralAccount)) {
						passed("Verifying the deferral account",
								"deferral account  "
										+ input.get("deferralAccount3")
										+ "   value should be displayed successfully",
								"deferral account value is displayed successfully"
										+ ActualdeferralAccnt + "");
					} else {
						failed("Verifying the deferral account",
								"deferral account   "
										+ input.get("deferralAccount3")
										+ "   value should be displayed successfully",
								"deferral account value is not displayed successfully "
										+ ActualdeferralAccnt + "");
					}

					if (input.get("RecognitionAccount3").contains(
							ActualRecognitionAccount)) {

						passed("Verifying the Recognition account",
								"Recognition account  "
										+ input.get("RecognitionAccount3")
										+ "   value should be displayed successfully",
								"Recognition account value is displayed successfully"
										+ ActualRecognitionAcc + "");
					} else {
						failed("Verifying the Recognition account",
								"Recognition account  "
										+ input.get("RecognitionAccount3")
										+ " value should be displayed successfully",
								"Recognition account value is not displayed successfully "
										+ ActualRecognitionAcc + "");
					}
				}

				uiDriver.click("Back");
			}
		}
		uiDriver.handleAlert("", "STAY");
		SleepUtils.sleep(TimeSlab.YIELD);
		if (uiDriver.checkElementPresent("cancelbtn")) {
			passed("Check for cancel button", "Click on Cancel Button",
					" successfully clicked on  cancel button");

		} else {
			failed("Check for cancel button", "Click on Cancel Button",
					" failed to click on  cancel button");
		}

		uiDriver.click("cancelbtn");
		uiDriver.resetFrame();

	}

	/****************************************
	 * Name: VerifyReclassificationJournalEntriesAfterBill 
	 * Description: VerifyReclassificationJournalEntriesAfterBill 
	 * Date: 30-Nov-2017
	 ****************************************/

	public void VerifyReclassificationJournalEntriesAfterBill(DataRow input,
			DataRow output) {
		uiDriver.executeJavaScript("scroll(0,500)");
		int invoiceRow = 2;
		int accRows = uiDriver.webDr.findElements(By.xpath("//*[@id='line_splits']/tbody/tr")).size();
		for (i = 0; i < accRows - 1; i++) {

			if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains(	"Deferred Rev - Unpaid"))

			{
				String debitvalue = uiDriver.getDyanmicData("UnpaidAMount");
				String debvalue = debitvalue.replace("#",
						Integer.toString(invoiceRow));
				String DebitAmount = uiDriver.getValue(debvalue);

				if (uiDriver.getValue(
						"//*[@id='line_splits']/tbody/tr[" + invoiceRow
								+ "]/td[2]").equals("")) {
					failed("Verify the Debit Amount",
							"Credit Amount should be displayed as '"
									+ DebitAmount + "'",
							"Credit Amount is not displayed as '" + DebitAmount
									+ "' ");
				} else {
					passed("Verify the Debit Amount",
							"Credit Amount should be displayed as '"
									+ DebitAmount + "'",
							"Credit Amount is displayed as '" + DebitAmount
									+ "' ");
				}
			}
			if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Unbilled Dom"))

			{
				String creditvalue = uiDriver.getDyanmicData("UnBilledAMount");
				String credvalue = creditvalue.replace("#",
						Integer.toString(invoiceRow));
				String CreditAmount = uiDriver.getValue(credvalue);
				// String DebitAmount = uiDriver.getValue("UnBilledAMount");
				if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals("")) {
					failed("Verify the Debit Amount",
							"Debit Amount should be displayed as '"
									+ CreditAmount + "'",
							"Debit Amount is not displayed as '" + CreditAmount
									+ "' ");
				} else {
					passed("Verify the Debit Amount",
							"Debit Amount should be displayed as '"
									+ CreditAmount + "'",
							"Debit Amount is displayed as '" + CreditAmount
									+ "' ");
				}
			}

			invoiceRow++;
		}
	}

	/****************************************
	 * Name: verifyAcceptPayment
	 * Description: verifyAcceptPayment 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void verifyAcceptPayment(DataRow input, DataRow output)
			throws InterruptedException {
		int invoiceRow = 2;
		int accRows = uiDriver.webDr.findElements(By.xpath("//form[contains(@id,'body_actions')]//table[contains(@id,'div__body')]/tbody/tr[contains(@class,'row')]")).size();
		for (i = 0; i < accRows - 1; i++) {

			if (uiDriver.getValue("//form[contains(@id,'body_actions')]//tbody/tr["	+ invoiceRow + "]/td[1]").contains("Undeposited"))

			{
				if (uiDriver.getValue("//form[contains(@id,'body_actions')]//tbody/tr["	+ invoiceRow + "]/td[2]").equals("")) {
					failed("Validating Debit Amount",
							"Validating Debit Amount should be successfull",
							"Debit amount is not Deferred Rev - Generic");
				} else {
					passed("Debit is Deferred Rev - Generic",
							"Debit is Deferred Rev - Generic",
							"Debit amount is Undeposited Funds");
				}
			}
			if (uiDriver.getValue("//form[contains(@id,'body_actions')]//tbody/tr["	+ (invoiceRow + 1) + "]/td[1]").contains("Generic Billed AR"))

			{
				if (uiDriver.getValue("//form[contains(@id,'body_actions')]//tbody/tr["+ (invoiceRow + 1) + "]/td[3]").equals("")) {
					failed("Validating Credit Amount",
							"Validating Credit Amount should be successfull",
							"Credit amount is not Generic billed AR");
				} else {
					passed("Credit is generic billed AR",
							"Credit is generic billed AR",
							"Credit amount is Generic billed AR");
				}
			}

			invoiceRow++;
		}

	}
	
	/****************************************
	 * Name: writeoffInvoiceAmount
	 * Description: verifyAcceptPayment 
	 * Date: 30-Nov-2017
	 ****************************************/
	public void writeoffInvoiceAmount(DataRow input, DataRow output)
			throws InterruptedException {
		SleepUtils.sleep(TimeSlab.HIGH);
//		String Num = input.get("conf");
//		uiDriver.setValue("SearchSO", Num);
//		SleepUtils.sleep(TimeSlab.MEDIUM);
//		uiDriver.click("SalesOrder");
//		SleepUtils.sleep(5);
//		uiDriver.refresh();
//		uiDriver.executeJavaScript("scroll(0,500)");
//		uiDriver.click("relatedRecord");
//		SleepUtils.sleep(TimeSlab.LOW);
//		uiDriver.click("invoiceNo");
//		SleepUtils.sleep(TimeSlab.LOW);

		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("writeOffRemainingAmount");
		// write code to click on write off button
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.click("reclassJEntry");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("writeOffBadDebt");
		uiDriver.executeJavaScript("scroll(0,500)");
		int invoiceRow = 2;
		int transRows = uiDriver.webDr.findElements(By.xpath("//*[@id='line_splits']//tbody/tr")).size();
		for (i = 0; i < transRows - 1; i++) {
			uiDriver.executeJavaScript("scroll(0,500);");
			if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Write Off Bad Debt")) {
				if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[2]").equals("")) {
					failed("Write Off Bad Debt",
							"Validating Debit Amount should be successfull",
							"Debit amount is not Write Off Bad Debt Receivable");
				} else {
					passed("Debit is Write Off Bad Debt Receivable",
							"Debit is Write Off Bad Debt Receivable",
							"Debit amount is Write Off Bad Debt Receivable");
				}
			}
			if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Generic Billed AR")) {
				if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals("")) {
					failed("Validating CREDIT Amount",
							"Validating CREDIT Amount should be successfull",
							"CREDIT amount is not Generic Billed AR");
				} else {
					passed("CREDIT is Generic Billed AR",
							"CREDIT is Generic Billed AR",
							"CREDIT amount is Generic Billed AR");
				}
			}
			if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[1]").contains("Billed Dom")) {
				if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow+ "]/td[3]").equals("")) {
					failed("Validating CREDIT Amount",
							"Validating CREDIT Amount should be successfull",
							"CREDIT amount is not Billed Dom");
				} else {
					passed("CREDIT is Billed Dom", "CREDIT is Billed Dom",
							"CREDIT amount is Billed Dom");
				}
			} else {
			}
			invoiceRow++;

		}

		/*uiDriver.click("Back1");
		SleepUtils.sleep(5);
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("reclassJEntry");
		uiDriver.click("BadDebt");
		int invoiceRow1 = 2;
		int transRows1 = uiDriver.webDr.findElements(By.xpath("//*[@id='line_splits']//tbody/tr")).size();
		for (i = 0; i < transRows - 1; i++) {
			uiDriver.executeJavaScript("scroll(0,500);");
			if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow1+ "]/td[1]").contains("Bad Debt Revenue")) {
				if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow1+ "]/td[3]").equals("")) {
					failed("Validating Credit Amount",
							"Validating Credit Amount should be successfull",
							"Debit amount is not Bad Debt Revenue");
				} else {
					passed("Credit is Bad Debt Revenue",
							"Credit is Bad Debt Revenue",
							"Credit is Bad Debt Revenue");
				}
			}
			if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow1+ "]/td[1]").contains("Contract revenue")) {
				if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow1+ "]/td[2]").equals("")) {
					failed("Validating Debit Amount",
							"Validating Debit Amount should be successfull",
							"Debit amount is not Contract revenue-DOM");
				} else {
					passed("Debit amount is not Contract revenue-DOM",
							"Debit amount is  Contract revenue-DOM",
							"Debit amount is  Contract revenue-DOM");
				}
			}

			if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow1+ "]/td[1]").contains("Generic Bad Debt Revenue")) {
				if (uiDriver.getValue("//*[@id='line_splits']/tbody/tr[" + invoiceRow1+ "]/td[3]").equals("")) {
					failed("Validating Debit Amount",
							"Validating Debit Amount should be successfull",
							"Debit amount is not Generic Bad Debt Revenue");
				} else {
					passed("Debit amount is not Generic Bad Debt Revenue",
							"Debit amount is Generic Bad Debt Revenue",
							"Debit amount is Generic Bad Debt Revenue");
				}
			}

			invoiceRow1++;

		}*/

	}
	
	

	/****************************************
	 * Name: ChangeRoleToManager2
	 * Description: Changing the role from administrator to Manager2
	 * Date: 30-Nov-2017
	 ****************************************/
	public void ChangeRoleToManager2(DataRow input, DataRow output)
	{
		SleepUtils.sleep(8);
		uiDriver.mouseOver("Profile");
		SleepUtils.sleep(5);
		uiDriver.click("ManagerRole2");
		SleepUtils.sleep(5);
		if(uiDriver.checkElementPresent("Manager2")){
		uiDriver.click("Manager2");
			passed("Verify Changing the role from administrator to Manager2",
				"Administrator Role to Manager2 Role must be changed Successfully",
				"Administrator Role to Manager2 Role is changed Successfully");
		}	
			
	}
	
	
	/****************************************
	 * Name: ChangeRoleToManager2
	 * Description: Changing the role from administrator to Manager2
	 * Date: 30-Nov-2017
	 ****************************************/
	public void ChangeRoleToManager210K(DataRow input, DataRow output)
	{
		SleepUtils.sleep(8);
		uiDriver.mouseOver("Profile");
		SleepUtils.sleep(5);
		uiDriver.click("ManagerRole2");
		SleepUtils.sleep(5);
		if(uiDriver.checkElementPresent("Manager2")){
		//uiDriver.click("Manager2");
			passed("Verify Changing the role from administrator to Manager2",
				"Administrator Role to Manager2 Role must be changed Successfully",
				"Administrator Role to Manager2 Role is changed Successfully");
		}	
			
	}
	
	/****************************************
	 * Name: ChangeRoleToManager
	 * Description: Changing the role from administrator to Manager
	 * Date: 30-Nov-2017
	 ****************************************/
	public void ChangeRoleToManager(DataRow input, DataRow output)
	{
		SleepUtils.sleep(10);
		uiDriver.mouseOver("Profile");
		SleepUtils.sleep(5);
		uiDriver.click("ManagerRole");
		SleepUtils.sleep(5);
		if(uiDriver.checkElementPresent("Manager1")){
		uiDriver.click("Manager1");
				passed("Verify Changing the role from administrator to Manager",
				"Administrator Role to Manager Role must be changed Successfully",
				"Administrator Role to Manager Role is changed Successfully");
		SleepUtils.sleep(5);
		}
	}	

	
	/****************************************
	 * Name: WriteoffInvoiceAmountByManager
	 * Description: WriteoffInvoiceAmountByManager
	 * Date: 30-Nov-2017
	 ****************************************/
	public void WriteoffInvoiceAmountByManager(DataRow input, DataRow output){
		
//			SleepUtils.sleep(TimeSlab.MEDIUM);
//			String Num = input.get("conf");
//			uiDriver.setValue("SearchSO", Num);
//			SleepUtils.sleep(TimeSlab.MEDIUM);
//		    uiDriver.click("SalesOrder");
//			SleepUtils.sleep(5);
//			uiDriver.refresh();
//			uiDriver.executeJavaScript("scroll(0,500)");
//			uiDriver.click("relatedRecord");
//			SleepUtils.sleep(TimeSlab.LOW);
//			uiDriver.click("invoiceNo");
			SleepUtils.sleep(TimeSlab.LOW);
			for(int i=0; i<10; i++) {	
				SleepUtils.sleep(TimeSlab.YIELD);
				uiDriver.ScrollPageUp();
				SleepUtils.sleep(TimeSlab.YIELD);
			}
			passed("WriteoffInvoiceAmountByManager", "Before WriteoffInvoiceAmountByManager", 
					"Before WriteoffInvoiceAmountByManager");
			SleepUtils.sleep(TimeSlab.LOW);
			uiDriver.click("writeOffRemainingAmount");
			SleepUtils.sleep(TimeSlab.MEDIUM);
			uiDriver.handleAlert("", "ok");
            //uiDriver.click("goback");
 	        SleepUtils.sleep(TimeSlab.LOW);
 	       passed("WriteoffInvoiceAmountByManager", "After WriteoffInvoiceAmountByManager", 
					"After WriteoffInvoiceAmountByManager");
		}
			
	
	
		
	/****************************************
	 * Name: ChangeRoleToAdministrator
	 * Description: Changing the role from Manager to Administrator
	 * Date: 30-Nov-2017
	 ****************************************/
	public void ChangeRoleToAdministrator(DataRow input, DataRow output)
	{
		uiDriver.mouseOverAndClick("Profile", "AdministratorRole");
		uiDriver.click("Administrator");
		passed("Verify Changing the role from Manager to administrator",
				"Manager Role to Administrator Role must be changed Successfully",
				"Manager Role to Administrator Role is changed Successfully");
		SleepUtils.sleep(5);
			
	}
	
	/****************************************
	 * Name: ChangeRoleToManager10K
	 * Description: Changing the role from administrator to Manager
	 * Date: 30-Nov-2017
	 ****************************************/
	public void ChangeRoleToManager10K(DataRow input, DataRow output)
	{
		SleepUtils.sleep(1);
		uiDriver.mouseOver("Profile");
		SleepUtils.sleep(5);
		uiDriver.click("//span[contains(text(),'NBCUniversal Media, LLC 10KQA  -  NBCU: Manager 1')]");
		SleepUtils.sleep(5);
		if(uiDriver.checkElementPresent("//span[contains(text(),'NBCU: Manager 1')]//..//span[contains(text(),'NBCUniversal Media, LLC 10KQA')]")){
		//uiDriver.click("Manager1");
				passed("Verify Changing the role from administrator to Manager",
				"Administrator Role to Manager Role must be changed Successfully",
				"Administrator Role to Manager Role is changed Successfully");
		SleepUtils.sleep(5);
		}
	}	
	
	/****************************************
	 * Name: ChangeRoleToManager10K
	 * Description: Changing the role from administrator to Manager
	 * Date: 30-Nov-2017
	 ****************************************/
	public void ChangeRoleToQA10K(DataRow input, DataRow output)
    {
          SleepUtils.sleep(1);
          uiDriver.mouseOver("//*[@id='spn_cRR_d1']/a/div[2]/span[1]");
          SleepUtils.sleep(5);
          uiDriver.click("//span[contains(text(),'NBCUniversal Media, LLC 10k QA  -  NBCU: QA')]");
          SleepUtils.sleep(5);
          if(uiDriver.checkElementPresent("//span[contains(text(),'NBCUniversal Media, LLC 10k QA  -  NBCU: QA')]")){
          //uiDriver.click("Manager1");
                      passed("Verify Changing the role to QA",
                      "QA Role must be changed Successfully",
                      "QA Role is changed Successfully");
          SleepUtils.sleep(5);
          }
    }

	/****************************************
	 * Name: ChangeRoleToAdministrator10K
	 * Description: Changing the role from  Manager to administrator
	 * Date: 30-Nov-2017
	 ****************************************/
	public void ChangeRoleToAdministrator10K(DataRow input, DataRow output)
	{
		SleepUtils.sleep(10);
		uiDriver.mouseOver("Profile");
		SleepUtils.sleep(5);
		uiDriver.click("Admin");
		SleepUtils.sleep(5);
		if(uiDriver.checkElementPresent("Admintab")){
		//uiDriver.click("Manager1");
				passed("Verify Changing the role from  Manager to administrator",
				" Manager Role to Administrator Role must be changed Successfully",
				"Manager Role to Administrator Role is changed Successfully");
		SleepUtils.sleep(5);
		}
	}	
	
	/****************************************
* Name: EnablePayship
	 * Description: EnablePayship
	 * Date: 25-Jun-2018
	 ****************************************/
	public void EnablePayship(DataRow input, DataRow output)
	{
		
		uiDriver.click("Payship");
		passed("Payship Enabled",
				"Payship Enabled Successfully",
				"Payship Enabled Successfully");
		SleepUtils.sleep(5);
			
	}	 

/* Name: ApproveWriteOffByManager2 
	 * Description:Method to validate Debit and Credit Amount
	 * Date: 30-Nov-2017
	 ****************************************/
	public void ApproveWriteOffByManager2(DataRow input, DataRow output)
			throws InterruptedException {
		SleepUtils.sleep(TimeSlab.HIGH);
		uiDriver.ScrollPageUp();
		uiDriver.ScrollPageUp();
//		String Num = input.get("conf");
//		uiDriver.setValue("SearchSO", Num);
//		SleepUtils.sleep(TimeSlab.MEDIUM);
//		uiDriver.click("SalesOrder");
//		passed("SalesOrder", "SalesOrder Should be displayed Successfully",
//				"SalesOrder is displayed Successfully");
//		SleepUtils.sleep(5);
//		uiDriver.refresh();
//		uiDriver.executeJavaScript("scroll(0,500)");
//		uiDriver.click("relatedRecord");
//		SleepUtils.sleep(TimeSlab.LOW);
//		uiDriver.click("invoiceNo");
		passed("ApproveWriteOffByManager2", "Before ApproveWriteOffByManager2", 
				"Before ApproveWriteOffByManager2");
		uiDriver.click("ApproveWriteOff");
		passed("Approve WriteOff",
				"Approve WriteOff Button Should be Clicked Successfully",
				"Approve WriteOff Button is Clicked Successfully");
		SleepUtils.sleep(10);
		
	}	
	
	
	
	/****************************************
	 * Name: initializeRow 
	 * Description:Method to validate Debit and Credit Amount
	 * Date: 30-Nov-2017
	 ****************************************/
	
	public void initializeRow(DataRow input, DataRow output)
	{
		nextRow=2;
		firstRow=2;
		ItemCol =2;
		revenueRow=2;
		i=2;
	}
	
	
	/****************************************
	 * Name: updateFTKey 
	 * Description:Method to validate Debit and Credit Amount
	 * Date: 30-Nov-2017
	 ****************************************/
	
	public void updateFTKey(DataRow input, DataRow output) throws InterruptedException {

	       uiDriver.executeJavaScript("scroll(0,-1000)");
           uiDriver.click("edit");
           SleepUtils.sleep(TimeSlab.MEDIUM);
           uiDriver.executeJavaScript("scroll(1000,2000)");
           int FTRows = uiDriver.webDr.findElements(By.xpath("//*[@id='item_splits']/tbody/tr[contains(@id,'item_row')]")).size();
           Random rdm=new Random();
           for(int i=1;i<=FTRows;i++)
          {
                String updateFT = uiDriver.getDyanmicData("updateFTKey");
                String updateFTkey = updateFT.replace("#", Integer.toString(i));
                String ele1 = "//*[@id=\"item_row_1\"]/td[62]";
                WebElement ele2 = uiDriver.webDr.findElement(By.xpath(ele1));

                Actions action=new Actions(uiDriver.webDr);
                action.moveToElement(ele2).build().perform();
                
                uiDriver.executeJavaScript("scroll(0,-200)");
                uiDriver.click_dynamic(updateFTkey);
                //uiDriver.click("editFTkey");
               int key1=rdm.nextInt(100000);
               uiDriver.setValue("editFTkey", Integer.toString(key1));
          }
               uiDriver.click("Save");
   }
	/****************************************
     * Name: ReadSO
      * Description:Method to read the sales order
     * Date: 10-May-2018
     ****************************************/
     public void ReadSalesOrder(DataRow input, DataRow output) {
            String SONum = uiDriver.getValue("SONumber");
            output.put("SalesOrderNum", SONum);
            passed("Read the Sales order",
                        "Sales order is displayed as '" + SONum+ "' Successfully", "Sales order "  + SONum + " is displayed Successfully");
     }  
     
     /****************************************
      * Name: verifyRevRec
       * Description:Method to read the sales order
      * Date: 10-May-2018
      ****************************************/
     public void verifyRevRec(DataRow input, DataRow output) {           
            String tableRows = uiDriver.getObjMap("tableRows");
            uiDriver.executeJavaScript("scroll(0,500)");
            String actualRevrecMethod = uiDriver.getValue(tableRows + nextRow+ uiDriver.getObjMap("RevrecMethod"));
            String actualRevRecStartDate = uiDriver.getValue(tableRows + nextRow + uiDriver.getObjMap("RevRecStartDate"));
            String actualRevRecEndDate = uiDriver.getValue(tableRows + nextRow+ uiDriver.getObjMap("RevRecEndDate"));
            String actualHold = uiDriver.getValue(tableRows + nextRow+ uiDriver.getObjMap("Hold"));         
            //String actuallICENSEFEE = uiDriver.getValue("licensefee");
            // String actualGLPN=uiDriver.getValue("GLPN");
            String RevrecMethod = input.get("RevrecMethod");
            if (input.get("RevrecMethod").contains(actualRevrecMethod)) {
                   passed("Verifying the  RevrecMethod",
                                "RevrecMethod should be displayed as '" + RevrecMethod+ "' Successfully", "RevrecMethod "    + actualRevrecMethod + " is displayed Successfully");
            } else {
                  failed("Verifying the  RevrecMethod",    "RevrecMethod should be displayed as '" + RevrecMethod+ "' Successfully",
                                "RevrecMethod "+ actualRevrecMethod      + " is not displayed Successfully");
            }
            SleepUtils.sleep(5);
            String RevRecStartDate = input.get("RevRecStartDate");
            if (input.get("RevRecStartDate").contains(actualRevRecStartDate)||actualRevRecStartDate.contains(RevRecStartDate)) {
                   passed("Verifying the  RevRecStartDate",
                                "RevRecStartDate should be displayed as '" + RevRecStartDate+ "' Successfully", "RevrecMethod "    + actualRevRecStartDate + " is displayed Successfully");
            } else {
                   failed("Verifying the  RevRecStartDate", "RevRecStartDate should be displayed as '" + RevRecStartDate+ "' Successfully",
                                "RevRecStartDate "+ actualRevRecStartDate       + " is not displayed Successfully");
            }
           
            String RevRecEndDate = input.get("RevRecEndDate");
            if (input.get("RevRecEndDate").contains(actualRevRecEndDate)||actualRevRecEndDate.contains(RevRecEndDate)) {
                   passed("Verifying the  RevRecEndDate",
                                "RevRecEndDate should be displayed as '" + RevRecEndDate+ "' Successfully", "RevrecMethod "    + actualRevRecEndDate + " is displayed Successfully");
            } else {

                   failed("Verifying the  RevRecEndDate",   "RevRecEndDate should be displayed as '" + RevRecStartDate+ "' Successfully",
                                "RevRecEndDate "+ actualRevRecStartDate  + " is not displayed Successfully");
            }
           
            if (actualHold.equalsIgnoreCase(" ")||actualHold.equalsIgnoreCase("Yes")) {
                   passed("Verifying the  Hold",
                                "Hold should be displayed as '" + actualHold+ "' Successfully", "Hold "       + actualHold + " is displayed Successfully");
            } else {
                   failed("Verifying the  Hold",     "Hold should be displayed as '" + actualHold+ "' Successfully",
                                "Hold "+ actualHold  + " is not displayed Successfully");
            }
           
            nextRow++;
            }
	     
	 /****************************************
		 * Name: updatePlanforrevrec 
		 * Description:Method to update revenue plan for rev rec
		 * Date: 10-May-2018
		 ****************************************/
	public void updatePlanforrevrec(DataRow input, DataRow output) throws ParseException {
		uiDriver.click("editbtn");
		SleepUtils.sleep(TimeSlab.MEDIUM);
if(uiDriver.checkElementPresent("allocationcheckbx"))
{
	uiDriver.click("allocationcheckbx");
}
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("saveBtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.handleAlert("", "OK");
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.click("UpdateRevPlanBtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("refreshBtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		// uiDriver.click("submissionIDHeader");
		// uiDriver.click("completeBtn");
		// refressh
		Date date = new Date();
		DateFormat dateFormat = new SimpleDateFormat("h:mm");
		String strDate = dateFormat.format(date);
		Date d = dateFormat.parse(strDate);
		Calendar cal = Calendar.getInstance();
		cal.setTime(d);
		cal.add(Calendar.MINUTE, 1);
		String newTime = dateFormat.format(cal.getTime());
		String Complete = uiDriver.getDyanmicData("CompleteStatus1");
		String CompleteStaus = Complete.replace("#", newTime);
		cal.add(Calendar.MINUTE, 1);
		String newTime2 = dateFormat.format(cal.getTime());
		String Complete2 = uiDriver.getDyanmicData("CompleteStatus2");
		String CompleteStaus2 = Complete2.replace("#", newTime2);
		cal.add(Calendar.MINUTE, 1);
		String newTime3 = dateFormat.format(cal.getTime());
		String Complete3 = uiDriver.getDyanmicData("CompleteStatus3");
		String CompleteStaus3 = Complete3.replace("#", newTime3);
		if (uiDriver.checkElementPresent_dynamic(CompleteStaus)) {
			uiDriver.click_dynamic(CompleteStaus);
		} else {
			// do nothing
		}

		if (uiDriver.checkElementPresent_dynamic(CompleteStaus2)) {
			uiDriver.click_dynamic(CompleteStaus2);
		} else {
			// do nothing
		}
		if (uiDriver.checkElementPresent_dynamic(CompleteStaus3)) {

			uiDriver.click_dynamic(CompleteStaus3);
		} else {
			// do nothing
		}
		uiDriver.executeJavaScript("scroll(0,500)");
		passed("Verify Processed Reclassification Journal entries",
				"Processed Reclassification Journal entries page should be displayed",
				"Processed ification Journal entries page is displayed");
		int RevPlanRows = 6;
		// int
		// RevPlanRows=uiDriver.webDr.findElements(By.xpath("//*[@id='body_actions']")).size();
		for (int r = 0; r < RevPlanRows - 1; r++) {
			String s1 = uiDriver.getDyanmicData("RevenuePlanNumber1");
			String s2 = s1.replace("#", Integer.toString(r));
			SleepUtils.sleep(10);
			if (uiDriver.checkElementPresent_dynamic(s2)) {
				uiDriver.click_dynamic(s2);
				uiDriver.executeJavaScript("scroll(0,300)");
				passed("Click On the Revenue Paln Number " + s2 + "",
						"Should be SuccessFully Clicked on Revenue Paln Number "+ s2 + "",
						"SuccessFully Clicked on Revenue Paln Number " + s2	+ "");
				String Recognized=uiDriver.getValue("Recognized");
				passed("Verified Recognized " + Recognized + "",
						"Should verify Recognized"+ Recognized + "",
						"SuccessFully verify Amount " + Recognized	+ "");
				String Amount=uiDriver.getValue("Amount");
				passed("Verified Amount " + Amount + "",
						"Should verify Amount "+ Amount + "",
						"SuccessFully verify Amount" + Amount	+ "");
				String Status=uiDriver.getValue("Status");
				passed("Verified Amount " + Status + "",
						"Should verify Amount "+ Status + "",
						"SuccessFully verify Amount" + Status	+ "");
				
				passed("Verify the Revenue Paln Number",
						"Revenue Recognition Plan Page Should be displayed",
						"Revenue Recognition Plan Page is displayed");

				uiDriver.back();
							} else {
				// Do Nothing
			}

		}

		SleepUtils.sleep(10);
		uiDriver.back();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.back();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.refresh();
		SleepUtils.sleep(TimeSlab.YIELD);
		String Revenuenumber = uiDriver.getValue("Revenuenumber");
		output.put("Revenuenumber", Revenuenumber);

	}

	/****************************************
	 * Name: viewPlansforrevrec 
	 * Description:Method to update revenue plan for rev rec
	 * Date: 10-May-2018
	 ****************************************/
	public void viewPlansforrevrec(DataRow input, DataRow output) throws ParseException {
		
				
		int planRows = uiDriver.webDr.findElements(By.xpath("(//*[@class='uir-machine-table'])[1]/tbody/tr[contains(@class,'uir-machine-row uir-machine-row')]")).size();
        for(int i=2;i<=planRows+1;i++)
        {
	
             String viewicon = uiDriver.getDyanmicData("viewicon");
             String viewicon1 = viewicon.replace("#", Integer.toString(i));
		/*if(uiDriver.checkElementPresent_dynamicexecuteJavaScript(viewicon)) {
			uiDriver.click_dynamic(viewicon);
		} else {
			// do nothing
		}*/
             
             uiDriver.executeJavaScript("window.scrollBy(0,500)");
             WebElement ele = uiDriver.webDr.findElement(By.xpath(viewicon1));
             String ele1 = "(//*[@class='uir-machine-table'])[1]/tbody/tr[2]/td[17]";
             WebElement ele2 = uiDriver.webDr.findElement(By.xpath(ele1));

             Actions action=new Actions(uiDriver.webDr);
             action.moveToElement(ele2).build().perform();
            
             //uiDriver.executeJavaScript("arguments[0].scrollIntoView();", uiDriver.webDr.findElement(By.xpath(viewicon1))");
             
		 SleepUtils.sleep(TimeSlab.YIELD);
             uiDriver.click_dynamic(viewicon1);
             SleepUtils.sleep(TimeSlab.YIELD);
             uiDriver.setFrame("iconframe");
             SleepUtils.sleep(TimeSlab.YIELD);
         if(uiDriver.checkElementPresent("NoRecords"))
         {
            	 String Norecords=uiDriver.getValue("NoRecords");
            	 if(input.get("Norecords").contains(Norecords))
            	 {
            		 passed("Verifying No Records is displayed",
          					"No Revenue Records should be  displayed", "No Revenue Records is  displayed");
            	 }
            	 else
            	 {
            		 failed("Verifying No Records is displayed",
           					"No Revenue Records should be  displayed", "No Revenue Records is not displayed");
             	 }
            	 
             }
         else
         {
        	 if (i == 2) {
                 

             String Status=uiDriver.getValue("Status");
             String Amount=uiDriver.getValue("Amount").replace(",", "");
                          
             if(input.get("Status").contains(Status))
             {
            	 passed("Verifying the  Status",
     					"Status should be displayed as '" + input.get("Status")+ "' Successfully", "Status "	+ Status + " is displayed Successfully");
     		} else {
     			failed("Verifying the  Status",
     					"Status should be displayed as '" + input.get("Status")+ "' Successfully", "Status "	+ Status + " is not displayed Successfully");
     		} 
             SleepUtils.sleep(TimeSlab.YIELD);
             if(input.get("Amount").contains(Amount))
             {
            	 passed("Verifying the  Amount",
     					"Amount should be displayed as '" + input.get("Amount")+ "' Successfully", "Amount "	+ Amount + " is displayed Successfully");
     		} else {
     			failed("Verifying the  Amount",
     					"Amount should be displayed as '" + input.get("Amount")+ "' Successfully", "Amount "	+ Amount + " is not displayed Successfully");
     		} 
             }
        	 if (i == 3) {
                 

                 String Status=uiDriver.getValue("Status");
                 String Amount=uiDriver.getValue("Amount").replace(",", "");
                              
                 if(input.get("Status1").contains(Status))
                 {
                	 passed("Verifying the  Status",
         					"Status should be displayed as '" + input.get("Status1")+ "' Successfully", "Status "	+ Status + " is displayed Successfully");
         		} else {
         			failed("Verifying the  Status",
         					"Status should be displayed as '" + input.get("Status1")+ "' Successfully", "Status "	+ Status + " is not displayed Successfully");
         		} 
                 SleepUtils.sleep(TimeSlab.YIELD);
                 if(input.get("Amount1").contains(Amount))
                 {
                	 passed("Verifying the  Amount",
         					"Status should be displayed as '" + input.get("Amount1")+ "' Successfully", "Amount"	+ Amount + " is displayed Successfully");
         		} else {
         			failed("Verifying the  Amount",
         					"Status should be displayed as '" + input.get("Amount1")+ "' Successfully", "Amount "	+ Amount + " is not displayed Successfully");
         		} 
                 }
           if (i == 4) {
                 

                 String Status=uiDriver.getValue("Status");
                 String Amount=uiDriver.getValue("Amount").replace(",", "");                              
                 if(input.get("Status2").contains(Status))
                 {
                	 passed("Verifying the  Status",
         					"Status should be displayed as '" + input.get("Status2")+ "' Successfully", "Status "	+ Status + " is displayed Successfully");
         		} else {
         			failed("Verifying the  Status",
         					"Status should be displayed as '" + input.get("Status2")+ "' Successfully", "Status "	+ Status + " is not displayed Successfully");
         		} 
                 SleepUtils.sleep(TimeSlab.YIELD);
                 if(input.get("Amount2").contains(Amount))
                 {
                	 passed("Verifying the  Amount",
         					"Status should be displayed as '" + input.get("Amount2")+ "' Successfully", "Amount "	+ Amount + " is displayed Successfully");
         		} else {
         			failed("Verifying the  Amount",
         					"Status should be displayed as '" + input.get("Amount2")+ "' Successfully", "Amount "	+ Amount + " is not displayed Successfully");
         		} 
                 }
if (i == 5) {
    

    String Status=uiDriver.getValue("Status");
    String Amount=uiDriver.getValue("Amount").replace(",", "");   
                 
    if(input.get("Status3").contains(Status))
    {
   	 passed("Verifying the  Status",
				"Status should be displayed as '" + input.get("Status3")+ "' Successfully", "Status "	+ Status + " is displayed Successfully");
	} else {
		failed("Verifying the  Status",
				"Status should be displayed as '" + input.get("Status3")+ "' Successfully", "Status "	+ Status + " is not displayed Successfully");
	} 
    SleepUtils.sleep(TimeSlab.YIELD);
    if(input.get("Amount3").contains(Amount))
    {
   	 passed("Verifying the  Amount",
				"Status should be displayed as '" + input.get("Amount3")+ "' Successfully", "Amount "	+ Amount + " is displayed Successfully");
	} else {
		failed("Verifying the  Amount",
				"Status should be displayed as '" + input.get("Amount3")+ "' Successfully", "Amount "	+ Amount + " is not displayed Successfully");
	} 
    }

    	
             
        }
         SleepUtils.sleep(TimeSlab.YIELD);
         uiDriver.click("cancelbtn");
         uiDriver.resetFrame();
        }
	}
		//revenueRow++;
	
	/****************************************
    * Name: ADD MC Data
     * Description:Method to read the sales order
    * Date: 21-May-2018
    ****************************************/
    public void addMCData(DataRow input, DataRow output) {
    	
    	uiDriver.click("Custom");
    	uiDriver.executeJavaScript("scroll(0,1500)");
    	uiDriver.click("addmcdata");
    	uiDriver.setValue("addmcdata", input.get("addmcdata"));
	}

    /****************************************
     * Name: Validate MarketCode
      * Description:Method to read alert popup
     * Date: 21-May-2018
     ****************************************/
     public void ValidatepopupMarketCode(DataRow input, DataRow output) {
    	/* uiDriver.click("edit");
    	 uiDriver.click("selectmarket");
    	 uiDriver.setValue("editmarket", "FANC");
    	 uiDriver.click("OK");*/
     	
    	 if(uiDriver.isAlertPresent()){
			 String alerttext=uiDriver.getAlertText();   
			 System.out.println(alerttext);
			 uiDriver.handleAlert("", "OK");
			 //uiDriver.handleAlert("Payment amounts allocated to the lines do not match the total payment amount. Please allocate the remaining balance to the lines., button","OK");
			 if(alerttext.contains("cannot use market code"))
			 {
				 passed("Validation alert verified ", "popup displayed should be displayed for invalid popup",
	                     "popup displayed should be displayed for invalid popup"); 
			 }
			 uiDriver.click("selectmarket");
	    	uiDriver.setValue("editmarket", input.get("validMarketCode"));
	    	 uiDriver.click("OK");
	    	 
    	 }
			 else {}
    	 //uiDriver.click("Save");
}
     
     
     
     /****************************************
      * Name: EnableInterCompanyFlag
      * Description:Method to read alert popup
      * Date: 21-May-2018
      ****************************************/
      public void EnableInterCompanyFlag(DataRow input, DataRow output) {   
     
    	uiDriver.click("InterCompanyFlag");  
          
      } 
     
      
      /****************************************
      * Name: updateMarketCode 
      * Description: updateMarketCode
      * Date: 30-Nov-2017
      ****************************************/
      public void updateMarketCode(DataRow input, DataRow output) throws InterruptedException {

             uiDriver.executeJavaScript("scroll(0,-1000)");
                 uiDriver.click("edit");
                 SleepUtils.sleep(TimeSlab.MEDIUM);
                 uiDriver.executeJavaScript("scroll(1000,2000)");           
      uiDriver.click("marketCodeSet");
      SleepUtils.sleep(TimeSlab.MEDIUM);
      uiDriver.setValue("marketCode",input.get("marketCode"));
      SleepUtils.sleep(TimeSlab.MEDIUM); 
                     uiDriver.click("Save");
                     passed("Save the Sales order",
                             "sales order saved Successfully  ",
                             "sales order saved Successfully");
          

      }
      
      
    
      
      
      /****************************************
       * Name: FMVBatchScripts 
       * Description: FMVBatchScripts
       * Date: 30-Nov-2017
       ****************************************/
      public void FMVBatchScripts(DataRow input, DataRow output) throws InterruptedException 

  	{     
    	       SleepUtils.sleep(TimeSlab.MEDIUM);
  		uiDriver.mouseOver("Customization");
  		SleepUtils.sleep(TimeSlab.YIELD);
  		uiDriver.mouseOver("Scripting");
  		SleepUtils.sleep(TimeSlab.YIELD);
  		uiDriver.mouseOver("Scripts");
  		SleepUtils.sleep(TimeSlab.YIELD);
  		uiDriver.click("Scripts");
		if(uiDriver.checkElementPresent("EditCalcEngine"))
		{
			uiDriver.click("EditCalcEngine");
		}
		else
		{
  		SleepUtils.sleep(TimeSlab.YIELD);
  		SleepUtils.sleep(TimeSlab.LOW);
  		uiDriver.click("dropdownbtn");
  		SleepUtils.sleep(TimeSlab.HIGH);
  		uiDriver.click("NBCUFMV");
  		SleepUtils.sleep(TimeSlab.HIGH);
  		uiDriver.click("EditCalcEngine");
  		SleepUtils.sleep(TimeSlab.LOW);
		}
  		uiDriver.click("Deployments");
  		SleepUtils.sleep(TimeSlab.LOW);
  		uiDriver.click("NBCUFMVCALCENGINE");
  		SleepUtils.sleep(TimeSlab.LOW);
  		uiDriver.click("EditScript");
  		SleepUtils.sleep(TimeSlab.LOW);
  		if(uiDriver.checkElementPresent("SaveAndExecute"))
  		{	
  			uiDriver.click("SaveAndExecute");
  			uiDriver.handleAlert("", "OK");
  		}
  		else{
  			for(int i=0;i<=50;i++){
  				SleepUtils.sleep(30);
  				uiDriver.refresh();		
  				uiDriver.mouseOver("dropdown");
  				System.out.println("***********************"+i);
  				if(uiDriver.checkElementPresent("SaveAndExecute"))
  				{	
  					uiDriver.click("SaveAndExecute");
  					uiDriver.handleAlert("", "OK");
  					break;
  				}
  					
  				
  			}	
  			}
  		uiDriver.refresh();	
  		SleepUtils.sleep(30);
  		uiDriver.refresh();	
  		for(int i=0;i<=50;i++){
  			SleepUtils.sleep(30);
  			uiDriver.refresh();			
  			System.out.println("***********************"+i);
  			System.out.println(uiDriver.getValue("Status"));
  			if(uiDriver.getValue("Status").equalsIgnoreCase("Complete"))
  			break;
  			
  		}	
    		
  		
  	}
      
      
      /****************************************
       * Name: FMVBatchScriptFMVCreation 
       * Description: FMVBatchScripts
       * Date: 30-Nov-2017
       ****************************************/
      public void FMVBatchScriptFMVCreation(DataRow input, DataRow output) throws InterruptedException 

    	{     
    	  	SleepUtils.sleep(TimeSlab.MEDIUM);
    		uiDriver.mouseOver("Customization");
    		SleepUtils.sleep(TimeSlab.YIELD);
    		uiDriver.mouseOver("Scripting");
    		SleepUtils.sleep(TimeSlab.YIELD);
    		uiDriver.mouseOver("Scripts");
    		SleepUtils.sleep(TimeSlab.YIELD);
    		uiDriver.click("Scripts");
    		SleepUtils.sleep(TimeSlab.YIELD);
		if(uiDriver.checkElementPresent("EditFMVCreation"))
		{
			uiDriver.click("EditFMVCreation");
		}
		else
		{
    		SleepUtils.sleep(TimeSlab.LOW);
    		uiDriver.click("dropdownbtn");
    		SleepUtils.sleep(TimeSlab.HIGH);
    		uiDriver.click("NBCUFMV");
    		SleepUtils.sleep(TimeSlab.HIGH);
    		uiDriver.click("EditFMVCreation");
    		SleepUtils.sleep(TimeSlab.LOW);
		}
    		uiDriver.click("Deployments");
    		SleepUtils.sleep(TimeSlab.LOW);
    		uiDriver.click("NBCUFMVCALCENGINE");
    		SleepUtils.sleep(TimeSlab.LOW);
    		uiDriver.click("EditScript");
    		SleepUtils.sleep(TimeSlab.LOW);
    		if(uiDriver.checkElementPresent("SaveAndExecute"))
    		{	
    			uiDriver.click("SaveAndExecute");
    			uiDriver.handleAlert("", "OK");
    		}
    		else{
    			for(int i=0;i<=50;i++){
    				SleepUtils.sleep(30);
    				uiDriver.refresh();		
    				uiDriver.mouseOver("dropdown");
    				System.out.println("***********************"+i);
    				if(uiDriver.checkElementPresent("SaveAndExecute"))
    				{	
    					uiDriver.click("SaveAndExecute");
    					uiDriver.handleAlert("", "OK");
    					break;
    				}
    					
    				
    			}	
    			}
    		uiDriver.refresh();	
    		SleepUtils.sleep(30);
    		uiDriver.refresh();	
    		for(int i=0;i<=50;i++){
    			SleepUtils.sleep(30);
    			uiDriver.refresh();			
    			System.out.println("***********************"+i);
    			System.out.println(uiDriver.getValue("Status"));
    			if(uiDriver.getValue("Status").equalsIgnoreCase("Complete"))
    			break;
    			
    		}	
      		
    		
    	}
        
        
 
      
      /****************************************
       * Name: FMVBatchScriptFMVCreation 
       * Description: FMVBatchScripts
       * Date: 30-Nov-2017
       ****************************************/
      public void FMVBatchScriptReclassQuery(DataRow input, DataRow output) throws InterruptedException 

    	{     
    	  	SleepUtils.sleep(TimeSlab.MEDIUM);
    		uiDriver.mouseOver("Customization");
    		SleepUtils.sleep(TimeSlab.YIELD);
    		uiDriver.mouseOver("Scripting");
    		SleepUtils.sleep(TimeSlab.YIELD);
    		uiDriver.mouseOver("Scripts");
    		SleepUtils.sleep(TimeSlab.YIELD);
    		uiDriver.click("Scripts");
    		SleepUtils.sleep(TimeSlab.YIELD);
		if(uiDriver.checkElementPresent("EditFMVReclassQuery"))
		{
			uiDriver.click("EditFMVReclassQuery");
		}
		else
		{
    		SleepUtils.sleep(TimeSlab.LOW);
    		uiDriver.click("dropdownbtn");
    		SleepUtils.sleep(TimeSlab.HIGH);
    		uiDriver.click("NBCUFMV");
    		SleepUtils.sleep(TimeSlab.HIGH);
    		uiDriver.click("EditFMVReclassQuery");
    		SleepUtils.sleep(TimeSlab.LOW);
		}
    		uiDriver.click("Deployments");
    		SleepUtils.sleep(TimeSlab.LOW);
    		uiDriver.click("NBCUFMVCALCENGINE");
    		SleepUtils.sleep(TimeSlab.LOW);
    		uiDriver.click("EditScript");
    		SleepUtils.sleep(TimeSlab.LOW);
    		if(uiDriver.checkElementPresent("SaveAndExecute"))
    		{	
    			uiDriver.click("SaveAndExecute");
    			uiDriver.handleAlert("", "OK");
    		}
    		else{
    			for(int i=0;i<=50;i++){
    				SleepUtils.sleep(30);
    				uiDriver.refresh();		
    				uiDriver.mouseOver("dropdown");
    				System.out.println("***********************"+i);
    				if(uiDriver.checkElementPresent("SaveAndExecute"))
    				{	
    					uiDriver.click("SaveAndExecute");
    					uiDriver.handleAlert("", "OK");
    					break;
    				}
    					
    				
    			}	
    			}
    		uiDriver.refresh();	
    		SleepUtils.sleep(30);
    		uiDriver.refresh();	
    		for(int i=0;i<=50;i++){
    			SleepUtils.sleep(30);
    			uiDriver.refresh();			
    			System.out.println("***********************"+i);
    			System.out.println(uiDriver.getValue("Status"));
    			if(uiDriver.getValue("Status").equalsIgnoreCase("Complete"))
    				passed("Verify CompleteStatus",
    						"CompleteStatus should be displayed successfully",
    						"CompleteStatus is not displayed successfully");

    			break;
    			
    		}	
      		
    		
    	}
        
      
     
	/**
	 * Overriding toString() method of object class to print SJMDriver format
	 * string
	 */
	public String toString() {
		return "NBCUDriver()";
	}

	public static int i = 2, j = 2;
	int nextRow =2, firstRow = 2, ItemCol =2 ,revenueRow=2;
	String orderId, FMVDimention, SONum;
	List<WebElement> fmvValue = new ArrayList<WebElement>();
	List<String> fmvVal = new ArrayList<String>();

}
