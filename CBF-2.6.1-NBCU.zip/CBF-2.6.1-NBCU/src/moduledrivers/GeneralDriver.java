package moduledrivers;

import static cbf.engine.TestResultLogger.failed;
import static cbf.engine.TestResultLogger.log;
import static cbf.engine.TestResultLogger.passed;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;

import cbf.engine.TestResult.ResultType;
import cbf.utils.DataRow;
import cbf.utils.SleepUtils;
import cbf.utils.SleepUtils.TimeSlab;
import cbfx.basedrivers.BaseWebModuleDriver;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class GeneralDriver extends BaseWebModuleDriver {

	/**
	 * Launches Application
	 * 
	 * @param input
	 *            DataRow of input parameters
	 * @param output
	 *            empty DataRow passed to capture any runtime output during
	 *            execution of component
	 */

	public void launchApp(DataRow input, DataRow output) {
		uiDriver.launchApplication(input.get("url"));
		if (uiDriver.checkPage(input.get("pageName"))) {
			passed("Launching the Application", "Should open the Application", "Application opened sucessfully!");
		} 

	}

	public void ReadingDatfromRunOrderSheet(DataRow input, DataRow output) throws InvalidFormatException, IOException{
		
		String ReadPath="D:/Automation/RunOrderSheet_Copy.xls"; 
		FileInputStream fs=new FileInputStream(ReadPath);
		Workbook wb=WorkbookFactory.create(fs);
		Sheet sh=wb.getSheet("FO_and_GD_Conditional_Avail");
		int  rowcount=wb.getSheet("FO_and_GD_Conditional_Avail").getLastRowNum();
		
		System.out.println(rowcount);
		
		for(int i=0;i<=rowcount;i++)
		{
			Row r=sh.getRow(i);
			String ssname=r.getCell(0).getStringCellValue();
			System.out.println(ssname+"-----");
			
			String namesecanrio= input.get("ScenarioName");
			if(namesecanrio.equals(ssname))
			{
				
			String writePath="D:/Automation/RunOrderSheet_Copy.xls"; 
			FileInputStream gs=new FileInputStream(writePath);
			Workbook wb1=WorkbookFactory.create(gs);
			
			Sheet sh1=wb1.getSheet("FO_and_GD_Conditional_Avail");
			Row row=sh1.getRow(i);
			Cell c=row.getCell(1);
			c.setCellValue("y");
			FileOutputStream foos=new FileOutputStream(writePath);
			wb1.write(foos);
			
		}
			else
			{
				String writePath="D:/Automation/RunOrderSheet_Copy.xls"; 
				FileInputStream gs=new FileInputStream(writePath);
				Workbook wb1=WorkbookFactory.create(gs);
				
				Sheet sh1=wb1.getSheet("FO_and_GD_Conditional_Avail");
				Row row=sh1.getRow(i);
				Cell c=row.getCell(1);
				c.setCellValue("n");
				FileOutputStream foos=new FileOutputStream(writePath);
				wb1.write(foos);
			}
		
	}
	
	}

	/**
	 * Login to Application
	 * 
	 * @param input
	 *            DataRow of input parameters
	 * @param output
	 * 
	 *            empty DataRow passed to capture any runtime output during
	 *            execution of component
	 */
	public void ReadingDatfromTestSet(DataRow input, DataRow output) throws InvalidFormatException, IOException{
		String ReadPath="D:/CAFE2.0/CBF-2.6.1-NBCU/Test/Sample_Nbcu/Lab/TestSet.xls"; 
		FileInputStream fs=new FileInputStream(ReadPath);
		Workbook wb=WorkbookFactory.create(fs);
		Sheet sh=wb.getSheet("ExcelTestSet");
		int  rowcount=wb.getSheet("ExcelTestSet").getLastRowNum();
		System.out.println(rowcount);
		for(int i=1;i<=rowcount;i++)
		{
		Row r=sh.getRow(i);
		String ssname=r.getCell(1).getStringCellValue();
		System.out.println(ssname+"-----");
		//String namesecanrio= input.get("ScenarioName");
		String namesecanrio = input.get("ScenarioName");
		if(namesecanrio.equals(ssname))
		{
		String writePath="D:/CAFE2.0/CBF-2.6.1-NBCU/Test/Sample_Nbcu/Lab/TestSet.xls"; 
		FileInputStream gs=new FileInputStream(writePath);
		Workbook wb1=WorkbookFactory.create(gs);
		Sheet sh1=wb1.getSheet("ExcelTestSet");
		Row row=sh1.getRow(i);
		//Cell c=row.getCell(1);
		Cell d=row.getCell(3);
		d.setCellValue("Yes");
		FileOutputStream foos=new FileOutputStream(writePath);
		wb1.write(foos);
		}
		else{
		String writePath="D:/CAFE2.0/CBF-2.6.1-NBCU/Test/Sample_Nbcu/Lab/TestSet.xls"; 
		FileInputStream gs=new FileInputStream(writePath);
		Workbook wb1=WorkbookFactory.create(gs);
		Sheet sh1=wb1.getSheet("ExcelTestSet");
		Row row=sh1.getRow(i);
		//Cell c=row.getCell(1);
		Cell d=row.getCell(3);
		d.setCellValue("No");
		FileOutputStream foos=new FileOutputStream(writePath);
		wb1.write(foos);
		}
		}

		}

		
		
	public void clickOnAvail(DataRow input, DataRow output)
	{
		
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.click("avail");
		SleepUtils.sleep(TimeSlab.YIELD);
		if(uiDriver.checkElementPresent("//h3[text()='Please sign in']")) {			
			passed("clickOnAvail", "Sign In Page should display", "Sign In Page is displayed successfully");
		} else {
			failed("clickOnAvail", "Sign In Page should display", "Sign In Page is not displayed successfully");
		}
	}
	
	public void login(DataRow input, DataRow output) {
		uiDriver.setValue("username", input.get("username"));
		uiDriver.setValue("password", input.get("password"));
		uiDriver.click("loginBtn");
		if(uiDriver.checkElementPresent("answer"))
		{
		uiDriver.setValue("answer", input.get("answer"));
		uiDriver.click("submitAnswer");
				}
		if (uiDriver.checkPage(input.get("pageName"))) {
			passed("Login to Application", "Should login the Application", "Application opened sucessfully!");
		} 
	}

	
	public void loginFilmtrack(DataRow input, DataRow output) {
		
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.switchToWindow("Avails Login");
		uiDriver.setValue("username", input.get("username"));
		uiDriver.setValue("password", input.get("password"));
		uiDriver.click("loginBtn");
		passed("Login to FilmTrack Application",
				"Should loginto the Application",
				"FilmTrack Application opened sucessfully!");
		
		
	}
	
	public void launchUFT(DataRow input, DataRow output) {
	
			try{
	
			System.out.println("start test");
			Runtime.getRuntime().exec(new String[] {
			        "wscript.exe", "D:\\MYSAFE.vbs"
			        }); 
			}
			catch (Exception err) {
			err.printStackTrace();
			}
	
	}

	/**
	 * Overriding toString() method of object class to print FlightBookingDriver
	 * format string
	 */
	public String toString() {
		return "GeneralDriver()";
	}

}
