package moduledrivers;

import static cbf.engine.TestResultLogger.failed;
import static cbf.engine.TestResultLogger.log;
import static cbf.engine.TestResultLogger.passed;

import java.io.IOException;
import java.sql.SQLException;

import cbf.engine.TestResult.ResultType;
import cbf.utils.DataRow;
import cbf.utils.SleepUtils;
import cbf.utils.SleepUtils.TimeSlab;
import cbfx.basedrivers.BaseWebModuleDriver;

public class SalesforceDriver extends BaseWebModuleDriver {

	/**
	 * Launches Application
	 * 
	 * @param input
	 *            DataRow of input parameters
	 * @param output
	 *            empty DataRow passed to capture any runtime output during
	 *            execution of component
	 */

	public void launchApp(DataRow input, DataRow output) {
		uiDriver.launchApplication(input.get("url"));
		if (uiDriver.checkPage(input.get("pageName"))) {
			passed("Launching the Application", "Should open the Application", "Application opened sucessfully!");
		} else {
			failed("Launching the Application", "Should open the Application", "Error in opening the Application");
		}

	}

	/**
	 * Login to Application
	 * 
	 * @param input
	 *            DataRow of input parameters
	 * @param output
	 *            empty DataRow passed to capture any runtime output during
	 *            execution of component
	 */
	public void login(DataRow input, DataRow output) {
		uiDriver.setValue("username", input.get("username"));
		uiDriver.setValue("password", input.get("password"));
		uiDriver.click("loginBtn");
		SleepUtils.sleep(TimeSlab.YIELD);
		uiDriver.setValue("answer", input.get("answer"));
		uiDriver.click("submitAnswer");
		if (uiDriver.checkPage(input.get("pageName"))) {
			passed("Login to Application", "Should login the Application", "Application opened sucessfully!");
		} else {
			log("Login the Application", ResultType.FAILED, "Should open the Application",
					"Error in opening the Application", true);
		}
	}

	/**
	 * Overriding toString() method of object class to print FlightBookingDriver
	 * format string
	 */
	public String toString() {
		return "SalesforceDriver()";
	}

}
